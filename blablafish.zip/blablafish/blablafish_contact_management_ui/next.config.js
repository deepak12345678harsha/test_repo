/** @type {import('next').NextConfig} */
const nextConfig = {
    reactStrictMode: true,
    basePath: '/contact-management',
    eslint: {
        dirs: ['.'], //Run eslint on base directory
    },
};

module.exports = nextConfig;
