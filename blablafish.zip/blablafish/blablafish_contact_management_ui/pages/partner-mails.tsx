import { NextPage } from 'next';
import PartnerMailsTriggerOverview from '@components/views/partner-mails-trigger-overview';

const PartnerMailsTriggerPage: NextPage = () => {
    return <PartnerMailsTriggerOverview />;
};

export default PartnerMailsTriggerPage;
