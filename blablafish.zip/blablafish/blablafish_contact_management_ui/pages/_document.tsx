import Document, { Html, Main, Head as NextHead, NextScript } from 'next/document';

class CustomDocument extends Document {
    render() {
        return (
            <Html>
                <NextHead />
                {this.props.isDevelopment && <link rel="stylesheet" href="https://pattern-library.portal.otto.market/versions/latest/obc-components.css" />}
                <body>
                    <Main />
                    <NextScript />
                </body>
            </Html>
        );
    }
}

export default CustomDocument;
