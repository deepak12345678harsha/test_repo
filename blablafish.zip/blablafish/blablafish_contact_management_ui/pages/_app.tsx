import { AppProps } from 'next/app';
import { useRouter } from 'next/router';
import { makeServer } from '@mock/server';

export type SSIIncludeProps = {
    includeSSI?: boolean;
};

if (process.env.NODE_ENV === 'development') {
    makeServer({ environment: 'development' });
}
// makeServer();

const filterPageProps = (pageProps: SSIIncludeProps) => {
    const props = { ...pageProps };
    delete props['includeSSI'];
    return props;
};

const CustomApp = ({ Component, pageProps }: AppProps<SSIIncludeProps>) => {
    const router = useRouter();
    const { includeSSI } = pageProps;

    //Workaround to fix basePath being added to URL in settings view
    router.events?.on('routeChangeComplete', (url: string) => {
        if (url.indexOf('settings?') != -1) {
            history.replaceState(history.state, url, url.substring(router.basePath.length));
        }
    });

    return (
        <div>
            {includeSSI ? (
                <>
                    <div dangerouslySetInnerHTML={{ __html: `<!--# include virtual="/frame" -->` }} />
                    <div className="portal_container">
                        <div className="portal_nav" dangerouslySetInnerHTML={{ __html: `<!--# include virtual="/navigation" -->` }} />
                        <main className="portal_main">
                            <div slot="mainContent">
                                <Component {...filterPageProps(pageProps)} />
                            </div>
                            <div dangerouslySetInnerHTML={{ __html: `<!--# include virtual="/frame/footer" -->` }} />
                        </main>
                    </div>
                </>
            ) : (
                <Component {...filterPageProps(pageProps)} />
            )}
        </div>
    );
};

export default CustomApp;
