import { NextApiHandler } from 'next';

const Status: NextApiHandler = (req, res) => {
    res.status(200).json({ status: 'ok' });
};

export default Status;
