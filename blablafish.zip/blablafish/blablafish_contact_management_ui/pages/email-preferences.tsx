import { NextPage } from 'next';
import UserMailPreferenceOverview from '@components/views/email-preferences-overview';

const EmailPreferencesPage: NextPage = () => {
    return <UserMailPreferenceOverview />;
};

export default EmailPreferencesPage;
