import { NextPage } from 'next';
import Newsletter from '@components/views/newsletter-overview';

const NewsletterPage: NextPage = () => {
    return <Newsletter />;
};

export default NewsletterPage;
