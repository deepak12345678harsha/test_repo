import { GetServerSideProps, NextPage } from 'next';
import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';
import Header from '@components/elements/header';
import { BlacklistedEmailsOverview } from '@components/views/blacklisted-emails-overview';
import { DEFAULT_PAGINATION_LIMIT, DEFAULT_SELECTED_PAGE, PAGE_QUERY_PARAM, PAGINATION_LIMIT_QUERY_PARAM, SEARCH_PARAM } from '../utils/pagination-constants';

export type RouteState = {
    pageNo: number;
    size: number;
    search?: string;
};

export type BlacklistedMailsPage = {
    includeSSI: boolean;
};

const BlacklistedMailsPage: NextPage<BlacklistedMailsPage> = () => {
    const router = useRouter();

    const [isReady, setIsReady] = useState<boolean>(false);

    useEffect(() => {
        setIsReady(router.isReady);
    }, [router.isReady]);

    const routeState: RouteState = {
        pageNo: router.query.pageNo ? Number(router.query.pageNo) : DEFAULT_SELECTED_PAGE,
        size: router.query.size ? Number(router.query.size) : DEFAULT_PAGINATION_LIMIT,
        search: router.query.search ? String(router.query.search) : undefined,
    };

    const updateRouteQueryParams = (queryParams: NodeJS.Dict<string | string[]>) => {
        router.push(
            {
                pathname: '/blacklisted-mails',
                query: queryParams,
            },
            undefined,
            { shallow: true },
        );
    };

    const updatePageSelected = (newPage: any) => {
        const queryParams = { ...router.query };
        queryParams[PAGE_QUERY_PARAM] = newPage;
        updateRouteQueryParams(queryParams);
    };

    const updatePaginationLimit = (newLimit: any) => {
        const queryParams = { ...router.query };
        queryParams[PAGINATION_LIMIT_QUERY_PARAM] = newLimit;
        queryParams[PAGE_QUERY_PARAM] = String(DEFAULT_SELECTED_PAGE);
        updateRouteQueryParams(queryParams);
    };

    const updateSearchTerm = (searchTerm: any) => {
        const queryParams = { ...router.query };
        queryParams[SEARCH_PARAM] = searchTerm;
        queryParams[PAGE_QUERY_PARAM] = String(DEFAULT_SELECTED_PAGE);
        queryParams[PAGINATION_LIMIT_QUERY_PARAM] = router.query[PAGINATION_LIMIT_QUERY_PARAM] || String(DEFAULT_PAGINATION_LIMIT);
        updateRouteQueryParams(queryParams);
    };

    return isReady ? (
        <>
            <Header text={'E-Mail Sperrliste'} />
            <div className="obc_content-container">
                <BlacklistedEmailsOverview {...routeState} setPageSelected={updatePageSelected} setLimitSelected={updatePaginationLimit} searchFor={updateSearchTerm} />
            </div>
        </>
    ) : (
        <div />
    );
};

export const getServerSideProps: GetServerSideProps<BlacklistedMailsPage> = async () => {
    return { props: { includeSSI: true } };
};

export default BlacklistedMailsPage;
