import type { NextPage } from 'next';
import TopicsOverview from '@components/views/topics-overview';

const TopicsOverviewPage: NextPage = () => {
    return <TopicsOverview />;
};

export default TopicsOverviewPage;
