export SERVICE_NAME=contact_management_ui
export REGISTRY_NAME=contact-management-ui
export REVISION=$(git rev-parse HEAD)
export INFRA_ACCOUNT_ID=348078512286
export AWS_DEFAULT_REGION=eu-central-1
export TFSEC_VERSION="1.27.6"