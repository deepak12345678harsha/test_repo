import { callApi, Page } from '.';

export type BlacklistedUserEmail = {
    userFullName: string;
    emailAddress: string;
};

export type BlacklistedUserEmailResponse = {
    userFirstName: string;
    userLastName: string;
    emailAddress: string;
};

export async function getBlacklistedUsers(search: string, pageNo: number, size: number): Promise<Page<BlacklistedUserEmailResponse>> {
    const uri = `/contact-management/v1/blacklisted-mails?search=${search}&page=${--pageNo}&size=${size}`;
    return await callApi(uri, {
        method: 'GET',
    });
}

export async function deleteBlacklistedUsers(selectedItems: Set<string>): Promise<Page<BlacklistedUserEmailResponse>> {
    const uri = `/contact-management/v1/blacklisted-mails`;
    return await callApi(uri, {
        method: 'PUT',
        body: JSON.stringify(Array.from(selectedItems)),
        headers: {
            'Content-Type': 'application/json',
        },
    });
}
