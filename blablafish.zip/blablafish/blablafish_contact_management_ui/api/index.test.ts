import fetchMock from 'jest-fetch-mock';
import { ContactManagementAPI } from '@api/index';

describe('API Test', () => {
    beforeEach(() => {
        fetchMock.resetMocks();
    });

    it('test callApi for invalid response', async () => {
        mockFetchTopics();
        try {
            await ContactManagementAPI.getTopics();
        } catch (ex: any) {
            expect(ex).not.toBeNull();
            expect(ex.message).toBe('403');
        }
    });

    it('test callApi for exceptions', async () => {
        mockFetchTopicsException();
        try {
            await ContactManagementAPI.getTopics();
        } catch (ex: any) {
            expect(ex).not.toBeNull();
            expect(ex.message).toBe('test');
        }
    });

    it('test callApi for empty body', async () => {
        mockFetchTopicsEmptyBody();

        const response = await ContactManagementAPI.getTopics();
        expect(response).toBeNull();
    });

    const mockFetchTopics = () => {
        fetchMock.mockResponseOnce('', {
            status: 403,
        });
    };

    const mockFetchTopicsException = () => {
        fetchMock.mockReject(new Error('test'));
    };

    const mockFetchTopicsEmptyBody = () => {
        fetchMock.mockResponseOnce('', {
            status: 204,
        });
    };
});
