import { callApi, OverviewDTO } from '@api/index';

export type UserEmailPreference = {
    topicId: number;
    name: string;
    description: string;
    canUnsubscribe: boolean;
    optIn: boolean;
};

export namespace UserEmailPreferenceApi {
    export async function fetchUserEmailPreferences(): Promise<OverviewDTO<UserEmailPreference>> {
        return callApi(`/contact-management/v1/subscribers/notification-preferences`, {
            method: 'GET',
        });
    }

    export async function updateUserEmailPreferences(preferences: UserEmailPreference[]): Promise<OverviewDTO<UserEmailPreference>> {
        const requestBody = preferences.map(preference => {
            return {
                topicId: preference.topicId,
                optIn: preference.optIn,
            };
        });
        return callApi(`/contact-management/v1/subscribers/notification-preferences`, {
            method: 'POST',
            body: JSON.stringify(requestBody),
            headers: {
                'Content-Type': 'application/json',
            },
        });
    }
}
