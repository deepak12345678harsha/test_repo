import { TdHTMLAttributes, ThHTMLAttributes } from 'react';

export type TableColumn<T> = {
    name?: string;
    cellKey: keyof T | '';
    primaryColumn?: boolean;
    getHeaderCellAttributes?: () => ThHTMLAttributes<HTMLTableHeaderCellElement>;

    getCellAttributes?: (rowData: T) => TdHTMLAttributes<HTMLTableDataCellElement>;
    renderData?: (cellData: any, rowData: T) => React.ReactElement;
    renderHeader?: () => React.ReactElement;
};

export type TableData = Record<string, unknown>;

export type TableProps<T extends TableData> = {
    className?: string;
    columns: Array<TableColumn<T>>;
    data: Array<T>;
    renderChildren?: (row: T) => React.ReactElement;
};
