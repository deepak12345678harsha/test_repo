import { toJson } from '@api/index';

export namespace PartnerMailsAPI {
    export function sendMultiplePartnerEmailRequest(formData: FormData): Promise<void> {
        return callApi('/contact-management/v1/multi-partner-mails', {
            method: 'POST',
            body: formData,
        });
    }

    export async function callApi(path: RequestInfo, init?: RequestInit) {
        let res: Response;
        try {
            res = await fetch(path, init);
        } catch (ex) {
            console.log(ex);
            throw ex;
        }
        if (!res.ok) {
            throw new Error(await res.text());
        }
        return toJson(res);
    }
}
