export type OverviewDTO<T> = {
    items: T[];
    count: number;
};

export type TopicDTO = {
    id: string;
    name: string;
    description: string;
    subscribers: SubscriberDTO[];
};

export type SubscriberDTO = {
    id: string;
    firstName: string;
    lastName: string;
    email: string;
};

export type AddUserRequest = {
    userIds: string[];
};

export type Page<T> = {
    //Total page size
    totalPages: number;
    //Total elements
    totalElements: number;
    //Current page number
    number: number;
    //size of pages
    size: number;
    //Element size of page
    numberOfElements: number;
    content: T[];
    first: boolean;
    last: boolean;
    empty: boolean;
};

export namespace ContactManagementAPI {
    export function getTopics(): Promise<OverviewDTO<TopicDTO>> {
        return callApi('/contact-management/v1/topics', {
            method: 'GET',
        });
    }

    export function addUsersToTopic(topicId: string, userIds: string[]): Promise<void> {
        return callApi(`/contact-management/v1/topics/${topicId}/subscribers`, {
            method: 'PUT',
            body: JSON.stringify({
                userIds: userIds,
            } as AddUserRequest),
            headers: {
                'Content-Type': 'application/json',
            },
        });
    }

    export function unsubscribeUserFromTopic(topicId: string, subscriberId: string): Promise<void> {
        return callApi(`/contact-management/v1/topics/${topicId}/subscribers/${subscriberId}`, {
            method: 'DELETE',
        });
    }

    export async function getUsers(search?: string): Promise<OverviewDTO<SubscriberDTO>> {
        let uri = `/contact-management/v1/subscribers`;
        if (search) {
            uri = `${uri}?search=${encodeURIComponent(search)}`;
        }
        return await callApi(uri, {
            method: 'GET',
        });
    }
}

export async function callApi(path: RequestInfo, init?: RequestInit) {
    let res: Response;
    try {
        res = await fetch(path, init);
    } catch (ex) {
        console.log(ex);
        throw ex;
    }
    if (!res.ok) {
        throw new Error('' + res.status);
    }
    return toJson(res);
}

export async function toJson(response: Response) {
    const body = await response.text();
    return body?.length ? JSON.parse(body) : null;
}
