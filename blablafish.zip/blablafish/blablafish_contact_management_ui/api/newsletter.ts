import { callApi } from '@api/index';

export type NotificationTypeDTO = {
    notificationType: string;
    text: string;
    subtext: string;
};

export type SubscriptionStatusDTO = {
    isSubscribed: boolean;
    text: string;
    time: string;
};

export namespace NewsletterAPI {
    export function getNewsletterSubscriptionStatus(): Promise<SubscriptionStatusDTO> {
        return callApi('/contact-management/v1/subscribers/newsletter-subscription-status', {
            method: 'GET',
        });
    }

    export function modifyNewsletterSubscriptionStatus(isSubscribed: boolean, text: string): Promise<SubscriptionStatusDTO> {
        return callApi(`/contact-management/v1/subscribers/newsletter-subscription-status`, {
            method: 'PUT',
            body: JSON.stringify({
                isSubscribed,
                text,
            } as SubscriptionStatusDTO),
            headers: {
                'Content-Type': 'application/json',
            },
        });
    }
}
