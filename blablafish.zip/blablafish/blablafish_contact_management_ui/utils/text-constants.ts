export const DESC =
    'Liste an E-Mail-Adressen von Nutzer*innen, die von Benachrichtigungen über Retouren, Produkten und Aufträgen ausgeschlossen sind. Füge Nutzer*innen zur Liste hinzu, um sie für Benachrichtigungen zu sperren und lösche Nutzer*innen, um sie wieder freizuschalten.';
export const SEARCH_PLACEHOLDER = 'Suche nach E-Mail-Adresse';

export const MODAL_DELETE_BLACKLISTED_EMAIL_TITLE = 'E-Mail-Adresse von Sperrliste löschen';
export const MODAL_DELETE_BLACKLISTED_EMAIL_DESC =
    'Willst du wirklich folgende E-Mail-Adresse von der Sperrliste löschen und ihre(n) Nutzer*in damit für E-Mail Benachrichtigungen über Retouren, Produkte und Aufträge freischalten?:';

export const EMAILS_DELETED_SUCCESSFULLY_MSG = 'Die E-Mail-Adresse wurde erfolgreich gelöscht';

export const API_FAILED_TEXT = 'Hoppla, da ist etwas schief gelaufen.';
export const API_FAILED_SUBTEXT = 'Bitte probiere es gleich nochmal.';
export const API_SUCCESS_TEXT = 'Die Änderungen wurden erfolgreich gespeichert.';

export const CANCEL = 'Abbrechen';
export const DELETE = 'Löschen';
export const SAVE = 'Speichern';

export const EDITABLE_MAIL_PREFERENCE_TITLE = 'Benachrichtigungseinstellungen';
export const EDITABLE_MAIL_PREFERENCE_SUBTITLE = 'Verwalten Sie hier, für welches Thema Sie E-Mail-Benachrichtigung erhalten wollen.';

export const UNEDITABLE_MAIL_TOPICS_TITLE = 'Verpflichtende Benachrichtungen';
export const UNEDITABLE_MAIL_TOPICS_SUBTITLE = 'Diese E-Mail-Benachrichtigungen können Sie nicht abbestellen.';

export const NO_MAIL_PREFERENCE_AVAILABLE_MESSAGE = 'Keine E-Mail-Benachrichtigungen zum Verwalten.';
export const MAIL_PREFERENCE_ALWAYS_ACTIVE_TEXT = 'Immer aktiv';
