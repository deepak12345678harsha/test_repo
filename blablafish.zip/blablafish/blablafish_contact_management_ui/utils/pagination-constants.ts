export const DEFAULT_SELECTED_PAGE = 1;
export const DEFAULT_PAGINATION_LIMIT = 10;

export const PAGE_QUERY_PARAM = 'pageNo';
export const PAGINATION_LIMIT_QUERY_PARAM = 'size';
export const SEARCH_PARAM = 'search';
