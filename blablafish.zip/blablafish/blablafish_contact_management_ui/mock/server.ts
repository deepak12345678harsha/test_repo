import { createServer, Model, Response } from 'miragejs';
import { ModelDefinition, Registry } from 'miragejs/-types';
import Schema from 'miragejs/orm/schema';
import { BlacklistedUserEmailResponse } from '@api/blacklisted-emails';
import { SubscriptionStatusDTO } from '@api/newsletter';
import { AddUserRequest, OverviewDTO, Page, SubscriberDTO, TopicDTO } from '../api';

const TopicsModel: ModelDefinition<TopicDTO> = Model.extend({});
const UsersModel: ModelDefinition<SubscriberDTO> = Model.extend({});
const EmailPreferenceModel: ModelDefinition<any> = Model.extend({});

type ApiRegistry = Registry<
    {
        topic: typeof TopicsModel;
        user: typeof UsersModel;
        userMailPreference: typeof EmailPreferenceModel;
    },
    {
        /* factories can be defined here */
    }
>;
type ApiSchema = Schema<ApiRegistry>;

type MirageServerOpts = {
    environment: 'development' | 'test';
};

export const makeServer = (options: MirageServerOpts) => {
    return createServer({
        environment: options.environment,
        models: {
            topic: TopicsModel,
            user: UsersModel,
            userMailPreference: EmailPreferenceModel,
        },

        seeds: function (server) {
            const schema: ApiSchema = server.schema;

            for (let i = 0; i < 75; i++) {
                schema.create('user', {
                    id: `${i + 1}`,
                    firstName: `User`,
                    lastName: `${i + 1}`,
                    email: `user_${i + 1}@otto.de`,
                });
            }
            schema.create('topic', {
                id: '1',
                name: 'Verträge',
                description: 'Hinterlegen Sie hier Kontaktpersonen, welche bei vertraglichen Anliegen (z.B. bei Vertragsaktualisierung) ' + 'kontaktiert werden sollen.',
                subscribers: [
                    {
                        id: '1',
                        email: 'user_1@payment-shop.de',
                        firstName: 'User',
                        lastName: '1',
                    },
                    {
                        id: '2',
                        email: 'user_2@payment-shop.de',
                        firstName: 'User',
                        lastName: '2',
                    },
                ],
            });
            schema.create('topic', {
                id: '2',
                name: 'Verstöße',
                description:
                    'Hinterlegen Sie hier Kontaktpersonen, welche bei Verstößen (z.B. bei einem Verstoß gegen Richtlinien) ' + 'kontaktiert werden können und handlungsfähig sind.',
                subscribers: [
                    {
                        id: '5',
                        email: 'user_5@payment-shop.de',
                        firstName: 'User',
                        lastName: '5',
                    },
                ],
            });

            schema.create('userMailPreference', {
                userId: 'abc123',
                topicId: 1,
                name: 'Benachrichtigung bei Buchung von Services',
                description: 'Sie erhalten eine Bestätigung per E-Mail, wenn Sie einen Service gebucht haben.',
                canUnsubscribe: true,
                optIn: false,
            } as any);
            schema.create('userMailPreference', {
                userId: 'abc123',
                topicId: 2,
                name: 'Status-Updates für Ihre Service-Buchungen',
                description: 'Sie werden von uns benachrichtigt, wenn es zu ihren Servicebuchungen neue Statusmeldungen gibt.',
                canUnsubscribe: false,
                optIn: false,
            } as any);
            schema.create('userMailPreference', {
                userId: 'abc123',
                topicId: 3,
                name: 'Benachrichtigung beim automatisierten Deaktivieren von Nutzern',
                description:
                    'Sie erhalten eine Benachrichtigung, wenn ein Nutzer Ihres Unternehmens automatisiert deaktiviert wurde, weil z.B. seine E-Mail-Adresse nicht mehr erreicht werden konnte.',
                canUnsubscribe: true,
                optIn: true,
            } as any);
            schema.create('userMailPreference', {
                userId: 'abc123',
                topicId: 4,
                name: 'Benachrichtigung bei Contentveränderungen Ihrer Produktvarianten',
                description: 'Sie erhalten eine Benachrichtigung, wenn es eine Contentveränderung bei einer Ihrer Produktvarianten gibt, um diese zu prüfen.',
                canUnsubscribe: false,
                optIn: false,
            } as any);
        },

        routes() {
            this.namespace = 'contact-management/v1';
            this.get('/topics', (schema: ApiSchema) => {
                return {
                    items: schema.all('topic').models,
                    count: schema.all('topic').length,
                } as OverviewDTO<TopicDTO>;
            });

            this.get('/subscribers', (schema: ApiSchema, request) => {
                const search: string = request.queryParams['search'];
                const allUsers = schema.all('user').models;
                let allObject = allUsers;
                if (search) {
                    allObject = allObject.filter(a => {
                        if (search) {
                            return a.email.includes(search);
                        }
                        return true;
                    });
                }
                return {
                    items: allObject,
                    count: allUsers.length,
                } as OverviewDTO<SubscriberDTO>;
            });

            this.put('/topics/:topicId/subscribers', (schema: ApiSchema, request) => {
                const topicId = request.params.topicId;
                const addUserRequest: AddUserRequest = JSON.parse(request.requestBody);
                const users: SubscriberDTO[] = addUserRequest.userIds.map(userId => {
                    const findBy = schema.findBy('user', {
                        id: userId,
                    });
                    if (findBy) {
                        return {
                            id: findBy.id,
                            firstName: findBy.firstName,
                            lastName: findBy.lastName,
                            email: findBy.email,
                        };
                    }
                    return {
                        id: '1',
                        firstName: 'firstName',
                        lastName: 'lastName',
                        email: 'email',
                    };
                });
                const topic = schema.findBy('topic', {
                    id: topicId,
                });
                if (topic) {
                    const newUsers = [...topic.subscribers, ...users];
                    topic?.update({
                        subscribers: newUsers,
                    });
                }
                return new Response(200);
            });

            this.delete('/topics/:topicId/subscribers/:subscriberId', (schema: ApiSchema, request) => {
                const topicId = request.params.topicId;
                const subscriberId = request.params.subscriberId;
                const topic = schema.findBy('topic', {
                    id: topicId,
                });
                const newUsers = topic?.subscribers.filter(user => {
                    return user.id !== subscriberId;
                });
                topic?.update({
                    subscribers: newUsers,
                });
                return new Response(200);
            });

            this.get('/subscribers/newsletter-subscription-status', () => {
                return {
                    isSubscribed: false,
                    text: 'someText',
                    time: '2022-09-15T09:04:45.456Z',
                } as SubscriptionStatusDTO;
            });

            this.put('/subscribers/newsletter-subscription-status', (schema: ApiSchema, request) => {
                const requestBody: SubscriptionStatusDTO = JSON.parse(request.requestBody);
                return {
                    isSubscribed: requestBody.isSubscribed,
                    text: requestBody.text,
                    time: new Date().toISOString(),
                } as SubscriptionStatusDTO;
            });

            this.get('/subscribers/notification-preferences', (schema: ApiSchema) => {
                const userId = 'abc123';
                const dataParsed = schema.where('userMailPreference', { userId: userId } as any).models.map(model => {
                    delete model.attrs['userId'];
                    return model;
                });
                return {
                    items: dataParsed,
                    count: 4,
                };
            });

            this.post('/subscribers/notification-preferences', (schema: ApiSchema, request) => {
                const userId = 'abc123';
                const requestBody = JSON.parse(request.requestBody);
                requestBody.forEach((updatedPreference: { topicId: any; optIn: any }) => {
                    schema.findBy('userMailPreference', { userId: userId, topicId: updatedPreference.topicId } as any)?.update({ optIn: updatedPreference.optIn });
                });
                return new Response(200);
            });

            this.post('/multi-partner-mails', (schema: ApiSchema, request) => {
                const requestBody = request;
                console.log(JSON.stringify(requestBody));
                return new Response(200);
            });

            this.get('/blacklisted-mails', (schema: ApiSchema, request) => {
                const { search, page, size } = request.queryParams;
                const sizeParam = Number(size);
                const pageNumberParam = Number(page);

                const dataParsed = schema.all('user').models.map(model => {
                    return {
                        userFirstName: model.attrs['firstName'],
                        userLastName: model.attrs['lastName'],
                        emailAddress: model.attrs['email'],
                    } as BlacklistedUserEmailResponse;
                });

                let blacklistedEmails;
                let totalEmailIds;
                if (search) {
                    blacklistedEmails = dataParsed.filter(data => data.emailAddress == search);
                    totalEmailIds = dataParsed.length;
                } else {
                    const startIndex = pageNumberParam * sizeParam;
                    const endIndex = startIndex + sizeParam;
                    // @ts-ignore
                    blacklistedEmails = dataParsed.slice(startIndex, endIndex);
                    // @ts-ignore
                    totalEmailIds = dataParsed.length;
                }
                const totalPageCount = Math.ceil(totalEmailIds / sizeParam);
                return {
                    totalElements: totalEmailIds,
                    totalPages: totalPageCount,
                    number: pageNumberParam,
                    size: sizeParam,
                    first: pageNumberParam === 1,
                    last: pageNumberParam === totalPageCount,
                    content: blacklistedEmails,
                    empty: blacklistedEmails.length == 0,
                    numberOfElements: blacklistedEmails.length,
                } as Page<BlacklistedUserEmailResponse>;
            });

            this.put('/blacklisted-mails', (schema: ApiSchema, request) => {
                const body = JSON.parse(request.requestBody);
                body.forEach((emailAddress: any) => {
                    schema
                        .findBy('user', {
                            email: emailAddress,
                        })
                        ?.destroy();
                });
                return new Response(200);
            });

            this.namespace = ''; // or this.namespace = "/"
            this.passthrough();
        },
    });
};
