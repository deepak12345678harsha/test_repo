module.exports = {
    testEnvironment: 'jsdom',
    testPathIgnorePatterns: ['<rootDir>/.next/', '<rootDir>/node_modules/'],
    setupFilesAfterEnv: ['<rootDir>/setupTests.js'],
    moduleNameMapper: {
        '\\.(css|less|scss|sass)$': 'identity-obj-proxy',
        '^@components/(.*)$': '<rootDir>/components/$1',
        '^@mock/(.*)$': '<rootDir>/mock/$1',
        '^@api/(.*)$': '<rootDir>/api/$1',
    },
    transform: {
        '^.+\\.(js|jsx|ts|tsx)$': '<rootDir>/node_modules/babel-jest',
    },
    collectCoverageFrom: ['**/*.{ts,tsx}'],
    coveragePathIgnorePatterns: [
        'node_modules',
        '<rootDir>/pages/_app.tsx',
        '<rootDir>/pages/_document.tsx',
        '<rootDir>/mock/server.ts',
        '<rootDir>/next-env.d.ts',
        '<rootDir>/pages/api/health.ts',
    ],
};
