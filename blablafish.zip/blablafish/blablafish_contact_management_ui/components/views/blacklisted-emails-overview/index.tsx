import React, { PropsWithChildren, useEffect, useState } from 'react';

import { BlacklistedUserEmail, BlacklistedUserEmailResponse, deleteBlacklistedUsers, getBlacklistedUsers } from '@api/blacklisted-emails';
import { Page } from '@api/index';
import { TableColumn } from '@api/table';
import CheckboxTable from '@components/elements/checkbox-table';
import Modal, { ModalProps } from '@components/elements/modal';
import Notification, { NotificationProps, NotificationType } from '@components/elements/newsletter-elements/Notification';
import Pagination from '@components/elements/pagination';
import SearchField from '@components/elements/search-field';
import { RouteState } from '../../../pages/blacklisted-mails';
import {
    API_FAILED_SUBTEXT,
    API_FAILED_TEXT,
    CANCEL,
    DELETE,
    DESC,
    EMAILS_DELETED_SUCCESSFULLY_MSG,
    MODAL_DELETE_BLACKLISTED_EMAIL_DESC,
    MODAL_DELETE_BLACKLISTED_EMAIL_TITLE,
    SEARCH_PLACEHOLDER,
} from '../../../utils/text-constants';

type BlacklistedEmailsOverviewProps = RouteState & {
    setPageSelected: (page: number) => void;
    setLimitSelected: (limit: number) => void;
    searchFor: (search: string) => void;
};

export const BlacklistedEmailsOverview = (props: BlacklistedEmailsOverviewProps) => {
    const [selectedItems, setSelectedItems] = useState<Set<string>>(new Set());

    const [blacklistedEmailsResponse, setBlacklistedEmailsResponse] = useState<Page<BlacklistedUserEmailResponse>>();

    const [modalData, setModalData] = useState<PropsWithChildren<ModalProps>>();

    const [notification, setNotification] = useState<NotificationProps>();

    const fetchBlacklistedEmails = () => {
        const searchTerm = props.search ? `${encodeURIComponent(props.search.trim())}` : '';
        getBlacklistedUsers(searchTerm, props.pageNo, props.size)
            .then((response: Page<BlacklistedUserEmailResponse>) => {
                if (response) {
                    response.number = response.number + 1;
                    setBlacklistedEmailsResponse(response);
                }
            })
            .catch(() => {
                setNotification({
                    notificationType: NotificationType.FAILURE.toString(),
                    text: API_FAILED_TEXT,
                    subtext: API_FAILED_SUBTEXT,
                    btnCloseAction: () => setNotification(undefined),
                });
            });
    };

    const deleteSelectedEmailIds = () => {
        deleteBlacklistedUsers(selectedItems)
            .then(() => {
                setModalData(undefined);
                setSelectedItems(new Set());
                setNotification({
                    notificationType: NotificationType.SUCCESS,
                    text: EMAILS_DELETED_SUCCESSFULLY_MSG,
                    btnCloseAction: () => setNotification(undefined),
                });
            })
            .then(() => {
                fetchBlacklistedEmails();
            })
            .catch(() => {
                setModalData(undefined);
                setNotification({
                    notificationType: NotificationType.FAILURE,
                    text: API_FAILED_TEXT,
                    subtext: API_FAILED_SUBTEXT,
                    btnCloseAction: () => setNotification(undefined),
                });
            });
    };

    useEffect(() => {
        fetchBlacklistedEmails();
    }, [props.pageNo, props.size, props.search]);

    const closeModalFn = () => {
        setModalData(undefined);
    };

    function showDeleteDialog() {
        if (selectedItems.size !== 0) {
            setModalData({
                title: MODAL_DELETE_BLACKLISTED_EMAIL_TITLE,
                saveText: DELETE,
                closeText: CANCEL,
                saveFn: () => deleteSelectedEmailIds(),
                closeFn: () => closeModalFn(),
            });
        }
    }

    function getColumns(): TableColumn<BlacklistedUserEmail>[] {
        return [
            { cellKey: 'emailAddress', name: 'E-Mail-Adresse', primaryColumn: true },
            { cellKey: 'userFullName', name: 'Nutzer' },
        ];
    }

    function getBlacklistedEmails(): Array<BlacklistedUserEmail> {
        return blacklistedEmailsResponse
            ? blacklistedEmailsResponse.content.map(blacklistedEmail => {
                  return {
                      emailAddress: blacklistedEmail.emailAddress ? blacklistedEmail.emailAddress : '',
                      userFullName: blacklistedEmail.userFirstName && blacklistedEmail.userLastName ? blacklistedEmail.userFirstName + ' ' + blacklistedEmail.userLastName : '',
                  };
              })
            : [];
    }

    return (
        <>
            {modalData && (
                <Modal title={modalData.title} saveText={modalData.saveText} saveFn={modalData.saveFn} closeText={modalData.closeText} closeFn={modalData.closeFn}>
                    <>
                        <p>{MODAL_DELETE_BLACKLISTED_EMAIL_DESC}</p>
                        <p data-testid="emails-to-delete">
                            <b>{Array.from(selectedItems).join(', ')}</b>
                        </p>
                    </>
                </Modal>
            )}
            <p className="description">{DESC}</p>
            {notification && <Notification {...notification} />}
            <div className="obc_mt-4">
                <SearchField defaultValue={props.search} search={searchTerm => props.searchFor(searchTerm)} placeholder={SEARCH_PLACEHOLDER} />
            </div>
            <div className="obc_mt-4">
                <button data-testid="delete-button" type="button" className="obc_btn" onClick={showDeleteDialog} disabled={selectedItems.size === 0}>
                    {DELETE}
                </button>
            </div>
            {blacklistedEmailsResponse && (
                <div className="obc_mt-4" data-testid="email-count">
                    <span className="obc_copy-bold">
                        Nutzer*innen ({blacklistedEmailsResponse.content.length}/{blacklistedEmailsResponse.totalElements})
                    </span>
                    <CheckboxTable keyField="emailAddress" selectedItems={selectedItems} setSelectedItems={setSelectedItems} columns={getColumns()} data={getBlacklistedEmails()} />
                    <div className="pagination">
                        <Pagination page={blacklistedEmailsResponse} updatePageSize={props.setLimitSelected} updatePage={props.setPageSelected} />
                    </div>
                </div>
            )}
        </>
    );
};
