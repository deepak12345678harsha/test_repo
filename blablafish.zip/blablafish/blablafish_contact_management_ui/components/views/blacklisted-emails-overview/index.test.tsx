import { act, fireEvent, render, screen, within } from '@testing-library/react';
import fetchMock from 'jest-fetch-mock';
import { BlacklistedEmailsOverview } from '@components/views/blacklisted-emails-overview/index';

describe('Render blacklisted mails overview', () => {
    beforeEach(() => {
        fetchMock.resetMocks();
    });

    afterEach(() => {
        jest.resetModules();
    });

    it('Blacklisted mails view when API fetched and delete all users', async () => {
        mockGetAPIForBlacklistedMails();
        mockPutAPIForDeletingBlacklistedMails();
        mockGetAPIForBlacklistedMails();

        await act(() => {
            render(<BlacklistedEmailsOverview pageNo={1} searchFor={jest.fn()} setLimitSelected={jest.fn()} setPageSelected={jest.fn()} size={75} search={''} />);
        });

        const title = screen.getByText(
            'Liste an E-Mail-Adressen von Nutzer*innen, die von Benachrichtigungen über Retouren, Produkten und Aufträgen ausgeschlossen sind. Füge Nutzer*innen zur Liste hinzu, um sie für Benachrichtigungen zu sperren und lösche Nutzer*innen, um sie wieder freizuschalten.',
        );
        expect(title).toBeVisible();
        const searchBar = screen.getByRole('textbox', { name: '' });
        await act(() => {
            fireEvent.change(searchBar, { target: { value: 'emailAddress@email.com' } });
            fireEvent.click(screen.getByRole('button', { name: '' }));
        });

        const getAllCheckBoxes = screen.getAllByRole('checkbox', { name: '' });
        fireEvent.click(getAllCheckBoxes[1]);

        const deleteButton = screen.getByRole('button', { name: 'Löschen' });
        act(() => {
            fireEvent.click(deleteButton);
        });

        const view = screen.getByTestId('modal');
        expect(view).toBeVisible();

        const confirmDeleteButton = within(view).getByRole('button', {
            name: 'Löschen',
        });
        await act(() => {
            fireEvent.click(confirmDeleteButton);
        });
        const notification = screen.getByTestId('newsletter_notification_div');
        expect(notification.getAttribute('class')).toBe('obc_alert nptn_notification obc_alert--success');
        const closeNotification = screen.getByTestId('newsletter_notification_close');
        fireEvent.click(closeNotification);

        expect(fetchMock.mock.calls.length).toBe(3);
    });

    it('Blacklisted mails view when GET API not fetched', async () => {
        mockFailedGetAPIForBlacklistedMails();

        await act(() => {
            render(<BlacklistedEmailsOverview pageNo={1} searchFor={jest.fn()} setLimitSelected={jest.fn()} setPageSelected={jest.fn()} size={75} search={''} />);
        });

        const title = screen.getByText(
            'Liste an E-Mail-Adressen von Nutzer*innen, die von Benachrichtigungen über Retouren, Produkten und Aufträgen ausgeschlossen sind. Füge Nutzer*innen zur Liste hinzu, um sie für Benachrichtigungen zu sperren und lösche Nutzer*innen, um sie wieder freizuschalten.',
        );
        expect(title).toBeVisible();
        const notification = screen.getByTestId('newsletter_notification_div');
        expect(notification.getAttribute('class')).toBe('obc_alert nptn_notification obc_alert--error');

        const closeNotification = screen.getByTestId('newsletter_notification_close');
        fireEvent.click(closeNotification);
    });

    it('Blacklisted mails view when GET API fetched and not continuing with delete after selection', async () => {
        mockGetAPIForBlacklistedMails();

        await act(() => {
            render(<BlacklistedEmailsOverview pageNo={1} searchFor={jest.fn()} setLimitSelected={jest.fn()} setPageSelected={jest.fn()} size={75} search={''} />);
        });

        const title = screen.getByText(
            'Liste an E-Mail-Adressen von Nutzer*innen, die von Benachrichtigungen über Retouren, Produkten und Aufträgen ausgeschlossen sind. Füge Nutzer*innen zur Liste hinzu, um sie für Benachrichtigungen zu sperren und lösche Nutzer*innen, um sie wieder freizuschalten.',
        );
        expect(title).toBeVisible();
        const getAllCheckBoxes = screen.getAllByRole('checkbox', { name: '' });
        fireEvent.click(getAllCheckBoxes[1]);

        const deleteButton = screen.getByRole('button', { name: 'Löschen' });
        act(() => {
            fireEvent.click(deleteButton);
        });

        const view = screen.getByTestId('modal');
        expect(view).toBeVisible();

        const abortDeleteButton = within(view).getByRole('button', {
            name: 'Abbrechen',
        });
        await act(() => {
            fireEvent.click(abortDeleteButton);
        });
    });

    it('Blacklisted mails view when GET API fetched but PUT API failed', async () => {
        mockGetAPIForBlacklistedMails();
        mockFailedPutAPIForBlacklistedMails();

        await act(() => {
            render(<BlacklistedEmailsOverview pageNo={1} searchFor={jest.fn()} setLimitSelected={jest.fn()} setPageSelected={jest.fn()} size={75} search={''} />);
        });

        const getAllCheckBoxes = screen.getAllByRole('checkbox', { name: '' });
        fireEvent.click(getAllCheckBoxes[1]);

        act(() => {
            fireEvent.click(screen.getByRole('button', { name: 'Löschen' }));
        });

        const view = screen.getByTestId('modal');
        expect(view).toBeVisible();

        const confirmDeleteButton = within(view).getByRole('button', {
            name: 'Löschen',
        });
        await act(() => {
            fireEvent.click(confirmDeleteButton);
        });

        console.log(fetchMock.mock.calls);

        const notification = screen.getByTestId('newsletter_notification_div');
        expect(notification.getAttribute('class')).toBe('obc_alert nptn_notification obc_alert--error');

        const closeNotification = screen.getByTestId('newsletter_notification_close');
        fireEvent.click(closeNotification);
    });

    const mockGetAPIForBlacklistedMails = () => {
        fetchMock.mockResponseOnce(
            JSON.stringify({
                totalElements: 1,
                totalPages: 1,
                number: 0,
                size: 1,
                first: true,
                last: true,
                content: [
                    {
                        userFirstName: 'User First Name',
                        userLastName: 'User Last Name',
                        emailAddress: 'emailAddress@email.com',
                    },
                ],
                empty: false,
                numberOfElements: 1,
            }),
        );
    };

    const mockPutAPIForDeletingBlacklistedMails = () => {
        fetchMock.mockOnce('200');
    };

    const mockFailedGetAPIForBlacklistedMails = () => {
        fetchMock.mockOnce('Not found', { status: 404 });
    };

    const mockFailedPutAPIForBlacklistedMails = () => {
        fetchMock.mockResponseOnce('Not found', { status: 404 });
    };
});
