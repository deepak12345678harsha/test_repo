import { act, fireEvent, render, screen, waitForElementToBeRemoved } from '@testing-library/react';
import fetchMock from 'jest-fetch-mock';
import TopicComponent from './topic-component';

describe('Topic Component View', () => {
    beforeEach(() => {
        fetchMock.resetMocks();
    });

    it('render a topic', async () => {
        const topicMock = {
            id: '1',
            name: 'test',
            description: 'testDescription',
            subscribers: [
                {
                    id: '1',
                    firstName: 'testName',
                    lastName: '',
                    email: 'testEmail',
                },
            ],
        };
        render(<TopicComponent topic={topicMock} reloadTopics={jest.fn()} />);
        const tagElm = screen.getByText('testEmail');
        expect(tagElm).toBeVisible();
    });

    it('get modal window when user is deleted, when multiple users are present', async () => {
        mockDeleteUserFromATopic();

        const topicMock = {
            id: '1',
            name: 'test',
            description: 'testDescription',
            subscribers: [
                {
                    id: '1',
                    firstName: 'testName1',
                    lastName: '',
                    email: 'testEmail1',
                },
                {
                    id: '2',
                    firstName: 'testName2',
                    lastName: '',
                    email: 'testEmail2',
                },
            ],
        };

        render(<TopicComponent topic={topicMock} reloadTopics={jest.fn()} />);
        const tagElm = screen.getByText('testEmail1');
        expect(tagElm).toBeVisible();

        fireEvent.mouseEnter(tagElm);

        const button = screen.getByTestId('tag-close-button');
        fireEvent.click(button);
        const modalElement = screen.getByText('Soll der Kontakt wirklich entfernt werden?');
        expect(modalElement).toBeVisible();
        expect(screen.getByText('Kontakt entfernen')).toBeVisible();
        expect(screen.getByText('Abbrechen')).toBeVisible();

        const deleteModalElementButton = screen.getByText('Kontakt entfernen');
        fireEvent.click(deleteModalElementButton);
        await waitForElementToBeRemoved(screen.getByText('Soll der Kontakt wirklich entfernt werden?'));
        expect(fetchMock.mock.calls.length).toBe(1);
    });

    it('get modal window when trying to delete one user from multiple users ' + 'and close the modal window using close button', async () => {
        mockDeleteUserFromATopic();

        const topicMock = {
            id: '1',
            name: 'test',
            description: 'testDescription',
            subscribers: [
                {
                    id: '1',
                    firstName: 'testName1',
                    lastName: '',
                    email: 'testEmail1',
                },
                {
                    id: '2',
                    firstName: 'testName2',
                    lastName: '',
                    email: 'testEmail2',
                },
            ],
        };

        render(<TopicComponent topic={topicMock} reloadTopics={jest.fn()} />);
        const tagElm = screen.getByText('testEmail1');
        expect(tagElm).toBeVisible();

        fireEvent.mouseEnter(tagElm);

        const button = screen.getByTestId('tag-close-button');
        fireEvent.click(button);
        expect(screen.getByText('Soll der Kontakt wirklich entfernt werden?')).toBeVisible();

        const cancelDeleteModalElementButton = screen.getByText('Abbrechen');
        fireEvent.click(cancelDeleteModalElementButton);

        expect(screen.getByText('test')).toBeVisible();
    });

    it('get modal window when trying to delete the last user and close the modal window using close button', async () => {
        mockDeleteUserFromATopic();

        const topicMock = {
            id: '1',
            name: 'test',
            description: 'testDescription',
            subscribers: [
                {
                    id: '1',
                    firstName: 'testName',
                    lastName: '',
                    email: 'testEmail',
                },
            ],
        };

        render(<TopicComponent topic={topicMock} reloadTopics={jest.fn()} />);
        const tagElm = screen.getByText('testEmail');
        expect(tagElm).toBeVisible();

        fireEvent.mouseEnter(tagElm);

        const button = screen.getByTestId('tag-close-button');
        fireEvent.click(button);
        expect(screen.getByText('Der Kontakt kann nicht entfernt werden!')).toBeVisible();

        const cancelDeleteModalElementButton = screen.getByText('Schließen');
        fireEvent.click(cancelDeleteModalElementButton);

        expect(screen.getByText('test')).toBeVisible();
    });

    it('get modal window when trying to delete the last user and close the modal window using close icon', async () => {
        mockDeleteUserFromATopic();

        const topicMock = {
            id: '1',
            name: 'test',
            description: 'testDescription',
            subscribers: [
                {
                    id: '1',
                    firstName: 'testName',
                    lastName: '',
                    email: 'testEmail',
                },
            ],
        };

        render(<TopicComponent topic={topicMock} reloadTopics={jest.fn()} />);
        const tagElm = screen.getByText('testEmail');
        expect(tagElm).toBeVisible();

        fireEvent.mouseEnter(tagElm);

        const button = screen.getByTestId('tag-close-button');
        fireEvent.click(button);
        expect(screen.getByText('Der Kontakt kann nicht entfernt werden!')).toBeVisible();
        const cancelDeleteModalElementButton = screen.getByTestId('modal-header-close-button');
        fireEvent.click(cancelDeleteModalElementButton);

        expect(screen.getByText('test')).toBeVisible();
    });

    it('get modal window when trying to add a user and add a user', async () => {
        mockGetUsersForATopicToAdd();
        mockAddUsersForATopic();
        mockGetTopicsReload();

        const topicMock = {
            id: '1',
            name: 'test',
            description: 'testDescription',
            subscribers: [
                {
                    id: '1',
                    firstName: 'testName',
                    lastName: '',
                    email: 'testEmail',
                },
            ],
        };

        await act(async () => {
            render(<TopicComponent topic={topicMock} reloadTopics={jest.fn()} />);
        });

        await act(async () => {
            fireEvent.click(screen.getByText('Hinzufügen'));
        });

        expect(screen.getByText('Neuen Kontakt hinzufügen')).toBeVisible();
        expect(screen.getByText('Test User 1')).toBeVisible();

        const checkBoxes = screen.getAllByTestId('add-users-checkbox');
        checkBoxes.forEach(element => {
            fireEvent.click(element);
        });

        fireEvent.click(screen.getByTestId('add-to-button'));

        expect(screen.getByText('testEmail')).toBeVisible();
        expect(fetchMock.mock.calls.length).toBe(1);
    });

    it('get modal window when trying to add a user and close the modal window', async () => {
        mockGetUsersForATopicToAdd();

        const topicMock = {
            id: '1',
            name: 'test',
            description: 'testDescription',
            subscribers: [
                {
                    id: '1',
                    firstName: 'testName',
                    lastName: '',
                    email: 'testEmail',
                },
            ],
        };

        await act(async () => {
            render(<TopicComponent topic={topicMock} reloadTopics={jest.fn()} />);
        });

        await act(async () => {
            fireEvent.click(screen.getByText('Hinzufügen'));
        });

        expect(screen.getByText('Neuen Kontakt hinzufügen')).toBeVisible();
        expect(screen.getByText('Test User 1')).toBeVisible();

        fireEvent.click(screen.getByTestId('modal-header-close-button'));

        expect(screen.getByText('testEmail')).toBeVisible();
    });

    const mockDeleteUserFromATopic = () => {
        fetchMock.mockOnce('200');
    };

    const mockGetUsersForATopicToAdd = () => {
        fetchMock.mockResponseOnce(
            JSON.stringify({
                items: [
                    {
                        id: '1',
                        firstName: 'Test User',
                        lastName: '1',
                        email: 'testemail1@otto.de',
                    },
                    {
                        id: '2',
                        firstName: 'Test User',
                        lastName: '2',
                        email: 'testemail2@otto.de',
                    },
                    {
                        id: '3',
                        firstName: 'Test User',
                        lastName: '3',
                        email: 'testemail3@otto.de',
                    },
                ],
                count: 3,
            }),
        );
    };

    const mockAddUsersForATopic = () => {
        fetchMock.mockOnce('200');
    };

    const mockGetTopicsReload = () => {
        fetchMock.mockResponseOnce(
            JSON.stringify({
                id: '1',
                name: 'test',
                description: 'testDescription',
                subscribers: [
                    {
                        id: '1',
                        firstName: 'testName',
                        lastName: '',
                        email: 'testEmail',
                    },
                    {
                        id: '1',
                        firstName: 'Test User',
                        lastName: '1',
                        email: 'testemail1@otto.de',
                    },
                    {
                        id: '2',
                        firstName: 'Test User',
                        lastName: '2',
                        email: 'testemail2@otto.de',
                    },
                    {
                        id: '3',
                        firstName: 'Test User',
                        lastName: '3',
                        email: 'testemail3@otto.de',
                    },
                ],
            }),
        );
    };
});
