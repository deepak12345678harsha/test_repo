import React, { FC, Fragment, useEffect, useState } from 'react';
import { ContactManagementAPI, OverviewDTO, TopicDTO } from '@api/index';
import styles from './index.module.css';
import TopicComponent from './topic-component';

export type TopicsOverviewProps = Record<string, never>;

const TopicsOverview: FC<TopicsOverviewProps> = () => {
    const [topicsOverview, setTopicsOverview] = useState<OverviewDTO<TopicDTO>>();

    const initTopics = async () => {
        const topics = await ContactManagementAPI.getTopics();
        setTopicsOverview(topics);
    };

    useEffect(() => {
        initTopics();
    }, []);

    return (
        <div className={styles.blabla_topics_overview}>
            <div className="obc_grid">
                <div className="obc_grid__col-1-of-3">
                    <div className="obc_copy100">{'Geben Sie hier die passenden Ansprechpartner an, die bei verschiedenen Themen kontaktiert werden sollen.'}</div>
                </div>
            </div>
            <div className={'obc_divider'} />
            {topicsOverview &&
                topicsOverview.items.map(topic => {
                    return (
                        <Fragment key={topic.id}>
                            <TopicComponent topic={topic} reloadTopics={initTopics} />
                            <div className={'obc_divider'} />
                        </Fragment>
                    );
                })}
        </div>
    );
};

export default TopicsOverview;
