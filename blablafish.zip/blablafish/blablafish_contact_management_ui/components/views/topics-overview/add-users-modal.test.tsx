import { expect } from '@jest/globals';
import { act, fireEvent, render, screen } from '@testing-library/react';
import fetchMock from 'jest-fetch-mock';
import AddUsersModal from '@components/views/topics-overview/add-users-modal';

describe('Add Users Modal Test', () => {
    beforeEach(() => {
        fetchMock.resetMocks();
    });

    afterEach(() => {
        jest.resetModules();
    });

    it('test to select 10 users and then add the user', async () => {
        mockGetUsersForATopicToAdd();

        await act(async () => {
            render(<AddUsersModal closeModal={jest.fn()} topic={topicMock} subscribers={getSubscribersForTheTopic} />);
        });
        expect(screen.getByText('Test User 1')).toBeVisible();

        const checkBoxes = screen.getAllByTestId('add-users-checkbox');
        checkBoxes.forEach(element => {
            fireEvent.click(element);
        });

        const addUsers = screen.getByTestId('modal-save-button');
        fireEvent.click(addUsers);
    });

    it('test to select 10 users and then uncheck 10 users', async () => {
        mockGetUsersForATopicToAdd();

        await act(async () => {
            render(<AddUsersModal closeModal={jest.fn()} topic={topicMock} subscribers={getSubscribersForTheTopic} />);
        });
        expect(screen.getByText('Test User 1')).toBeVisible();

        const checkBoxes = screen.getAllByTestId('add-users-checkbox');
        checkBoxes.forEach(element => {
            fireEvent.click(element);
        });

        const uncheckBoxes = screen.getAllByTestId('add-users-checkbox');
        uncheckBoxes.forEach(element => {
            fireEvent.click(element);
        });
    });

    it('test to search for a user', async () => {
        mockGetUsersForATopicToAdd();
        mockGetUsersForATopicToAdd();

        await act(async () => {
            render(<AddUsersModal closeModal={jest.fn()} topic={topicMock} subscribers={getSubscribersForTheTopic} />);
        });
        expect(screen.getByText('Test User 1')).toBeVisible();

        const searchBar = screen.getByPlaceholderText('Bitte vollständige Mail-Adresse eingeben');
        fireEvent.change(searchBar, { target: { value: 'testemail9@otto.de' } });

        await act(async () => {
            const searchButton = screen.getByTestId('search-button');
            fireEvent.click(searchButton);
        });

        expect(screen.getByText('testemail9@otto.de')).toBeVisible();
    });

    it('should keep button disabled if none selected', async () => {
        mockGetUsersForATopicToAdd();
        mockGetUsersForATopicToAdd();

        await act(async () => {
            render(<AddUsersModal closeModal={jest.fn()} topic={topicMock} subscribers={getSubscribersForTheTopic} />);
        });
        expect(screen.getByText('Test User 1')).toBeVisible();
        expect(screen.getByText('Hinzufügen')).toBeDisabled();
    });

    it('should enable button if user selected', async () => {
        mockGetUsersForATopicToAdd();
        mockGetUsersForATopicToAdd();

        await act(async () => {
            render(<AddUsersModal closeModal={jest.fn()} topic={topicMock} subscribers={getSubscribersForTheTopic} />);
        });
        expect(screen.getByText('Test User 1')).toBeVisible();
        expect(screen.getByTestId('modal-save-button')).toBeDisabled();

        const checkBoxes = screen.getAllByTestId('add-users-checkbox');
        checkBoxes.forEach(element => {
            fireEvent.click(element);
        });
        expect(screen.getByTestId('modal-save-button')).not.toBeDisabled();
    });

    it('test to just clear a search while searching a user without clicking search icon', async () => {
        mockGetUsersForATopicToAdd();
        mockGetUsersForATopicToAdd();
        await act(async () => {
            render(<AddUsersModal closeModal={jest.fn()} topic={topicMock} subscribers={getSubscribersForTheTopic} />);
        });
        expect(fetchMock.mock.calls.length).toBe(1);
        expect(screen.getByText('Test User 1')).toBeVisible();
        const removeSearchButton = screen.queryByTestId('remove-search-text-button');
        expect(removeSearchButton).toBeNull();

        const searchBar = screen.getByPlaceholderText('Bitte vollständige Mail-Adresse eingeben');
        await act(() => {
            fireEvent.change(searchBar, { target: { value: 'testemail9@otto.de' } });
        });

        expect(screen.getByTestId('remove-search-text-button')).toBeVisible();
        fireEvent.click(screen.getByTestId('remove-search-text-button'));

        const searchBarAfterClear = screen.getByTestId('add-users-search-input');
        expect(searchBarAfterClear.value).toBe('');
    });

    it('test to clear a search after searching for user', async () => {
        mockGetUsersForATopicToAdd();
        mockGetOneUserForATopicToAddDuringSearch();
        mockGetUsersForATopicToAdd();
        await act(async () => {
            render(<AddUsersModal closeModal={jest.fn()} topic={topicMock} subscribers={getSubscribersForTheTopic} />);
        });
        expect(fetchMock.mock.calls.length).toBe(1);
        expect(screen.getByText('Test User 1')).toBeVisible();

        const searchBar = screen.getByPlaceholderText('Bitte vollständige Mail-Adresse eingeben');

        await act(() => {
            fireEvent.change(searchBar, { target: { value: 'testemail9@otto.de' } });
            fireEvent.click(screen.getByTestId('search-button'));
        });

        expect(fetchMock.mock.calls.length).toBe(2);
        expect(screen.queryByText('Test User 1')).toBeNull();
        expect(screen.queryByText('Test User 9')).toBeVisible();

        expect(screen.getByTestId('remove-search-text-button')).toBeVisible();
        fireEvent.click(screen.getByTestId('remove-search-text-button'));

        expect(fetchMock.mock.calls.length).toBe(3);
        const searchBarAfterClear = screen.getByTestId('add-users-search-input');
        expect(searchBarAfterClear.value).toBe('');
    });

    const mockGetUsersForATopicToAdd = () => {
        const req = {
            items: [
                {
                    id: '0',
                    firstName: 'Test User',
                    lastName: '0',
                    email: 'testemail0@otto.de',
                },
            ],
            count: 10,
        };

        for (let i = 0; i < 10; i++) {
            req.items[i] = {
                id: `${i}`,
                firstName: `Test User`,
                lastName: `${i}`,
                email: `testemail${i}@otto.de`,
            };
        }
        fetchMock.mockResponseOnce(JSON.stringify(req));
    };

    const mockGetOneUserForATopicToAddDuringSearch = () => {
        const req = {
            items: [
                {
                    id: '9',
                    firstName: 'Test User',
                    lastName: '9',
                    email: 'testemail9@otto.de',
                },
            ],
            count: 1,
        };
        fetchMock.mockResponseOnce(JSON.stringify(req));
    };

    const getSubscribersForTheTopic = [
        {
            id: '1',
            firstName: 'Test User',
            lastName: '1',
            email: 'testemail0@otto.de',
        },
    ];

    const topicMock = {
        id: '1',
        name: 'test',
        description: 'testDescription',
        subscribers: [
            {
                id: '1',
                firstName: 'Test User',
                lastName: '1',
                email: 'testemail0@otto.de',
            },
        ],
    };
});
