import { act, render } from '@testing-library/react';
import fetchMock from 'jest-fetch-mock';
import TopicsOverview from '@components/views/topics-overview/index';

describe('Topics overview View', () => {
    beforeEach(() => {
        fetchMock.resetMocks();
    });

    it('render topics overview', async () => {
        mockFetchTopics();
        await act(async () => {
            render(<TopicsOverview />);
        });
        expect(fetchMock.mock.calls.length).toBe(1);
    });

    const mockFetchTopics = () => {
        fetchMock.mockResponseOnce(
            JSON.stringify({
                items: [
                    {
                        id: '1',
                        name: 'test',
                        description: 'testDescription',
                        subscribers: [
                            {
                                id: '1',
                                firstName: 'testName',
                                email: 'testEmail',
                            },
                        ],
                    },
                ],
            }),
        );
    };
});
