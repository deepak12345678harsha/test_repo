import React, { FC, useEffect, useState } from 'react';
import { ContactManagementAPI, OverviewDTO, SubscriberDTO, TopicDTO } from '@api/index';
import Modal from '@components/elements/modal';
import SearchField from '@components/elements/search-field';
import Table, { TableColumn } from '@components/elements/table';
import styles from './add-users-modal.module.css';

export type AddUsersModalProps = {
    closeModal: (save: boolean) => void;
    topic: TopicDTO;
    subscribers: SubscriberDTO[];
};

const AddUsersModal: FC<AddUsersModalProps> = props => {
    const [checkedRows, setCheckedRows] = useState<Record<string, boolean>>({});
    const [users, setUsers] = useState<OverviewDTO<SubscriberDTO>>();
    const [search, setSearch] = useState('');

    const subscriberIds = props.subscribers.map(subscriber => subscriber.id);

    const columnsForTable: TableColumn<SubscriberDTO>[] = [
        {
            name: '',
            cellStyles: { textAlign: 'center' },
            renderData: rowData => {
                if (subscriberIds.includes(rowData.id)) {
                    return <input className={`obc_form__check-input`} type={'checkbox'} checked={true} readOnly={true} data-testid="add-users-checkbox" />;
                } else {
                    return (
                        <input
                            className={`obc_form__check-input`}
                            data-testid="add-users-checkbox"
                            type="checkbox"
                            checked={checkedRows[rowData.id] == true}
                            onClick={() => {
                                if (checkedRows[rowData.id]) {
                                    delete checkedRows[rowData.id];
                                    setCheckedRows({ ...checkedRows });
                                } else {
                                    setCheckedRows({ ...checkedRows, [rowData.id]: true });
                                }
                            }}
                        />
                    );
                }
            },
        },
        {
            name: 'Kontakt',
            renderData: rowData => {
                if (subscriberIds.includes(rowData.id)) {
                    return <p className={styles.text_roll + ' ' + styles.grey_text}>{rowData.firstName + ' ' + rowData.lastName}</p>;
                } else {
                    return <p className={styles.text_roll}>{rowData.firstName + ' ' + rowData.lastName}</p>;
                }
            },
        },
        {
            name: 'E-Mail-Adresse',
            renderData: rowData => {
                if (subscriberIds.includes(rowData.id)) {
                    return <p className={styles.text_roll + ' ' + styles.grey_text}>{rowData.email}</p>;
                } else {
                    return <p className={styles.text_roll}>{rowData.email}</p>;
                }
            },
        },
    ];
    const getUsers = async () => {
        const usersResponse = await ContactManagementAPI.getUsers(search);
        setUsers(usersResponse);
    };

    const addUsers = async () => {
        const userIds = Object.keys(checkedRows);
        saveUsersClickToDataLayer(userIds.length);
        await ContactManagementAPI.addUsersToTopic(props.topic.id, userIds);
        props.closeModal(true);
    };

    const saveUsersClickToDataLayer = (count: number) => {
        // @ts-ignore
        window.dataLayer = window.dataLayer || [];
        // @ts-ignore
        window.dataLayer.push({
            event: 'gaEvent',
            event_name: 'save_subscriptions',
            count: count,
            save_subscriptions: {
                event_category: 'Contactmanagement',
                event_action: 'Save Topic Subscriptions',
                event_label: props.topic.name,
            },
        });
    };

    const searchUserClickToDataLayer = () => {
        // @ts-ignore
        window.dataLayer = window.dataLayer || [];
        // @ts-ignore
        window.dataLayer.push({
            event: 'gaEvent',
            event_name: 'search_subscribers',
            search_subscribers: {
                event_category: 'Contactmanagement',
                event_action: 'Search For User',
                event_label: props.topic.name,
            },
        });
    };

    useEffect(() => {
        getUsers();
    }, []);

    useEffect(() => {
        if (users) {
            getUsers();
        }
    }, [search]);

    return (
        <Modal
            title={'Neuen Kontakt hinzufügen'}
            modelClassName={styles.max_width_700px}
            saveText={'Hinzufügen'}
            saveFn={addUsers}
            isSaveDisabled={Object.keys(checkedRows).length == 0}
            closeText={'Abbrechen'}
            closeFn={() => props.closeModal(false)}>
            <div className={'obc_mt-5'}>
                <SearchField
                    search={value => {
                        setSearch(value);
                        searchUserClickToDataLayer();
                    }}
                    placeholder={'Bitte vollständige Mail-Adresse eingeben'}
                />
                {users && <Table data={users.items} columns={columnsForTable} />}
            </div>
        </Modal>
    );
};

export default AddUsersModal;
