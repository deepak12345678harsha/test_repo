import React, { FC, useState } from 'react';
import { ContactManagementAPI, SubscriberDTO, TopicDTO } from '@api/index';
import Modal from '@components/elements/modal';
import Tag from '@components/elements/tag';
import AddUsersModal from '@components/views/topics-overview/add-users-modal';
import styles from './topic-component.module.css';

export type TopicComponentProps = {
    topic: TopicDTO;
    reloadTopics: () => Promise<void>;
};

const TopicComponent: FC<TopicComponentProps> = props => {
    const [addUserModal, setAddUserModal] = useState(false);
    const [deleteUser, setDeleteUser] = useState<SubscriberDTO>();

    const { id: topicId, name, description, subscribers } = props.topic;

    const multiUser = props.topic.subscribers.length > 1;

    const addSubscribersClickToDataLayer = () => {
        // @ts-ignore
        window.dataLayer = window.dataLayer || [];
        // @ts-ignore
        window.dataLayer.push({
            event: 'gaEvent',
            event_name: 'add_subscribers',
            content_title: name,
            add_subscribers: {
                event_category: 'Contactmanagement',
                event_action: 'Topic Click',
                event_label: name,
            },
        });
    };

    const deleteSubscriberClickToDataLayer = () => {
        // @ts-ignore
        window.dataLayer = window.dataLayer || [];
        // @ts-ignore
        window.dataLayer.push({
            event: 'gaEvent',
            event_name: 'delete_subscribers',
            content_title: name,
            delete_subscribers: {
                event_category: 'Contactmanagement',
                event_action: 'Delete Subscriber',
                event_label: name,
            },
        });
    };

    return (
        <div className="obc_grid">
            {addUserModal && (
                <AddUsersModal
                    closeModal={save => {
                        setAddUserModal(false);
                        if (save) {
                            props.reloadTopics();
                        }
                    }}
                    topic={props.topic}
                    subscribers={subscribers}
                />
            )}

            {deleteUser && multiUser && (
                <Modal
                    title={'Soll der Kontakt wirklich entfernt werden?'}
                    saveText={'Kontakt entfernen'}
                    saveFn={async () => {
                        deleteSubscriberClickToDataLayer();
                        await ContactManagementAPI.unsubscribeUserFromTopic(topicId, deleteUser.id);
                        setDeleteUser(undefined);
                        await props.reloadTopics();
                    }}
                    closeText={'Abbrechen'}
                    closeFn={() => setDeleteUser(undefined)}>
                    <div className={'obc_mt-5'}>
                        Der Kontakt <b>{deleteUser.firstName + ' ' + deleteUser.lastName + ' (' + deleteUser.email + ')'}</b> bekommt anschließend keine Nachrichten mehr zu diesem
                        Kontext!
                    </div>
                </Modal>
            )}

            {deleteUser && !multiUser && (
                <Modal title={'Der Kontakt kann nicht entfernt werden!'} saveText={'Schließen'} saveFn={() => setDeleteUser(undefined)} closeFn={() => setDeleteUser(undefined)}>
                    <div className={'obc_mt-5'}>
                        Es muss mindestens ein Kontakt hinterlegt sein. Wenn Sie diesen Kontakt entfernen möchten, legen Sie bitte zuerst einen anderen Verantwortlichen fest!
                    </div>
                </Modal>
            )}

            <div className="obc_grid__col-1-of-3">
                <div className="obc_heading3">{name}</div>
                <div className="obc_copy100">{description}</div>
            </div>
            <div className={`obc_grid obc_grid__col ${styles.blabla_topic_margin_left}`}>
                <div className="obc_grid__col">
                    {subscribers.map(user => {
                        return (
                            <div key={user.id}>
                                <Tag
                                    label={user.email}
                                    onCloseTag={() => {
                                        setDeleteUser(user);
                                    }}
                                />
                            </div>
                        );
                    })}
                </div>

                <div className="obc_grid__col-auto">
                    <button
                        type="button"
                        className="obc_btn"
                        onClick={() => {
                            setAddUserModal(true);
                            addSubscribersClickToDataLayer();
                        }}>
                        <i className="obc_icon-plus obc_mr-1" data-testid="add-to-button" />
                        {'Hinzufügen'}
                    </button>
                </div>
            </div>
        </div>
    );
};

export default TopicComponent;
