import React, { FC, useState } from 'react';
import { PartnerMailsAPI } from '@api/partner-mails';
import Notification, { NotificationProps } from '@components/elements/newsletter-elements/Notification';
import Title from '@components/elements/newsletter-elements/Title';
import styles from './index.module.css';

export type PartnerMailsTriggerOverviewProps = Record<string, never>;

const PartnerMailsTriggerOverview: FC<PartnerMailsTriggerOverviewProps> = () => {
    const [partnerIds, setPartnerIds] = useState('');
    const [emailBodyText, setEmailBodyText] = useState('');
    const [file, setFile] = useState('');
    const [fileName, setFileName] = useState('');
    const [notification, setNotification] = useState<NotificationProps>();

    const onUpload = (e: any) => {
        setFile(e.target.files[0]);
        setFileName(e.target.files[0].name);
    };

    const handlePartnerIds = (e: any) => {
        setPartnerIds(e.target.value);
    };

    const handleEmailTextBody = (e: any) => {
        setEmailBodyText(e.target.value);
    };

    const clearUploadedFile = (e: any) => {
        e.target.files[0] = null;
        setFile('');
        setFileName('');
    };

    const sendMail = () => {
        const formData = new FormData();
        formData.append('partnerIds', partnerIds);
        formData.append('emailBodyText', emailBodyText);
        formData.append('file', file);
        postPartnerMailsRequest(formData).then();
    };

    const postPartnerMailsRequest = async (formData: FormData) => {
        try {
            await PartnerMailsAPI.sendMultiplePartnerEmailRequest(formData);
            setNotification({
                notificationType: 'success',
                text: 'Mail Requests have been successfully created for provided partners',
                btnCloseAction: () => setNotification(undefined),
            });
        } catch (e: any) {
            console.log(e);
            setNotification({
                notificationType: 'error',
                text: 'Mail request creation failed. ',
                subtext: 'Mail creation failed for partners - ' + JSON.stringify(JSON.parse(e.message).details),
                btnCloseAction: () => setNotification(undefined),
            });
        }
    };

    const renderForm = () => {
        return (
            <form className="obc_form">
                <div className="obc_form-group">
                    <label className="obc_form__label">
                        Input your partner IDs
                        <span className="obc_form__hint-text">Separate them using commas</span>
                    </label>
                    <textarea className="obc_form__textarea" placeholder="Partner ids" onChange={handlePartnerIds}></textarea>
                    <span className="obc_form__error-text">Is required!</span>
                </div>

                <div className="obc_form-group">
                    <label className="obc_form__label">Input the text body for the mail</label>
                    <textarea className="obc_form__textarea" placeholder="" onChange={handleEmailTextBody}></textarea>
                    <span className="obc_form__error-text">Is required!</span>
                </div>

                <div>
                    <input type="file" className={styles.input_file_attachment} id="attachment-upload-input" onChange={onUpload} />
                    <label htmlFor="attachment-upload-input">
                        Upload a file for attachment <i className="obc_icon-upload"></i>
                        {fileName}
                    </label>
                    <button onClick={clearUploadedFile} className="obc_alert__close" data-testid="remove-uploaded-file"></button>
                </div>

                <div style={{ marginTop: '20px' }}>
                    <button type="button" className="obc_btn-primary" onClick={sendMail}>
                        Send mail
                    </button>
                </div>
            </form>
        );
    };

    return (
        <div>
            <div dangerouslySetInnerHTML={{ __html: `<!--# include virtual="/frame" -->` }} />
            <div className="portal_container">
                <div className="portal_nav" dangerouslySetInnerHTML={{ __html: `<!--# include virtual="/navigation" -->` }} />
                <main className="portal_main">
                    <div slot="mainContent">
                        <div style={{ marginTop: '27px' }}>
                            {notification && <Notification {...notification} />}
                            <Title text={'Send one mail to different partners at the same time'} />
                            <div className="obc_grid">
                                <div className="obc_grid__col-2-of-3 obc_content-container">{renderForm()}</div>
                            </div>
                        </div>
                    </div>
                    <div dangerouslySetInnerHTML={{ __html: `<!--# include virtual="/frame/footer" -->` }} />
                </main>
            </div>
        </div>
    );
};

export default PartnerMailsTriggerOverview;
