import { act, configure, render, screen } from '@testing-library/react';
import fetchMock from 'jest-fetch-mock';
import NewsletterOverview from '@components/views/newsletter-overview/index';

describe(' Render Newsletter View', () => {
    beforeEach(() => {
        fetchMock.resetMocks();
    });

    it('subscribe to a newsletter, close the notification and unsubscribe', async () => {
        mockUnsubscribed();
        mockSubscriptionPutToSubscribe();
        mockSubscriptionPutToUnsubscribe();

        await act(() => {
            render(<NewsletterOverview />);
        });
        await act(() => {
            const tagElm = screen.getByText('Anmeldung OTTO-Market-Newsletter');
            expect(tagElm).toBeVisible();
            const checkBox = screen.getByTestId('subscription_checkbox');
            expect(checkBox).not.toBeChecked();
            checkBox.click();
            expect(screen.getByTestId('subscription_checkbox')).toBeChecked();
            //to subscribe
            screen.getByTestId('subscription_button').click();
        });
        expect(fetchMock.mock.calls.length).toBe(2);
        expect(fetchMock.mock.calls[1][1].method).toBe('PUT');
        expect(screen.getByTestId('newsletter_notification_div')).toBeVisible();

        await act(() => {
            //to close the notification
            screen.getByTestId('newsletter_notification_close').click();
            //to unsubscribe
            expect(screen.getByTestId('subscription_checkbox')).toBeChecked();
            screen.getByTestId('subscription_checkbox').click();
            screen.getByTestId('subscription_button').click();
            expect(screen.getByTestId('subscription_checkbox')).not.toBeChecked();
        });
        expect(fetchMock.mock.calls[2][1].method).toBe('PUT');
    });

    it('render newsletter overview when api returns error', async () => {
        mockUnsubscribed();
        mockSubscriptionApiError();

        await act(async () => {
            render(<NewsletterOverview />);
        });
        await act(() => {
            const tagElm = screen.getByText('Anmeldung OTTO-Market-Newsletter');
            expect(tagElm).toBeVisible();
            const checkBox = screen.getByTestId('subscription_checkbox');
            expect(checkBox).not.toBeChecked();
            checkBox.click();
            screen.getByTestId('subscription_button').click();
        });

        configure({
            testIdAttribute: 'class',
        });
        expect(screen.getByTestId('obc_alert nptn_notification obc_alert--error')).toBeVisible();
    });

    const mockUnsubscribed = () => {
        fetchMock.mockResponseOnce(
            JSON.stringify({
                isSubscribed: false,
                text: 'text',
            }),
        );
    };

    const mockSubscriptionPutToSubscribe = () => {
        fetchMock.mockResponseOnce(
            JSON.stringify({
                isSubscribed: true,
                text: 'text',
            }),
        );
    };

    const mockSubscriptionPutToUnsubscribe = () => {
        fetchMock.mockResponseOnce(
            JSON.stringify({
                isSubscribed: false,
                text: 'text',
            }),
        );
    };

    const mockSubscriptionApiError = () => {
        fetchMock.mockReject(new Error('test'));
    };
});
