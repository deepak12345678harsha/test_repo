import Image from 'next/image';
import { FC, useEffect, useState } from 'react';
import { NewsletterAPI, NotificationTypeDTO } from '@api/newsletter';
import Button from '@components/elements/newsletter-elements/Button';
import Checkbox from '@components/elements/newsletter-elements/Checkbox';
import Notification from '@components/elements/newsletter-elements/Notification';
import Title from '@components/elements/newsletter-elements/Title';
import styles from './index.module.css';

export type NewsletterProps = Record<string, never>;

const Newsletter: FC<NewsletterProps> = () => {
    const [subscribed, setSubscribed] = useState(false);
    const [notification, setNotification] = useState<NotificationTypeDTO>();

    const acceptTextElement = (
        <div>
            Ja, ich möchte den OTTO-Market-Newsletter der Otto (GmbH & Co KG) erhalten und Informationen über Angebote, neue Services und Updates von OTTO Market erhalten. Diese
            Einwilligung kann jederzeit mit Wirkung für die Zukunft unter{' '}
            <a className="obc_link" href="https://portal.otto.market/profile/Newsletter">
                https://portal.otto.market/profile/Newsletter
            </a>{' '}
            oder am Ende jeder E-Mail widerrufen werden.
        </div>
    );
    const acceptText =
        acceptTextElement.props.children[0] +
        acceptTextElement.props.children[1] +
        acceptTextElement.props.children[2].props.children +
        acceptTextElement.props.children[3] +
        acceptTextElement.props.children[4];

    useEffect(() => {
        getNewsletterStatus();
    }, []);

    const getNewsletterStatus = async () => {
        let newsletterStatus;
        try {
            newsletterStatus = await NewsletterAPI.getNewsletterSubscriptionStatus();
            setSubscribed(newsletterStatus.isSubscribed);
        } catch (error) {
            console.log(error);
            setNotification({ notificationType: 'error', text: 'Hoppla, da ist etwas schief gelaufen.', subtext: 'Bitte probiere es gleich nochmal.' });
        }
    };

    const updateNewsletter = async () => {
        let newsletterStatus;
        try {
            newsletterStatus = await NewsletterAPI.modifyNewsletterSubscriptionStatus(subscribed, acceptText);
            setSubscribed(newsletterStatus.isSubscribed);
            const notificationProps = subscribed
                ? {
                      notificationType: 'success',
                      text: 'Ihre Newsletter-Anmeldung war erfolgreich!',
                      subtext:
                          'Vielen Dank für Ihre Anmeldung zum OTTO-Market-Newsletter.  Wir freuen uns, Sie in Zukunft über Angebote, neue Services und Updates von OTTO Market informieren zu dürfen.',
                  }
                : {
                      notificationType: 'info',
                      text: 'Ihre Newsletter-Abmeldung war erfolgreich!',
                      subtext:
                          'Schade, dass Sie keine weiteren Informationen über Angebote, neue Services und Updates von OTTO Market wünschen. Wir respektieren das und bestätigen hiermit die erfolgreiche Abmeldung von unserem Newsletter.',
                  };
            setNotification(notificationProps);
        } catch (error) {
            console.log(error);
            setNotification({ notificationType: 'error', text: 'Hoppla, da ist etwas schief gelaufen.', subtext: 'Bitte probiere es gleich nochmal.' });
        }
    };

    let notificationBubble;
    if (notification && notification.notificationType !== 'none') {
        notificationBubble = (
            <Notification
                btnCloseAction={() => setNotification({ notificationType: 'none', text: '', subtext: '' })}
                notificationType={notification.notificationType}
                text={notification.text}
                subtext={notification.subtext}
            />
        );
    }

    return (
        <div className={styles.newsletter}>
            {notificationBubble}
            <div className={styles.content}>
                <Title text="Anmeldung OTTO-Market-Newsletter" />
                <Image src="/contact-management/newsletter/newsletter.png" alt="newsletter" height="440" width="1600" priority={true} />
                <div className="obc_copy100">
                    <div className={styles.subheader}>Für den Newsletter von OTTO Market anmelden und nichts mehr verpassen!</div>
                    <div className={styles.text}>
                        Für den Newsletter von OTTO Market anmelden und nichts mehr verpassen! Mit dem OTTO-Market-Newsletter informieren wir Sie über Neuigkeiten und wichtige
                        Informationen rund um OTTO Market: Sie bekommen von uns regelmäßig Nachrichten über unser Partner-Portal <b>OTTO Partner Connect</b> wie zum Beispiel über
                        neue Funktionen oder Änderungen, aber auch Informationen über technische Updates oder neu freigeschaltete Produktgruppen. Außerdem erhalten Sie
                        Informationen über Aktionen und neue Services für die Vermarktung Ihrer Produkte.
                    </div>
                </div>
                <div className={styles.checkbox}>
                    <Checkbox isActive={subscribed} id="nptn_newsletter-checkbox" callback={setSubscribed} titleJSX={acceptTextElement} />
                </div>
            </div>
            <hr className="obc_divider" />
            <div className="nptn_btn_form">
                <Button title="Speichern" isPrimary onClick={updateNewsletter} />
            </div>
        </div>
    );
};

export default Newsletter;
