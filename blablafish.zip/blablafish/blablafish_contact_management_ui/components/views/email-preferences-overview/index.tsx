import React, { FC, useEffect, useRef, useState } from 'react';
import { UserEmailPreference, UserEmailPreferenceApi } from '@api/email-preference';
import Notification, { NotificationProps } from '@components/elements/newsletter-elements/Notification';
import Subtitle from '@components/elements/newsletter-elements/Subtitle';
import Title from '@components/elements/newsletter-elements/Title';
import SpinnerWrapper from '@components/elements/spinner/spinner-wrapper';
import useLoader from '@components/hooks/loading';
import GroupedMailPreferences from '@components/views/email-preferences-overview/grouped-mail-preferences';
import {
    API_FAILED_SUBTEXT,
    API_FAILED_TEXT,
    API_SUCCESS_TEXT,
    CANCEL,
    EDITABLE_MAIL_PREFERENCE_TITLE,
    NO_MAIL_PREFERENCE_AVAILABLE_MESSAGE,
    SAVE,
} from '../../../utils/text-constants';

export type UserMailPreferenceOverviewProps = Record<string, never>;

const UserMailPreferenceOverview: FC<UserMailPreferenceOverviewProps> = () => {
    const mountedRef = useRef<boolean>(false);
    const { isLoading, toggleLoading } = useLoader(true);
    const [editableEmailPreferences, setEditableEmailPreferences] = useState<UserEmailPreference[]>([]);
    const [uneditableEmailPreferences, setUneditableEmailPreferences] = useState<UserEmailPreference[]>([]);
    const [notification, setNotification] = useState<NotificationProps>();

    useEffect(() => {
        mountedRef.current = true;
        toggleLoading(fetchUserEmailPreferences).then();
        return () => {
            mountedRef.current = false;
        };
    }, []);

    const fetchUserEmailPreferences = async () => {
        try {
            const userMailPreferences: UserEmailPreference[] = (await UserEmailPreferenceApi.fetchUserEmailPreferences()).items;
            if (mountedRef.current) {
                setEditableEmailPreferences(userMailPreferences.filter(preference => preference.canUnsubscribe));
                setUneditableEmailPreferences(userMailPreferences.filter(preference => !preference.canUnsubscribe));
            }
        } catch (e) {
            setNotification({
                notificationType: 'error',
                text: API_FAILED_TEXT,
                subtext: API_FAILED_SUBTEXT,
                btnCloseAction: () => setNotification(undefined),
            });
        }
    };

    const handlePreferenceChange = async (event: { target: { id: any } }) => {
        const topicId = Number(event.target.id);
        const updatedMailPreferences: UserEmailPreference[] = editableEmailPreferences.map(userMailPreference => {
            if (userMailPreference.topicId === topicId) {
                userMailPreference.optIn = !userMailPreference.optIn;
            }
            return userMailPreference;
        });
        setEditableEmailPreferences(updatedMailPreferences);
    };

    const updateUserEmailPreferences = async () => {
        try {
            await UserEmailPreferenceApi.updateUserEmailPreferences(editableEmailPreferences);
            setNotification({
                notificationType: 'success',
                text: API_SUCCESS_TEXT,
                btnCloseAction: () => setNotification(undefined),
            });
            await fetchUserEmailPreferences();
        } catch (e) {
            setNotification({
                notificationType: 'error',
                text: API_FAILED_TEXT,
                subtext: API_FAILED_SUBTEXT,
                btnCloseAction: () => setNotification(undefined),
            });
        }
    };

    const renderButtons = () => {
        return (
            <div className="obc_text-right">
                <button className="obc_btn obc_mr-1" onClick={() => toggleLoading(fetchUserEmailPreferences)} data-testid="email-preference-cancel">
                    {CANCEL}
                </button>
                <button className="obc_btn-primary obc_mr-1" onClick={() => toggleLoading(updateUserEmailPreferences)} data-testid="email-preference-save">
                    {SAVE}
                </button>
            </div>
        );
    };

    const isAnyMailTopicAvailable = () => {
        return (editableEmailPreferences && editableEmailPreferences.length > 0) || (uneditableEmailPreferences && uneditableEmailPreferences.length > 0);
    };

    return (
        <div id="user-mail-preferences" style={{ marginTop: '27px' }}>
            {notification && <Notification {...notification} />}
            <SpinnerWrapper size="large" show={isLoading}>
                {isAnyMailTopicAvailable() ? (
                    <>
                        <GroupedMailPreferences
                            editablePreferences={editableEmailPreferences}
                            uneditablePreferences={uneditableEmailPreferences}
                            handlePreferenceChange={handlePreferenceChange}
                        />
                        {renderButtons()}
                    </>
                ) : (
                    <div>
                        <Title text={EDITABLE_MAIL_PREFERENCE_TITLE} />
                        <Subtitle text={NO_MAIL_PREFERENCE_AVAILABLE_MESSAGE} />
                    </div>
                )}
            </SpinnerWrapper>
        </div>
    );
};

export default UserMailPreferenceOverview;
