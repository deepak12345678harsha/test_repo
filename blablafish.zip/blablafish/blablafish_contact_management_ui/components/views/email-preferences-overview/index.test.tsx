import { act, render, screen } from '@testing-library/react';
import fetchMock from 'jest-fetch-mock';
import UserMailPreferenceOverview from '@components/views/email-preferences-overview/index';

describe('Render Email preferences View', () => {
    beforeEach(() => {
        fetchMock.resetMocks();
    });

    it('Email preferences view when API not fetched', async () => {
        await act(() => {
            render(<UserMailPreferenceOverview />);
        });

        const title = screen.getByText('Benachrichtigungseinstellungen');
        expect(title).toBeVisible();

        const notification = screen.getByTestId('newsletter_notification_div');
        expect(notification.getAttribute('class')).toBe('obc_alert nptn_notification obc_alert--error');
    });

    it('Email preferences view when API has uneditable preferences', async () => {
        mockGetUneditablePreferences();
        await act(() => {
            render(<UserMailPreferenceOverview />);
        });

        const emailPreferenceRows = screen.getAllByTestId('email-preference-row');
        expect(emailPreferenceRows.length).toBe(2);
        const emailPreferenceNoToggleRows = screen.getAllByTestId('email-preference-no-toggle');
        expect(emailPreferenceNoToggleRows.length).toBe(2);
    });

    it('Email preferences view when API has all editable preferences', async () => {
        mockGetEditablePreferences();
        await act(() => {
            render(<UserMailPreferenceOverview />);
        });

        const emailPreferenceRows = screen.getAllByTestId('email-preference-row');
        expect(emailPreferenceRows.length).toBe(2);
        const emailPreferenceNoToggleRows = screen.getAllByTestId('toggle');
        expect(emailPreferenceNoToggleRows.length).toBe(2);
    });

    it('Email preferences view when API has only editable preferences', async () => {
        mockGetEditableAndUneditablePreferences();
        await act(() => {
            render(<UserMailPreferenceOverview />);
        });

        const emailPreferenceRows = screen.getAllByTestId('email-preference-row');
        expect(emailPreferenceRows.length).toBe(2);
        const emailPreferenceToggleRows = screen.getAllByTestId('toggle');
        expect(emailPreferenceToggleRows.length).toBe(1);
    });

    it('Email preferences view when an editable preference is toggled and updated', async () => {
        mockGetEditableAndUneditablePreferences();
        mockUpdatePreferences();
        mockGetEditableAndUneditablePreferences();

        await act(() => {
            render(<UserMailPreferenceOverview />);
        });

        const emailPreferenceToggleRow = screen.getByTestId('toggle');
        expect(emailPreferenceToggleRow).toBeVisible();

        const saveButton = screen.getByTestId('email-preference-save');
        expect(saveButton).toBeVisible();
        await act(() => {
            emailPreferenceToggleRow.click();
            saveButton.click();
        });

        const notification = screen.getByTestId('newsletter_notification_div');
        expect(notification).toBeVisible();
        expect(notification.getAttribute('class')).toBe('obc_alert nptn_notification obc_alert--success');
        await act(() => {
            screen.getByTestId('newsletter_notification_close').click();
        });
    });

    it('Email preferences view when an editable preference is toggled and cancelled', async () => {
        mockGetEditableAndUneditablePreferences();
        mockGetEditableAndUneditablePreferences();

        await act(() => {
            render(<UserMailPreferenceOverview />);
        });

        const emailPreferenceToggleRow = screen.getByTestId('toggle');
        expect(emailPreferenceToggleRow).toBeVisible();

        const cancelButton = screen.getByTestId('email-preference-cancel');
        expect(cancelButton).toBeVisible();
        await act(() => {
            emailPreferenceToggleRow.click();
            cancelButton.click();
        });
    });

    it('Email preferences view show error notification when get api throws error', async () => {
        mockErrorResponse();
        await act(() => {
            render(<UserMailPreferenceOverview />);
        });

        const notification = screen.getByTestId('newsletter_notification_div');
        expect(notification).toBeVisible();
        expect(notification.getAttribute('class')).toBe('obc_alert nptn_notification obc_alert--error');
        await act(() => {
            screen.getByTestId('newsletter_notification_close').click();
        });
    });

    it('Email preferences view show error notification when update api throws error', async () => {
        mockGetEditableAndUneditablePreferences();
        mockErrorResponse();
        await act(() => {
            render(<UserMailPreferenceOverview />);
        });

        const emailPreferenceToggleRow = screen.getByTestId('toggle');
        expect(emailPreferenceToggleRow).toBeVisible();

        const saveButton = screen.getByTestId('email-preference-save');
        expect(saveButton).toBeVisible();
        await act(() => {
            emailPreferenceToggleRow.click();
            saveButton.click();
        });

        const notification = screen.getByTestId('newsletter_notification_div');
        expect(notification).toBeVisible();
        expect(notification.getAttribute('class')).toBe('obc_alert nptn_notification obc_alert--error');
        await act(() => {
            screen.getByTestId('newsletter_notification_close').click();
        });
    });

    const mockGetUneditablePreferences = () => {
        fetchMock.mockResponseOnce(
            JSON.stringify({
                items: [
                    {
                        topicId: 1,
                        name: 'Topic 1',
                        description: 'Description for Topic 1',
                        canUnsubscribe: false,
                        optIn: false,
                    },
                    {
                        topicId: 2,
                        name: 'Topic 2',
                        description: 'Description for Topic 2',
                        canUnsubscribe: false,
                        optIn: false,
                    },
                ],
            }),
        );
    };

    const mockGetEditableAndUneditablePreferences = () => {
        fetchMock.mockResponseOnce(
            JSON.stringify({
                items: [
                    {
                        topicId: 1,
                        name: 'Topic 1',
                        description: 'Description for Topic 1',
                        canUnsubscribe: true,
                        optIn: false,
                    },
                    {
                        topicId: 2,
                        name: 'Topic 2',
                        description: 'Description for Topic 2',
                        canUnsubscribe: false,
                        optIn: true,
                    },
                ],
            }),
        );
    };

    const mockGetEditablePreferences = () => {
        fetchMock.mockResponseOnce(
            JSON.stringify({
                items: [
                    {
                        topicId: 1,
                        name: 'Topic 1',
                        description: 'Description for Topic 1',
                        canUnsubscribe: true,
                        optIn: false,
                    },
                    {
                        topicId: 2,
                        name: 'Topic 2',
                        description: 'Description for Topic 2',
                        canUnsubscribe: true,
                        optIn: true,
                    },
                ],
            }),
        );
    };

    const mockUpdatePreferences = () => {
        fetchMock.mockOnce('200');
    };

    const mockErrorResponse = () => {
        fetchMock.mockResponseOnce('', {
            status: 403,
        });
    };
});
