import React, { FC } from 'react';
import { UserEmailPreference } from '@api/email-preference';
import Toggle from '@components/elements/toggle';
import { MAIL_PREFERENCE_ALWAYS_ACTIVE_TEXT } from '../../../utils/text-constants';

export type MailPreferenceProps = {
    mailPreference: UserEmailPreference;
    handlePreferenceChange: (event: React.ChangeEvent<HTMLInputElement>) => Promise<void>;
};

const EmailPreferenceOptions: FC<MailPreferenceProps> = props => {
    return (
        <div className="obc_grid obc_mb-3" data-testid="email-preference-row">
            <div className="obc_grid__col-3-of-4">
                <div className="obc_copy100">{props.mailPreference.name}</div>
                <div className="obc_copy50" style={{ color: 'rgb(158, 158, 158)' }}>
                    {props.mailPreference.description}
                </div>
            </div>
            <div className="obc_grid__col-1-of-4">
                {props.mailPreference.canUnsubscribe ? (
                    <Toggle checked={props.mailPreference.optIn} id={props.mailPreference.topicId + ''} handleChange={props.handlePreferenceChange} />
                ) : (
                    <div className={'obc_copy50'} data-testid="email-preference-no-toggle">
                        {MAIL_PREFERENCE_ALWAYS_ACTIVE_TEXT}
                    </div>
                )}
            </div>
        </div>
    );
};

export default EmailPreferenceOptions;
