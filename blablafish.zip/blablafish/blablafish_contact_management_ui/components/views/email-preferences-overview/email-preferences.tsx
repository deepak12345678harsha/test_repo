import React, { FC } from 'react';
import { UserEmailPreference } from '@api/email-preference';
import Subtitle from '@components/elements/newsletter-elements/Subtitle';
import Title from '@components/elements/newsletter-elements/Title';
import EmailPreferenceOptions from '@components/views/email-preferences-overview/email-preference-options';

export type MailPreferenceProps = {
    title: string;
    subtitle: string;
    emailPreferences: UserEmailPreference[];
    handlePreferenceChange: (event: React.ChangeEvent<HTMLInputElement>) => Promise<void>;
};

const EmailPreferences: FC<MailPreferenceProps> = props => {
    return (
        <div className="obc_grid obc_mt-2">
            <div className="obc_grid__col-1-of-3">
                <Title text={props.title} />
                <Subtitle text={props.subtitle} />
            </div>
            <div className="obc_grid__col-2-of-3">
                {props.emailPreferences.map(preference => (
                    <EmailPreferenceOptions key={preference.topicId} mailPreference={preference} handlePreferenceChange={props.handlePreferenceChange} />
                ))}
            </div>
        </div>
    );
};

export default EmailPreferences;
