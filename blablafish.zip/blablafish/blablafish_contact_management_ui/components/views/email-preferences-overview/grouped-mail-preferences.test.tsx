import { act, render, screen } from '@testing-library/react';
import fetchMock from 'jest-fetch-mock';
import UserMailPreferenceOverview from '@components/views/email-preferences-overview/index';

describe('Render Email preferences View', () => {
    beforeEach(() => {
        fetchMock.resetMocks();
    });

    it('Email preferences view when API not fetched', async () => {
        await act(() => {
            render(<UserMailPreferenceOverview />);
        });

        const title = screen.getByText('Benachrichtigungseinstellungen');
        expect(title).toBeVisible();

        const notification = screen.getByTestId('newsletter_notification_div');
        expect(notification.getAttribute('class')).toBe('obc_alert nptn_notification obc_alert--error');
    });
});
