import React, { FC } from 'react';
import { UserEmailPreference } from '@api/email-preference';
import EmailPreferences from '@components/views/email-preferences-overview/email-preferences';
import { EDITABLE_MAIL_PREFERENCE_SUBTITLE, EDITABLE_MAIL_PREFERENCE_TITLE, UNEDITABLE_MAIL_TOPICS_SUBTITLE, UNEDITABLE_MAIL_TOPICS_TITLE } from '../../../utils/text-constants';

export type GroupedMailPreferencesProps = {
    editablePreferences: UserEmailPreference[];
    uneditablePreferences: UserEmailPreference[];
    handlePreferenceChange: (event: React.ChangeEvent<HTMLInputElement>) => Promise<void>;
};

const GroupedMailPreferences: FC<GroupedMailPreferencesProps> = props => {
    const renderEditableMailPreferences = () => {
        if (props.editablePreferences && props.editablePreferences.length > 0) {
            return (
                <EmailPreferences
                    title={EDITABLE_MAIL_PREFERENCE_TITLE}
                    subtitle={EDITABLE_MAIL_PREFERENCE_SUBTITLE}
                    emailPreferences={props.editablePreferences}
                    handlePreferenceChange={props.handlePreferenceChange}
                />
            );
        } else {
            return <></>;
        }
    };

    const renderDivider = () => {
        if (props.editablePreferences && props.editablePreferences.length > 0 && props.uneditablePreferences && props.uneditablePreferences.length > 0) {
            return <hr className="obc_divider" />;
        } else {
            return <></>;
        }
    };

    const renderUneditableMailTopics = () => {
        if (props.uneditablePreferences?.length > 0) {
            return (
                <EmailPreferences
                    title={UNEDITABLE_MAIL_TOPICS_TITLE}
                    subtitle={UNEDITABLE_MAIL_TOPICS_SUBTITLE}
                    emailPreferences={props.uneditablePreferences}
                    handlePreferenceChange={props.handlePreferenceChange}
                />
            );
        } else {
            return <></>;
        }
    };

    return (
        <>
            {renderEditableMailPreferences()}
            {renderDivider()}
            {renderUneditableMailTopics()}
        </>
    );
};

export default GroupedMailPreferences;
