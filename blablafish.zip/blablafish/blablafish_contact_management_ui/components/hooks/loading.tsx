import { useEffect, useRef, useState } from 'react';

const useLoader = (initialState?: boolean) => {
    const [loadingState, setLoadingState] = useState({
        loading: !!initialState,
        count: 0,
    });

    const mountedRef = useRef<boolean>(true);

    useEffect(() => {
        mountedRef.current = true;
        return () => {
            mountedRef.current = false;
        };
    }, []);

    const toggleLoader = async (cb: () => Promise<void>) => {
        setLoadingState(prevLoadingState => {
            const updatedCount = prevLoadingState.count + 1;
            return {
                loading: true,
                count: updatedCount,
            };
        });

        try {
            await cb();
        } catch (e) {
            throw e;
        } finally {
            if (mountedRef.current) {
                setLoadingState(prevLoadingState => {
                    const updatedCount = prevLoadingState.count - 1;
                    return {
                        loading: updatedCount > 0,
                        count: updatedCount,
                    };
                });
            }
        }
    };

    return { isLoading: loadingState.loading, toggleLoading: toggleLoader, mountedRef };
};

export default useLoader;
