import { FC } from 'react';
import { TableProps } from '@api/table';
import styles from './index.module.css';
import Table from '../blacklisted-email-elements/Table';
import Checkbox from '../checkbox';

type CheckboxTableProps<T extends TableProps<any>> = TableProps<T> & {
    keyField: string;
    selectedItems: Set<string>;
    setSelectedItems: (items: Set<string>) => void;
};

const CheckboxTable: FC<CheckboxTableProps<any>> = props => {
    const { selectedItems, setSelectedItems, keyField } = props;

    function selectItem(item: string): Set<string> {
        return new Set<string>(selectedItems).add(item);
    }

    function unselectItem(item: string): Set<string> {
        const newSet = new Set<string>(selectedItems);
        newSet.delete(item);
        return newSet;
    }

    const checkChangeForAllItems = (event: any) => {
        event.target.checked ? setSelectedItems(new Set(props.data.map(item => item[keyField]))) : setSelectedItems(new Set());
    };

    function allItemsSelected(): boolean {
        return selectedItems.size === props.data.length && props.data.filter(item => !selectedItems.has(item[keyField])).length === 0;
    }

    function renderCheckBoxHeader() {
        return <Checkbox checked={allItemsSelected()} handleChange={checkChangeForAllItems} />;
    }

    function renderCheckbox(cellData: any, rowData: { [x: string]: any }) {
        const item = rowData[keyField];
        return (
            <Checkbox
                checked={selectedItems.has(item)}
                handleChange={evt => {
                    evt.target.checked ? setSelectedItems(selectItem(item)) : setSelectedItems(unselectItem(item));
                }}
            />
        );
    }

    const getColumns = () => {
        return [
            {
                cellKey: '',
                renderHeader: renderCheckBoxHeader,
                renderData: renderCheckbox,
                getCellAttributes: () => {
                    return {
                        className: [styles.checkboxTableCell].join(' '),
                    };
                },
                getHeaderCellAttributes: () => {
                    return {
                        className: [styles.checkboxTableCell].join(' '),
                    };
                },
            },
            ...props.columns,
        ];
    };
    return <Table columns={getColumns()} data={props.data} />;
};

export default CheckboxTable;
