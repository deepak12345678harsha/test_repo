import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import { Page } from '../../../api/index';
import Pagination from './index';

describe('should test Pagination component', () => {
    it('should render Pagination', () => {
        const page: Page<any> = {
            totalElements: 50,
            size: 10,
            number: 1,
            first: true,
            last: false,
            totalPages: 5,
            content: [],
            numberOfElements: 10,
            empty: false,
        };
        render(<Pagination page={page} updatePageSize={jest.fn} updatePage={jest.fn} />);
        const pageSizeElm = screen.queryByText('10');
        const pagesElm = screen.queryByText('1');

        expect(pageSizeElm).toBeVisible();
        expect(pagesElm).toBeVisible();
    });

    it('should verify Pagination pageSize part', () => {
        let pageSize = 10;
        const updatePageSize = jest.fn(val => {
            pageSize = val;
        });
        const page: Page<any> = {
            totalElements: 50,
            size: pageSize,
            number: 1,
            first: true,
            last: false,
            totalPages: 5,
            content: [],
            numberOfElements: 10,
            empty: false,
        };
        render(<Pagination page={page} updatePageSize={updatePageSize} updatePage={jest.fn} />);
        const pageSizeElm = screen.queryByText('10');

        fireEvent.click(pageSizeElm.nextElementSibling);

        expect(pageSizeElm).toBeVisible();
        expect(updatePageSize).toBeCalledTimes(1);
        expect(pageSize).toBe(25);

        fireEvent.click(pageSizeElm.nextElementSibling.nextElementSibling);

        expect(pageSizeElm).toBeVisible();
        expect(updatePageSize).toBeCalledTimes(2);
        expect(pageSize).toBe(50);
    });

    it('should verify Pagination page part', () => {
        let curPage = 1;
        const updatePage = jest.fn(val => {
            curPage = val;
        });

        const page: Page<any> = {
            totalElements: 50,
            size: 10,
            number: curPage,
            first: curPage == 1,
            last: false,
            totalPages: 5,
            content: [],
            numberOfElements: 10,
            empty: false,
        };
        render(<Pagination page={page} updatePageSize={jest.fn()} updatePage={updatePage} />);
        const pageElm = screen.queryByText('1');
        expect(pageElm).toBeVisible();

        fireEvent.click(screen.queryByText('2'));
        expect(updatePage).toBeCalledTimes(1);
        expect(curPage).toBe(2);

        fireEvent.click(screen.queryByText('3'));
        expect(updatePage).toBeCalledTimes(2);
        expect(curPage).toBe(3);
    });

    it('should verify page moving logic', () => {
        const page: Page<any> = {
            totalElements: 50,
            size: 10,
            number: 1,
            first: true,
            last: false,
            totalPages: 5,
            content: [],
            numberOfElements: 10,
            empty: false,
        };
        render(<Pagination page={page} updatePageSize={jest.fn} updatePage={jest.fn} />);
        expect(screen.queryByText('1')).toBeVisible();
        expect(screen.queryByText('2')).toBeVisible();
        expect(screen.queryByText('3')).toBeVisible();
        expect(screen.queryByText('4')).toBeNull();
        cleanup();

        page.number = 2;
        page.first = false;
        render(<Pagination page={page} updatePageSize={jest.fn} updatePage={jest.fn} />);
        expect(screen.queryByText('1')).toBeVisible();
        expect(screen.queryByText('2')).toBeVisible();
        expect(screen.queryByText('3')).toBeVisible();
        expect(screen.queryByText('4')).toBeNull();
        cleanup();

        page.number = 3;
        page.first = false;
        render(<Pagination page={page} updatePageSize={jest.fn} updatePage={jest.fn} />);
        expect(screen.queryByText('1')).toBeNull();
        expect(screen.queryByText('2')).toBeVisible();
        expect(screen.queryByText('3')).toBeVisible();
        expect(screen.queryByText('4')).toBeVisible();
        cleanup();

        page.number = 4;
        page.first = false;
        render(<Pagination page={page} updatePageSize={jest.fn} updatePage={jest.fn} />);
        expect(screen.queryByText('1')).toBeNull();
        expect(screen.queryByText('2')).toBeNull();
        expect(screen.queryByText('3')).toBeVisible();
        expect(screen.queryByText('4')).toBeVisible();
        expect(screen.queryByText('5')).toBeVisible();
    });

    it('should verify page actions', () => {
        let page = -1;
        const updatePage = jest.fn(val => {
            page = val;
        });
        const pageProp: Page<any> = {
            totalElements: 50,
            size: 10,
            number: 3,
            first: false,
            last: false,
            totalPages: 5,
            content: [],
            numberOfElements: 10,
            empty: false,
        };
        render(<Pagination page={pageProp} updatePageSize={jest.fn} updatePage={updatePage} />);

        fireEvent.click(screen.queryByText('‹'));
        expect(page).toBe(2);

        fireEvent.click(screen.queryByText('›'));
        expect(page).toBe(4);
    });
});
