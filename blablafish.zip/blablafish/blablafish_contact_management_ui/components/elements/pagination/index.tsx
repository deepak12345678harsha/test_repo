import React, { FC } from 'react';
import { Page } from '@api/index';

export type PaginationProps = {
    page: Page<any>;
    updatePageSize: (newSize: number) => void;
    updatePage: (newPage: number) => void;
};

const Pagination: FC<PaginationProps> = props => {
    const pageSizes: number[] = [10, 25, 50];
    const { size, number, totalPages, first, last } = props.page;

    const renderPageSizeButton = (pageSize: number) => {
        return (
            <button type="button" key={pageSize} onClick={() => props.updatePageSize(pageSize)} className={size == pageSize ? 'obc_btn-secondary' : 'obc_btn'}>
                {pageSize}
            </button>
        );
    };

    const renderPageButton = (page: number) => {
        return (
            <button type="button" key={page} onClick={() => props.updatePage(page)} className={number == page ? 'obc_btn-secondary' : 'obc_btn'}>
                {page}
            </button>
        );
    };

    const isFirstPage = () => {
        return first;
    };

    const isLastPage = () => {
        return last;
    };

    const renderPages = () => {
        const elms: React.ReactElement[] = [];
        let index;
        let pageLimit = 3;
        const mid = Math.floor(pageLimit / 2);

        if (number + mid >= totalPages) {
            index = totalPages - pageLimit + 1;
        } else if (number - mid < 1) {
            index = 1;
        } else {
            index = number - Math.floor(pageLimit / 2);
        }
        for (let i = index; i <= totalPages && pageLimit > 0; i++, pageLimit--) {
            if (i > 0) {
                elms.push(renderPageButton(i));
            }
        }
        return elms;
    };

    return props.page.totalElements > 0 ? (
        <div className="obc_grid obc_mt-2">
            <div className="obc_grid__col">{pageSizes.map(pageSize => renderPageSizeButton(pageSize))}</div>
            <div className="obc_grid__col-auto">
                <button type="button" key="prev" disabled={isFirstPage()} onClick={() => props.updatePage(number - 1)} className={'obc_btn'}>
                    {'‹'}
                </button>
                {renderPages()}
                <button type="button" key="next" disabled={isLastPage()} onClick={() => props.updatePage(number + 1)} className={'obc_btn'}>
                    {'›'}
                </button>
            </div>
        </div>
    ) : (
        <></>
    );
};

export default Pagination;
