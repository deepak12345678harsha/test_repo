import React, { FC } from 'react';

export type TableColumn<T> = {
    name: string;
    accessor?: keyof T;
    renderData?: (dataRow: T) => React.ReactElement;
    cellStyles?: React.CSSProperties;
};

export type TableProps<T> = {
    columns: TableColumn<T>[];
    data: T[];
};

const Table: FC<TableProps<any>> = props => {
    return (
        <table className="obc_table">
            <thead>
                <tr>
                    {props.columns.map((column, columnIndex) => {
                        return <th key={'column_' + columnIndex}>{column.name}</th>;
                    })}
                </tr>
            </thead>
            <tbody>
                {props.data?.length > 0 && (
                    <tr className="obc_table__spacer-row">
                        <td colSpan={props.columns.length} />
                    </tr>
                )}
                {props.data.map((dataRow, rowIndex) => {
                    return (
                        <tr key={'row_' + rowIndex}>
                            {props.columns.map((column, columnIndex) => {
                                const cellStyles = column.cellStyles || {};
                                return (
                                    <td key={'cell_' + rowIndex + '_' + columnIndex} style={cellStyles}>
                                        {column.accessor ? dataRow[column.accessor] : column.renderData && column.renderData(dataRow)}
                                    </td>
                                );
                            })}
                        </tr>
                    );
                })}
            </tbody>
        </table>
    );
};

export default Table;
