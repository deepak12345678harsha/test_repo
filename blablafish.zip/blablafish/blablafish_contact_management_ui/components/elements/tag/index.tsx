import React, { FC, useState } from 'react';
import styles from './index.module.css';

export type TagProps = {
    label: string;

    onCloseTag: (event: React.MouseEvent<HTMLButtonElement>) => void;
};

const Tag: FC<TagProps> = props => {
    const [hover, setHover] = useState(false);

    const tagClassNames = ['obc_tag'];

    if (!hover) {
        tagClassNames.push(styles.obc_tag__transparent);
    }

    return (
        <span
            className={tagClassNames.join(' ')}
            onMouseEnter={() => {
                setHover(true);
            }}
            onMouseLeave={() => {
                setHover(false);
            }}>
            <span className="obc_tag__text">{props.label}</span>
            {hover && <button className="obc_tag__close" data-testid="tag-close-button" onClick={props.onCloseTag}></button>}
        </span>
    );
};

export default Tag;
