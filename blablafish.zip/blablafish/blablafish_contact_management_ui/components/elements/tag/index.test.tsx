import { fireEvent, render, screen } from '@testing-library/react';
import Tag from './index';

describe('Tag Component', () => {
    it('render a tag', async () => {
        const mock = jest.fn();
        render(<Tag label="test" onCloseTag={mock} />);

        const tagElm = screen.getByText('test');
        expect(tagElm).toBeVisible();

        expect(tagElm.nextSibling).toBeNull();
    });

    it('render and hover a tag', async () => {
        const mock = jest.fn();
        render(<Tag label="test" onCloseTag={mock} />);

        const tagElm = screen.getByText('test');
        expect(tagElm).toBeVisible();
        expect(tagElm.nextSibling).toBeNull();

        fireEvent.mouseEnter(tagElm);

        const hoverTagElm = screen.getByText('test');
        expect(hoverTagElm).toBeVisible();
        expect(hoverTagElm.nextSibling).toBeVisible();

        fireEvent.mouseLeave(tagElm);

        const hoverLeaveTagElm = screen.getByText('test');
        expect(hoverLeaveTagElm).toBeVisible();
        expect(hoverLeaveTagElm.nextSibling).toBeNull();
    });

    it('click on close tag', async () => {
        const mock = jest.fn();
        render(<Tag label="test" onCloseTag={mock} />);

        let tagElm = screen.getByText('test');
        expect(tagElm).toBeVisible();
        expect(tagElm.nextSibling).toBeNull();

        fireEvent.mouseEnter(tagElm);

        const button = screen.getByTestId('tag-close-button');
        fireEvent.click(button);

        tagElm = screen.getByText('test');
        expect(tagElm).toBeVisible();
        expect(mock).toBeCalled();
    });
});
