import React from 'react';

type ToggleProps = {
    checked: boolean;
    id: string;
    handleChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
};
const Toggle = (props: ToggleProps) => {
    return (
        <div className="obc_toggle">
            <input className="obc_toggle__input" id={props.id} type="checkbox" onChange={props.handleChange} checked={props.checked} />
            <label className="obc_toggle__label" htmlFor={props.id + ''}>
                <span className="obc_toggle__switch" data-testid="toggle" />
            </label>
        </div>
    );
};

export default Toggle;
