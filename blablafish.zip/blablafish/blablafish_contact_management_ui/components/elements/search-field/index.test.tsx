import { fireEvent, render, screen } from '@testing-library/react';
import SearchField from './index';

describe('should test SearchField component', () => {
    it('should render SearchField', () => {
        render(<SearchField defaultValue="test" search={jest.fn()} />);

        const htmlElement = screen.queryByPlaceholderText('Suchen') as HTMLInputElement;
        expect(htmlElement).toBeVisible();
        expect(htmlElement.value).toBe('test');

        fireEvent.change(htmlElement, {
            target: { value: 'temp' },
        });
        expect(htmlElement.value).toBe('temp');
    });
});
