import React, { FC, useState } from 'react';
import styles from './index.module.css';

export type SearchFieldProps = {
    placeholder?: string;
    defaultValue?: string;
    search: (value: string) => void;
};

const SearchField: FC<SearchFieldProps> = props => {
    const [searchString, setSearchString] = useState(props.defaultValue ? props.defaultValue : '');

    const onFormSubmit = (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();
        event.stopPropagation();
        props.search(searchString);
    };

    const clearSearch = () => {
        setSearchString('');
        props.search('');
    };

    return (
        <form className={'obc_form-group'} onSubmit={onFormSubmit}>
            <div className={'obc_grid'}>
                <div className={'obc_grid__col-1-of-2 ' + styles.no_margin_right + ' ' + styles.pos_relative}>
                    <input
                        className={'obc_form__input ' + styles.input}
                        type="text"
                        name="search"
                        value={searchString}
                        placeholder={props.placeholder || 'Suchen'}
                        onChange={e => setSearchString(e.target.value)}
                        data-testid="add-users-search-input"
                    />
                    {searchString && (
                        <span className={'obc_icon-close ' + styles.search_input_delete_icon} data-testid="remove-search-text-button" onClick={() => clearSearch()} title="" />
                    )}
                </div>
                <div className={'obc_grid__col-2-of-2 ' + styles.no_margin_left}>
                    <button type="submit" className={'obc_btn-primary ' + styles.button} data-testid="search-button">
                        <i className="obc_icon-search" />
                    </button>
                </div>
            </div>
        </form>
    );
};

export default SearchField;
