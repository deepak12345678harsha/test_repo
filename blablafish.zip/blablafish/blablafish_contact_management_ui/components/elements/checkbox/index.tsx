type CheckboxProps = {
    checked: boolean;
    handleChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
};
const Checkbox = (props: CheckboxProps) => {
    return (
        <div data-testid="checkbox" className="obc_form__check">
            <input
                data-testid="checkbox-input"
                className="obc_form__check-input"
                type="checkbox"
                name="checkbox-group"
                id="checkboxOne"
                checked={props.checked}
                onChange={props.handleChange}
            />
        </div>
    );
};

export default Checkbox;
