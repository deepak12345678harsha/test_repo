import { FC } from 'react';
import { TableColumn, TableProps } from '@api/table';

const Table: FC<TableProps<any>> = props => {
    const renderHeader = (column: TableColumn<any>, index: number) => {
        let attr = {};
        if (column.getHeaderCellAttributes) {
            attr = column.getHeaderCellAttributes();
        }
        return (
            <th key={'column_' + index} {...attr} data-testid="table-header">
                {column.renderHeader ? column.renderHeader() : column.name}
            </th>
        );
    };

    return (
        <div className="nptn_table" data-id="nptn_table">
            <table className="obc_table">
                <thead>
                    <tr>
                        {props.columns.map((column, index) => {
                            return renderHeader(column, index);
                        })}
                    </tr>
                </thead>
                <tbody>
                    <tr className="obc_table__spacer-row">
                        <td colSpan={props.columns.length} />
                    </tr>
                    {props.data?.map((row, rowIndex) => {
                        const uniqueId = rowIndex;
                        return (
                            <tr key={'row_' + uniqueId} data-testid="row">
                                {props.columns.map((column, colIndex) => {
                                    let attr = {};
                                    if (column.getCellAttributes) {
                                        attr = column.getCellAttributes(row);
                                    }
                                    if (column.primaryColumn) {
                                        return (
                                            <th {...attr} key={'cell_' + uniqueId + '_' + colIndex}>
                                                {column.renderData ? column.renderData(row[column.cellKey], row) : row[column.cellKey]}
                                            </th>
                                        );
                                    } else {
                                    }
                                    return (
                                        <td {...attr} key={'cell_' + uniqueId + '_' + colIndex}>
                                            {column.renderData ? column.renderData(row[column.cellKey], row) : row[column.cellKey]}
                                        </td>
                                    );
                                })}
                            </tr>
                        );
                    })}
                </tbody>
            </table>
        </div>
    );
};

export default Table;
