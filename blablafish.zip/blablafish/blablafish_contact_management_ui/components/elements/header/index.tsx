import { FC, PropsWithChildren } from 'react';

export type ProjectProps = {
    text: string;
};

const Header: FC<PropsWithChildren<ProjectProps>> = props => {
    return (
        <div className="obc_title-container obc_grid obc_grid--align-items-center obc_m-0">
            <div className="obc_grid--align-items-center obc_grid__col obc_text-left">
                <h1 className="obc_heading1">{props.text}</h1>
            </div>
            {props.children}
        </div>
    );
};

export default Header;
