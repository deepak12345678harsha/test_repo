import { FC } from 'react';
import styles from './index.module.css';

export type SpinnerProps = {
    size?: 'large' | 'small';
};

const Spinner: FC<SpinnerProps> = props => {
    return (
        <div className={styles.spinner_component_wrapper}>
            <div className={styles.spinner_background}>
                <div className={`obc_spinner obc_spinner--${props.size}`} role="spinner" />
            </div>
        </div>
    );
};

export default Spinner;
