import React, { FC, PropsWithChildren } from 'react';
import Spinner from '@components/elements/spinner/index';

export type SpinnerProps = {
    size?: 'large' | 'small';
    show?: boolean;
};

const SpinnerWrapper: FC<PropsWithChildren<SpinnerProps>> = props => {
    return <div>{props.show ? <Spinner size={props.size} /> : props.children}</div>;
};

export default SpinnerWrapper;
