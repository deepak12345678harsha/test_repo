import React, { FC, PropsWithChildren } from 'react';

type MaybePromise<T> = Promise<T> | T;

export type ModalProps = {
    title: string;

    saveText: string;
    saveFn: (event: React.MouseEvent<HTMLElement>) => MaybePromise<void>;

    closeText?: string;
    closeFn?: (event: React.MouseEvent<HTMLElement>) => void;
    isSaveDisabled?: boolean;

    modelClassName?: string;
};

const Modal: FC<PropsWithChildren<ModalProps>> = props => {
    const fixUndefined = (style?: string) => {
        if (!style) {
            return '';
        }
        return style;
    };

    const renderSaveButton = () => {
        return (
            <button disabled={props.isSaveDisabled} onClick={props.saveFn} type="button" data-testid="modal-save-button" className={`obc_btn-primary`}>
                {props.saveText}
            </button>
        );
    };

    return (
        <div className="obc_modal-bg" data-testid="modal">
            <div className={`obc_modal ${fixUndefined(props.modelClassName)}`}>
                <div className="obc_modal__header">
                    <h2 className="obc_heading2">{props.title}</h2>
                    <button onClick={props.closeFn} type="button" className="obc_modal__close" data-testid="modal-header-close-button">
                        <span className="obc_icon-close" />
                    </button>
                </div>
                <div className="obc_modal__body" data-testid="modal-body">
                    <div className="obc_copy100">
                        <span>{props.children}</span>
                    </div>
                </div>
                <div className="obc_modal__footer">
                    {props.closeText && (
                        <button onClick={props.closeFn} type="button" className="obc_btn obc_mr-2" data-testid="modal-footer-close-button">
                            {props.closeText}
                        </button>
                    )}
                    {renderSaveButton()}
                </div>
            </div>
        </div>
    );
};

export default Modal;
