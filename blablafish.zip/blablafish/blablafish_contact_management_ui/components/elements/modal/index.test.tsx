import { act, fireEvent, render, screen } from '@testing-library/react';
import Modal from './index';

describe('Model component', () => {
    it('render model component', async () => {
        await act(async () => {
            render(<Modal title={'Test'} saveText={'Save'} saveFn={jest.fn()} isSaveDisabled={false} />);
        });
        const modelTitle = screen.getByText('Test');
        expect(modelTitle).toBeVisible();
        const saveButton = screen.getByText('Save');
        expect(saveButton).toBeVisible();
    });

    it('render model component with close', async () => {
        await act(async () => {
            render(<Modal title={'Test'} saveText={'Save'} saveFn={jest.fn()} closeText={'Close'} closeFn={jest.fn()} isSaveDisabled={false} />);
        });
        const modelTitle = screen.getByText('Test');
        expect(modelTitle).toBeVisible();
        const closeButton = screen.getByText('Close');
        expect(closeButton).toBeVisible();
    });

    it('render model component with model class', async () => {
        await act(async () => {
            render(<Modal title={'Test'} saveText={'Save'} saveFn={jest.fn()} modelClassName={'model_test'} isSaveDisabled={false} />);
        });
        expect(screen.getByTestId('modal')).toBeVisible();
    });

    it('render model component and click save', async () => {
        const saveFn = jest.fn();
        await act(async () => {
            render(<Modal title={'Test'} saveText={'Save'} saveFn={saveFn} isSaveDisabled={false} />);
        });

        const saveButton = screen.getByText('Save');
        expect(saveButton).toBeVisible();
        fireEvent.click(saveButton);

        expect(saveFn).toBeCalledTimes(1);
    });

    it('render model component and click close', async () => {
        const closeFn = jest.fn();
        await act(async () => {
            render(<Modal title={'Test'} saveText={'Save'} saveFn={jest.fn()} closeText={'Close'} closeFn={closeFn} isSaveDisabled={false} />);
        });

        const closeButton = screen.getByText('Close');
        expect(closeButton).toBeVisible();
        fireEvent.click(closeButton);

        expect(closeFn).toBeCalledTimes(1);
    });
});
