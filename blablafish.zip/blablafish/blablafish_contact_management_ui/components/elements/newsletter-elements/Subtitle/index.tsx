import React, { FC } from 'react';

export type SubTitleProps = {
    text: string;
};

const Subtitle: FC<SubTitleProps> = props => {
    return <div className="nptn_subtitle obc_copy100">{props.text}</div>;
};
export default Subtitle;
