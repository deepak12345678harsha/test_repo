import { FC } from 'react';
import styles from './index.module.css';

export type CheckboxProps = {
    style?: React.CSSProperties;
    handleChange?: (event: React.ChangeEvent<HTMLInputElement>) => void;
    disabled?: boolean;
    isActive: boolean;
    callback: (arg: boolean) => void;
    title?: string;
    titleJSX?: any;
    hint?: string;
    id?: string;
};

const Checkbox: FC<CheckboxProps> = props => {
    return (
        <div className="obc_form-group">
            <div className="obc_form__check">
                <div className={styles.text}>
                    <label className="obc_form__label obc_copy100">
                        <div className={styles.input}>
                            <input
                                disabled={props.disabled}
                                className="obc_form__check-input"
                                data-testid="subscription_checkbox"
                                type="checkbox"
                                name="checkbox-group"
                                checked={props.isActive}
                                onChange={e => props.callback(e.target.checked)}
                            />
                        </div>
                        {props.title || props.titleJSX}
                    </label>
                    <span className="obc_form__hint-text">{props.hint}</span>
                </div>
            </div>
        </div>
    );
};

export default Checkbox;
