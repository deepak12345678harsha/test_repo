import { act, render, screen } from '@testing-library/react';
import Checkbox from '@components/elements/newsletter-elements/Checkbox/index';

describe('should test checkbox component', () => {
    it('render checkbox', async () => {
        await act(async () => {
            render(
                <Checkbox
                    isActive={true}
                    callback={() => {
                        return null;
                    }}
                />,
            );
        });
        expect(screen.getByTestId('subscription_checkbox')).toBeVisible();
    });
});
