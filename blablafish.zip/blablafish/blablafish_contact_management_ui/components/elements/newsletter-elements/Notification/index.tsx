import { FC } from 'react';

export enum NotificationType {
    SUCCESS = 'success',
    FAILURE = 'error',
    INFO = 'info',
}

export type NotificationProps = {
    notificationType: string;
    text: string;
    subtext?: string;
    btnCloseAction: any;
};

const Notification: FC<NotificationProps> = props => {
    let className = 'obc_alert nptn_notification ';
    if (props.notificationType === 'success') {
        className = className + 'obc_alert--success';
    } else if (props.notificationType === 'error') {
        className = className + 'obc_alert--error';
    } else if (props.notificationType === 'info') {
        className = className + 'obc_alert--info';
    }

    return (
        <div className={className} data-testid="newsletter_notification_div">
            <i className="obc_alert__icon"></i>
            <div className="obc_alert__text">
                <strong>{props.text}</strong> {props.subtext}
            </div>
            <button onClick={props.btnCloseAction} className="obc_alert__close" data-testid="newsletter_notification_close"></button>
        </div>
    );
};

export default Notification;
