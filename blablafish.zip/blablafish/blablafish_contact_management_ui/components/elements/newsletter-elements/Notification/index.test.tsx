import { act, render, screen } from '@testing-library/react';
import Notification from '@components/elements/newsletter-elements/Notification';

describe('should test Notification component', () => {
    it('render checkbox', async () => {
        await act(async () => {
            render(
                <Notification
                    notificationType={'info'}
                    text={'text'}
                    subtext={'subtext'}
                    btnCloseAction={() => {
                        return null;
                    }}
                />,
            );
        });
        expect(screen.getByTestId('newsletter_notification_div')).toBeVisible();
    });
});
