import { FC } from 'react';

export type TitleProps = {
    text: string;
};

const Title: FC<TitleProps> = props => {
    return <div className="obc_heading3">{props.text}</div>;
};

export default Title;
