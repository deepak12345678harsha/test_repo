import { act, render, screen } from '@testing-library/react';
import Button from '@components/elements/newsletter-elements/Button/index';

describe('should test Button component', () => {
    it('render button', async () => {
        await act(async () => {
            render(
                <Button
                    isPrimary={false}
                    withIcon={true}
                    title="title"
                    onClick={() => {
                        return null;
                    }}
                />,
            );
        });
        const button = screen.getByTestId('subscription_button');
        expect(button).toBeVisible();
    });
});
