import { FC } from 'react';

export type ButtonProps = {
    isPrimary: boolean;
    withIcon?: boolean;
    disabled?: boolean;
    title: string;
    onClick: () => void;
};

const Button: FC<ButtonProps> = props => {
    let className = 'obc_btn';
    if (props.isPrimary) {
        className = 'obc_btn-primary';
    }

    let icon = null;
    if (props.withIcon) {
        icon = <i className="obc_icon-plus-bold obc_mr-1"></i>;
    }

    return (
        <button data-testid="subscription_button" type="button" className={className} onClick={props.onClick} disabled={props.disabled}>
            {icon}
            {props.title}
        </button>
    );
};

export default Button;
