import { act, render, screen } from '@testing-library/react';
import EmailPreferencesPage from '../pages/email-preferences';
import { EDITABLE_MAIL_PREFERENCE_TITLE } from '../utils/text-constants';

describe('Email Preference', () => {
    it('renders a heading', async () => {
        await act(async () => {
            render(<EmailPreferencesPage />);
        });
        expect(screen.getByText(EDITABLE_MAIL_PREFERENCE_TITLE)).toBeVisible();
    });
});
