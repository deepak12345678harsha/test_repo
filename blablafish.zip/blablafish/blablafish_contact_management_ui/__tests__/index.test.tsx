import { act, render } from '@testing-library/react';
import TopicsOverviewPage from '../pages';

describe('Home', () => {
    it('renders a heading', async () => {
        await act(async () => {
            render(<TopicsOverviewPage />);
        });
    });
});
