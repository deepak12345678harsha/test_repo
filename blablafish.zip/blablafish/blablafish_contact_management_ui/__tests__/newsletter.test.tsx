import { act, render, screen } from '@testing-library/react';
import NewsletterPage from '../pages/newsletter';

describe('Newsletter', () => {
    it('renders a heading', async () => {
        await act(async () => {
            render(<NewsletterPage />);
        });
        expect(screen.getByText('Anmeldung OTTO-Market-Newsletter')).toBeVisible();
    });
});
