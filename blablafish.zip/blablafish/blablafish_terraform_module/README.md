# blablafish_terraform_module


## Tag a module
```
  git commit -m "${COMMIT_MESSAGE}"
  git tag "${NEW_GIT_TAG}"
  git push && git push --tags
