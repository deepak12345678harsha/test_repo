# blablafish_contact_management_realm

This repository is used for automated creation of mondodb triggers.

All the trigger configs are present in /triggers folder as json file per trigger.

These triggers configs are deployed automatically in atlas mongodb cluster with every code-commits.


