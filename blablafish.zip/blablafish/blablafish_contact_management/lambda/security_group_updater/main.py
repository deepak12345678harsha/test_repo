import boto3
from logging import getLogger, INFO
import asyncio
import os
import dns.resolver
logger = getLogger()
logger.setLevel(INFO)

region = os.environ["REGION"]
ec2_client = boto3.client('ec2', region)
ec2 = boto3.resource('ec2')

async def get_security_group_details():
    logger.info('Get details of security group')
    await asyncio.sleep(3)
    try:
        logger.info('Get details of security group')
        environment = os.environ["ENVIRONMENT"]
        response = ec2_client.describe_security_groups(
            Filters=[
                {
                    'Name': 'group-name',
                    'Values': [
                        f"{environment}-contactmanagement-alb-incoming",
                    ]
                },
            ]
        )
    except Exception as e:
        logger.info(e)

    return response

async def get_security_group_details_ui():
    logger.info('Get details of security group')
    await asyncio.sleep(3)
    try:
        logger.info('Get details of security group')
        environment = os.environ["ENVIRONMENT"]
        response = ec2_client.describe_security_groups(
            Filters=[
                {
                    'Name': 'group-name',
                    'Values': [
                        f"{environment}-contact-mgmt-ui-alb-incoming",
                    ]
                },
            ]
        )
    except Exception as e:
        logger.info(e)

    return response

def checkIfSgHasIngressRule(ip_permissions):
    if len(ip_permissions) > 0:
        return True
    return False

def checkIfIpHasChanged(ip_permissions, ips):
    # Check if the IPs of the host is already in the security group as an ingress rule
    ip_permissions = str(ip_permissions)
    logger.info('Current ip-permission of security-group: ' + ip_permissions)
    if len(ips) != len(ip_permissions):
        return True
    for ip in ips:
        ip = str(ip).replace('"', '')
        logger.info('Current ip of host: ' + ip)
        if ip not in ip_permissions:
            logger.info('Current ip: ' + ip + ' not in Security-Group. IPs will be added!')
            return True
    return False

def addIpsAsIngressRuleToSg(ips, security_group):
    for ip in ips:
        ip = str(ip).replace('"', '') + "/32"
        logger.info('IP: ' + ip + ' added')
        security_group.authorize_ingress(IpProtocol="tcp",CidrIp=ip,FromPort=443,ToPort=443)

def resolveIPs(hostnames):
    ipRanges = []
    for domain in hostnames:
        ips=dns.resolver.query(domain,"TXT").response.answer[0]
        for ip in ips:
            ipRanges.append(ip)
    return ipRanges

def updateSecurityGroup(sgId, hostnames):

    security_group = ec2.SecurityGroup(sgId)
    ip_permissions = security_group.ip_permissions

    # Get IPs of Host

    ips=resolveIPs(hostnames)

    sgHasIpPermissions=checkIfSgHasIngressRule(ip_permissions)
    ipsChanged=checkIfIpHasChanged(ip_permissions, ips)

    # Update Security Group if needed

    if not sgHasIpPermissions:
        addIpsAsIngressRuleToSg(ips, security_group)
        logger.info('IPs added for hostname ' + ','.join(hostnames))
        return "IPs added for hostname " + ','.join(hostnames)
    else:
        if ipsChanged:
            security_group.revoke_ingress(IpPermissions=security_group.ip_permissions)
            addIpsAsIngressRuleToSg(ips, security_group)
            logger.info('IPs updated for hostname ' + ','.join(hostnames))
            return "IPs updated for hostname " + ','.join(hostnames)
        else:
            logger.info('IPs not changed for hostname ' + ','.join(hostnames))
            return "IPs not changed for hostname " + ','.join(hostnames)

def lambda_handler(sns_event, _):
    logger.info(sns_event)

    environment = os.environ["ENVIRONMENT"]
    if environment == "develop":
       environment = "nonlive"

    print("Hello, World!"+ environment)
    allowedDomains = ["egress."+environment+".portal.otto.market.","egress."+environment+".internal.api.otto.market.",
        "egress."+environment+".internal.otto.market."]

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    #The describe api call gets details of our security group
    response = loop.run_until_complete(get_security_group_details())

    securityGroupId= response['SecurityGroups'][0]['GroupId']
    logger.info('SecurityGroup Ids: ' +securityGroupId)

    response_ui = loop.run_until_complete(get_security_group_details_ui())

    securityGroupIdUI= response_ui['SecurityGroups'][0]['GroupId']
    logger.info('SecurityGroup Ids UI :' +securityGroupIdUI)

    try:
        updateSecurityGroup(securityGroupId, allowedDomains)
        logger.info('The IPs were successfully updated')
        updateSecurityGroup(securityGroupIdUI, allowedDomains)
        logger.info('The IPs were successfully updated')
    except Exception as e:
        logger.info(e)