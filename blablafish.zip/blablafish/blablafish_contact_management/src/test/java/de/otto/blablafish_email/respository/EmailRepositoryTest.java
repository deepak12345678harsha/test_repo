package de.otto.blablafish_email.respository;

import static de.otto.blablafish_email.model.entity.Email.*;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import de.otto.blablafish_email.model.entity.Email;
import de.otto.blablafish_email.model.entity.EmailStatus;
import de.otto.blablafish_email.model.entity.EmailStatusHistoryEntry;
import java.time.Instant;
import java.util.Collections;
import java.util.List;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

class EmailRepositoryTest {

  private final MongoTemplate mongoTemplate = mock(MongoTemplate.class);
  private final EmailRepository emailRepository = new EmailRepository(mongoTemplate);

  @Test
  public void shouldFindAndModifyByEmailIdAndStatus() {
    Instant time = Instant.now();
    String emailId = "629089ba391a524f0b687f4a";

    Email email = getEmail(emailId, time);
    EmailStatusHistoryEntry historyEntry = EmailStatusHistoryEntry.of(EmailStatus.SENDING, time);

    ArgumentCaptor<Query> queryCaptor = ArgumentCaptor.forClass(Query.class);
    ArgumentCaptor<Update> updateDefinitionCaptor = ArgumentCaptor.forClass(Update.class);

    Query expectedQuery =
        Query.query(Criteria.where("id").is(emailId))
            .addCriteria(Criteria.where("status").is(email.getStatus()));
    Update expectedUpdateDefinition =
        new Update()
            .set("status", historyEntry.getStatus())
            .set("statusTimestamp", historyEntry.getDate())
            .addToSet("statusHistory", historyEntry);

    when(mongoTemplate.findAndModify(any(Query.class), any(Update.class), eq(Email.class)))
        .thenReturn(email);

    emailRepository.findByIdStatusAndSaveEmailStatusHistory(
        emailId, email.getStatus(), historyEntry);

    verify(mongoTemplate)
        .findAndModify(queryCaptor.capture(), updateDefinitionCaptor.capture(), eq(Email.class));
    assertThat(queryCaptor.getValue()).isEqualTo(expectedQuery);
    assertThat(updateDefinitionCaptor.getValue()).isEqualTo(expectedUpdateDefinition);
  }

  @Test
  public void shouldFindByEmailIdAndSetAwsMessageId() {
    String emailId = "629089ba391a524f0b687f4a";
    Email email = getEmail(emailId, Instant.now());
    ArgumentCaptor<Query> queryCaptor = ArgumentCaptor.forClass(Query.class);
    ArgumentCaptor<Update> updateDefinitionCaptor = ArgumentCaptor.forClass(Update.class);

    Query expectedQuery = Query.query(Criteria.where("id").is(emailId));
    Update expectedUpdateDefinition = new Update().set("awsMessageId", email.getAwsMessageId());

    emailRepository.findByIdAndSetAwsMessageId(emailId, email.getAwsMessageId());

    verify(mongoTemplate)
        .findAndModify(queryCaptor.capture(), updateDefinitionCaptor.capture(), eq(Email.class));
    assertThat(queryCaptor.getValue()).isEqualTo(expectedQuery);
    assertThat(updateDefinitionCaptor.getValue()).isEqualTo(expectedUpdateDefinition);
  }

  private Email getEmail(String emailId, Instant time) {
    return Email.builder()
        .id(emailId)
        .awsMessageId("awsMessageId")
        .mailRequestId(new ObjectId(emailId))
        .htmlBody(encryptedHtmlBody("htmlBody"))
        .textBody(encryptedTextBody("textBody"))
        .subject(encryptedSubject("subject"))
        .toAddress(encryptedToAddress("toAddress"))
        .fromAddress(Email.encryptedFromAddress("fromAddress"))
        .createdAt(time)
        .sendDate(time)
        .status(EmailStatus.READY_TO_SEND)
        .statusTimestamp(time)
        .statusHistory(List.of(EmailStatusHistoryEntry.of(EmailStatus.READY_TO_SEND, time)))
        .attachmentIds(Collections.emptySet())
        .build();
  }
}
