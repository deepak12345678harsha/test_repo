package de.otto.blablafish_email.listener;

import static org.assertj.core.api.Assertions.assertThat;
import static org.testcontainers.shaded.org.awaitility.Awaitility.await;

import com.amazonaws.services.sqs.AmazonSQS;
import de.otto.blablafish_email.model.entity.Email;
import de.otto.blablafish_email.model.entity.EmailRecipient;
import de.otto.blablafish_email.model.entity.EmailRequest;
import de.otto.blablafish_email.model.entity.EmailRequestStatus;
import de.otto.blablafish_email.model.entity.EmailRequester;
import de.otto.blablafish_email.model.entity.EmailStatus;
import de.otto.blablafish_email.model.entity.EmailStatusHistoryEntry;
import de.otto.blablafish_email.model.entity.SESEvent;
import java.io.IOException;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.query.BasicQuery;

class SESEventsListenerIT extends AbstractContainerIT {

  final Instant testTime = Instant.ofEpochSecond(1605540139);
  @Autowired private AmazonSQS sqs;

  @Value("${sesEvents.queueUrl}")
  private String queueName;

  @Test
  void testHandleDeliveryEvent() throws IOException {
    var awsMessageId = "010701763011ab6e-9329c3f6-d01c-499c-8519-e388fe7b3a7c-000000";
    var payload = new Document("title", "hey hey!");
    var recipient = generateRecipient("mc1234@yahoo.com", "Cameron", "Mcmahon", "111", testTime);
    var mailRequest =
        generateMailRequest(
            payload, 1, List.of(recipient), new EmailRequester("test-client", "test-sub"));
    var mail = generateMail(mailRequest, recipient, awsMessageId, testTime);

    mongoTemplate.insert(mail);
    mongoTemplate.insert(mailRequest);

    var queueUrl = sqs.getQueueUrl(queueName).getQueueUrl();
    var sesEventMessage = readFileAsString("messaging/sesevents/delivery.json");
    sqs.sendMessage(queueUrl, sesEventMessage);

    await()
        .atMost(5, TimeUnit.SECONDS)
        .untilAsserted(
            () -> {
              assertThat(sqs.receiveMessage(queueUrl).getMessages()).isEmpty();
              assertThat(mongoTemplate.findById(mail.getId(), Email.class).getStatusHistory())
                  .hasSize(2);
            });

    final EmailRequest actualMailRequest =
        mongoTemplate.findById(mailRequest.getRequestId(), EmailRequest.class);
    final Email actualMail = mongoTemplate.findById(mail.getId(), Email.class);
    final SESEvent actualSESEvent =
        mongoTemplate.findOne(
            new BasicQuery(new Document("awsMessageId", awsMessageId)), SESEvent.class);

    assertThat(actualMailRequest).isNotNull();
    assertThat(actualMailRequest.getRecipients().get(0).getEmailStatusHistoryEntry().getStatus())
        .isEqualTo(EmailStatus.AWS_DELIVERY);
    assertThat(actualMailRequest.getStatus())
        .isEqualTo(EmailRequestStatus.MINIMUM_ONE_MAIL_DELIVERED);

    assertThat(actualMail).isNotNull();
    assertThat(actualMail.getStatus()).isEqualTo(EmailStatus.AWS_DELIVERY);
    assertThat(actualMail.getStatusHistory().size()).isEqualTo(2);
    assertThat(actualSESEvent).isNotNull();
  }

  @Test
  void testHandleClickEvent() throws IOException {
    var awsMessageId = "010701763011ab6e-9329c3f6-d01c-499c-8519-e388fe7b3a7c-000000";
    var payload = new Document("title", "hey hey!");
    var recipient = generateRecipient("mc1234@yahoo.com", "Cameron", "Mcmahon", "111", testTime);
    var mailRequest =
        generateMailRequest(
            payload, 1, List.of(recipient), new EmailRequester("test-client", "dddssss"));
    var mail = generateMail(mailRequest, recipient, awsMessageId, testTime);
    mongoTemplate.insert(mail);
    mongoTemplate.insert(mailRequest);
    var queueUrl = sqs.getQueueUrl(queueName).getQueueUrl();
    var sesEventMessage = readFileAsString("messaging/sesevents/click.json");

    sqs.sendMessage(queueUrl, sesEventMessage);

    await()
        .atMost(5, TimeUnit.SECONDS)
        .untilAsserted(
            () -> {
              assertThat(sqs.receiveMessage(queueUrl).getMessages()).isEmpty();
              assertThat(mongoTemplate.findById(mail.getId(), Email.class).getStatusHistory())
                  .hasSize(2);
            });
    var actualMailRequest = mongoTemplate.findById(mailRequest.getRequestId(), EmailRequest.class);
    var actualMail = mongoTemplate.findById(mail.getId(), Email.class);
    var actualSESEvent =
        mongoTemplate.findOne(
            new BasicQuery(new Document("awsMessageId", awsMessageId)), SESEvent.class);

    assertThat(actualMailRequest).isNotNull();
    assertThat(actualMailRequest.getRecipients().get(0).getEmailStatusHistoryEntry().getStatus())
        .isEqualTo(EmailStatus.AWS_CLICK);
    assertThat(actualMailRequest.getStatus()).isEqualTo(EmailRequestStatus.ACCEPTED);

    assertThat(actualMail).isNotNull();
    assertThat(actualMail.getStatus()).isEqualTo(EmailStatus.AWS_CLICK);
    assertThat(actualMail.getStatusHistory().size()).isEqualTo(2);

    assertThat(actualSESEvent).isNotNull();
  }

  @Test
  void testHandleAutoReplyEvent() throws IOException {
    var awsMessageId = "0107018017733849-632b55a4-d8d2-42ea-a2cf-f1471452867a-000000";
    var payload = new Document("title", "test");
    var recipient = generateRecipient("test@gmail.com", "test", "user", "111", testTime);
    var mailRequest =
        generateMailRequest(
            payload, 1, List.of(recipient), new EmailRequester("test-client", "testSub"));
    var mail = generateMail(mailRequest, recipient, awsMessageId, testTime);

    mongoTemplate.insert(mail);
    mongoTemplate.insert(mailRequest);

    var queueUrl = sqs.getQueueUrl(queueName).getQueueUrl();
    var sesEventMessage = readFileAsString("messaging/sesevents/autoReply.json");

    sqs.sendMessage(queueUrl, sesEventMessage);

    await()
        .atMost(5, TimeUnit.SECONDS)
        .untilAsserted(
            () -> {
              assertThat(sqs.receiveMessage(queueUrl).getMessages()).isEmpty();
              assertThat(mongoTemplate.findById(mail.getId(), Email.class).getStatusHistory())
                  .hasSize(2);
            });
    var actualMailRequest = mongoTemplate.findById(mailRequest.getRequestId(), EmailRequest.class);
    var actualMail = mongoTemplate.findById(mail.getId(), Email.class);
    var actualSESEvent =
        mongoTemplate.findOne(
            new BasicQuery(new Document("awsMessageId", awsMessageId)), SESEvent.class);
    assertThat(actualMailRequest).isNotNull();
    assertThat(actualMailRequest.getRecipients().get(0).getEmailStatusHistoryEntry().getStatus())
        .isEqualTo(EmailStatus.READY_TO_SEND);
    assertThat(actualMailRequest.getStatus()).isEqualTo(EmailRequestStatus.ACCEPTED);

    assertThat(actualMail).isNotNull();
    assertThat(actualMail.getStatus()).isEqualTo(EmailStatus.AWS_BOUNCE);
    assertThat(actualMail.getStatusHistory().size()).isEqualTo(2);

    assertThat(actualSESEvent).isNotNull();
  }

  @Test
  void testHandleClickEventWithoutUpdatingRecipientEmailStatus() throws IOException {
    var awsMessageId = "010701763011ab6e-9329c3f6-d01c-499c-8519-e388fe7b3a7c-000000";
    var payload = new Document("title", "hey hey!");
    var recipient =
        generateRecipient("mc1234@yahoo.com", "Cameron", "Mcmahon", "111", Instant.now());
    var mailRequest =
        generateMailRequest(
            payload, 1, List.of(recipient), new EmailRequester("test-client", "dddssss"));
    var mail = generateMail(mailRequest, recipient, awsMessageId, Instant.now());
    mongoTemplate.insert(mail);
    mongoTemplate.insert(mailRequest);
    var queueUrl = sqs.getQueueUrl(queueName).getQueueUrl();
    var sesEventMessage = readFileAsString("messaging/sesevents/click.json");

    sqs.sendMessage(queueUrl, sesEventMessage);

    await()
        .atMost(5, TimeUnit.SECONDS)
        .untilAsserted(
            () -> {
              assertThat(sqs.receiveMessage(queueUrl).getMessages()).isEmpty();
              assertThat(mongoTemplate.findById(mail.getId(), Email.class).getStatusHistory())
                  .hasSize(2);
            });
    var actualMailRequest = mongoTemplate.findById(mailRequest.getRequestId(), EmailRequest.class);
    var actualMail = mongoTemplate.findById(mail.getId(), Email.class);
    var actualSESEvent =
        mongoTemplate.findOne(
            new BasicQuery(new Document("awsMessageId", awsMessageId)), SESEvent.class);
    assertThat(actualMailRequest).isNotNull();
    assertThat(actualMailRequest.getRecipients().get(0).getEmailStatusHistoryEntry().getStatus())
        .isEqualTo(EmailStatus.READY_TO_SEND);
    assertThat(actualMail).isNotNull();
    assertThat(actualMail.getStatus()).isEqualTo(EmailStatus.READY_TO_SEND);
    assertThat(actualMail.getStatusHistory().size()).isEqualTo(2);
    assertThat(actualMail.getStatusHistory().get(0).getStatus())
        .isEqualTo(EmailStatus.READY_TO_SEND);
    assertThat(actualMail.getStatusHistory().get(1).getStatus()).isEqualTo(EmailStatus.AWS_CLICK);
    assertThat(actualSESEvent).isNotNull();
  }

  private EmailRecipient generateRecipient(
      String email, String firstName, String lastName, String partnerId, Instant statusTimestamp) {
    return EmailRecipient.builder()
        .emailId(UUID.randomUUID().toString())
        .emailAddress(EmailRecipient.encryptEmail(email))
        .firstName(EmailRecipient.encryptFirstName(firstName))
        .lastName(EmailRecipient.encryptLastName(lastName))
        .newsletterAccepted(false)
        .partnerId(partnerId)
        .emailStatusHistoryEntry(
            EmailStatusHistoryEntry.of(EmailStatus.READY_TO_SEND, statusTimestamp))
        .build();
  }

  private EmailRequest generateMailRequest(
      Document payload,
      Integer topicId,
      List<EmailRecipient> recipients,
      EmailRequester requester) {
    return EmailRequest.builder()
        .requestId(new ObjectId())
        .topicId(topicId)
        .createdAt(testTime)
        .recipients(recipients)
        .payload(EmailRequest.encryptPayload(payload))
        .requester(requester)
        .status(EmailRequestStatus.ACCEPTED)
        .build();
  }

  private Email generateMail(
      EmailRequest mailRequest,
      EmailRecipient recipient,
      String awsMessageId,
      Instant statusTimestamp) {
    Map<String, Object> payload = mailRequest.getPayload().getValue();

    Map<String, Object> userVariables =
        Map.of(
            "firstName", recipient.getFirstName().getValue(),
            "lastName", recipient.getLastName().getValue(),
            "email", recipient.getEmailAddress().getValue(),
            "partnerId", recipient.getPartnerId(),
            "newsletterAccepted", recipient.getNewsletterAccepted());
    payload.put("user", userVariables);

    var textBody = UUID.randomUUID().toString();
    var htmlBody = UUID.randomUUID().toString();
    var subject = UUID.randomUUID().toString();

    return Email.builder()
        .id(recipient.getEmailId())
        .awsMessageId(awsMessageId)
        .mailRequestId(mailRequest.getRequestId())
        .htmlBody(Email.encryptedHtmlBody(htmlBody))
        .textBody(Email.encryptedTextBody(textBody))
        .subject(Email.encryptedSubject(subject))
        .toAddress(Email.encryptedToAddress(recipient.getEmailAddress().getValue()))
        .fromAddress(Email.encryptedFromAddress("no-reply@example.org"))
        .createdAt(testTime)
        .sendDate(testTime)
        .status(EmailStatus.READY_TO_SEND)
        .statusTimestamp(statusTimestamp)
        .statusHistory(
            List.of(EmailStatusHistoryEntry.of(EmailStatus.READY_TO_SEND, statusTimestamp)))
        .build();
  }
}
