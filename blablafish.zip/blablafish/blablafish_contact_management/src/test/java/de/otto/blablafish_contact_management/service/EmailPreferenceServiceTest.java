package de.otto.blablafish_contact_management.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

import de.otto.blablafish_contact_management.exception.SubscriberDoesNotExistException;
import de.otto.blablafish_contact_management.model.dto.UpdateEmailPreferenceRequestDTO;
import de.otto.blablafish_contact_management.model.dto.UserPrincipal;
import de.otto.blablafish_contact_management.model.entity.EmailPreference;
import de.otto.blablafish_contact_management.model.entity.Subscriber;
import de.otto.blablafish_contact_management.respository.EmailPreferenceRepository;
import de.otto.blablafish_contact_management.respository.SubscriberRepository;
import de.otto.blablafish_contact_management.respository.TopicRepository;
import de.otto.blablafish_contact_management.testDataConfig.SubscriberTestConfig;
import de.otto.blablafish_contact_management.testDataConfig.TopicTestBuilder;
import java.time.Instant;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class EmailPreferenceServiceTest {

  private EmailPreferenceService emailPreferenceService;

  @Mock private TopicRepository topicRepository;

  @Mock private SubscriberRepository subscriberRepository;

  @Mock private EmailPreferenceRepository emailPreferenceRepository;

  @BeforeEach
  public void setEmailPreferenceService() {
    emailPreferenceService =
        new EmailPreferenceService(
            subscriberRepository, emailPreferenceRepository, topicRepository);
  }

  @Test
  void shouldGetAllEmailPreferencesWhenUserFound() throws SubscriberDoesNotExistException {
    Subscriber subscriber = new SubscriberTestConfig().subscriberBuilder().build();
    when(subscriberRepository.findByEmail(anyString())).thenReturn(Optional.ofNullable(subscriber));
    when(topicRepository.findAll(true, subscriber.getEffectiveRoleIds()))
        .thenReturn(TopicServiceTest.getAllTopics(false));
    when(emailPreferenceRepository.findAll(any())).thenReturn(Collections.emptyList());
    UserPrincipal principal = new UserPrincipal(null, null, null, null, "email@email.com");
    var result = emailPreferenceService.getAllEmailPreferencesForSubscriber(principal);
    assertThat(result.size()).isEqualTo(2);
  }

  @Test
  void shouldGetAllEmailPreferencesWhenUserNotFound() {
    when(subscriberRepository.findByEmail(anyString())).thenReturn(Optional.empty());
    UserPrincipal principal = new UserPrincipal(null, null, null, null, "email@email.com");
    try {
      emailPreferenceService.getAllEmailPreferencesForSubscriber(principal);
    } catch (SubscriberDoesNotExistException ex) {
      assertThat(ex.getMessage()).isEqualTo("Subscriber does not exist");
    }
  }

  @Test
  void shouldGetEmailPreferenceWithSubscriberSetPreferences()
      throws SubscriberDoesNotExistException {
    var subscriber = new SubscriberTestConfig().subscriberBuilder().build();
    boolean userOptedIn = false;
    var emailPreference =
        EmailPreference.builder()
            .subscriberId(subscriber.getUserId())
            .topicId(1)
            .lastUpdatedAt(Instant.now())
            .optIn(userOptedIn)
            .build();
    when(subscriberRepository.findByEmail(any())).thenReturn(Optional.of(subscriber));
    when(topicRepository.findAll(true, subscriber.getEffectiveRoleIds()))
        .thenReturn(TopicServiceTest.getAllTopics(false));
    when(emailPreferenceRepository.findAll(any())).thenReturn(List.of(emailPreference));
    var principal = new UserPrincipal(null, null, null, null, "email@email.com");
    var result = emailPreferenceService.getAllEmailPreferencesForSubscriber(principal);
    assertThat(result.size()).isEqualTo(2);
    assertThat(result.get(0).isOptIn()).isFalse();
  }

  @Test
  void shouldNotUpdateEmailPreferencesWhenSubscriberDoesNotExists() {
    var updateEmailPreferences = List.of(new UpdateEmailPreferenceRequestDTO(100, true));
    String email = "testuser1mail@otto.de";
    when(subscriberRepository.findByEmail(email)).thenReturn(Optional.empty());

    assertThatThrownBy(
            () -> emailPreferenceService.updateEmailPreferences(email, updateEmailPreferences))
        .isInstanceOf(SubscriberDoesNotExistException.class)
        .hasMessage("Subscriber does not exist");
    verify(emailPreferenceRepository, times(0)).upsertAll(any());
  }

  @Test
  void shouldNotUpdateEmailPreferencesWhenApplicableTopicNotFound()
      throws SubscriberDoesNotExistException {
    var subscriber = new SubscriberTestConfig().subscriberBuilder().build();
    var email = subscriber.getEmail().getValue();
    when(subscriberRepository.findByEmail(email)).thenReturn(Optional.of(subscriber));
    when(topicRepository.findAll(true, true, subscriber.getEffectiveRoleIds()))
        .thenReturn(Collections.emptyList());
    var updateEmailPreferences = List.of(new UpdateEmailPreferenceRequestDTO(100, true));
    emailPreferenceService.updateEmailPreferences(email, updateEmailPreferences);
    verify(emailPreferenceRepository).upsertAll(eq(Collections.emptyList()));
  }

  @Test
  void shouldUpdateEmailPreferenceWhenForValidTopicIds() throws SubscriberDoesNotExistException {
    var subscriber = new SubscriberTestConfig().subscriberBuilder().build();
    var topic = new TopicTestBuilder().topicBuilder().build();
    var email = subscriber.getEmail().getValue();
    var emailPreferenceRequestDTO = new UpdateEmailPreferenceRequestDTO(topic.getId(), true);
    when(subscriberRepository.findByEmail(email)).thenReturn(Optional.of(subscriber));
    when(topicRepository.findAll(true, true, subscriber.getEffectiveRoleIds()))
        .thenReturn(List.of(topic));
    emailPreferenceService.updateEmailPreferences(email, List.of(emailPreferenceRequestDTO));

    var expectedList = List.of(emailPreferenceRequestDTO.toEmailPreference(subscriber.getUserId()));
    var captor = ArgumentCaptor.forClass(List.class);
    verify(emailPreferenceRepository).upsertAll(captor.capture());
    assertThat(captor.getValue())
        .usingRecursiveComparison()
        .ignoringFields("lastUpdatedAt")
        .isEqualTo(expectedList);
  }
}
