package de.otto.blablafish_email.integrationtest;

import static de.otto.blablafish_email.utils.Constants.CONTACT_MANAGEMENT_EMAIL_READ_ROLE;
import static de.otto.blablafish_email.utils.Constants.CONTACT_MANAGEMENT_INTERNAL_EMAIL_WRITE_ROLE;
import static de.otto.blablafish_email.utils.Constants.CONTACT_MANAGEMENT_PARTNER_EMAIL_WRITE_ROLE;
import static de.otto.blablafish_email.utils.Constants.CONTACT_MANAGEMENT_USER_EMAIL_WRITE_ROLE;
import static io.restassured.RestAssured.with;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.matchesPattern;

import de.otto.blablafish_contact_management.config.Features;
import de.otto.blablafish_contact_management.integrationtest.helpers.JwtHelper;
import de.otto.blablafish_contact_management.model.dto.ErrorResponse;
import de.otto.blablafish_contact_management.model.dto.EventType;
import de.otto.blablafish_contact_management.model.entity.EmailPreference;
import de.otto.blablafish_contact_management.model.entity.Requester;
import de.otto.blablafish_contact_management.model.entity.Status;
import de.otto.blablafish_contact_management.model.entity.Subscriber;
import de.otto.blablafish_contact_management.model.entity.Topic;
import de.otto.blablafish_contact_management.respository.EmailPreferenceRepository;
import de.otto.blablafish_contact_management.respository.SubscriberRepository;
import de.otto.blablafish_contact_management.respository.TopicRepository;
import de.otto.blablafish_contact_management.testDataConfig.SubscriberTestConfig;
import de.otto.blablafish_contact_management.testDataConfig.TopicTestBuilder;
import de.otto.blablafish_email.listener.AbstractContainerIT;
import de.otto.blablafish_email.model.dto.EmailRecipientDTO;
import de.otto.blablafish_email.model.dto.EmailRequestDTO;
import de.otto.blablafish_email.model.dto.PostEmailToInternalRequest;
import de.otto.blablafish_email.model.dto.PostEmailToPartnerRequest;
import de.otto.blablafish_email.model.dto.PostEmailToUserRequest;
import de.otto.blablafish_email.model.entity.EmailRecipient;
import de.otto.blablafish_email.model.entity.EmailRequest;
import de.otto.blablafish_email.model.entity.EmailRequestStatus;
import de.otto.blablafish_email.model.entity.EmailRequester;
import de.otto.blablafish_email.model.entity.EmailStatus;
import de.otto.blablafish_email.model.entity.EmailStatusHistoryEntry;
import de.otto.blablafish_email.respository.EmailRequestRepository;
import de.otto.blablafish_email.testDataConfig.EmailRequestTestConfig;
import io.restassured.common.mapper.TypeRef;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import java.time.Instant;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.BasicQuery;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.HttpStatus;
import org.testcontainers.shaded.com.fasterxml.jackson.databind.ObjectMapper;
import org.togglz.junit5.AllDisabled;
import org.togglz.testing.TestFeatureManager;

@AllDisabled(Features.class)
class EmailRequestIT extends AbstractContainerIT {

  private final int topic1Id = 1;
  private final int topic2Id = 2;
  private final ObjectId user1Id = new ObjectId("62bec37d21d8c96a1dff30cb");
  private final ObjectId user2Id = new ObjectId();
  private final String partnerId = "partner1";
  private final ObjectId requestId = new ObjectId("62bec37d21d8c96a1dff30cc");
  private final Topic topic1 =
      TopicTestBuilder.createTopic(
          topic1Id,
          "topic1",
          "description1",
          "email",
          true,
          Arrays.asList("123", "456"),
          "",
          "",
          "",
          new Document());
  private final Topic topic2 =
      TopicTestBuilder.createTopic(
          topic2Id,
          "topic2",
          "description2",
          "email",
          true,
          Arrays.asList("789", "147"),
          "",
          "",
          "",
          new Document());
  @Autowired private TopicRepository topicRepository;
  @Autowired private SubscriberRepository subscriberRepository;
  @Autowired private EmailRequestRepository emailRequestRepository;
  @Autowired private EmailPreferenceRepository emailPreferenceRepository;

  @Test
  void shouldReturn403WhenRequiredRoleIsNotPresentForPostPartnerMails() {
    final String requesterKeycloakId = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken(
            "test-client",
            requesterKeycloakId,
            List.of(CONTACT_MANAGEMENT_EMAIL_READ_ROLE),
            partnerId);

    final ErrorResponse errorResponse =
        with()
            .body(getCreateEmailByDirectRecipientRequest(Map.of("test", "yes")))
            .given()
            .header("Authorization", jwt)
            .port(port)
            .basePath(BASE_PATH)
            .contentType(ContentType.JSON)
            .when()
            .request("POST", "/v1/partner-mails")
            .then()
            .statusCode(HttpStatus.FORBIDDEN.value())
            .and()
            .extract()
            .body()
            .as(new TypeRef<>() {});
    assertThat(errorResponse.getMessage()).isEqualTo("Access is denied");
  }

  @Test
  void shouldPostEmailRequestForGivenPartner() {
    insertTopics();
    insertSubscribers();
    removeEmailPreferences();

    final Map<String, Object> payload = Map.of("test", "yes");
    final String requesterKeycloakId = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken(
            "test-client",
            requesterKeycloakId,
            List.of(CONTACT_MANAGEMENT_PARTNER_EMAIL_WRITE_ROLE),
            partnerId);

    final PostEmailToPartnerRequest request = getCreateEmailByDirectRecipientRequest(payload);

    final Response response =
        with()
            .body(request)
            .given()
            .header("Authorization", jwt)
            .port(port)
            .basePath(BASE_PATH)
            .contentType(ContentType.JSON)
            .when()
            .request("POST", "/v1/partner-mails")
            .then()
            .statusCode(HttpStatus.CREATED.value())
            .and()
            .header(
                "location", matchesPattern(".*localhost/contact-management/v1/mails-requests/.*"))
            .extract()
            .response();

    final EmailRequest savedEmailRequest = getMailRequestFromResponse(response);
    assertThat(savedEmailRequest).isNotNull();
    assertThat(savedEmailRequest.getTopicId()).isEqualTo(topic1Id);
    assertThat(savedEmailRequest.getRecipients()).hasSize(2);
    final EmailRecipient recipient = savedEmailRequest.getRecipients().get(0);
    assertThat(recipient.getPartnerId()).isEqualTo(partnerId);
    assertThat(recipient.getEmailAddress().getValue()).isEqualTo("testuser1mail@otto.de");
    assertThat(recipient.getFirstName().getValue()).isEqualTo("TestUser1FirstName");
    assertThat(recipient.getLastName().getValue()).isEqualTo("TestUser1LastName");
  }

  @Test
  void shouldPostEmailRequestForGivenPartnerAndHaveExpectedResponseHeader(
      TestFeatureManager featureManager) {
    featureManager.enable(Features.EXCLUDE_CONTACT_MANAGEMENT_IN_RESPONSE_URI_HEADER);
    insertTopics();
    insertSubscribers();
    removeEmailPreferences();

    final Map<String, Object> payload = Map.of("test", "yes");
    final String requesterKeycloakId = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken(
            "test-client",
            requesterKeycloakId,
            List.of(CONTACT_MANAGEMENT_PARTNER_EMAIL_WRITE_ROLE),
            partnerId);

    final PostEmailToPartnerRequest request = getCreateEmailByDirectRecipientRequest(payload);

    final Response response =
        with()
            .body(request)
            .given()
            .header("Authorization", jwt)
            .port(port)
            .basePath(BASE_PATH)
            .contentType(ContentType.JSON)
            .when()
            .request("POST", "/v1/partner-mails")
            .then()
            .statusCode(HttpStatus.CREATED.value())
            .and()
            .header("location", matchesPattern(".*localhost/v1/mails-requests/.*"))
            .extract()
            .response();

    final EmailRequest savedEmailRequest = getMailRequestFromResponse(response);
    assertThat(savedEmailRequest).isNotNull();
    assertThat(savedEmailRequest.getTopicId()).isEqualTo(topic1Id);
    assertThat(savedEmailRequest.getRecipients()).hasSize(2);
    final EmailRecipient recipient = savedEmailRequest.getRecipients().get(0);
    assertThat(recipient.getPartnerId()).isEqualTo(partnerId);
    assertThat(recipient.getEmailAddress().getValue()).isEqualTo("testuser1mail@otto.de");
    assertThat(recipient.getFirstName().getValue()).isEqualTo("TestUser1FirstName");
    assertThat(recipient.getLastName().getValue()).isEqualTo("TestUser1LastName");
  }

  @Test
  void shouldPostEmailRequestForSubscribersWithPreferencesOptedIn() {
    insertTopics();
    insertSubscribers();
    insertEmailPreferences();

    final Map<String, Object> payload = Map.of("test", "yes");
    final String requesterKeycloakId = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken(
            "test-client",
            requesterKeycloakId,
            List.of(CONTACT_MANAGEMENT_PARTNER_EMAIL_WRITE_ROLE),
            partnerId);

    final PostEmailToPartnerRequest request = getCreateEmailByDirectRecipientRequest(payload);

    final Response response =
        with()
            .body(request)
            .given()
            .header("Authorization", jwt)
            .port(port)
            .basePath(BASE_PATH)
            .contentType(ContentType.JSON)
            .when()
            .request("POST", "/v1/partner-mails")
            .then()
            .statusCode(HttpStatus.CREATED.value())
            .and()
            .header(
                "location", matchesPattern(".*localhost/contact-management/v1/mails-requests/.*"))
            .extract()
            .response();

    final EmailRequest savedEmailRequest = getMailRequestFromResponse(response);
    assertThat(savedEmailRequest).isNotNull();
    assertThat(savedEmailRequest.getTopicId()).isEqualTo(topic1Id);
    assertThat(savedEmailRequest.getRecipients()).hasSize(2);
    final EmailRecipient recipient = savedEmailRequest.getRecipients().get(0);
    assertThat(recipient.getPartnerId()).isEqualTo(partnerId);
    assertThat(recipient.getEmailAddress().getValue()).isEqualTo("testuser1mail@otto.de");
    assertThat(recipient.getFirstName().getValue()).isEqualTo("TestUser1FirstName");
    assertThat(recipient.getLastName().getValue()).isEqualTo("TestUser1LastName");
  }

  @Test
  void shouldPostEmailRequestForGivenPartnerWhenNoSubscribersForTopicAndAdminUsersExist() {
    insertTopics();
    Subscriber user1 =
        SubscriberTestConfig.createSubscriber(
            user1Id,
            partnerId,
            Set.of(),
            "TestUser1FirstName",
            "TestUser1LastName",
            "testuser1mail@otto.de",
            new HashSet<>(List.of("1627cc31ea20d40a10388febc")),
            Status.ENABLED,
            Instant.now(),
            Instant.now(),
            Requester.ofEventType(EventType.NEPTUNE_USER_SET),
            null);
    user1 = user1.toBuilder().groups(Set.of("onboardingAdministration", "administration")).build();
    subscriberRepository.upsert(user1);
    removeEmailPreferences();

    final Map<String, Object> payload = Map.of("test", "yes");
    final String requesterKeycloakId = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken(
            "test-client",
            requesterKeycloakId,
            List.of(CONTACT_MANAGEMENT_PARTNER_EMAIL_WRITE_ROLE),
            partnerId);

    final PostEmailToPartnerRequest request = getCreateEmailByDirectRecipientRequest(payload);

    final Response response =
        with()
            .body(request)
            .given()
            .header("Authorization", jwt)
            .port(port)
            .basePath(BASE_PATH)
            .contentType(ContentType.JSON)
            .when()
            .request("POST", "/v1/partner-mails")
            .then()
            .statusCode(HttpStatus.CREATED.value())
            .and()
            .header(
                "location", matchesPattern(".*localhost/contact-management/v1/mails-requests/.*"))
            .extract()
            .response();

    final EmailRequest savedEmailRequest = getMailRequestFromResponse(response);
    assertThat(savedEmailRequest).isNotNull();
    assertThat(savedEmailRequest.getTopicId()).isEqualTo(topic1Id);
    assertThat(savedEmailRequest.getRecipients()).hasSize(1);
    final EmailRecipient recipient = savedEmailRequest.getRecipients().get(0);
    assertThat(recipient.getPartnerId()).isEqualTo(partnerId);
    assertThat(recipient.getEmailAddress().getValue()).isEqualTo("testuser1mail@otto.de");
    assertThat(recipient.getFirstName().getValue()).isEqualTo("TestUser1FirstName");
    assertThat(recipient.getLastName().getValue()).isEqualTo("TestUser1LastName");
  }

  @Test
  void shouldReturn422WhenNoAdminAvailableAndNoUserSubscribed() {
    insertTopics();
    Subscriber user1 =
        SubscriberTestConfig.createSubscriber(
            user1Id,
            partnerId,
            Set.of(),
            "TestUser1FirstName",
            "TestUser1LastName",
            "testuser1mail@otto.de",
            new HashSet<>(List.of("1627cc31ea20d40a10388febc")),
            Status.DISABLED,
            Instant.now(),
            Instant.now(),
            Requester.ofEventType(EventType.NEPTUNE_USER_SET),
            null);
    subscriberRepository.upsert(user1);
    insertEmailPreferences(false);

    final Map<String, Object> payload = Map.of("test", "yes");
    final String requesterKeycloakId = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken(
            "test-client",
            requesterKeycloakId,
            List.of(CONTACT_MANAGEMENT_PARTNER_EMAIL_WRITE_ROLE),
            partnerId);

    final PostEmailToPartnerRequest request = getCreateEmailByDirectRecipientRequest(payload);

    final ErrorResponse response =
        with()
            .body(request)
            .given()
            .header("Authorization", jwt)
            .port(port)
            .basePath(BASE_PATH)
            .contentType(ContentType.JSON)
            .when()
            .request("POST", "/v1/partner-mails")
            .then()
            .statusCode(HttpStatus.UNPROCESSABLE_ENTITY.value())
            .extract()
            .body()
            .as(new TypeRef<>() {});

    assertThat(response.getMessage())
        .isEqualTo(
            "No users found with the required permissions or all users are unsubscribed to the topic: "
                + topic1Id);
  }

  @Test
  void shouldReturn403WhenRequiredRoleIsNotPresentForGetMailRequest() {
    final String requesterKeycloakId = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken(
            "test-client",
            requesterKeycloakId,
            List.of(CONTACT_MANAGEMENT_PARTNER_EMAIL_WRITE_ROLE),
            partnerId);
    final ErrorResponse errorResponse =
        with()
            .given()
            .header("Authorization", jwt)
            .port(port)
            .basePath(BASE_PATH)
            .contentType(ContentType.JSON)
            .when()
            .request("GET", "/v1/mails-requests/" + requestId)
            .then()
            .statusCode(HttpStatus.FORBIDDEN.value())
            .and()
            .extract()
            .body()
            .as(new TypeRef<>() {});
    assertThat(errorResponse.getMessage()).isEqualTo("Access is denied");
  }

  @Test
  void shouldReturn422WhenAllUsersHaveOptedOutForReceivingEmail() {
    insertTopics();
    insertSubscribers();
    insertEmailPreferences(false);

    final Map<String, Object> payload = Map.of("test", "yes");
    final String requesterKeycloakId = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken(
            "test-client",
            requesterKeycloakId,
            List.of(CONTACT_MANAGEMENT_PARTNER_EMAIL_WRITE_ROLE),
            partnerId);

    final PostEmailToPartnerRequest request = getCreateEmailByDirectRecipientRequest(payload);

    final ErrorResponse response =
        with()
            .body(request)
            .given()
            .header("Authorization", jwt)
            .port(port)
            .basePath(BASE_PATH)
            .contentType(ContentType.JSON)
            .when()
            .request("POST", "/v1/partner-mails")
            .then()
            .statusCode(HttpStatus.UNPROCESSABLE_ENTITY.value())
            .extract()
            .body()
            .as(new TypeRef<>() {});

    assertThat(response.getMessage())
        .isEqualTo("User(s) have not opted in to receive email for topic id: " + topic1Id);
  }

  @Test
  void shouldGetEmailRequestById() {
    insertEmailRequest();

    final String requesterKeycloakId = UUID.randomUUID().toString();
    final Map<String, Object> payload = Map.of("key", "val");
    String jwt =
        JwtHelper.createToken(
            "test-client",
            requesterKeycloakId,
            List.of(CONTACT_MANAGEMENT_EMAIL_READ_ROLE),
            partnerId);

    final EmailRequestDTO savedEmailRequest =
        with()
            .given()
            .header("Authorization", jwt)
            .port(port)
            .basePath(BASE_PATH)
            .contentType(ContentType.JSON)
            .when()
            .request("GET", "/v1/mails-requests/" + requestId)
            .then()
            .statusCode(HttpStatus.OK.value())
            .and()
            .extract()
            .body()
            .as(new TypeRef<>() {});
    var recipientDTOS =
        List.of(
            getEmailRecipientDto(
                savedEmailRequest.getRecipients().get(0).getEmailId(),
                savedEmailRequest.getRecipients().get(0).getEmailStatus().getDate()));
    var expectedEmailRequest =
        new EmailRequestDTO(
            1,
            recipientDTOS,
            new ObjectMapper().convertValue(payload, Document.class),
            savedEmailRequest.getCreatedAt(),
            EmailRequestStatus.ACCEPTED,
            null);

    assertThat(savedEmailRequest).usingRecursiveComparison().isEqualTo(expectedEmailRequest);
  }

  @Test
  void shouldPostEmailRequestToSendMailToRequestUser() {
    insertTopics();
    insertSubscribers();
    insertEmailPreferences();

    final Map<String, Object> payload = Map.of("test", "yes");
    final String requesterKeycloakId = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken(
            "test-client",
            requesterKeycloakId,
            List.of(CONTACT_MANAGEMENT_USER_EMAIL_WRITE_ROLE),
            partnerId);
    final PostEmailToUserRequest userMailRequest =
        new PostEmailToUserRequest(
            partnerId,
            topic1Id,
            payload,
            "TestUser1FirstName",
            "TestUser1LastName",
            "testuser1mail@otto.de",
            Set.of());

    final Response response =
        with()
            .body(userMailRequest)
            .given()
            .header("Authorization", jwt)
            .port(port)
            .basePath(BASE_PATH)
            .contentType(ContentType.JSON)
            .when()
            .request("POST", "/v1/user-mails")
            .then()
            .statusCode(HttpStatus.CREATED.value())
            .and()
            .header(
                "location", matchesPattern(".*localhost/contact-management/v1/mails-requests/.*"))
            .extract()
            .response();

    EmailRequest savedEmailRequest = getMailRequestFromResponse(response);
    assertThat(savedEmailRequest).isNotNull();
    assertThat(savedEmailRequest.getTopicId()).isEqualTo(topic1Id);
    assertThat(savedEmailRequest.getRecipients()).hasSize(1);
    EmailRecipient recipient = savedEmailRequest.getRecipients().get(0);
    assertThat(recipient.getPartnerId()).isEqualTo(partnerId);
    assertThat(recipient.getEmailAddress().getValue()).isEqualTo("testuser1mail@otto.de");
    assertThat(recipient.getFirstName().getValue()).isEqualTo("TestUser1FirstName");
    assertThat(recipient.getLastName().getValue()).isEqualTo("TestUser1LastName");
  }

  @Test
  void shouldReturn403WhenRequiredRoleIsNotPresentForSendMailToRequestUser() {
    insertTopics();
    insertSubscribers();

    final Map<String, Object> payload = Map.of("test", "yes");
    final String requesterKeycloakId = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken(
            "test-client",
            requesterKeycloakId,
            List.of(CONTACT_MANAGEMENT_PARTNER_EMAIL_WRITE_ROLE),
            partnerId);
    final PostEmailToUserRequest userMailRequest =
        new PostEmailToUserRequest(
            partnerId,
            topic1Id,
            payload,
            "TestUser1FirstName",
            "TestUser1LastName",
            "testuser1mail@otto.de",
            Set.of());

    final ErrorResponse errorResponse =
        with()
            .body(userMailRequest)
            .given()
            .header("Authorization", jwt)
            .port(port)
            .basePath(BASE_PATH)
            .contentType(ContentType.JSON)
            .when()
            .request("POST", "/v1/user-mails")
            .then()
            .statusCode(HttpStatus.FORBIDDEN.value())
            .and()
            .extract()
            .body()
            .as(new TypeRef<>() {});

    assertThat(errorResponse.getMessage()).isEqualTo("Access is denied");
  }

  @Test
  void shouldPostEmailRequestToSendInternalMailToRequestUser() {
    insertTopics();

    final Map<String, Object> payload = Map.of("test", "yes");
    final String requesterKeycloakId = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken(
            "test-client",
            requesterKeycloakId,
            List.of(CONTACT_MANAGEMENT_INTERNAL_EMAIL_WRITE_ROLE),
            partnerId);
    final PostEmailToInternalRequest internalMailRequest =
        new PostEmailToInternalRequest(
            topic1Id,
            payload,
            "TestUser1FirstName",
            "TestUser1LastName",
            "testuser1mail@otto.de",
            Set.of());

    final Response response =
        with()
            .body(internalMailRequest)
            .given()
            .header("Authorization", jwt)
            .port(port)
            .basePath(BASE_PATH)
            .contentType(ContentType.JSON)
            .when()
            .request("POST", "/v1/internal-mails")
            .then()
            .statusCode(HttpStatus.CREATED.value())
            .and()
            .header(
                "location", matchesPattern(".*localhost/contact-management/v1/mails-requests/.*"))
            .extract()
            .response();

    EmailRequest savedEmailRequest = getMailRequestFromResponse(response);
    assertThat(savedEmailRequest).isNotNull();
    assertThat(savedEmailRequest.getTopicId()).isEqualTo(topic1Id);
    assertThat(savedEmailRequest.getRecipients()).hasSize(1);
    EmailRecipient recipient = savedEmailRequest.getRecipients().get(0);
    assertThat(recipient.getPartnerId()).isEmpty();
    assertThat(recipient.getEmailAddress().getValue()).isEqualTo("testuser1mail@otto.de");
    assertThat(recipient.getFirstName().getValue()).isEqualTo("TestUser1FirstName");
    assertThat(recipient.getLastName().getValue()).isEqualTo("TestUser1LastName");
  }

  @Test
  void shouldReturn403WhenRequiredRoleIsNotPresentForSendInternalMailToRequestUser() {
    insertTopics();

    final Map<String, Object> payload = Map.of("test", "yes");
    final String requesterKeycloakId = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken(
            "test-client",
            requesterKeycloakId,
            List.of(CONTACT_MANAGEMENT_PARTNER_EMAIL_WRITE_ROLE),
            partnerId);
    final PostEmailToInternalRequest internalMailRequest =
        new PostEmailToInternalRequest(
            topic1Id,
            payload,
            "TestUser1FirstName",
            "TestUser1LastName",
            "testuser1mail@otto.de",
            Set.of());

    final ErrorResponse errorResponse =
        with()
            .body(internalMailRequest)
            .given()
            .header("Authorization", jwt)
            .port(port)
            .basePath(BASE_PATH)
            .contentType(ContentType.JSON)
            .when()
            .request("POST", "/v1/internal-mails")
            .then()
            .statusCode(HttpStatus.FORBIDDEN.value())
            .and()
            .extract()
            .body()
            .as(new TypeRef<>() {});

    assertThat(errorResponse.getMessage()).isEqualTo("Access is denied");
  }

  private PostEmailToPartnerRequest getCreateEmailByDirectRecipientRequest(
      Map<String, Object> payload) {
    return new PostEmailToPartnerRequest(partnerId, topic1Id, payload, null, Set.of());
  }

  private EmailRequest getMailRequestFromResponse(Response response) {
    final String location = response.getHeader("Location");
    final String[] split = location.split("/");
    final String requestId = split[split.length - 1];

    return mongoTemplate.findOne(
        new BasicQuery(new Document("requestId", requestId)), EmailRequest.class);
  }

  private void insertTopics() {
    topicRepository.save(topic1);
    topicRepository.save(topic2);
  }

  private void insertSubscribers() {
    Subscriber user1 =
        SubscriberTestConfig.createSubscriber(
            user1Id,
            partnerId,
            new HashSet<>(Arrays.asList(topic1Id, topic2Id)),
            "TestUser1FirstName",
            "TestUser1LastName",
            "testuser1mail@otto.de",
            new HashSet<>(List.of("1627cc31ea20d40a10388febc")),
            Status.ENABLED,
            Instant.now(),
            Instant.now(),
            Requester.ofEventType(EventType.NEPTUNE_USER_SET),
            null);
    Subscriber user2 =
        SubscriberTestConfig.createSubscriber(
            user2Id,
            partnerId,
            new HashSet<>(List.of(topic1Id)),
            "TestUser2FirstName",
            "TestUser2LastName",
            "testuser2mail@otto.de",
            new HashSet<>(List.of("1234")),
            Status.ENABLED,
            Instant.now(),
            Instant.now(),
            Requester.ofEventType(EventType.NEPTUNE_USER_SET),
            null);
    subscriberRepository.upsert(user1);
    subscriberRepository.upsert(user2);
  }

  private void insertEmailPreferences() {
    insertEmailPreferences(true);
  }

  private void insertEmailPreferences(boolean optIn) {
    var emailPreference1 =
        EmailPreference.builder()
            .subscriberId(user1Id)
            .topicId(topic1Id)
            .optIn(optIn)
            .lastUpdatedAt(Instant.now())
            .build();
    var emailPreference2 =
        EmailPreference.builder()
            .subscriberId(user2Id)
            .topicId(topic1Id)
            .optIn(optIn)
            .lastUpdatedAt(Instant.now())
            .build();
    emailPreferenceRepository.upsertAll(List.of(emailPreference1, emailPreference2));
  }

  private void removeEmailPreferences() {
    mongoTemplate.remove(new Query(), EmailPreference.class);
  }

  private void insertEmailRequest() {
    Subscriber user1 =
        SubscriberTestConfig.createSubscriber(
            user1Id,
            partnerId,
            new HashSet<>(Arrays.asList(topic1Id, topic2Id)),
            "TestUser1FirstName",
            "TestUser1LastName",
            "testuser1mail@otto.de",
            new HashSet<>(List.of("1627cc31ea20d40a10388febc")),
            Status.ENABLED,
            Instant.now(),
            Instant.now(),
            Requester.ofEventType(EventType.NEPTUNE_USER_SET),
            null);
    EmailRecipient recipient = EmailRecipient.of(user1);
    EmailRequest emailRequest =
        EmailRequestTestConfig.createEmailRequest(
            requestId,
            topic1Id,
            Map.of("key", "val"),
            EmailRequester.of("test-client", UUID.randomUUID().toString()),
            List.of(recipient),
            EmailRequestStatus.ACCEPTED);
    emailRequestRepository.insert(emailRequest);
  }

  private EmailRecipientDTO getEmailRecipientDto(String id, Instant time) {
    return EmailRecipientDTO.builder()
        .emailId(id)
        .firstName("TestUser1FirstName")
        .lastName("TestUser1LastName")
        .email("testuser1mail@otto.de")
        .emailStatus(new EmailStatusHistoryEntry(EmailStatus.READY_TO_SEND, time))
        .partnerId("partner1")
        .build();
  }
}
