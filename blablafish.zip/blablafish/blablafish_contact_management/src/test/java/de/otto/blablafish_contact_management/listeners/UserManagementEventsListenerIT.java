package de.otto.blablafish_contact_management.listeners;

import static java.util.concurrent.TimeUnit.SECONDS;
import static org.assertj.core.api.Assertions.assertThat;
import static org.testcontainers.shaded.org.awaitility.Awaitility.await;

import com.amazonaws.services.sqs.AmazonSQS;
import de.otto.blablafish_contact_management.config.Features;
import de.otto.blablafish_contact_management.model.entity.NewsletterSubscription;
import de.otto.blablafish_contact_management.model.entity.NewsletterSubscriptionStatus;
import de.otto.blablafish_contact_management.model.entity.Subscriber;
import de.otto.blablafish_contact_management.respository.SubscriberRepository;
import de.otto.blablafish_contact_management.testDataConfig.SubscriberTestConfig;
import de.otto.blablafish_email.listener.AbstractContainerIT;
import de.otto.newsletter.model.entity.SubscriberChangeEntry;
import java.time.Instant;
import java.util.List;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.togglz.junit5.AllEnabled;

@AllEnabled(Features.class)
public class UserManagementEventsListenerIT extends AbstractContainerIT {

  @Value("${userManagementEvents.queueUrl}")
  private String userManagementEventQueue;

  @Autowired private SubscriberRepository subscriberRepository;

  @Autowired private AmazonSQS sqs;

  @Autowired private MongoTemplate mongoTemplate;

  @Test
  void shouldListenToNewsletterStatusChangedEvent() {
    var subscriber =
        new SubscriberTestConfig()
            .subscriberBuilder()
            .newsletterSubscription(null)
            .userId(new ObjectId("629089ba391a524f0b687f4a"))
            .build();
    subscriberRepository.upsert(subscriber);
    var queueUrl = sqs.getQueueUrl(userManagementEventQueue).getQueueUrl();
    String newsLetterChangedEvent =
        """
                {
                  "eventId": "9a60261b-93a2-4602-9735-96f9366c5fb8",
                  "traceId": "def8ec70-70b3-464d-8ee3-82abf042a807",
                  "context": "neptune-usermanagement",
                  "type": "neptune-usermanagement.NEWSLETTER_STATUS_CHANGED",
                  "eventTime": "2020-10-12T07:17:00.077Z",
                  "data": {
                    "neptuneUserId": "629089ba391a524f0b687f4a",
                    "status" : "UNSUBSCRIBED",
                    "newsletterAcceptedText" : "randomText",
                    "timestamp": "2022-09-14T07:17:00.077Z"
                  }
                }
            """;
    sqs.sendMessage(queueUrl, newsLetterChangedEvent);

    newsLetterChangedEvent =
        """
                {
                  "eventId": "9a60261b-93a2-4602-9735-96f9366c5fb8",
                  "traceId": "def8ec70-70b3-464d-8ee3-82abf042a807",
                  "context": "neptune-usermanagement",
                  "type": "neptune-usermanagement.NEWSLETTER_STATUS_CHANGED",
                  "eventTime": "2020-10-14T07:17:00.077Z",
                  "data": {
                    "neptuneUserId": "629089ba391a524f0b687f4a",
                    "status" : "SUBSCRIBED",
                    "newsletterAcceptedText" : "randomText",
                    "timestamp": "2022-09-13T07:17:00.077Z"
                  }
                }
            """;
    sqs.sendMessage(queueUrl, newsLetterChangedEvent);

    await()
        .atMost(5, SECONDS)
        .until(() -> mongoTemplate.findAll(SubscriberChangeEntry.class).size() == 1);

    assertThatQueueHasConsumedAllMessages(sqs, queueUrl);

    var expectedStatus =
        new NewsletterSubscription(
            NewsletterSubscriptionStatus.UNSUBSCRIBED,
            "randomText",
            Instant.parse("2022-09-14T07:17:00.077Z"));
    Subscriber updatedSubscriber =
        subscriberRepository.findById(subscriber.getUserId()).orElseThrow();
    assertThat(updatedSubscriber.getNewsletterSubscription())
        .usingRecursiveComparison()
        .isEqualTo(expectedStatus);
    List<SubscriberChangeEntry> subscriberChangeEntries =
        mongoTemplate.findAll(SubscriberChangeEntry.class);
    assertThat(subscriberChangeEntries).hasSize(1);
    assertThat(subscriberChangeEntries.get(0).getSubscriberChangeTime())
        .isEqualTo("2022-09-13T07:17:00.077Z");
  }

  @Test
  void shouldCreateSubscriberChangedEntryWhenOldNewsletterUpdateEventReceived() {
    Subscriber subscriber =
        new SubscriberTestConfig()
            .subscriberBuilder()
            .userId(new ObjectId("629089ba391a524f0b687f4a"))
            .build();
    mongoTemplate.insert(subscriber);
    String queueUrl = sqs.getQueueUrl(userManagementEventQueue).getQueueUrl();
    String newsLetterChangedEvent =
        """
                {
                  "eventId": "9a60261b-93a2-4602-9735-96f9366c5fb8",
                  "traceId": "def8ec70-70b3-464d-8ee3-82abf042a807",
                  "context": "neptune-usermanagement",
                  "type": "neptune-usermanagement.NEWSLETTER_STATUS_CHANGED",
                  "eventTime": "2020-10-12T07:17:00.077Z",
                  "data": {
                    "neptuneUserId": "629089ba391a524f0b687f4a",
                    "status" : "UNSUBSCRIBED",
                    "newsletterAcceptedText" : "randomText",
                    "timestamp": "2020-09-12T07:17:00.077Z"
                  }
                }
            """;

    sqs.sendMessage(queueUrl, newsLetterChangedEvent);

    await()
        .atMost(5, SECONDS)
        .until(() -> mongoTemplate.findAll(SubscriberChangeEntry.class).size() == 1);
    assertThatQueueHasConsumedAllMessages(sqs, queueUrl);
    var allEntries = mongoTemplate.findAll(SubscriberChangeEntry.class);
    assertThat(allEntries).hasSize(1);
  }
}
