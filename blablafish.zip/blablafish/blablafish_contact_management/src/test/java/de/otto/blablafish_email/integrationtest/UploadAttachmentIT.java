package de.otto.blablafish_email.integrationtest;

import static de.otto.blablafish_email.utils.Constants.CONTACT_MANAGEMENT_EMAIL_READ_ROLE;
import static de.otto.blablafish_email.utils.Constants.CONTACT_MANAGEMENT_PARTNER_EMAIL_WRITE_ROLE;
import static io.restassured.RestAssured.with;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.amazonaws.services.s3.AmazonS3;
import de.otto.blablafish_contact_management.integrationtest.helpers.JwtHelper;
import de.otto.blablafish_contact_management.model.dto.ErrorResponse;
import de.otto.blablafish_email.listener.AbstractContainerIT;
import de.otto.blablafish_email.model.entity.EmailAttachment;
import io.restassured.common.mapper.TypeRef;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import java.io.File;
import java.util.List;
import java.util.UUID;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

public class UploadAttachmentIT extends AbstractContainerIT {

  @Autowired private AmazonS3 amazonS3;

  private final String partnerId = "partner1";

  @Test
  public void shouldReturn403WhenRequiredRoleIsNotPresentForPostUploadAttachment() {
    final String requesterKeycloakId = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken(
            "test-client",
            requesterKeycloakId,
            List.of(CONTACT_MANAGEMENT_EMAIL_READ_ROLE),
            partnerId);

    final ErrorResponse errorResponse =
        with()
            .given()
            .header("Authorization", jwt)
            .port(port)
            .basePath(BASE_PATH)
            .contentType(ContentType.MULTIPART)
            .multiPart("file", new File("src/test/resources/uploadForEmail.txt"))
            .when()
            .request("POST", "/v1/uploads")
            .then()
            .statusCode(HttpStatus.FORBIDDEN.value())
            .and()
            .extract()
            .body()
            .as(new TypeRef<>() {});
    Assertions.assertThat(errorResponse.getMessage()).isEqualTo("Access is denied");
  }

  @Test
  public void shouldUploadAttachmentForEmails() {
    final String requesterKeycloakId = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken(
            "test-client",
            requesterKeycloakId,
            List.of(CONTACT_MANAGEMENT_PARTNER_EMAIL_WRITE_ROLE),
            partnerId);

    final Response response =
        with()
            .given()
            .header("Authorization", jwt)
            .port(port)
            .basePath(BASE_PATH)
            .contentType(ContentType.MULTIPART)
            .multiPart("file", new File("src/test/resources/uploadForEmail.txt"))
            .when()
            .request("POST", "/v1/uploads")
            .then()
            .statusCode(HttpStatus.CREATED.value())
            .and()
            .extract()
            .response();

    EmailAttachment attachment =
        mongoTemplate.findById(response.getBody().asString(), EmailAttachment.class);
    assertThat(attachment.getS3BucketName()).isEqualTo("develop-email-file-uploads");
    assertTrue(amazonS3.doesObjectExist("develop-email-file-uploads", attachment.getS3UploadKey()));
  }
}
