package de.otto.newsletter.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import de.otto.newsletter.exception.JWTActionNotFoundException;
import de.otto.newsletter.exception.RSAKeyPairDoesNotExistException;
import de.otto.newsletter.model.JWTActions;
import de.otto.newsletter.model.entity.RSAKeyPair;
import de.otto.newsletter.repository.RSAKeyPairRepository;
import io.jsonwebtoken.*;
import java.security.Key;
import java.util.Base64;
import java.util.Optional;
import javax.crypto.spec.SecretKeySpec;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.Test;

class JWTServiceTest {

  private final RSAKeyPairRepository rsaKeyPairRepository = mock(RSAKeyPairRepository.class);
  private final JWTService jwtService;
  private final RSAKeyPair rsaKeyPair;
  private final String privateKeyString;
  private final String subscriberId = "629089ba391a524f0b687f4a";
  private final String keyId = "kid";

  public JWTServiceTest() {
    jwtService = new JWTService(rsaKeyPairRepository);
    String publicKeyString =
        "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAwJPLseDAr5fDFWehS3kIM9JxvGsYlNmW5dxcp8oqIMjGqdh1RF9Cq40YaHJGCISdlSBFjqpgMfv3JaUajvSYlPwTu5f8rIp+xKTlWNM+S0zEY6ROS5JlQVOZmznUXo+qtCIWZkvsNIrM0sWeFVG3w2mc8SSrqCn+ObF5Xr2gFmRGGkiVM00vCp5o6wBfd4w08Mvx92Az2D5X8QRmPjZtg4FZKZ5YZxxtYeo9QIel4C/di3Ex343P7F9w6h0J4Eou4AC6L+kFmZ8jaFxwZB4TCI3UyJZ4G+MRsdZBne5O9CjGzl7Oaz4bmlyQi3NraB+iUVLfg4abB6T82IMHy4naRwIDAQAB";
    privateKeyString =
        "MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDAk8ux4MCvl8MVZ6FLeQgz0nG8axiU2Zbl3FynyiogyMap2HVEX0KrjRhockYIhJ2VIEWOqmAx+/clpRqO9JiU/BO7l/ysin7EpOVY0z5LTMRjpE5LkmVBU5mbOdRej6q0IhZmS+w0iszSxZ4VUbfDaZzxJKuoKf45sXlevaAWZEYaSJUzTS8KnmjrAF93jDTwy/H3YDPYPlfxBGY+Nm2DgVkpnlhnHG1h6j1Ah6XgL92LcTHfjc/sX3DqHQngSi7gALov6QWZnyNoXHBkHhMIjdTIlngb4xGx1kGd7k70KMbOXs5rPhuaXJCLc2toH6JRUt+DhpsHpPzYgwfLidpHAgMBAAECggEANQV8Q9FZu/7Q24fYxOrh80KxxerGrdTq0wbFC/2Bc91TtVe/kb+Yn5sNaVRtK9M3f+OOwyTtr1VsSpUWpt15VSvCUxgZnXfUR1gPPVGMCTdtqvGGDRCViFL4K+DUM+TiXw4zlJ66vgypMC7ww3XoXokpiMtL59UIBeJzRD55YTBoReM/WBLQmbHNKA1ZWwgt9keD2ALOmnzpQEaffQZqyn5b8XsMsG06Zjdih0PgWdUm35NXT6FKzQcjBzbGBKhR4y7snMk5icFRm+0Lnn/i6fJ5qLz0VJYQRIJLhtdzwyVd+veqe41zDQUAtQsQdQ0jpyYpBH26ZGERjXF794eNAQKBgQDbGc/0y2nlrEH9r6J3xibblz2ChFGJeLDbdKGKKpu4qEPupE2gbHhwuJTSlX2mqluqGGin7GBoaDVc1dKu97XkkQ329fo4wNOcqX5phP4w9dEc1C+8NtcUJ2J9d2qEfubD0J5/u5oB2ErCsd1ppO/T9L4+Fg+cbb+Bu0KjeKpJZwKBgQDhAnbZkBfT43Z7xtK70dXQUe5QIUyoBzMWQxH+eOBXbsYmQKlx9PA4FjZAEWHaA8ECaCmj17OkCSjFuw26e96YzQkgBFWnvykAvaNL/+7jPSqmM/stX4lW4sae9oTGgWLpKkbXaIi1yTgkiQEEM3kA+owdnbhi9lmfAGEd4eP8IQKBgQCyo3cUhg1Pf4VGi78RnPPtsoAqPCwmw8qfA5b6CgdxJXBN0JSiKg6BCV393HjYPKoEI2ahE27/cYegq43droYVV9dk9eUQBNgEMYWqDw8ZaDMZKD/LW4M9IWeCGK02XilUmnHAf3rv6iP6Xf7CtgH8dN3vzRjpV+n+ommQ0z80HQKBgE7LdB9ADHgRAZ7aw1UuaDepWVEKODPnQYacOiLo5Xb4vb8Licr0QWMCtEC/VYrpIZ/cJijQEoJxCqwjku0pD4xm0Lk7i1tQ3+T4g8TLfTZqZxMIxP7go9GfXHqyTVDOYnrQaTppyuYN7vEsYQS9mbQ0CPkeEEHnjv7VPS0fu5zBAoGBAMe4uM7C1UWkogWYa8MYoDxn6Psi3quV335A6MwHZ7gawwEM2ukMKmznQ1oDJbKjpElCOJ/eFtydZL/3FHg21+x/mrKKYAWiXiy4uQMl3+tCuyW0asd3vH3L18OLSGai/wv/1OGn9iSkF10OI3s6dhq0WtncETtQI/qgbC7jcbyG";
    rsaKeyPair =
        new RSAKeyPair(
            "kid", publicKeyString, RSAKeyPair.encryptPrivateKey(privateKeyString), true);
  }

  @Test
  void shouldGenerateJwt() {
    when(rsaKeyPairRepository.findByActiveSigningKey()).thenReturn(Optional.of(rsaKeyPair));

    String jwt = jwtService.getJWT(new ObjectId(subscriberId), JWTActions.UNSUBSCRIBE_NEWSLETTER);

    Key hmacKey =
        new SecretKeySpec(
            Base64.getDecoder().decode(privateKeyString), SignatureAlgorithm.HS256.getJcaName());
    JwtParser jwtParser = Jwts.parserBuilder().setSigningKey(hmacKey).build();
    Jws<Claims> claimsJws = jwtParser.parseClaimsJws(jwt);
    assertThat(claimsJws.getBody().getSubject()).isEqualTo(subscriberId);
    assertThat(claimsJws.getBody().get("action"))
        .isEqualTo(JWTActions.UNSUBSCRIBE_NEWSLETTER.toString());
    assertThat(claimsJws.getHeader().getAlgorithm()).isEqualTo("HS256");
    assertThat(claimsJws.getHeader().getKeyId()).isEqualTo(keyId);
  }

  @Test
  void shouldGetClaimsWithValidJWT() {
    String jwt =
        "eyJraWQiOiJraWQiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI2MjkwODliYTM5MWE1MjRmMGI2ODdmNGEiLCJhY3Rpb24iOiJVTlNVQlNDUklCRV9ORVdTTEVUVEVSIiwiZXhwIjoxOTc5NzE5OTE0fQ.OlDlTLEQoXvWPh6S90opLz8BwrmOWpwjjGRHP7T7wzg";
    when(rsaKeyPairRepository.findActiveSigningKeyByKeyId(keyId))
        .thenReturn(Optional.of(rsaKeyPair));

    Claims claims = jwtService.getClaims(jwt);
    assertNotNull(claims);
    assertEquals(subscriberId, claims.getSubject());
  }

  @Test
  void shouldThrowRSAKeyPairDoesNotExistExceptionWhenKeyIdIsNotPresent() {
    String jwt =
        "eyJraWQiOiJraWQiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI2MjkwODliYTM5MWE1MjRmMGI2ODdmNGEiLCJhY3Rpb24iOiJVTlNVQlNDUklCRV9ORVdTTEVUVEVSIiwiZXhwIjoxOTc5NzE5OTE0fQ.OlDlTLEQoXvWPh6S90opLz8BwrmOWpwjjGRHP7T7wzg";
    when(rsaKeyPairRepository.findActiveSigningKeyByKeyId(keyId)).thenReturn(Optional.empty());

    var exception =
        assertThrows(RSAKeyPairDoesNotExistException.class, () -> jwtService.getClaims(jwt));
    assertEquals("RSA Key Pair Doesn't Exist for the keyId: kid", exception.getMessage());
  }

  @Test
  void shouldThrowExpiredJwtExceptionWhenJWTIsExpired() {
    String jwt =
        "eyJraWQiOiJraWQiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI2MjkwODliYTM5MWE1MjRmMGI2ODdmNGEiLCJhY3Rpb24iOiJVTlNVQlNDUklCRV9ORVdTTEVUVEVSIiwiZXhwIjoxNjY0MzYwNzY4fQ.Bf3-04nYZQPahXpj3g2pMHqr5hHAwXej6l1rsZDWf24";
    when(rsaKeyPairRepository.findActiveSigningKeyByKeyId(keyId))
        .thenReturn(Optional.of(rsaKeyPair));

    assertThrows(ExpiredJwtException.class, () -> jwtService.getClaims(jwt));
  }

  @Test
  void shouldThrowJWTActionNotFoundExceptionWhenActionIsNotPresent() {
    String jwt =
        "eyJraWQiOiJraWQiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI2MjkwODliYTM5MWE1MjRmMGI2ODdmNGEiLCJhY3Rpb24iOiIiLCJleHAiOjE5Nzk3ODUzODl9.Gsnsb2_Fyo6yD9W4ogrXdD4eEjpmH6QM3i_Ic3Ykzwo";
    when(rsaKeyPairRepository.findActiveSigningKeyByKeyId(keyId))
        .thenReturn(Optional.of(rsaKeyPair));

    Claims claims = jwtService.getClaims(jwt);

    var exception =
        assertThrows(
            JWTActionNotFoundException.class,
            () -> jwtService.verifyClaimAction(claims, JWTActions.UNSUBSCRIBE_NEWSLETTER));
    assertEquals(
        "Unknown JWT Action: " + JWTActions.UNSUBSCRIBE_NEWSLETTER, exception.getMessage());
  }
}
