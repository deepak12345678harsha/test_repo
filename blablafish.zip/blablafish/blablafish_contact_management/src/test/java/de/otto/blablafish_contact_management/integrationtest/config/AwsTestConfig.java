package de.otto.blablafish_contact_management.integrationtest.config;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.testcontainers.containers.localstack.LocalStackContainer.Service.*;

import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.http.HttpResponse;
import com.amazonaws.http.SdkHttpMetadata;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.simpleemailv2.AmazonSimpleEmailServiceV2;
import com.amazonaws.services.simpleemailv2.model.*;
import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.AmazonSNSClientBuilder;
import com.amazonaws.services.sns.model.CreateTopicResult;
import com.amazonaws.services.sqs.AmazonSQSAsync;
import com.amazonaws.services.sqs.AmazonSQSAsyncClientBuilder;
import io.awspring.cloud.messaging.config.QueueMessageHandlerFactory;
import io.awspring.cloud.messaging.config.SimpleMessageListenerContainerFactory;
import io.awspring.cloud.messaging.listener.QueueMessageHandler;
import io.awspring.cloud.messaging.listener.SimpleMessageListenerContainer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.messaging.converter.MappingJackson2MessageConverter;
import org.springframework.messaging.handler.annotation.support.PayloadArgumentResolver;
import org.springframework.messaging.handler.invocation.HandlerMethodArgumentResolver;
import org.testcontainers.containers.localstack.LocalStackContainer;
import org.testcontainers.containers.wait.strategy.Wait;
import org.testcontainers.utility.DockerImageName;

@Profile("integration")
@Configuration
public class AwsTestConfig {

  @Value("${mongoDbTrigger.emailRequests.queueUrl}")
  private String emailRequestsQueueName;

  @Value("${mongoDbTrigger.mails.queueUrl}")
  private String emailTriggerQueueName;

  @Value("${sesEvents.queueUrl}")
  private String sesEventsQueueName;

  @Value("${mongoDbTrigger.mailBlacklists.queueUrl}")
  private String emailBlacklistsQueueName;

  @Value("${mongoDbTrigger.changeEvents.queueUrl}")
  private String mongoChangeEventQueueName;

  @Value("${userManagementEvents.queueUrl}")
  private String userManagementEventQueue;

  @Value("${mongoDbTrigger.subscribers.changeEvents.queueUrl}")
  private String subscribersMongoDBTriggerChangeEventQueueName;

  @Value("${mongoDbTrigger.subscribers.actions.queueUrl}")
  private String subscribersMongoDBActionsTriggerQueueName;

  @Value("${emailAttachmentEvents.queueUrl}")
  private String emailAttachmentEventQueueName;

  @Value("${mongoDbTrigger.mails.migration.queueUrl}")
  private String emailMigrationQueUrl;

  private static final String MAIL_ATTACHMENT_BUCKET_NAME = "develop-email-file-uploads";

  @Bean
  public AWSCredentialsProvider localStackContainerAWsCredentialsProvider(
      LocalStackContainer localStackContainer) {
    return localStackContainer.getDefaultCredentialsProvider();
  }

  @Bean
  public LocalStackContainer localStackContainer() {
    LocalStackContainer localStackContainer =
        new LocalStackContainer(DockerImageName.parse("localstack/localstack:0.12.5"))
            .withServices(SQS, SNS, S3, SES);
    localStackContainer.start();
    localStackContainer.waitingFor(Wait.forHealthcheck());
    return localStackContainer;
  }

  @Bean
  public AmazonSQSAsync amazonSQSAsync(LocalStackContainer localStackContainer) {
    var amazonSQSAsync =
        AmazonSQSAsyncClientBuilder.standard()
            .withEndpointConfiguration(localStackContainer.getEndpointConfiguration(SQS))
            .withCredentials(localStackContainer.getDefaultCredentialsProvider())
            .build();
    createQueues(amazonSQSAsync);
    return amazonSQSAsync;
  }

  private void createQueues(AmazonSQSAsync amazonSQSAsync) {
    amazonSQSAsync.createQueue(emailRequestsQueueName);
    amazonSQSAsync.createQueue(emailTriggerQueueName);
    amazonSQSAsync.createQueue(sesEventsQueueName);
    amazonSQSAsync.createQueue(emailBlacklistsQueueName);
    amazonSQSAsync.createQueue(mongoChangeEventQueueName);
    amazonSQSAsync.createQueue(userManagementEventQueue);
    amazonSQSAsync.createQueue(subscribersMongoDBTriggerChangeEventQueueName);
    amazonSQSAsync.createQueue(subscribersMongoDBActionsTriggerQueueName);
    amazonSQSAsync.createQueue(emailAttachmentEventQueueName);
    amazonSQSAsync.createQueue(emailMigrationQueUrl);
  }

  @Bean
  public SimpleMessageListenerContainerFactory simpleMessageListenerContainerFactory(
      AmazonSQSAsync amazonSQSAsync) {
    SimpleMessageListenerContainerFactory msgListenerContainerFactory =
        new SimpleMessageListenerContainerFactory();
    msgListenerContainerFactory.setAmazonSqs(amazonSQSAsync);
    msgListenerContainerFactory.setWaitTimeOut(3);
    return msgListenerContainerFactory;
  }

  @Bean
  public QueueMessageHandler queueMessageHandler(AmazonSQSAsync amazonSQSAsync) {
    QueueMessageHandlerFactory queueMsgHandlerFactory = new QueueMessageHandlerFactory();
    queueMsgHandlerFactory.setAmazonSqs(amazonSQSAsync);
    QueueMessageHandler queueMessageHandler = queueMsgHandlerFactory.createQueueMessageHandler();
    List<HandlerMethodArgumentResolver> list = new ArrayList<>();
    HandlerMethodArgumentResolver resolver =
        new PayloadArgumentResolver(new MappingJackson2MessageConverter());
    list.add(resolver);
    queueMessageHandler.setArgumentResolvers(list);
    return queueMessageHandler;
  }

  @Bean
  public SimpleMessageListenerContainer simpleMessageListenerContainer(
      SimpleMessageListenerContainerFactory factory, QueueMessageHandler messageHandler) {
    SimpleMessageListenerContainer container = factory.createSimpleMessageListenerContainer();
    container.setMaxNumberOfMessages(5);
    container.setMessageHandler(messageHandler);
    return container;
  }

  @Bean
  public AmazonSimpleEmailServiceV2 AmazonSimpleEmailServiceV2() {
    final SendEmailResult sendEmailResult = new SendEmailResult();
    sendEmailResult.setMessageId("success-message-id");
    final AmazonSimpleEmailServiceV2 amazonSimpleEmailServiceV2 =
        Mockito.mock(AmazonSimpleEmailServiceV2.class);

    var httpResponse = new HttpResponse(null, null);
    httpResponse.setStatusCode(200);
    var sdkHttpMetadata = SdkHttpMetadata.from(httpResponse);

    var putSuppressedDestinationResult = new PutSuppressedDestinationResult();
    putSuppressedDestinationResult.setSdkHttpMetadata(sdkHttpMetadata);

    var deleteSuppressedDestinationResult = new DeleteSuppressedDestinationResult();
    deleteSuppressedDestinationResult.setSdkHttpMetadata(sdkHttpMetadata);

    var listSuppressedDestinationsResult = new ListSuppressedDestinationsResult();
    listSuppressedDestinationsResult.setSuppressedDestinationSummaries(Collections.emptyList());

    when(amazonSimpleEmailServiceV2.sendEmail(any(SendEmailRequest.class)))
        .thenReturn(sendEmailResult);
    when(amazonSimpleEmailServiceV2.putSuppressedDestination(
            any(PutSuppressedDestinationRequest.class)))
        .thenReturn(putSuppressedDestinationResult);
    when(amazonSimpleEmailServiceV2.deleteSuppressedDestination(
            any(DeleteSuppressedDestinationRequest.class)))
        .thenReturn(deleteSuppressedDestinationResult);
    when(amazonSimpleEmailServiceV2.listSuppressedDestinations(
            any(ListSuppressedDestinationsRequest.class)))
        .thenReturn(listSuppressedDestinationsResult);

    return amazonSimpleEmailServiceV2;
  }

  @Bean
  public AmazonS3 amazonS3(LocalStackContainer localStackContainer) {
    AmazonS3 amazonS3 =
        AmazonS3ClientBuilder.standard()
            .withEndpointConfiguration(localStackContainer.getEndpointConfiguration(S3))
            .withCredentials(localStackContainer.getDefaultCredentialsProvider())
            .build();

    amazonS3.createBucket(MAIL_ATTACHMENT_BUCKET_NAME);
    return amazonS3;
  }

  @Bean
  public AmazonSNS amazonSNS() {
    AmazonSNS sns =
        AmazonSNSClientBuilder.standard()
            .withEndpointConfiguration(localStackContainer().getEndpointConfiguration(SNS))
            .withCredentials(localStackContainer().getDefaultCredentialsProvider())
            .build();
    CreateTopicResult topic = sns.createTopic("email-service-events");
    System.setProperty("topic.email_events.arn", topic.getTopicArn());
    return sns;
  }
}
