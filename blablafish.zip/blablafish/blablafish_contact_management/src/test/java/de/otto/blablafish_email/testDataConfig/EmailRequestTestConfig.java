package de.otto.blablafish_email.testDataConfig;

import de.otto.blablafish_email.model.entity.EmailRecipient;
import de.otto.blablafish_email.model.entity.EmailRequest;
import de.otto.blablafish_email.model.entity.EmailRequestStatus;
import de.otto.blablafish_email.model.entity.EmailRequester;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import org.bson.Document;
import org.bson.types.ObjectId;

public class EmailRequestTestConfig {

  public static EmailRequest createEmailRequest(
      ObjectId requestId,
      Integer topicId,
      Map<String, Object> payload,
      EmailRequester requester,
      List<EmailRecipient> recipients,
      EmailRequestStatus status) {

    return EmailRequest.builder()
        .requestId(requestId)
        .topicId(topicId)
        .payload(EmailRequest.encryptPayload(new Document(payload)))
        .createdAt(Instant.now())
        .requester(requester)
        .recipients(recipients)
        .status(status)
        .build();
  }
}
