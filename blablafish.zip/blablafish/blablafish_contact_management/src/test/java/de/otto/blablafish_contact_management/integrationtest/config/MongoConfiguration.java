package de.otto.blablafish_contact_management.integrationtest.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.ClientEncryptionSettings;
import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.client.vault.ClientEncryptions;
import de.otto.blablafish_contact_management.encryption.EncryptionHelper;
import de.otto.blablafish_contact_management.encryption.MongoBinaryToEncryptedFieldConverter;
import de.otto.blablafish_contact_management.encryption.MongoEncryptedFieldToBinaryConverter;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.data.mongodb.MongoDatabaseFactory;
import org.springframework.data.mongodb.MongoTransactionManager;
import org.springframework.data.mongodb.core.convert.MongoCustomConversions;
import org.springframework.data.repository.init.Jackson2RepositoryPopulatorFactoryBean;

@TestConfiguration
@EnableAutoConfiguration
public class MongoConfiguration {

  private static final Logger LOGGER = LoggerFactory.getLogger(MongoConfiguration.class);

  private final String KeyVaultConnectionString;

  private final String keyVaultDatabase;

  private final String keyVaultCollection;

  private final String kmsProviderKey;

  public MongoConfiguration(
      @Value("${spring.data.mongodb.uri}") String keyVaultConnectionString,
      @Value("${application.keyVault.database}") String keyVaultDatabase,
      @Value("${application.keyVault.collection}") String keyVaultCollection,
      @Value("${application.kms-provider.key}") String kmsProviderKey) {
    LOGGER.info("initialized test mongo configuration");
    KeyVaultConnectionString = keyVaultConnectionString;
    this.keyVaultDatabase = keyVaultDatabase;
    this.keyVaultCollection = keyVaultCollection;
    this.kmsProviderKey = kmsProviderKey;
  }

  @Bean
  MongoTransactionManager transactionManager(MongoDatabaseFactory dbFactory) {
    return new MongoTransactionManager(dbFactory);
  }

  @Bean
  public MongoCustomConversions customConversions() {
    final EncryptionHelper encryptionHelper = clientEncryption();
    List<Object> converters = new ArrayList<>();
    converters.add(new MongoBinaryToEncryptedFieldConverter(encryptionHelper));
    converters.add(new MongoEncryptedFieldToBinaryConverter(encryptionHelper));
    return new MongoCustomConversions(converters);
  }

  @Bean
  public EncryptionHelper clientEncryption() {
    final ClientEncryptionSettings clientEncryptionSettings =
        ClientEncryptionSettings.builder()
            .keyVaultMongoClientSettings(mongoClientSettings())
            .keyVaultNamespace(keyVaultNamespace())
            .kmsProviders(kmsProvider())
            .build();
    return new EncryptionHelper(
        ClientEncryptions.create(clientEncryptionSettings), kmsProviderKey, null, null);
  }

  private MongoClientSettings mongoClientSettings() {
    final ConnectionString connectionString = new ConnectionString(this.KeyVaultConnectionString);
    return MongoClientSettings.builder().applyConnectionString(connectionString).build();
  }

  private String keyVaultNamespace() {
    return this.keyVaultDatabase + "." + this.keyVaultCollection;
  }

  private Map<String, Map<String, Object>> kmsProvider() {
    byte[] localMasterKey = new byte[96];

    InputStream resourceAsStream = MongoConfiguration.class.getResourceAsStream("master-key.txt");
    try {
      resourceAsStream = new FileInputStream("src/test/resources/master-key.txt");
      resourceAsStream.readNBytes(localMasterKey, 0, 96);
    } catch (IOException e) {
      LOGGER.error("Failed to read the master key", e);
    }

    Map<String, Object> keyMap = new HashMap<>();
    keyMap.put("key", localMasterKey);

    Map<String, Map<String, Object>> kmsProviders = new HashMap<>();
    kmsProviders.put(this.kmsProviderKey, keyMap);
    return kmsProviders;
  }

  @Bean("jsonRepositoryPopulator")
  public Jackson2RepositoryPopulatorFactoryBean populateTopicsCollection(
      final ObjectMapper objectMapper) {
    Jackson2RepositoryPopulatorFactoryBean bean = new Jackson2RepositoryPopulatorFactoryBean();
    bean.setMapper(objectMapper);
    bean.setResources(new Resource[] {new ClassPathResource("/topics/test_data.json")});
    return bean;
  }
}
