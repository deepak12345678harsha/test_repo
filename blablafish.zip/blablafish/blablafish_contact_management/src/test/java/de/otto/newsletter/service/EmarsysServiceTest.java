package de.otto.newsletter.service;

import static de.otto.blablafish_contact_management.model.entity.UserType.SERVICE_PROVIDER;
import static de.otto.newsletter.model.dto.EmarsysContactFields.USER_ID;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.anyInt;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import de.otto.blablafish_contact_management.exception.SubscriberDoesNotExistException;
import de.otto.blablafish_contact_management.model.entity.CommunicationSubscription;
import de.otto.blablafish_contact_management.model.entity.CommunicationSubscriptionStatus;
import de.otto.blablafish_contact_management.model.entity.Status;
import de.otto.blablafish_contact_management.model.entity.Subscriber;
import de.otto.blablafish_contact_management.service.SubscriberService;
import de.otto.blablafish_contact_management.testDataConfig.SubscriberTestConfig;
import de.otto.newsletter.exception.EmarsysConnectionFailedException;
import de.otto.newsletter.gateway.EmarsysApiGatewayClient;
import de.otto.newsletter.model.JWTActions;
import de.otto.newsletter.model.dto.DeleteEmarsysContactDTO;
import de.otto.newsletter.model.dto.EmarsysContactDTO;
import de.otto.newsletter.model.dto.GetEmarsysContactDTO;
import java.time.Instant;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;

@ExtendWith(MockitoExtension.class)
class EmarsysServiceTest {

  private final ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());
  @Mock private SubscriberService subscriberService;
  @Mock private EmarsysApiGatewayClient emarsysApiGatewayClient;
  @Mock private JWTService jwtService;
  private EmarsysService emarsysService;

  @BeforeEach
  public void setEmailBlacklistService() {
    emarsysService =
        new EmarsysService(subscriberService, jwtService, emarsysApiGatewayClient, objectMapper);
  }

  @Test
  void shouldDeleteContact() throws EmarsysConnectionFailedException {
    String subscriberId = "62bec37d21d8c96a1dff30cb";
    String emarsysContactResponse =
        """
            {
                "replyCode": 0,
                "data": {
                    "errors": [],
                    "result": [
                        {
                            "id": "990297970",
                            "1530": "6273b82904b1a3676f3e12c3"
                        }
                    ]
                }
            }
            """;
    ArgumentCaptor<DeleteEmarsysContactDTO> captor =
        ArgumentCaptor.forClass(DeleteEmarsysContactDTO.class);
    when(emarsysApiGatewayClient.getContact(any()))
        .thenReturn(new ResponseEntity<>(emarsysContactResponse, HttpStatus.OK));

    when(emarsysApiGatewayClient.deleteContact(any()))
        .thenReturn(new ResponseEntity<>(HttpStatus.OK));

    emarsysService.deleteContact(subscriberId);

    verify(emarsysApiGatewayClient).deleteContact(captor.capture());
    assertThat(captor.getValue().getKeyId()).isEqualTo(USER_ID);
    assertThat(captor.getValue().getUserId()).isEqualTo(subscriberId);
  }

  @Test
  void shouldNotInvokeDeleteContactIfUserDoesNotExist() throws EmarsysConnectionFailedException {
    String subscriberId = "62bec37d21d8c96a1dff30cb";
    String emarsysContactResponse =
        """
            {
                "replyCode": 0,
                "data": {
                    "errors": [
                      {
                              "key": "62bec37d21d8c96a1dff30cb",
                              "errorCode": 2008,
                              "errorMsg": "No contact found with the external id: 1530"
                      }
                    ],
                    "result": []
                }
            }
            """;
    ArgumentCaptor<GetEmarsysContactDTO> captor =
        ArgumentCaptor.forClass(GetEmarsysContactDTO.class);
    when(emarsysApiGatewayClient.getContact(any()))
        .thenReturn(new ResponseEntity<>(emarsysContactResponse, HttpStatus.OK));

    emarsysService.deleteContact(subscriberId);

    verify(emarsysApiGatewayClient).getContact(captor.capture());
    assertThat(captor.getValue().getKeyId()).isEqualTo(USER_ID);
    assertThat(captor.getValue().getKeyValues()).isEqualTo(Set.of(subscriberId));
    assertThat(captor.getValue().getFields()).isEqualTo(Set.of(USER_ID));

    verify(emarsysApiGatewayClient, times(0)).deleteContact(any());
  }

  @Test
  void shouldThrowEmarsysConnectionFailedExceptionOnGet() {
    String subscriberId = "62bec37d21d8c96a1dff30cb";
    when(emarsysApiGatewayClient.getContact(any()))
        .thenThrow(new HttpServerErrorException(HttpStatus.SERVICE_UNAVAILABLE));

    assertThrows(
        EmarsysConnectionFailedException.class, () -> emarsysService.deleteContact(subscriberId));
  }

  @Test
  void shouldThrowEmarsysConnectionFailedExceptionOnDelete() {
    String subscriberId = "62bec37d21d8c96a1dff30cb";
    String emarsysContactResponse =
        """
            {
                "replyCode": 0,
                "data": {
                    "errors": [],
                    "result": [
                        {
                            "id": "990297970",
                            "1530": "6273b82904b1a3676f3e12c3"
                        }
                    ]
                }
            }
            """;
    when(emarsysApiGatewayClient.getContact(any()))
        .thenReturn(new ResponseEntity<>(emarsysContactResponse, HttpStatus.OK));

    when(emarsysApiGatewayClient.deleteContact(any()))
        .thenThrow(new HttpClientErrorException(HttpStatus.SERVICE_UNAVAILABLE));
    assertThrows(
        EmarsysConnectionFailedException.class, () -> emarsysService.deleteContact(subscriberId));
  }

  @Test
  void shouldUpdateContactForCooperationUser()
      throws SubscriberDoesNotExistException, EmarsysConnectionFailedException {
    var newsletterUnsubscribeKey = "newsletter.unsubscribe.key";
    var communicationsUnsubscribeKey = "communication.unsubscribe.key";
    var subscriber = new SubscriberTestConfig().build();
    when(subscriberService.getSubscriberById(subscriber.getSubscriberIdAsString()))
        .thenReturn(subscriber);
    when(jwtService.getJWT(subscriber.getUserId(), JWTActions.UNSUBSCRIBE_NEWSLETTER))
        .thenReturn(newsletterUnsubscribeKey);
    when(jwtService.getJWT(subscriber.getUserId(), JWTActions.UNSUBSCRIBE_COMMUNICATIONS))
        .thenReturn(communicationsUnsubscribeKey);
    when(emarsysApiGatewayClient.updateContact(anyInt(), any()))
        .thenReturn(new ResponseEntity<>(HttpStatus.OK));

    emarsysService.updateOrCreateContact(subscriber.getSubscriberIdAsString());

    var captor = ArgumentCaptor.forClass(EmarsysContactDTO.class);
    verify(emarsysApiGatewayClient).updateContact(eq(1), captor.capture());
    var expectedContactDTO =
        EmarsysContactDTO.withPermissions(
            subscriber, newsletterUnsubscribeKey, communicationsUnsubscribeKey);
    assertThat(captor.getValue()).usingRecursiveComparison().isEqualTo(expectedContactDTO);
  }

  @Test
  void shouldUpdateContactWithCommunicationKeyWhenSubscriberHasNullCommunicationSubscription()
      throws SubscriberDoesNotExistException, EmarsysConnectionFailedException {
    final CommunicationSubscription communicationSubscriptionAsNull = null;
    var subscriber =
        new SubscriberTestConfig()
            .subscriberBuilder()
            .communicationSubscription(communicationSubscriptionAsNull)
            .newsletterSubscription(null)
            .build();
    when(subscriberService.getSubscriberById(subscriber.getSubscriberIdAsString()))
        .thenReturn(subscriber);
    var communicationsUnsubscribeKey = "";
    when(jwtService.getJWT(subscriber.getUserId(), JWTActions.UNSUBSCRIBE_COMMUNICATIONS))
        .thenReturn(communicationsUnsubscribeKey);
    when(emarsysApiGatewayClient.updateContact(anyInt(), any()))
        .thenReturn(new ResponseEntity<>(HttpStatus.OK));

    emarsysService.updateOrCreateContact(subscriber.getSubscriberIdAsString());

    var captor = ArgumentCaptor.forClass(EmarsysContactDTO.class);
    verify(emarsysApiGatewayClient).updateContact(eq(1), captor.capture());
    var expectedContactDTO =
        EmarsysContactDTO.withPermissions(subscriber, "", communicationsUnsubscribeKey);
    assertThat(captor.getValue()).usingRecursiveComparison().isEqualTo(expectedContactDTO);
  }

  @Test
  void shouldUpdateContactWithEmptyCommunicationKeyWhenCommunicationSubscriptionIsUnsubscribed()
      throws SubscriberDoesNotExistException, EmarsysConnectionFailedException {
    final var communicationSubscription =
        new CommunicationSubscription(CommunicationSubscriptionStatus.UNSUBSCRIBED, Instant.now());
    var subscriber =
        new SubscriberTestConfig()
            .subscriberBuilder()
            .communicationSubscription(communicationSubscription)
            .newsletterSubscription(null)
            .build();

    when(subscriberService.getSubscriberById(subscriber.getSubscriberIdAsString()))
        .thenReturn(subscriber);
    var emptyCommunicationsUnsubscribeKey = "";
    when(emarsysApiGatewayClient.updateContact(anyInt(), any()))
        .thenReturn(new ResponseEntity<>(HttpStatus.OK));

    emarsysService.updateOrCreateContact(subscriber.getSubscriberIdAsString());

    var captor = ArgumentCaptor.forClass(EmarsysContactDTO.class);
    verify(emarsysApiGatewayClient).updateContact(eq(1), captor.capture());
    var expectedContactDTO =
        EmarsysContactDTO.withPermissions(subscriber, "", emptyCommunicationsUnsubscribeKey);
    assertThat(captor.getValue()).usingRecursiveComparison().isEqualTo(expectedContactDTO);
  }

  @Test
  void shouldNotTriggerUpdateContactForNonCooperationUser()
      throws EmarsysConnectionFailedException, SubscriberDoesNotExistException {
    String subscriberId = "62bec37d21d8c96a1dff30cb";
    Subscriber subscriber =
        new SubscriberTestConfig().subscriberBuilder().userType(SERVICE_PROVIDER).build();
    when(subscriberService.getSubscriberById(subscriberId)).thenReturn(subscriber);

    emarsysService.updateOrCreateContact(subscriberId);

    verifyNoInteractions(emarsysApiGatewayClient);
  }

  @Test
  void shouldNotTriggerUpdateContactForInactiveSubscriber()
      throws EmarsysConnectionFailedException, SubscriberDoesNotExistException {
    String subscriberId = "62bec37d21d8c96a1dff30cb";
    Subscriber subscriber =
        new SubscriberTestConfig().subscriberBuilder().status(Status.INVITATION_SENT).build();
    when(subscriberService.getSubscriberById(subscriberId)).thenReturn(subscriber);

    emarsysService.updateOrCreateContact(subscriberId);

    verifyNoInteractions(emarsysApiGatewayClient);
  }

  @Test
  void shouldThrowEmarsysConnectionFailedException() throws SubscriberDoesNotExistException {
    String subscriberId = "62bec37d21d8c96a1dff30cb";
    String unsubscribeKey = "unsubscribe_key";
    Subscriber subscriber = new SubscriberTestConfig().build();
    when(subscriberService.getSubscriberById(subscriberId)).thenReturn(subscriber);
    when(jwtService.getJWT(any(), any())).thenReturn(unsubscribeKey);

    when(emarsysApiGatewayClient.updateContact(anyInt(), any()))
        .thenThrow(new HttpClientErrorException(HttpStatus.SERVICE_UNAVAILABLE));
    assertThrows(
        EmarsysConnectionFailedException.class,
        () -> emarsysService.updateOrCreateContact(subscriberId));
  }
}
