package de.otto.blablafish_email.listener;

import static org.assertj.core.api.Assertions.assertThat;
import static org.testcontainers.shaded.org.awaitility.Awaitility.await;

import com.amazonaws.services.sqs.AmazonSQS;
import de.otto.blablafish_contact_management.model.dto.EventType;
import de.otto.blablafish_contact_management.model.entity.Requester;
import de.otto.blablafish_contact_management.model.entity.Status;
import de.otto.blablafish_contact_management.model.entity.Subscriber;
import de.otto.blablafish_contact_management.model.entity.Topic;
import de.otto.blablafish_contact_management.testDataConfig.SubscriberTestConfig;
import de.otto.blablafish_contact_management.testDataConfig.TopicTestBuilder;
import de.otto.blablafish_email.model.entity.Email;
import de.otto.blablafish_email.model.entity.EmailRecipient;
import de.otto.blablafish_email.model.entity.EmailRequest;
import de.otto.blablafish_email.model.entity.EmailRequestStatus;
import de.otto.blablafish_email.model.entity.EmailRequester;
import de.otto.blablafish_email.respository.EmailRequestRepository;
import de.otto.blablafish_email.testDataConfig.EmailRequestTestConfig;
import java.io.IOException;
import java.nio.file.Files;
import java.time.Instant;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;

class EmailRequestsMongoDBEventListenerIT extends AbstractContainerIT {

  @Value("${mongoDbTrigger.emailRequests.queueUrl}")
  private String emailRequestsQueueName;

  @Autowired private AmazonSQS sqs;

  @Autowired private EmailRequestRepository emailRequestRepository;

  @Test
  void shouldRenderEmail() throws IOException {
    var emailRequestId = new ObjectId("62dfb73cf65bfa1ec6f05fe0");
    createTopic();
    createEmailRequest(emailRequestId);
    var event =
        "{\"id\":\"event-1\",\"source\":\"source-1\",\"account\":\"account1\",\"time\":1672385819.437603000,\"resources\":[\"aws/email-trigger-123494\"],\"detail\":{\"operationType\":\"UPDATE\",\"clusterTime\":{\"t\":1234587,\"i\":76554},"
            + "\"documentKey\":{\"_id\":\""
            + emailRequestId
            + "\"},\"updateDescription\":{\"removedFields\":null,\"updatedFields\":null,\"truncatedArrays\":null},\"ns\":{\"db\":\"db\",\"coll\":\"emailRequests\"}},\"detail-type\":\"detailType\"}";
    var queueUrl = sqs.getQueueUrl(emailRequestsQueueName).getQueueUrl();

    sqs.sendMessage(queueUrl, event);

    await()
        .atMost(5, TimeUnit.SECONDS)
        .untilAsserted(
            () -> {
              assertThat(sqs.receiveMessage(queueUrl).getMessages()).isEmpty();
              assertThat(mongoTemplate.findAll(Email.class)).hasSize(1);
            });
    var email = mongoTemplate.findAll(Email.class).get(0);
    assertThat(email.getFromAddress().getValue())
        .isEqualTo("no-reply@nonlive.partner-info.otto.market");
    assertThat(email.getTextBody().getValue())
        .isEqualTo(getFileContentAsString("emailPayloads/test_email_text"));
    assertThat(email.getHtmlBody().getValue())
        .isEqualTo(getFileContentAsString("emailPayloads/test_email_html"));
  }

  @NotNull
  private String getFileContentAsString(String s) throws IOException {
    return new String(Files.readAllBytes(new ClassPathResource(s).getFile().toPath()));
  }

  private void createEmailRequest(ObjectId emailRequestId) {
    final ObjectId user1Id = new ObjectId("62bec37d21d8c96a1dff30cb");
    final String partnerId = "partner1";
    final int topic2Id = 2;
    final int topic1Id = 1;

    Subscriber user1 =
        SubscriberTestConfig.createSubscriber(
            user1Id,
            partnerId,
            new HashSet<>(Arrays.asList(topic1Id, topic2Id)),
            "TestUser1FirstName",
            "TestUser1LastName",
            "testuser1mail@otto.de",
            new HashSet<>(List.of("1627cc31ea20d40a10388febc")),
            Status.ENABLED,
            Instant.now(),
            Instant.now(),
            Requester.ofEventType(EventType.NEPTUNE_USER_SET),
            null);
    EmailRecipient recipient = EmailRecipient.of(user1);
    EmailRequest emailRequest =
        EmailRequestTestConfig.createEmailRequest(
            emailRequestId,
            topic1Id,
            Map.of("adjective", "custom-adjective"),
            EmailRequester.of("test-client", UUID.randomUUID().toString()),
            List.of(recipient),
            EmailRequestStatus.ACCEPTED);
    emailRequestRepository.insert(emailRequest);
  }

  private void createTopic() {
    final Topic topic1 =
        TopicTestBuilder.createTopic(
            1,
            "topic1",
            "description1",
            "email",
            true,
            Arrays.asList("123", "456"),
            "",
            "/test-topic/text.ftl",
            "/test-topic/html.ftl",
            new Document());
    mongoTemplate.save(topic1);
  }
}
