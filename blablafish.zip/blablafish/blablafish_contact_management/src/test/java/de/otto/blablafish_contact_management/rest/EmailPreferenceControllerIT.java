package de.otto.blablafish_contact_management.rest;

import static de.otto.blablafish_email.utils.Constants.COOPERATION_BASIC;
import static io.restassured.RestAssured.with;
import static org.assertj.core.api.Assertions.assertThat;

import de.otto.blablafish_contact_management.integrationtest.helpers.JwtHelper;
import de.otto.blablafish_contact_management.model.dto.UpdateEmailPreferenceRequestDTO;
import de.otto.blablafish_contact_management.model.entity.EmailPreference;
import de.otto.blablafish_contact_management.testDataConfig.SubscriberTestConfig;
import de.otto.blablafish_contact_management.testDataConfig.TopicTestBuilder;
import de.otto.blablafish_email.listener.AbstractContainerIT;
import java.time.Instant;
import java.util.HashSet;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;

class EmailPreferenceControllerIT extends AbstractContainerIT {

  @Test
  void shouldUpdateEmailPreferences() {
    var topic =
        new TopicTestBuilder()
            .topicBuilder()
            .options(
                TopicTestBuilder.topicOptionsBuilder()
                    .displayOnContactManagementUI(false)
                    .displayOnEmailConfigUI(true)
                    .build())
            .build();
    var topic2 =
        new TopicTestBuilder()
            .topicBuilder()
            .id(2)
            .options(
                TopicTestBuilder.topicOptionsBuilder()
                    .displayOnContactManagementUI(false)
                    .displayOnEmailConfigUI(true)
                    .build())
            .build();
    var subscriber =
        new SubscriberTestConfig().subscriberBuilder().effectiveRoleIds(new HashSet<>()).build();
    mongoTemplate.insert(subscriber);
    mongoTemplate.insert(topic);
    mongoTemplate.insert(topic2);
    mongoTemplate.insert(new EmailPreference(1, subscriber.getUserId(), Instant.now(), true));
    var request1 = new UpdateEmailPreferenceRequestDTO(1, true);
    var request2 = new UpdateEmailPreferenceRequestDTO(2, false);
    var updateRequestBody = List.of(request1, request2);

    final String requesterKeycloakId = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken(
            "test-client",
            requesterKeycloakId,
            List.of(COOPERATION_BASIC),
            "partner1",
            subscriber.getEmail().getValue());
    with()
        .given()
        .header("Authorization", jwt)
        .port(port)
        .basePath(BASE_PATH)
        .contentType(MediaType.APPLICATION_JSON_VALUE)
        .body(updateRequestBody)
        .when()
        .request("POST", "/v1/subscribers/notification-preferences")
        .then()
        .statusCode(200);

    var emailPreferences = mongoTemplate.findAll(EmailPreference.class);
    assertThat(emailPreferences).hasSize(2);
    assertThat(emailPreferences.get(0).isOptIn()).isTrue();
    assertThat(emailPreferences.get(1).isOptIn()).isFalse();
  }
}
