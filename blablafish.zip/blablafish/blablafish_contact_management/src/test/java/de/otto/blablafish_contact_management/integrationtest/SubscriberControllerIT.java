package de.otto.blablafish_contact_management.integrationtest;

import static de.otto.blablafish_contact_management.utils.Constants.CONTACT_MANAGEMENT_SERVICE_SUBSCRIBER_READ_ROLE;
import static de.otto.blablafish_contact_management.utils.Constants.CONTACT_MANAGEMENT_SUBSCRIBER_WRITE_ROLE;
import static io.restassured.RestAssured.with;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

import de.otto.blablafish_contact_management.integrationtest.helpers.JwtHelper;
import de.otto.blablafish_contact_management.model.dto.*;
import de.otto.blablafish_contact_management.model.entity.Requester;
import de.otto.blablafish_contact_management.model.entity.Status;
import de.otto.blablafish_contact_management.model.entity.Subscriber;
import de.otto.blablafish_contact_management.model.entity.Topic;
import de.otto.blablafish_contact_management.respository.SubscriberRepository;
import de.otto.blablafish_contact_management.respository.TopicRepository;
import de.otto.blablafish_contact_management.rest.ResponseCollection;
import de.otto.blablafish_contact_management.testDataConfig.SubscriberTestConfig;
import de.otto.blablafish_contact_management.testDataConfig.TopicTestBuilder;
import de.otto.blablafish_email.listener.AbstractContainerIT;
import io.restassured.common.mapper.TypeRef;
import java.time.Instant;
import java.util.*;
import org.assertj.core.api.Assertions;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.data.mongodb.core.query.BasicQuery;
import org.springframework.http.HttpStatus;

class SubscriberControllerIT extends AbstractContainerIT {

  private final int topic1Id = 1;
  private final int topic2Id = 2;
  private final Topic topic1 =
      TopicTestBuilder.createTopic(
          topic1Id,
          "topic1",
          "description1",
          "email",
          true,
          Arrays.asList("123", "456"),
          "",
          "",
          "",
          new Document());
  private final Topic topic2 =
      TopicTestBuilder.createTopic(
          topic2Id,
          "topic2",
          "description2",
          "email",
          true,
          Arrays.asList("789", "147"),
          "",
          "",
          "",
          new Document());
  private final ObjectId user1Id = new ObjectId("62bec37d21d8c96a1dff30cb");
  private final ObjectId user2Id = new ObjectId();
  private final String partnerId = "partner1";

  @Autowired private SubscriberRepository subscriberRepository;

  @Autowired private TopicRepository topicRepository;

  @AfterEach
  void tearDown() {
    this.mongoTemplate.remove(new BasicQuery(new Document()), Topic.class);
    this.mongoTemplate.remove(new BasicQuery(new Document()), Subscriber.class);
  }

  @Test
  void shouldReturn403WhenRequiredRoleIsNotPresentForGetSubscribers() {
    final String requesterKeycloakId = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken("test-client", requesterKeycloakId, List.of("foobar"), partnerId);
    final ErrorResponse errorResponse =
        with()
            .given()
            .header("Authorization", jwt)
            .port(port)
            .basePath(BASE_PATH)
            .when()
            .request("GET", "/v1/subscribers")
            .then()
            .statusCode(HttpStatus.FORBIDDEN.value())
            .and()
            .extract()
            .body()
            .as(new TypeRef<>() {});
    Assertions.assertThat(errorResponse.getMessage()).isEqualTo("Access is denied");
  }

  @Test
  void shouldReturnAllSubscribersForPartner() {
    createSubscribers();
    ResponseCollection<SubscriberDTO> expectedUsers =
        new ResponseCollection<>(List.of(getSubscriberDTO1(), getSubscriberDTO2()));
    final String requesterKeycloakId = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken(
            "test-client",
            requesterKeycloakId,
            List.of(CONTACT_MANAGEMENT_SUBSCRIBER_WRITE_ROLE),
            partnerId);
    ResponseCollection<SubscriberDTO> actualUsers =
        with()
            .given()
            .header("Authorization", jwt)
            .port(port)
            .basePath(BASE_PATH)
            .when()
            .request("GET", "/v1/subscribers")
            .then()
            .statusCode(200)
            .and()
            .extract()
            .body()
            .as(new TypeRef<>() {});

    assertEquals(2, actualUsers.getCount());
    assertThat(actualUsers).usingRecursiveComparison().isEqualTo(expectedUsers);
  }

  @Test
  void shouldReturn403WhenRequiredRoleIsNotPresentForGetSubscribersByCompleteEmail() {
    final String requesterKeycloakId = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken("test-client", requesterKeycloakId, List.of("foobar"), partnerId);
    final ErrorResponse errorResponse =
        with()
            .given()
            .header("Authorization", jwt)
            .port(port)
            .basePath(BASE_PATH)
            .queryParam("search", "testuser1mail@otto.de")
            .when()
            .request("GET", "/v1/subscribers")
            .then()
            .statusCode(HttpStatus.FORBIDDEN.value())
            .and()
            .extract()
            .body()
            .as(new TypeRef<>() {});
    Assertions.assertThat(errorResponse.getMessage()).isEqualTo("Access is denied");
  }

  @Test
  void shouldReturnAllSubscribersForGivenPartnerAndCompleteEmail() {
    createSubscribers();
    ResponseCollection<SubscriberDTO> expectedUsers =
        new ResponseCollection<>(List.of(getSubscriberDTO1()));
    final String requesterKeycloakId = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken(
            "test-client",
            requesterKeycloakId,
            List.of(CONTACT_MANAGEMENT_SUBSCRIBER_WRITE_ROLE),
            partnerId);
    ResponseCollection<SubscriberDTO> actualUsers =
        with()
            .given()
            .header("Authorization", jwt)
            .port(port)
            .basePath(BASE_PATH)
            .queryParam("search", "testuser1mail@otto.de")
            .when()
            .request("GET", "/v1/subscribers")
            .then()
            .statusCode(200)
            .and()
            .extract()
            .body()
            .as(new TypeRef<>() {});

    assertEquals(1, actualUsers.getCount());
    assertThat(actualUsers).usingRecursiveComparison().isEqualTo(expectedUsers);
  }

  @Test
  void shouldReturnEmptySubscribersForNonExistentPartner() {
    createSubscribers();
    ResponseCollection<SubscriberDTO> expectedUsers =
        new ResponseCollection<>(Collections.emptyList());
    final String requesterKeycloakId = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken(
            "test-client",
            requesterKeycloakId,
            List.of(CONTACT_MANAGEMENT_SUBSCRIBER_WRITE_ROLE),
            "1234");
    ResponseCollection<SubscriberDTO> actualUsers =
        with()
            .given()
            .header("Authorization", jwt)
            .port(port)
            .basePath(BASE_PATH)
            .when()
            .request("GET", "/v1/subscribers")
            .then()
            .statusCode(200)
            .and()
            .extract()
            .body()
            .as(new TypeRef<>() {});

    assertEquals(0, actualUsers.getCount());
    assertThat(actualUsers).usingRecursiveComparison().isEqualTo(expectedUsers);
  }

  @Test
  void shouldReturnEmptySubscribersForPartialEmail() {
    createSubscribers();
    ResponseCollection<SubscriberDTO> expectedUsers =
        new ResponseCollection<>(Collections.emptyList());
    final String requesterKeycloakId = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken(
            "test-client",
            requesterKeycloakId,
            List.of(CONTACT_MANAGEMENT_SUBSCRIBER_WRITE_ROLE),
            partnerId);
    ResponseCollection<SubscriberDTO> actualUsers =
        with()
            .given()
            .header("Authorization", jwt)
            .port(port)
            .basePath(BASE_PATH)
            .queryParam("search", "testuser1mail")
            .when()
            .request("GET", "/v1/subscribers")
            .then()
            .statusCode(200)
            .and()
            .extract()
            .body()
            .as(new TypeRef<>() {});

    assertEquals(0, actualUsers.getCount());
    assertThat(actualUsers).usingRecursiveComparison().isEqualTo(expectedUsers);
  }

  @Test
  void shouldReturn403WhenRequiredRoleIsNotPresentForGetSubscribersByEmailAddress() {
    final String requesterKeycloakId = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken("test-client", requesterKeycloakId, List.of("foobar"), partnerId);
    final ErrorResponse errorResponse =
        with()
            .given()
            .header("Authorization", jwt)
            .port(port)
            .basePath(BASE_PATH)
            .queryParam("emailAddress", "testuser1mail@otto.de")
            .when()
            .request("GET", "/v1/subscribers")
            .then()
            .statusCode(HttpStatus.FORBIDDEN.value())
            .and()
            .extract()
            .body()
            .as(new TypeRef<>() {});
    Assertions.assertThat(errorResponse.getMessage()).isEqualTo("Access is denied");
  }

  @Test
  void shouldReturnUserByEmailAddress() {
    createSubscribers();
    SubscriberDTO expectedUser = getSubscriberDTO1();
    final String requesterKeycloakId = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken(
            "test-client",
            requesterKeycloakId,
            List.of(CONTACT_MANAGEMENT_SERVICE_SUBSCRIBER_READ_ROLE),
            partnerId);
    SubscriberDTO actualUser =
        with()
            .given()
            .header("Authorization", jwt)
            .port(port)
            .basePath(BASE_PATH)
            .queryParam("emailAddress", "testuser1mail@otto.de")
            .when()
            .request("GET", "/v1/subscribers")
            .then()
            .statusCode(200)
            .and()
            .extract()
            .body()
            .as(new TypeRef<>() {});

    assertThat(actualUser).usingRecursiveComparison().isEqualTo(expectedUser);
  }

  @Test
  void shouldNotCreateSubscribersWithSameEmailId() {
    String email = "testuser@otto.de";
    Subscriber subscriber1 =
        SubscriberTestConfig.createSubscriber(
            user1Id,
            partnerId,
            new HashSet<>(Arrays.asList(topic1Id, topic2Id)),
            "TestUser1FirstName",
            "TestUser1LastName",
            email,
            new HashSet<>(List.of("1627cc31ea20d40a10388febc")),
            Status.ENABLED,
            Instant.now(),
            Instant.now(),
            Requester.ofEventType(EventType.NEPTUNE_USER_SET),
            null);
    Subscriber subscriber2 =
        SubscriberTestConfig.createSubscriber(
            user2Id,
            partnerId,
            new HashSet<>(List.of(topic1Id)),
            "TestUser2FirstName",
            "TestUser2LastName",
            email,
            new HashSet<>(List.of("1234")),
            Status.ENABLED,
            Instant.now(),
            Instant.now(),
            Requester.ofEventType(EventType.NEPTUNE_USER_SET),
            null);
    subscriberRepository.upsert(subscriber1);
    DuplicateKeyException exception =
        assertThrows(DuplicateKeyException.class, () -> subscriberRepository.upsert(subscriber2));
    assertThat(exception.getMessage())
        .contains(
            "message='E11000 duplicate key error collection: test.subscribers index: email dup key");
  }

  @Test
  void shouldReturnErrorWhenNoSubscriberFoundByEmailAddress() {
    createSubscribers();
    ErrorResponse expectedResponse =
        new ErrorResponse(
            "User with email address: random@otto.de does not exists", 0, Collections.emptyList());
    final String requesterKeycloakId = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken(
            "test-client",
            requesterKeycloakId,
            List.of(CONTACT_MANAGEMENT_SERVICE_SUBSCRIBER_READ_ROLE),
            partnerId);
    ErrorResponse response =
        with()
            .given()
            .header("Authorization", jwt)
            .port(port)
            .basePath(BASE_PATH)
            .queryParam("emailAddress", "random@otto.de")
            .when()
            .request("GET", "/v1/subscribers")
            .then()
            .statusCode(404)
            .and()
            .extract()
            .body()
            .as(new TypeRef<>() {});

    assertThat(response).usingRecursiveComparison().isEqualTo(expectedResponse);
  }

  @Test
  void shouldReturn403WhenRequiredRoleIsNotPresentForDeleteSubscribers() {
    final String requesterKeycloakId = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken("test-client", requesterKeycloakId, List.of("foobar"), partnerId);
    final ErrorResponse errorResponse =
        with()
            .given()
            .header("Authorization", jwt)
            .port(port)
            .basePath(BASE_PATH)
            .when()
            .request("DELETE", "/v1/topics/" + topic1Id + "/subscribers/" + user1Id)
            .then()
            .statusCode(HttpStatus.FORBIDDEN.value())
            .and()
            .extract()
            .body()
            .as(new TypeRef<>() {});
    Assertions.assertThat(errorResponse.getMessage()).isEqualTo("Access is denied");
  }

  @Test
  void shouldUnsubscribeUserFromTopic() {
    createTopics();
    createSubscribers();
    final var requesterKeycloakId = UUID.randomUUID().toString();
    var jwt =
        JwtHelper.createToken(
            "test-client",
            requesterKeycloakId,
            List.of(CONTACT_MANAGEMENT_SUBSCRIBER_WRITE_ROLE),
            partnerId,
            "testuser1mail@otto.de");

    with()
        .given()
        .header("Authorization", jwt)
        .port(port)
        .basePath(BASE_PATH)
        .when()
        .request("DELETE", "/v1/topics/" + topic1Id + "/subscribers/" + user1Id)
        .then()
        .statusCode(200);

    var subscriber = subscriberRepository.findById(user1Id).orElseThrow();
    assertFalse(subscriber.getTopicIds().contains(topic1Id));
    assertThat(subscriber.getLastUpdatedBy().getSubscriberId()).isEqualTo(user1Id);
  }

  @Test
  void shouldNotDeleteLastUserInTopic() {
    createTopics();
    createSubscribers();
    ErrorResponse expectedErrorResponse =
        ErrorResponse.builder()
            .errorCode(1000)
            .message(
                "Cannot unsubscribe 62bec37d21d8c96a1dff30cb because it is last user in topic : 2")
            .build();
    final String requesterKeycloakId = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken(
            "test-client",
            requesterKeycloakId,
            List.of(CONTACT_MANAGEMENT_SUBSCRIBER_WRITE_ROLE),
            partnerId,
            "testuser1mail@otto.de");
    ErrorResponse errorResponse =
        with()
            .given()
            .header("Authorization", jwt)
            .port(port)
            .basePath(BASE_PATH)
            .when()
            .request("DELETE", "/v1/topics/" + topic2Id + "/subscribers/" + user1Id)
            .then()
            .statusCode(400)
            .and()
            .extract()
            .body()
            .as(ErrorResponse.class);

    Assertions.assertThat(errorResponse)
        .usingRecursiveComparison()
        .isEqualTo(expectedErrorResponse);
  }

  @Test
  void shouldReturn403WhenRequiredRoleIsNotPresentForPutSubscribers() {
    final String requesterKeycloakId = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken("test-client", requesterKeycloakId, List.of("foobar"), partnerId);
    final ErrorResponse errorResponse =
        with()
            .given()
            .header("Authorization", jwt)
            .header("Content-Type", "application/json")
            .body(
                "{\"userIds\": [\""
                    + user2Id
                    + "\",\"629089ba391a524f0b687f4a\",\"629089ba391a524f0b687f4b\",\"629089ba391a524f0b687f4c\",\""
                    + user1Id
                    + "\"]}")
            .port(port)
            .basePath(BASE_PATH)
            .when()
            .request("PUT", "/v1/topics/2/subscribers")
            .then()
            .statusCode(HttpStatus.FORBIDDEN.value())
            .and()
            .extract()
            .body()
            .as(new TypeRef<>() {});
    Assertions.assertThat(errorResponse.getMessage()).isEqualTo("Access is denied");
  }

  @Test
  void shouldSubscribeUsersToGivenTopic() {
    createTopics();
    createSubscribers();

    AddSubscribersResponse expectedResponse = getAddSubscribersResponse();
    final String subject = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken(
            "test-client",
            subject,
            List.of(CONTACT_MANAGEMENT_SUBSCRIBER_WRITE_ROLE),
            partnerId,
            "testuser1mail@otto.de");

    var userAgent =
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36";
    AddSubscribersResponse actualResponse =
        with()
            .given()
            .port(port)
            .basePath(BASE_PATH)
            .header("Authorization", jwt)
            .header("Content-Type", "application/json")
            .header("user-agent", userAgent)
            .body(
                "{\"userIds\": [\""
                    + user2Id
                    + "\",\"629089ba391a524f0b687f4a\",\"629089ba391a524f0b687f4b\",\"629089ba391a524f0b687f4c\",\""
                    + user1Id
                    + "\"]}")
            .when()
            .request("PUT", "/v1/topics/2/subscribers")
            .then()
            .statusCode(200)
            .and()
            .extract()
            .body()
            .as(new TypeRef<>() {});

    var subscriber = subscriberRepository.findById(user2Id).orElseThrow();
    assertEquals(2, subscriber.getTopicIds().size());
    assertTrue(subscriber.getTopicIds().contains(2));
    assertThat(subscriber.getLastUpdatedBy().getUserAgent()).isEqualTo(userAgent);
    assertThat(subscriber.getLastUpdatedBy().getSubscriberId()).isEqualTo(user1Id);

    Assertions.assertThat(actualResponse).usingRecursiveComparison().isEqualTo(expectedResponse);
  }

  @Test
  void shouldReturnTopicNotFoundWhenUsersSubscribeToTopicWhichDoesntExist() {
    createTopics();
    createSubscribers();

    final String requesterKeycloakId = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken(
            "test-client",
            requesterKeycloakId,
            List.of(CONTACT_MANAGEMENT_SUBSCRIBER_WRITE_ROLE),
            partnerId,
            "testuser1mail@otto.de");
    ErrorResponse topicSubscribers =
        with()
            .given()
            .port(port)
            .basePath(BASE_PATH)
            .header("Authorization", jwt)
            .header("Content-Type", "application/json")
            .body(" { \"userIds\": [\"" + user2Id.toString() + "\"]}")
            .when()
            .request("PUT", "/v1/topics/3/subscribers")
            .then()
            .statusCode(404)
            .and()
            .extract()
            .body()
            .as(new TypeRef<>() {});

    assertEquals("Topic with id 3 does not exists", topicSubscribers.getMessage());
  }

  @Test
  void shouldReturn403WhenRequiredRoleIsNotPresentForGetSubscriberById() {
    final String requesterKeycloakId = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken("test-client", requesterKeycloakId, List.of("foobar"), partnerId);
    final ErrorResponse errorResponse =
        with()
            .given()
            .header("Authorization", jwt)
            .port(port)
            .basePath(BASE_PATH)
            .when()
            .request("GET", "/v1/subscribers/" + user1Id)
            .then()
            .statusCode(HttpStatus.FORBIDDEN.value())
            .and()
            .extract()
            .body()
            .as(new TypeRef<>() {});
    Assertions.assertThat(errorResponse.getMessage()).isEqualTo("Access is denied");
  }

  @Test
  void shouldReturnSubscriberById() {
    createSubscribers();
    SubscriberDTO expectedUser = getSubscriberDTO1();
    final String requesterKeycloakId = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken(
            "test-client",
            requesterKeycloakId,
            List.of(CONTACT_MANAGEMENT_SERVICE_SUBSCRIBER_READ_ROLE),
            partnerId);
    SubscriberDTO actualUser =
        with()
            .given()
            .header("Authorization", jwt)
            .port(port)
            .basePath(BASE_PATH)
            .when()
            .request("GET", "/v1/subscribers/" + user1Id)
            .then()
            .statusCode(200)
            .and()
            .extract()
            .body()
            .as(new TypeRef<>() {});

    assertThat(actualUser).usingRecursiveComparison().isEqualTo(expectedUser);
  }

  private void createTopics() {
    topicRepository.save(topic1);
    topicRepository.save(topic2);
  }

  private void createSubscribers() {
    Subscriber user1 =
        SubscriberTestConfig.createSubscriber(
            user1Id,
            partnerId,
            new HashSet<>(Arrays.asList(topic1Id, topic2Id)),
            "TestUser1FirstName",
            "TestUser1LastName",
            "testuser1mail@otto.de",
            new HashSet<>(List.of("1627cc31ea20d40a10388febc")),
            Status.ENABLED,
            Instant.now(),
            Instant.now(),
            Requester.ofEventType(EventType.NEPTUNE_USER_SET),
            null);
    Subscriber user2 =
        SubscriberTestConfig.createSubscriber(
            user2Id,
            partnerId,
            new HashSet<>(List.of(topic1Id)),
            "TestUser2FirstName",
            "TestUser2LastName",
            "testuser2mail@otto.de",
            new HashSet<>(List.of("1234")),
            Status.ENABLED,
            Instant.now(),
            Instant.now(),
            Requester.ofEventType(EventType.NEPTUNE_USER_SET),
            null);
    subscriberRepository.upsert(user1);
    subscriberRepository.upsert(user2);
  }

  private AddSubscribersResponse getAddSubscribersResponse() {
    List<AddSubscriberResponse> statuses = new ArrayList<>();
    statuses.add(
        new AddSubscriberResponse(
            SubscriptionResponse.SUBSCRIPTION_SUCCESSFUL,
            Set.of(user1Id.toString(), user2Id.toString())));
    statuses.add(
        new AddSubscriberResponse(
            SubscriptionResponse.SUBSCRIPTION_UNSUCCESSFUL,
            Set.of(
                "629089ba391a524f0b687f4a",
                "629089ba391a524f0b687f4b",
                "629089ba391a524f0b687f4c")));
    return new AddSubscribersResponse(statuses);
  }

  private SubscriberDTO getSubscriberDTO1() {
    return SubscriberDTO.builder()
        .id(user1Id.toString())
        .email("testuser1mail@otto.de")
        .firstName("TestUser1FirstName")
        .lastName("TestUser1LastName")
        .build();
  }

  private SubscriberDTO getSubscriberDTO2() {
    return SubscriberDTO.builder()
        .id(user2Id.toString())
        .email("testuser2mail@otto.de")
        .firstName("TestUser2FirstName")
        .lastName("TestUser2LastName")
        .build();
  }
}
