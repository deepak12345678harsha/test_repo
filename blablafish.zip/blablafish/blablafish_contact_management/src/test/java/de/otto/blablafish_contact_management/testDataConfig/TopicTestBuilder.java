package de.otto.blablafish_contact_management.testDataConfig;

import de.otto.blablafish_contact_management.model.entity.Topic;
import de.otto.blablafish_contact_management.model.entity.TopicOptions;
import de.otto.blablafish_contact_management.model.entity.TopicOptions.TopicOptionsBuilder;
import java.util.Collections;
import java.util.List;
import org.bson.Document;

public class TopicTestBuilder {

  private int id = 1;
  private String name = "contracts";
  private String description = "Topic for contract";
  private List<String> mandatorySubscriberRoles = Collections.emptyList();
  private String emailSubject = "Email Subject for topic Contract";
  private String emailPlainTextTemplate = "files/contract.email.template.file";
  private String emailHtmlTemplate = "files/contract.email.html.template";
  private Document emailSchema = new Document("key1", "value-contract");

  public static Topic createTopic(
      int id,
      String name,
      String description,
      String communicationType,
      Boolean isMandatory,
      List<String> mandatorySubscriberRoles,
      String emailSubject,
      String emailPlainTextTemplate,
      String emailHtmlTemplate,
      Document emailSchema) {

    return Topic.builder()
        .id(id)
        .name(name)
        .description(description)
        .mandatorySubscriberRoles(mandatorySubscriberRoles)
        .emailSubject(emailSubject)
        .emailPlainTextTemplate(emailPlainTextTemplate)
        .emailHtmlTemplate(emailHtmlTemplate)
        .emailSchema(emailSchema)
        .options(topicOptionsBuilder().build())
        .build();
  }

  public Topic.TopicBuilder topicBuilder() {
    return Topic.builder()
        .id(id)
        .name(name)
        .description(description)
        .mandatorySubscriberRoles(mandatorySubscriberRoles)
        .emailSubject(emailSubject)
        .emailPlainTextTemplate(emailPlainTextTemplate)
        .emailHtmlTemplate(emailHtmlTemplate)
        .emailSchema(emailSchema)
        .options(topicOptionsBuilder().build());
  }

  public TopicTestBuilder id(int id) {
    this.id = id;
    return this;
  }

  public static TopicOptionsBuilder topicOptionsBuilder() {
    return TopicOptions.builder()
        .archiving(true)
        .displayOnContactManagementUI(true)
        .canUnsubscribe(true)
        .displayOnEmailConfigUI(false)
        .isSubscribedByDefault(true);
  }
}
