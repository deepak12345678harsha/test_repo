package de.otto.blablafish_contact_management.service;

import static de.otto.blablafish_contact_management.model.Actions.SYNC_USER_DATA_TO_EMARSYS;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

import de.otto.blablafish_contact_management.handler.ActionHandlerFactory;
import de.otto.blablafish_contact_management.model.Actions;
import de.otto.blablafish_contact_management.model.entity.ActionError;
import de.otto.blablafish_contact_management.model.entity.Subscriber;
import de.otto.blablafish_contact_management.respository.SubscriberRepository;
import de.otto.blablafish_contact_management.testDataConfig.SubscriberTestConfig;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class SubscriberActionServiceTest {
  @Mock private ActionHandlerFactory actionHandlerFactory;

  @Mock private SubscriberRepository subscriberRepository;

  private SubscriberActionService subscriberActionService;

  @BeforeEach
  void setUp() {
    subscriberActionService =
        new SubscriberActionService(subscriberRepository, actionHandlerFactory);
  }

  @Test
  void shouldUpdateActionErrorWhenProcessingAnActionFails() {
    String subscriberId = "62bec37d21d8c96a1dff30cb";
    Subscriber subscriber =
        new SubscriberTestConfig()
            .subscriberBuilder()
            .actions(actionsWith(SYNC_USER_DATA_TO_EMARSYS))
            .build();
    when(subscriberRepository.acquireLockAndReturnSubscriberById(subscriberId))
        .thenReturn(Optional.of(subscriber));
    RuntimeException exception = new RuntimeException("Action handle error");
    doThrow(exception).when(actionHandlerFactory).handlerFor(SYNC_USER_DATA_TO_EMARSYS);
    assertThatThrownBy(() -> subscriberActionService.executeAction(subscriberId))
        .isInstanceOf(RuntimeException.class);

    ArgumentCaptor<ActionError> captor = ArgumentCaptor.forClass(ActionError.class);
    verify(subscriberRepository).updateSubscriberActionError(any(), captor.capture());
    assertThat(captor.getValue())
        .usingRecursiveComparison()
        .ignoringFields("attemptedAt")
        .isEqualTo(ActionError.of(exception));
  }

  @Test
  void shouldReleaseLockWhenNoActionsPresent() {
    String subscriberId = "62bec37d21d8c96a1dff30cb";
    Subscriber subscriber = mock(Subscriber.class);
    LinkedList<Actions> emptyActions = new LinkedList<>();
    when(subscriber.getActions()).thenReturn(emptyActions);
    when(subscriberRepository.acquireLockAndReturnSubscriberById(subscriberId))
        .thenReturn(Optional.of(subscriber));

    subscriberActionService.executeAction(subscriberId);

    verify(subscriberRepository).releaseLockBySubscriberId(eq(subscriberId), any());
  }

  private LinkedList actionsWith(Actions... actions) {
    return new LinkedList(Arrays.stream(actions).toList());
  }
}
