package de.otto.blablafish_contact_management.listeners;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.matching;
import static com.github.tomakehurst.wiremock.client.WireMock.put;
import static com.github.tomakehurst.wiremock.client.WireMock.putRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.verify;
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.http.HttpHeaders.ACCEPT;
import static org.springframework.http.HttpHeaders.CONTENT_TYPE;
import static org.testcontainers.shaded.org.awaitility.Awaitility.await;
import static org.testcontainers.shaded.org.awaitility.Awaitility.given;

import com.amazonaws.services.simpleemailv2.AmazonSimpleEmailServiceV2;
import com.amazonaws.services.simpleemailv2.model.ListSuppressedDestinationsRequest;
import com.amazonaws.services.simpleemailv2.model.PutSuppressedDestinationRequest;
import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.model.SubscribeRequest;
import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.model.GetQueueAttributesRequest;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.matching.EqualToPattern;
import de.otto.blablafish_contact_management.config.Features;
import de.otto.blablafish_contact_management.integrationtest.config.WireMockExtension;
import de.otto.blablafish_contact_management.model.Actions;
import de.otto.blablafish_contact_management.testDataConfig.SubscriberTestConfig;
import de.otto.blablafish_email.listener.AbstractContainerIT;
import de.otto.newsletter.model.dto.EmarsysContactDTO;
import de.otto.newsletter.testdata.EmarsysContactDTOTestBuilder;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.togglz.junit5.AllEnabled;

@AllEnabled(Features.class)
@ExtendWith(WireMockExtension.class)
class SubscriberActionsMongoDBTriggerListenerIT extends AbstractContainerIT {

  @Value("${mongoDbTrigger.subscribers.actions.queueUrl}")
  private String subscribersMongoDBActionsTriggerQueueName;

  @Value("${topic.email_events.arn}")
  private String topicArn;

  @Autowired private AmazonSQS sqs;
  @Autowired private AmazonSNS sns;
  @Autowired private ObjectMapper objectMapper;
  @Autowired private AmazonSimpleEmailServiceV2 sesClient;

  @Test
  void shouldProcessSubscriberMongoDBTriggerActions() throws JsonProcessingException {
    var emarsysContactJsonAsString =
        objectMapper.writeValueAsString(
            EmarsysContactDTOTestBuilder.emarsysContactBuilder().build());

    var subscriber =
        new SubscriberTestConfig()
            .subscriberBuilder()
            .actions(new LinkedList<>(List.of(Actions.SYNC_USER_DATA_TO_EMARSYS)))
            .build();

    var updateContactUrl = "/contact-management/v1/emarsys/v2/contact/?create_if_not_exists=1";
    stubFor(
        put(updateContactUrl)
            .withHeader(
                HttpHeaders.CONTENT_TYPE, new EqualToPattern(MediaType.APPLICATION_JSON_VALUE))
            .willReturn(
                aResponse()
                    .withFixedDelay(1000)
                    .withStatus(HttpStatus.OK.value())
                    .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.TEXT_HTML_VALUE)
                    .withBody(emarsysContactJsonAsString)));

    mongoTemplate.insert(subscriber);
    var queueUrl = sqs.getQueueUrl(subscribersMongoDBActionsTriggerQueueName).getQueueUrl();
    var subscriberId = "62bec37d21d8c96a1dff30cb";
    var eventAsString =
        "{\"id\":\"event-1\",\"source\":\"mongodb/trigger/sub1234\",\"account\":\"account1\",\"time\":1234.587000000,\"resources\":[\"aws/trigger/sub1234\"],\"detail\":{\"operationType\":\"UPDATE\",\"clusterTime\":{\"i\":76554,\"t\":1234587},\"documentKey\":{\"_id\":\""
            + subscriberId
            + "\"},\"updateDescription\":{\"removedFields\":null,\"updatedFields\":null,\"truncatedArrays\":null},\"ns\":{\"db\":\"contact_management_db\",\"coll\":\"subscribers\"}},\"detail-type\":\"detailType\"}";

    sqs.sendMessage(queueUrl, eventAsString);

    await()
        .atMost(5, TimeUnit.SECONDS)
        .untilAsserted(
            () -> {
              assertThat(sqs.receiveMessage(queueUrl).getMessages()).isEmpty();
              assertThat(WireMock.getAllServeEvents()).hasSize(1);
            });
    assertThat(WireMock.getAllServeEvents()).hasSize(1);
    verify(
        1,
        putRequestedFor(urlEqualTo(updateContactUrl))
            .withHeader(CONTENT_TYPE, equalTo(MediaType.APPLICATION_JSON_VALUE))
            .withHeader(ACCEPT, equalTo(MediaType.TEXT_HTML_VALUE))
            .withHeader("X-WSSE", matching("UsernameToken .*")));
    var expectedContact =
        objectMapper.readValue(
            WireMock.getAllServeEvents().get(0).getRequest().getBodyAsString(),
            EmarsysContactDTO.class);
    assertThat(expectedContact.getGroups()).isEqualTo(Set.of("4", "7"));
    assertThat(expectedContact.getUserId()).isEqualTo(subscriber.getUserId().toString());
    assertThat(expectedContact.getPartnerId()).isEqualTo(subscriber.getPartnerId());
  }

  @Test
  void shouldSendSNSEventWhenDeletingBlacklistedEmail()
      throws JsonProcessingException, JSONException {

    var testQueueName = "unblacklist-event-test-queue";
    var testQueueUrl = sqs.createQueue(testQueueName).getQueueUrl();
    var testQueueAttributes =
        sqs.getQueueAttributes(
            new GetQueueAttributesRequest(testQueueUrl).withAttributeNames("QueueArn"));
    var testQueueArn = testQueueAttributes.getAttributes().get("QueueArn");

    var subscribeRequest =
        new SubscribeRequest()
            .withProtocol("sqs")
            .withEndpoint(testQueueArn)
            .withReturnSubscriptionArn(true)
            .withTopicArn(topicArn);
    var subscribeResult = sns.subscribe(subscribeRequest);
    assertThat(subscribeResult.getSubscriptionArn()).isNotNull();

    var subscriber =
        new SubscriberTestConfig()
            .subscriberBuilder()
            .actions(new LinkedList<>(List.of(Actions.SEND_UNBLACKLIST_EVENT_TO_NEPTUNE)))
            .build();
    mongoTemplate.insert(subscriber);

    var queueUrl = sqs.getQueueUrl(subscribersMongoDBActionsTriggerQueueName).getQueueUrl();
    var subscriberId = subscriber.getUserId().toHexString();
    var eventAsString =
        "{\"id\":\"event-1\",\"source\":\"mongodb/trigger/sub1234\",\"account\":\"account1\",\"time\":1234.587000000,\"resources\":[\"aws/trigger/sub1234\"],\"detail\":{\"operationType\":\"UPDATE\",\"clusterTime\":{\"i\":76554,\"t\":1234587},\"documentKey\":{\"_id\":\""
            + subscriberId
            + "\"},\"updateDescription\":{\"removedFields\":null,\"updatedFields\":null,\"truncatedArrays\":null},\"ns\":{\"db\":\"contact_management_db\",\"coll\":\"subscribers\"}},\"detail-type\":\"detailType\"}";

    sqs.sendMessage(queueUrl, eventAsString);

    given()
        .await()
        .atMost(5, TimeUnit.SECONDS)
        .untilAsserted(
            () -> {
              var messagesInQueue =
                  Integer.parseInt(
                      sqs.getQueueAttributes(
                              new GetQueueAttributesRequest(queueUrl)
                                  .withAttributeNames("ApproximateNumberOfMessages"))
                          .getAttributes()
                          .get("ApproximateNumberOfMessages"));
              assertThat(messagesInQueue).isZero();
            });

    given()
        .await()
        .atMost(5, TimeUnit.SECONDS)
        .untilAsserted(
            () -> {
              var messagesInQueue =
                  Integer.parseInt(
                      sqs.getQueueAttributes(
                              new GetQueueAttributesRequest(testQueueUrl)
                                  .withAttributeNames("ApproximateNumberOfMessages"))
                          .getAttributes()
                          .get("ApproximateNumberOfMessages"));
              assertThat(messagesInQueue).isEqualTo(1);
            });

    var receiveMessageResult = sqs.receiveMessage(testQueueUrl);
    var messageBody = receiveMessageResult.getMessages().get(0).getBody();
    var message = new JSONObject(objectMapper.readTree(messageBody).get("Message").textValue());

    assertThat(receiveMessageResult.getMessages()).size().isEqualTo(1);
    assertThat(message.getString("type")).hasToString("contact-management.EMAIL_UNBLACKLISTED");
    assertThat(message.getJSONObject("data").getString("neptuneUserId")).hasToString(subscriberId);

    sns.unsubscribe(subscribeResult.getSubscriptionArn());
    sqs.deleteQueue(queueUrl);
  }

  @Test
  void shouldRemoveEmailFromSuppressionList() {
    var subscriber =
        new SubscriberTestConfig()
            .subscriberBuilder()
            .actions(new LinkedList<>(List.of(Actions.REMOVE_EMAIL_FROM_SES_SUPPRESSION_LIST)))
            .build();
    mongoTemplate.insert(subscriber);

    var putSuppressedDestinationResult =
        sesClient.putSuppressedDestination(
            new PutSuppressedDestinationRequest()
                .withEmailAddress(subscriber.getEmail().getValue()));
    assertThat(putSuppressedDestinationResult.getSdkHttpMetadata().getHttpStatusCode())
        .isEqualTo(200);

    var queueUrl = sqs.getQueueUrl(subscribersMongoDBActionsTriggerQueueName).getQueueUrl();
    var subscriberId = subscriber.getUserId().toHexString();
    var eventAsString =
        "{\"id\":\"event-1\",\"source\":\"mongodb/trigger/sub1234\",\"account\":\"account1\",\"time\":1234.587000000,\"resources\":[\"aws/trigger/sub1234\"],\"detail\":{\"operationType\":\"UPDATE\",\"clusterTime\":{\"i\":76554,\"t\":1234587},\"documentKey\":{\"_id\":\""
            + subscriberId
            + "\"},\"updateDescription\":{\"removedFields\":null,\"updatedFields\":null,\"truncatedArrays\":null},\"ns\":{\"db\":\"contact_management_db\",\"coll\":\"subscribers\"}},\"detail-type\":\"detailType\"}";

    sqs.sendMessage(queueUrl, eventAsString);

    given()
        .await()
        .atMost(5, TimeUnit.SECONDS)
        .untilAsserted(
            () -> {
              var messagesInQueue =
                  Integer.parseInt(
                      sqs.getQueueAttributes(
                              new GetQueueAttributesRequest(queueUrl)
                                  .withAttributeNames("ApproximateNumberOfMessages"))
                          .getAttributes()
                          .get("ApproximateNumberOfMessages"));
              assertThat(messagesInQueue).isZero();
            });

    assertThat(
            sesClient
                .listSuppressedDestinations(new ListSuppressedDestinationsRequest())
                .getSuppressedDestinationSummaries())
        .isEmpty();
  }
}
