package de.otto.blablafish_contact_management.integrationtest.helpers;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.crypto.spec.SecretKeySpec;

public class JwtHelper {

  private static final long EXPIRATION_TIME = 864_000_000; // 10 days

  public static String createToken(String clientId, String subject) {

    byte[] apiKeySecretBytes;
    apiKeySecretBytes =
        "Yn2kjibddFAWtnPJ2AFlL8WXmohJMCvigQggaEypa5E=".getBytes(StandardCharsets.UTF_8);
    Key signingKey = new SecretKeySpec(apiKeySecretBytes, SignatureAlgorithm.HS256.getJcaName());

    Map<String, List<String>> realmroles = new HashMap<>();

    List<String> roles = List.of("Users_Write");

    realmroles.put("roles", roles);

    String jwt =
        Jwts.builder()
            .claim("azp", clientId)
            .claim("realm_access", realmroles)
            .claim("preferred_username", subject)
            .setSubject(subject)
            .setExpiration(new Date(System.currentTimeMillis() + EXPIRATION_TIME))
            .signWith(signingKey, SignatureAlgorithm.HS256)
            .compact();

    return "Bearer " + jwt;
  }

  public static String createToken(
      String clientId, String subject, List<String> roles, String partnerId) {

    byte[] apiKeySecretBytes;
    apiKeySecretBytes =
        "Yn2kjibddFAWtnPJ2AFlL8WXmohJMCvigQggaEypa5E=".getBytes(StandardCharsets.UTF_8);
    Key signingKey = new SecretKeySpec(apiKeySecretBytes, SignatureAlgorithm.HS256.getJcaName());

    Map<String, List<String>> realmRoles = new HashMap<>();

    realmRoles.put("roles", roles);

    String jwt =
        Jwts.builder()
            .claim("azp", clientId)
            .claim("realm_access", realmRoles)
            .claim("partner_id", partnerId)
            .setSubject(subject)
            .setExpiration(new Date(System.currentTimeMillis() + EXPIRATION_TIME))
            .signWith(signingKey, SignatureAlgorithm.HS256)
            .compact();

    return "Bearer " + jwt;
  }

  public static String createToken(
      String clientId, String subject, List<String> roles, String partnerId, String username) {

    byte[] apiKeySecretBytes;
    apiKeySecretBytes =
        "Yn2kjibddFAWtnPJ2AFlL8WXmohJMCvigQggaEypa5E=".getBytes(StandardCharsets.UTF_8);
    Key signingKey = new SecretKeySpec(apiKeySecretBytes, SignatureAlgorithm.HS256.getJcaName());

    Map<String, List<String>> realmRoles = new HashMap<>();

    realmRoles.put("roles", roles);

    String jwt =
        Jwts.builder()
            .claim("azp", clientId)
            .claim("realm_access", realmRoles)
            .claim("partner_id", partnerId)
            .claim("preferred_username", username)
            .setSubject(subject)
            .setExpiration(new Date(System.currentTimeMillis() + EXPIRATION_TIME))
            .signWith(signingKey, SignatureAlgorithm.HS256)
            .compact();

    return "Bearer " + jwt;
  }
}
