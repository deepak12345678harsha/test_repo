package de.otto.blablafish_contact_management.handler;

import static org.mockito.Mockito.verify;

import de.otto.blablafish_contact_management.exception.SubscriberDoesNotExistException;
import de.otto.blablafish_contact_management.model.entity.Status;
import de.otto.blablafish_contact_management.model.entity.Subscriber;
import de.otto.blablafish_contact_management.model.entity.UserType;
import de.otto.blablafish_contact_management.testDataConfig.SubscriberTestConfig;
import de.otto.newsletter.exception.EmarsysConnectionFailedException;
import de.otto.newsletter.service.EmarsysService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class SyncSubscriberDataToEmarsysHandlerTest {

  @Mock private EmarsysService emarsysService;

  private SyncSubscriberDataToEmarsysHandler syncSubscriberDataToEmarsysHandler;

  @BeforeEach
  void setUp() {
    syncSubscriberDataToEmarsysHandler = new SyncSubscriberDataToEmarsysHandler(emarsysService);
  }

  @Test
  void shouldUpdateOrCreateContactInEmarsysForActiveCooperationSubscriber()
      throws SubscriberDoesNotExistException, EmarsysConnectionFailedException {
    Subscriber subscriber =
        new SubscriberTestConfig()
            .subscriberBuilder()
            .status(Status.ENABLED)
            .userType(UserType.COOPERATION)
            .build();

    syncSubscriberDataToEmarsysHandler.handle(subscriber);

    verify(emarsysService).updateOrCreateContact(subscriber.getUserId().toString());
  }

  @Test
  void shouldDeleteContactInEmarsys() throws EmarsysConnectionFailedException {
    Subscriber subscriber =
        new SubscriberTestConfig().subscriberBuilder().markedForDeletion(true).build();

    syncSubscriberDataToEmarsysHandler.handle(subscriber);

    verify(emarsysService).deleteContact(subscriber.getUserId().toString());
  }
}
