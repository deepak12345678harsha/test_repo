package de.otto.blablafish_contact_management.testDataConfig;

import de.otto.blablafish_contact_management.model.dto.EventType;
import de.otto.blablafish_contact_management.model.entity.*;
import java.time.Instant;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.bson.types.ObjectId;

public class SubscriberTestConfig {
  public static final int TOPIC_1_ID = 1;
  private ObjectId userId = new ObjectId("62bec37d21d8c96a1dff30cb");
  private String partnerId = "1008941";
  private Set<Integer> topicIds = new HashSet<>(Collections.singletonList(TOPIC_1_ID));
  private String firstName = "TestUser1FirstName";
  private String lastName = "TestUser1LastName";
  private String email = "testuser1mail@otto.de";
  private Set<String> effectiveRoleIds = new HashSet<>(List.of("1627cc31ea20d40a10388febc"));
  private Set<String> groups = Set.of("services", "analytics");
  private Status status = Status.ENABLED;
  private UserType userType = UserType.COOPERATION;
  private Instant createdAt = Instant.parse("2022-08-22T10:15:30.00Z");
  private Instant updatedAt = Instant.parse("2022-08-23T10:15:30.00Z");
  private Requester lastUpdatedBy = Requester.ofEventType(EventType.NEPTUNE_USER_SET);
  private Instant eventTime = Instant.parse("2022-08-23T10:15:30.00Z");
  private Boolean isUserBlacklisted = false;
  private NewsletterSubscription newsletterSubscription =
      new NewsletterSubscription(
          NewsletterSubscriptionStatus.SUBSCRIBED,
          "text",
          Instant.parse("2022-08-25T10:15:30.00Z"));
  private Long version = 1L;

  public static Subscriber createSubscriber(
      ObjectId userId,
      String partnerId,
      Set<Integer> topicIds,
      String firstName,
      String lastName,
      String email,
      Set<String> effectiveRoleIds,
      Status status,
      Instant createdAt,
      Instant updatedAt,
      Requester lastUpdatedBy,
      NewsletterSubscription newsletterSubscription) {

    return Subscriber.builder()
        .userId(userId)
        .partnerId(partnerId)
        .topicIds(topicIds)
        .firstName(Subscriber.encryptFirstName(firstName))
        .lastName(Subscriber.encryptLastName(lastName))
        .email(Subscriber.encryptEmail(email))
        .effectiveRoleIds(effectiveRoleIds)
        .status(status)
        .userType(UserType.COOPERATION)
        .createdAt(createdAt)
        .updatedAt(updatedAt)
        .lastUpdatedBy(lastUpdatedBy)
        .eventTime(Instant.now())
        .newsletterSubscription(newsletterSubscription)
        .groups(Set.of("services", "analytics"))
        .build();
  }

  public static Subscriber createSubscriber(
      ObjectId userId,
      String partnerId,
      Set<Integer> topicIds,
      String firstName,
      String lastName,
      String email,
      Set<String> effectiveRoleIds,
      Status status,
      Instant createdAt,
      Instant updatedAt,
      Requester lastUpdatedBy,
      Boolean isUserBlacklisted,
      NewsletterSubscription newsletterSubscription) {
    return Subscriber.builder()
        .userId(userId)
        .partnerId(partnerId)
        .topicIds(topicIds)
        .firstName(Subscriber.encryptFirstName(firstName))
        .lastName(Subscriber.encryptLastName(lastName))
        .email(Subscriber.encryptEmail(email))
        .effectiveRoleIds(effectiveRoleIds)
        .status(status)
        .userType(UserType.COOPERATION)
        .createdAt(createdAt)
        .updatedAt(updatedAt)
        .lastUpdatedBy(lastUpdatedBy)
        .eventTime(Instant.now())
        .isUserBlacklisted(isUserBlacklisted)
        .newsletterSubscription(newsletterSubscription)
        .groups(Set.of("services", "analytics"))
        .build();
  }

  public Subscriber build() {
    return subscriberBuilder().build();
  }

  public Subscriber.SubscriberBuilder subscriberBuilder() {
    return Subscriber.builder()
        .userId(userId)
        .partnerId(partnerId)
        .topicIds(topicIds)
        .firstName(Subscriber.encryptFirstName(firstName))
        .lastName(Subscriber.encryptLastName(lastName))
        .email(Subscriber.encryptEmail(email))
        .effectiveRoleIds(effectiveRoleIds)
        .status(status)
        .userType(userType)
        .createdAt(createdAt)
        .updatedAt(updatedAt)
        .lastUpdatedBy(lastUpdatedBy)
        .eventTime(Instant.now())
        .newsletterSubscription(newsletterSubscription)
        .eventTime(eventTime)
        .isUserBlacklisted(isUserBlacklisted)
        .groups(groups)
        .version(version);
  }
}
