package de.otto.blablafish_contact_management.rest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;
import de.otto.blablafish_contact_management.exception.BlaBlaFishError;
import de.otto.blablafish_contact_management.exception.BlaBlaFishException;
import de.otto.blablafish_contact_management.exception.SubscriberDoesNotExistException;
import de.otto.blablafish_contact_management.exception.TopicNotFoundException;
import de.otto.blablafish_contact_management.model.dto.ErrorResponse;
import de.otto.blablafish_contact_management.model.dto.UserPrincipal;
import de.otto.blablafish_contact_management.service.SubscriberService;
import de.otto.blablafish_contact_management.service.TopicService;
import de.otto.blablafish_contact_management.utils.Helper;
import java.security.Principal;
import java.util.Collections;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.mockito.MockedStatic;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

@TestInstance(Lifecycle.PER_CLASS)
@WebMvcTest(SubscriberController.class)
class SubscriberControllerTest {

  public static final String SUBSCRIBER_URI = "/v1/topics/{topicId}/subscribers/{subscriberId}";

  public static final ObjectMapper objectMapper = new ObjectMapper();
  private static final MockedStatic<Helper> helperMockedStatic = mockStatic(Helper.class);
  private final Integer topicId = 1;
  private final String subscriberId = "validSubscriber123";
  @Autowired private WebApplicationContext webApplicationContext;
  @MockBean private SubscriberService subscriberService;
  @MockBean private TopicService topicService;
  private MockMvc mockMvc;

  @BeforeAll
  static void beforeAll() {
    var userPrincipal =
        new UserPrincipal("subject", "clientId", "partnerId", Collections.emptySet(), "userName");
    var mockPrincipal = mock(Principal.class);

    helperMockedStatic.when(() -> Helper.toUserPrincipal(mockPrincipal)).thenReturn(userPrincipal);
  }

  @AfterAll
  static void afterAll() {
    helperMockedStatic.close();
  }

  @BeforeEach
  void setUp() {
    mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
  }

  @Test
  void shouldDeleteSubscriberFromTopic() throws Exception {
    doNothing().when(subscriberService).unSubscribe(eq(subscriberId), eq(topicId), any());
    mockMvc
        .perform(delete(SUBSCRIBER_URI, topicId, subscriberId).header("user-agent", "agent-value"))
        .andExpect(status().isOk());
  }

  @Test
  void shouldReturn404WhenTopicDoesNotExists() throws Exception {
    var invalidTopicId = 15;
    doThrow(
            new TopicNotFoundException(
                String.format("Topic with id %s does not exists", invalidTopicId)))
        .when(subscriberService)
        .unSubscribe(eq(subscriberId), eq(invalidTopicId), any());
    var errorResponse = ErrorResponse.builder().message("Topic with id 15 does not exists").build();

    var response =
        mockMvc
            .perform(
                delete(SUBSCRIBER_URI, invalidTopicId, subscriberId)
                    .header("user-agent", "agent-value"))
            .andExpect(status().isNotFound())
            .andReturn()
            .getResponse()
            .getContentAsString();

    assertThat(response).isEqualTo(objectMapper.writeValueAsString(errorResponse));
  }

  @Test
  void shouldReturn404WhenSubscriberDoesNotExists() throws Exception {
    var invalidSubscriberId = "invalid124";
    doThrow(new SubscriberDoesNotExistException("Invalid subscriber id " + invalidSubscriberId))
        .when(subscriberService)
        .unSubscribe(eq(invalidSubscriberId), eq(topicId), any());
    var errorResponse = ErrorResponse.builder().message("Invalid subscriber id invalid124").build();
    var response =
        mockMvc
            .perform(
                delete(SUBSCRIBER_URI, topicId, invalidSubscriberId)
                    .header("user-agent", "agent-value"))
            .andExpect(status().isNotFound())
            .andReturn()
            .getResponse()
            .getContentAsString();

    assertThat(response).isEqualTo(objectMapper.writeValueAsString(errorResponse));
  }

  @Test
  void shouldReturn400WhenDeletingLastUserInTopic() throws Exception {

    var subscriberId = "invalid124";
    doThrow(
            new BlaBlaFishException(
                "Can not delete last user in topic :" + topicId,
                BlaBlaFishError.LAST_USER_DELETION_IN_TOPIC_ERROR))
        .when(subscriberService)
        .unSubscribe(eq(subscriberId), eq(topicId), any());
    var errorResponse =
        ErrorResponse.builder()
            .message("Can not delete last user in topic :1")
            .errorCode(1000)
            .build();

    var response =
        mockMvc
            .perform(
                delete(SUBSCRIBER_URI, topicId, subscriberId).header("user-agent", "agent-value"))
            .andExpect(status().isBadRequest())
            .andReturn()
            .getResponse()
            .getContentAsString();

    assertThat(response).isEqualTo(objectMapper.writeValueAsString(errorResponse));
  }
}
