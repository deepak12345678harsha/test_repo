package de.otto.blablafish_email.listener;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.getRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.postRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.verify;
import static org.assertj.core.api.Assertions.assertThat;
import static org.testcontainers.shaded.org.awaitility.Awaitility.await;

import com.amazonaws.services.sqs.AmazonSQS;
import com.github.tomakehurst.wiremock.matching.EqualToPattern;
import de.otto.blablafish_contact_management.config.Features;
import de.otto.blablafish_contact_management.integrationtest.config.WireMockExtension;
import de.otto.blablafish_email.gateway.InternalApiGatewayClient;
import de.otto.blablafish_email.model.entity.Email;
import de.otto.blablafish_email.model.entity.EmailMigrationRequest;
import de.otto.blablafish_email.model.entity.EmailMigrationStatus;
import de.otto.blablafish_email.model.entity.EmailRequest;
import de.otto.blablafish_email.model.entity.SESEvent;
import java.time.Instant;
import java.util.Collections;
import java.util.concurrent.TimeUnit;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.CacheManager;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.togglz.junit5.AllEnabled;

@ExtendWith({WireMockExtension.class})
@AllEnabled(Features.class)
class EmailMigrationMongoDbListenerIT extends AbstractContainerIT {

  @Autowired private CacheManager cacheManager;

  @Value("${mongoDbTrigger.mails.migration.queueUrl}")
  private String emailMigrationQueueName;

  @Autowired private AmazonSQS sqs;

  private static void mockHedwigEmailRequestGetAPI(
      String hedwigMailRequestApiResponse, String mailRequestId) {
    String getMailRequestsUrl = "/mails-requests/" + mailRequestId;
    stubFor(
        get(getMailRequestsUrl)
            .withHeader(HttpHeaders.AUTHORIZATION, new EqualToPattern("Bearer some.access.token"))
            .willReturn(
                aResponse()
                    .withStatus(HttpStatus.OK.value())
                    .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                    .withBody(hedwigMailRequestApiResponse)));
  }

  @Test
  void shouldMigrateEmail() {
    var queueUrl = sqs.getQueueUrl(emailMigrationQueueName).getQueueUrl();
    var emailRequestId = "637c6ceb76a06a7315267324";
    var emailMigrationRequest =
        new EmailMigrationRequest(
            new ObjectId(emailRequestId), EmailMigrationStatus.UNPROCESSED, Instant.now());
    mongoTemplate.insert(emailMigrationRequest);
    var mongoTriggerMessage =
        "{\"account\":\"account1\", \"detail\":{\"clusterTime\":{\"i\":76554, \"t\":1234587}, \"documentKey\":{\"_id\":\"637c6ceb76a06a7315267324\"}, \"ns\":{\"coll\":\"subscribers\", \"db\":\"contact_management_db\"}, \"operationType\":\"UPDATE\", \"updateDescription\":{\"removedFields\":null, \"truncatedArrays\":null, \"updatedFields\":null}}, \"detail-type\":\"detailType\", \"id\":\"event-1\", \"resources\":[\"aws/trigger/sub1234\"], \"source\":\"mongodb/trigger/sub1234\", \"time\":1234.587}";
    var internalApiTokenResponse =
        """
            {
                "access_token": "some.access.token",
                "expires_in": 14400,
                "refresh_expires_in": 0,
                "token_type": "Bearer",
                "not-before-policy": 0,
                "scope": "email profile"
            }
            """;
    var getAccessTokenUrl = "/v1/token";
    stubFor(
        post(getAccessTokenUrl)
            .willReturn(
                aResponse()
                    .withStatus(HttpStatus.OK.value())
                    .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                    .withBody(internalApiTokenResponse)));
    var hedwigMailRequestApiResponse =
        """
            {
                "topicId": 8,
                "recipients": [
                    {
                        "emailId": "7770b629-ff59-4011-ba3e-eeb56085e6b8",
                        "firstName": "user",
                        "lastName": "test",
                        "email": "user-test@otto.com",
                        "partnerId": null,
                        "emailStatus": {
                            "status": "AWS_CLICK",
                            "date": "2022-11-22T06:35:21.735Z"
                        }
                    }
                ],
                "payload": {
                    "link": "google.com"
                },
                "createdAt": "2022-11-22T06:32:11.589Z",
                "status": "MINIMUM_ONE_MAIL_DELIVERED"
            }
            """;
    var getMailRequestsUrl = "/mails-requests/637c6ceb76a06a7315267324";
    stubFor(
        get(getMailRequestsUrl)
            .withHeader(HttpHeaders.AUTHORIZATION, new EqualToPattern("Bearer some.access.token"))
            .willReturn(
                aResponse()
                    .withStatus(HttpStatus.OK.value())
                    .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                    .withBody(hedwigMailRequestApiResponse)));

    var hedwigMailAPIResponse =
        """
            {
                "mailId": "7770b629-ff59-4011-ba3e-eeb56085e6b8",
                "awsMessageId": "01070184bd40d065-504bce39-1a1d-4058-a675-554ce16520e6-000000",
                "htmlBody": "sample-html-body",
                "textBody": "sample-text-body",
                "subject": "Einladung zum Partner-Portal von Developer OTTO Market",
                "toAddress": "user-test@otto.com",
                "fromAddress": "no-reply@nonlive.portal.otto.market",
                "emailRequestId": "637c6ceb76a06a7315267324",
                "status": "AWS_DELIVERY",
                "statusTimestamp": "2022-11-28T08:00:54.260Z",
                "statusHistory": [
                    {
                        "status": "READY_TO_SEND",
                        "date": "2022-11-28T08:00:51.388Z"
                    },
                    {
                        "status": "SENDING",
                        "date": "2022-11-28T08:00:52.308Z"
                    }
                ]
            }
            """;
    var mailId = "7770b629-ff59-4011-ba3e-eeb56085e6b8";
    var mailAPIUrl = "/mails/" + mailId;
    stubFor(
        get(mailAPIUrl)
            .withHeader(HttpHeaders.AUTHORIZATION, new EqualToPattern("Bearer some.access.token"))
            .willReturn(
                aResponse()
                    .withStatus(HttpStatus.OK.value())
                    .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                    .withBody(hedwigMailAPIResponse)));

    var hedwigSESEventResponse =
        """
            [
                {
                    "id": "62f3508b0abbb01a89a65c1e",
                    "eventType": "DELIVERY",
                    "awsMessageId": "01070184bd40d065-504bce39-1a1d-4058-a675-554ce16520e6-000000",
                    "body": {
                        "notificationType": "Delivery",
                        "mail": {
                            "timestamp": "2022-08-09T11:55:35.313Z",
                            "source": "no-reply@nonlive.partner-info.otto.market",
                            "sourceArn": "arn:aws:ses:eu-central-1:353449567674:identity/nonlive.partner-info.otto.market",
                            "sourceIp": "18.158.236.189",
                            "callerIdentity": "blablafish_contact_management_develop_ecs_task_role",
                            "sendingAccountId": "353449567674",
                            "messageId": "010701828275d011-ae50c64d-8ad5-4d65-bef1-38c4c86a120c-000000",
                            "destination": [
                                "user-test@otto.com"
                            ]
                        },
                        "delivery": {
                            "timestamp": "2022-08-09T11:55:36.611Z",
                            "processingTimeMillis": 1298,
                            "recipients": [
                                "user-test@otto.com"
                            ],
                            "smtpResponse": "250 2.0.0 OK  1660046136 i9-20020a5d5849000000b00222cd2616d7si3835077wrf.58 - gsmtp",
                            "remoteMtaIp": "173.194.76.27",
                            "reportingMTA": "b224-14.smtp-out.eu-central-1.amazonses.com"
                        }
                    },
                    "createdAt": "2022-08-10T06:30:35.835Z",
                    "mailRequestId": "637c6ceb76a06a7315267324"
                }
            ]
            """;
    var awsMessageId = "01070184bd40d065-504bce39-1a1d-4058-a675-554ce16520e6-000000";
    var sesEventsAPIUrl = String.format("/mails-events?aws_message_id=%s", awsMessageId);
    var sesEventId = "62f3508b0abbb01a89a65c1e";
    stubFor(
        get(sesEventsAPIUrl)
            .withHeader(HttpHeaders.AUTHORIZATION, new EqualToPattern("Bearer some.access.token"))
            .willReturn(
                aResponse()
                    .withStatus(HttpStatus.OK.value())
                    .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                    .withBody(hedwigSESEventResponse)));

    sqs.sendMessage(queueUrl, mongoTriggerMessage);

    await()
        .atMost(5, TimeUnit.SECONDS)
        .untilAsserted(
            () -> {
              assertThat(sqs.receiveMessage(queueUrl).getMessages()).isEmpty();
              assertThat(
                      mongoTemplate.exists(
                          Query.query(Criteria.where("id").is(sesEventId)), SESEvent.class))
                  .isTrue();
            });
    var emailRequests = mongoTemplate.findAll(EmailRequest.class);
    assertThat(emailRequests).hasSize(1);
    assertThat(emailRequests.get(0).getTopicId()).isEqualTo(8);

    var emailMigrationRequests = mongoTemplate.findAll(EmailMigrationRequest.class);
    assertThat(emailMigrationRequests.get(0).getMailRequestId())
        .isEqualTo(new ObjectId(emailRequestId));
    assertThat(emailMigrationRequests.get(0).getStatus()).isEqualTo(EmailMigrationStatus.PROCESSED);

    assertThat(mongoTemplate.exists(Query.query(Criteria.where("id").is(mailId)), Email.class))
        .isTrue();
    assertThat(
            mongoTemplate.exists(Query.query(Criteria.where("id").is(sesEventId)), SESEvent.class))
        .isTrue();

    verify(1, postRequestedFor(urlEqualTo(getAccessTokenUrl)));
    verify(1, getRequestedFor(urlEqualTo(getMailRequestsUrl)));
    verify(1, getRequestedFor(urlEqualTo(String.format("/mails/%s", mailId))));
    verify(1, getRequestedFor(urlEqualTo(sesEventsAPIUrl)));
  }

  @Test
  void shouldCacheInternalAPIToken() throws InterruptedException {
    cacheManager.getCache(InternalApiGatewayClient.INTERNAL_API_ACCESS_TOKEN_CACHE_NAME).clear();
    var queueUrl = sqs.getQueueUrl(emailMigrationQueueName).getQueueUrl();

    var emailRequestId1 = "777c6ceb76a06a7315267324";
    var emailMigrationRequest1 =
        new EmailMigrationRequest(
            new ObjectId(emailRequestId1), EmailMigrationStatus.UNPROCESSED, Instant.now());
    mongoTemplate.insert(emailMigrationRequest1);

    var emailRequestId2 = "777c6ceb76a06a7315267325";
    var emailMigrationRequest2 =
        new EmailMigrationRequest(
            new ObjectId(emailRequestId2), EmailMigrationStatus.UNPROCESSED, Instant.now());
    mongoTemplate.insert(emailMigrationRequest2);

    var internalApiTokenResponse =
        """
            {
                "access_token": "some.access.token",
                "expires_in": 14400,
                "refresh_expires_in": 0,
                "token_type": "Bearer",
                "not-before-policy": 0,
                "scope": "email profile"
            }
            """;
    var getAccessTokenUrl = "/v1/token";
    stubFor(
        post(getAccessTokenUrl)
            .willReturn(
                aResponse()
                    .withStatus(HttpStatus.OK.value())
                    .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                    .withBody(internalApiTokenResponse)));

    var hedwigMailRequestApiResponse =
        """
              {
                  "topicId": 8,
                  "recipients": [
                      {
                          "emailId": "6660b629-ff59-4011-ba3e-eeb56085e6b8",
                          "firstName": "user",
                          "lastName": "test",
                          "email": "user-test@otto.com",
                          "partnerId": null,
                          "emailStatus": {
                              "status": "AWS_CLICK",
                              "date": "2022-11-22T06:35:21.735Z"
                          }
                      }
                  ],
                  "payload": {
                      "link": "google.com"
                  },
                  "createdAt": "2022-11-22T06:32:11.589Z",
                  "status": "MINIMUM_ONE_MAIL_DELIVERED"
              }
            """;

    var hedwigMailAPIResponse =
        """

            {
                "mailId": "6660b629-ff59-4011-ba3e-eeb56085e6b8",
                "awsMessageId": "01070184bd40d065-504bce39-1a1d-4058-a675-554ce16520e6-000000",
                "htmlBody": "sample-html-body",
                "textBody": "sample-text-body",
                "subject": "Einladung zum Partner-Portal von Developer OTTO Market",
                "toAddress": "user-test@otto.com",
                "fromAddress": "no-reply@nonlive.portal.otto.market",
                "emailRequestId": "637c6ceb76a06a7315267324",
                "status": "AWS_DELIVERY",
                "statusTimestamp": "2022-11-28T08:00:54.260Z",
                "statusHistory": [
                    {
                        "status": "READY_TO_SEND",
                        "date": "2022-11-28T08:00:51.388Z"
                    },
                    {
                        "status": "SENDING",
                        "date": "2022-11-28T08:00:52.308Z"
                    }
                ]
            }
            """;
    var mailId = "6660b629-ff59-4011-ba3e-eeb56085e6b8";
    var mailAPIUrl = "/mails/" + mailId;
    stubFor(
        get(mailAPIUrl)
            .withHeader(HttpHeaders.AUTHORIZATION, new EqualToPattern("Bearer some.access.token"))
            .willReturn(
                aResponse()
                    .withStatus(HttpStatus.OK.value())
                    .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                    .withBody(hedwigMailAPIResponse)));

    var hedwigSESEventResponse =
        """
            [
                {
                    "id": "62f3508b0abbb01a89a65c1e",
                    "eventType": "DELIVERY",
                    "awsMessageId": "01070184bd40d065-504bce39-1a1d-4058-a675-554ce16520e6-000000",
                    "body": {
                        "notificationType": "Delivery",
                        "mail": {
                            "timestamp": "2022-08-09T11:55:35.313Z",
                            "source": "no-reply@nonlive.partner-info.otto.market",
                            "sourceArn": "arn:aws:ses:eu-central-1:353449567674:identity/nonlive.partner-info.otto.market",
                            "sourceIp": "18.158.236.189",
                            "callerIdentity": "blablafish_contact_management_develop_ecs_task_role",
                            "sendingAccountId": "353449567674",
                            "messageId": "010701828275d011-ae50c64d-8ad5-4d65-bef1-38c4c86a120c-000000",
                            "destination": [
                                "user-test@otto.com"
                            ]
                        },
                        "delivery": {
                            "timestamp": "2022-08-09T11:55:36.611Z",
                            "processingTimeMillis": 1298,
                            "recipients": [
                                "user-test@otto.com"
                            ],
                            "smtpResponse": "250 2.0.0 OK  1660046136 i9-20020a5d5849000000b00222cd2616d7si3835077wrf.58 - gsmtp",
                            "remoteMtaIp": "173.194.76.27",
                            "reportingMTA": "b224-14.smtp-out.eu-central-1.amazonses.com"
                        }
                    },
                    "createdAt": "2022-08-10T06:30:35.835Z",
                    "mailRequestId": "637c6ceb76a06a7315267324"
                }
            ]
            """;
    var awsMessageId = "01070184bd40d065-504bce39-1a1d-4058-a675-554ce16520e6-000000";
    var sesEventsAPIUrl = "/mails-events?aws_message_id=" + awsMessageId;
    stubFor(
        get(sesEventsAPIUrl)
            .withHeader(HttpHeaders.AUTHORIZATION, new EqualToPattern("Bearer some.access.token"))
            .willReturn(
                aResponse()
                    .withStatus(HttpStatus.OK.value())
                    .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                    .withBody(hedwigSESEventResponse)));

    var mongoTriggerMessage1 =
        "{\"account\":\"account1\", \"detail\":{\"clusterTime\":{\"i\":76554, \"t\":1234587}, \"documentKey\":{\"_id\":\""
            + emailRequestId1
            + "\"}, \"ns\":{\"coll\":\"subscribers\", \"db\":\"contact_management_db\"}, \"operationType\":\"UPDATE\", \"updateDescription\":{\"removedFields\":null, \"truncatedArrays\":null, \"updatedFields\":null}}, \"detail-type\":\"detailType\", \"id\":\"event-1\", \"resources\":[\"aws/trigger/sub1234\"], \"source\":\"mongodb/trigger/sub1234\", \"time\":1234.587}";
    mockHedwigEmailRequestGetAPI(hedwigMailRequestApiResponse, emailRequestId1);

    var mongoTriggerMessage2 =
        "{\"account\":\"account1\", \"detail\":{\"clusterTime\":{\"i\":76554, \"t\":1234587}, \"documentKey\":{\"_id\":\""
            + emailRequestId2
            + "\"}, \"ns\":{\"coll\":\"subscribers\", \"db\":\"contact_management_db\"}, \"operationType\":\"UPDATE\", \"updateDescription\":{\"removedFields\":null, \"truncatedArrays\":null, \"updatedFields\":null}}, \"detail-type\":\"detailType\", \"id\":\"event-1\", \"resources\":[\"aws/trigger/sub1234\"], \"source\":\"mongodb/trigger/sub1234\", \"time\":1234.587}";
    mockHedwigEmailRequestGetAPI(hedwigMailRequestApiResponse, emailRequestId2);

    sqs.sendMessage(queueUrl, mongoTriggerMessage1);
    sqs.sendMessage(queueUrl, mongoTriggerMessage2);

    Thread.sleep(5000);
    int messageCountAfterMsgBeingConsumed =
        Integer.parseInt(
            sqs.getQueueAttributes(
                    queueUrl, Collections.singletonList("ApproximateNumberOfMessages"))
                .getAttributes()
                .get("ApproximateNumberOfMessages"));
    assertThat(messageCountAfterMsgBeingConsumed).isZero();

    var emailRequests = mongoTemplate.findAll(EmailRequest.class);
    assertThat(emailRequests).hasSize(2);
    assertThat(emailRequests.get(0).getTopicId()).isEqualTo(8);
    var emailMigrationRequests = mongoTemplate.findAll(EmailMigrationRequest.class);
    assertThat(emailMigrationRequests.get(0).getMailRequestId())
        .isEqualTo(new ObjectId(emailRequestId1));
    assertThat(emailMigrationRequests.get(0).getStatus()).isEqualTo(EmailMigrationStatus.PROCESSED);

    verify(1, postRequestedFor(urlEqualTo(getAccessTokenUrl)));
    verify(1, getRequestedFor(urlEqualTo(String.format("/mails-requests/%s", emailRequestId1))));
    verify(1, getRequestedFor(urlEqualTo(String.format("/mails-requests/%s", emailRequestId2))));
  }
}
