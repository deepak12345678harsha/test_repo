package de.otto.blablafish_email.respository;

import static de.otto.blablafish_email.model.entity.SESEvent.FIELD_AWS_MESSAGE_ID;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

import de.otto.blablafish_email.model.dto.ses.SESEventType;
import de.otto.blablafish_email.model.entity.SESEvent;
import java.util.Collections;
import java.util.List;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

class SESEventRepositoryTest {

  private final MongoTemplate mongoTemplate = mock(MongoTemplate.class);
  private final SESEventRepository repository = new SESEventRepository(mongoTemplate);
  private final String awsMessageId =
      "010701828275d011-ae50c64d-8ad5-4d65-bef1-38c4c86a120c-000000";

  @Test
  void shouldSaveSESEventWhenInsert() {
    SESEvent event =
        SESEvent.of(
            SESEventType.BOUNCE,
            awsMessageId,
            new ObjectId("62bec37d21d8c96a1dff30cb"),
            new Document());
    repository.insert(event);
    verify(mongoTemplate).save(event);
  }

  @Test
  void shouldReturnSesEventsByAWSMessageId() {
    var queryCaptor = ArgumentCaptor.forClass(Query.class);
    var expectedQuery = Query.query(Criteria.where(FIELD_AWS_MESSAGE_ID).is(awsMessageId));

    var sesEvent =
        SESEvent.of(
            SESEventType.BOUNCE,
            awsMessageId,
            new ObjectId("62bec37d21d8c96a1dff30cb"),
            new Document());
    when(mongoTemplate.find(queryCaptor.capture(), eq(SESEvent.class)))
        .thenReturn(List.of(sesEvent));

    var sesEvents = repository.findByAWSMessageId(awsMessageId);

    assertThat(sesEvents).isEqualTo(List.of(sesEvent));
    assertThat(queryCaptor.getValue()).usingRecursiveComparison().isEqualTo(expectedQuery);
    verify(mongoTemplate).find(queryCaptor.capture(), eq(SESEvent.class));
  }

  @Test
  void shouldReturnEmptyListWhenNotFoundByAWSMessageId() {
    var queryCaptor = ArgumentCaptor.forClass(Query.class);
    when(mongoTemplate.find(queryCaptor.capture(), eq(SESEvent.class)))
        .thenReturn(Collections.emptyList());

    var sesEvents = repository.findByAWSMessageId(awsMessageId);

    assertThat(sesEvents).isEmpty();
    verify(mongoTemplate).find(queryCaptor.capture(), eq(SESEvent.class));
  }
}
