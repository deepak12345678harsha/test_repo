package de.otto.newsletter.model.dto;

import static org.junit.jupiter.api.Assertions.*;

import de.otto.blablafish_contact_management.model.entity.CommunicationSubscription;
import de.otto.blablafish_contact_management.model.entity.CommunicationSubscriptionStatus;
import de.otto.blablafish_contact_management.model.entity.Subscriber;
import de.otto.blablafish_contact_management.testDataConfig.SubscriberTestConfig;
import java.time.Instant;
import java.util.Set;
import org.junit.jupiter.api.Test;

class EmarsysContactDTOTest {

  @Test
  void shouldCreateEmarsysContactDTOWithoutJwt() {
    Subscriber subscriber =
        new SubscriberTestConfig()
            .subscriberBuilder()
            .groups(
                Set.of(
                    "services",
                    "analytics",
                    "finance",
                    "orders",
                    "administration",
                    "customerInquiries",
                    "products",
                    "random"))
            .build();
    EmarsysContactDTO emarsysContactDTO = EmarsysContactDTO.withPermissions(subscriber, "", "");

    assertEquals(emarsysContactDTO.getUserId(), subscriber.getUserId().toString());
    assertEquals(emarsysContactDTO.getPartnerId(), subscriber.getPartnerId());
    assertEquals(emarsysContactDTO.getNewsletterOptIn(), 1);
    assertEquals(emarsysContactDTO.getNewsletterUnsubscribeKey().length(), 0);
    assertEquals(emarsysContactDTO.getGroups(), Set.of("1", "2", "3", "4", "5", "6", "7"));
  }

  @Test
  void shouldCreateEmarsysContactDTOWithJwt() {
    Subscriber subscriber = new SubscriberTestConfig().subscriberBuilder().build();
    String unsubscribeKey = "some-key";
    EmarsysContactDTO emarsysContactDTO =
        EmarsysContactDTO.withPermissions(subscriber, unsubscribeKey, "");

    assertEquals(emarsysContactDTO.getUserId(), subscriber.getUserId().toString());
    assertEquals(emarsysContactDTO.getPartnerId(), subscriber.getPartnerId());
    assertEquals(emarsysContactDTO.getNewsletterOptIn(), 1);
    assertEquals(emarsysContactDTO.getNewsletterUnsubscribeKey(), unsubscribeKey);
    assertEquals(emarsysContactDTO.getGroups(), Set.of("4", "7"));
  }

  @Test
  void shouldCreateEmarsysContactDTOWithoutGroups() {
    Subscriber subscriber = new SubscriberTestConfig().subscriberBuilder().groups(null).build();
    EmarsysContactDTO emarsysContactDTO = EmarsysContactDTO.withPermissions(subscriber, "", "");

    assertTrue(emarsysContactDTO.getGroups().isEmpty());
  }

  @Test
  void shouldSetCommunicationsOptInAsTrueWhenCommunicationsSubscriptionIsNull() {
    var subscriber =
        new SubscriberTestConfig().subscriberBuilder().communicationSubscription(null).build();
    var emarsysContactDTO = EmarsysContactDTO.withPermissions(subscriber, "", "");
    assertEquals(emarsysContactDTO.getCommunicationsOptIn(), 1);
  }

  @Test
  void shouldSetCommunicationsOptInAsTrueWhenCommunicationsSubscriptionIsSubscribed() {
    var subscriber =
        new SubscriberTestConfig()
            .subscriberBuilder()
            .communicationSubscription(
                new CommunicationSubscription(
                    CommunicationSubscriptionStatus.SUBSCRIBED, Instant.now()))
            .build();
    var emarsysContactDTO =
        EmarsysContactDTO.withPermissions(subscriber, "", "communication.unsubscribe.key");
    assertEquals(emarsysContactDTO.getCommunicationsOptIn(), 1);
    assertEquals(
        emarsysContactDTO.getCommunicationsUnsubscribeKey(), "communication.unsubscribe.key");
  }

  @Test
  void shouldSetCommunicationsOptInAsFalseWhenCommunicationsSubscriptionIsUnsubscribed() {
    var subscriber =
        new SubscriberTestConfig()
            .subscriberBuilder()
            .communicationSubscription(
                new CommunicationSubscription(
                    CommunicationSubscriptionStatus.UNSUBSCRIBED, Instant.now()))
            .build();
    var emarsysContactDTO = EmarsysContactDTO.withPermissions(subscriber, "", "");
    assertEquals(emarsysContactDTO.getCommunicationsOptIn(), 2);
  }
}
