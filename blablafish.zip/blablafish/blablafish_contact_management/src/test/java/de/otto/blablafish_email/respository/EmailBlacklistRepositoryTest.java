package de.otto.blablafish_email.respository;

import static com.mongodb.assertions.Assertions.assertTrue;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

import de.otto.blablafish_email.model.entity.EmailBlackListReason;
import de.otto.blablafish_email.model.entity.EmailBlacklist;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

class EmailBlacklistRepositoryTest {
  private final MongoTemplate mongoTemplate = mock(MongoTemplate.class);
  private final EmailBlacklistRepository repository = new EmailBlacklistRepository(mongoTemplate);

  @Test
  public void shouldSaveSESEventWhenInsert() {
    String emailAddress = "my-email@test.otto";
    EmailBlackListReason reason =
        EmailBlackListReason.ofSESEvent("aws-msg-id", "some failed email");
    ArgumentCaptor<Query> queryCaptor = ArgumentCaptor.forClass(Query.class);
    ArgumentCaptor<Update> updateArgumentCaptor = ArgumentCaptor.forClass(Update.class);
    Query expectedQuery =
        Query.query(Criteria.where("emailAddress").is(EmailBlacklist.encryptEmail(emailAddress)));
    Update expectedUpdate = new Update().push("reasons", reason);

    repository.upsert(emailAddress, reason);

    verify(mongoTemplate)
        .upsert(queryCaptor.capture(), updateArgumentCaptor.capture(), eq(EmailBlacklist.class));
    assertThat(queryCaptor.getValue()).usingRecursiveComparison().isEqualTo(expectedQuery);
    assertThat(updateArgumentCaptor.getValue()).isEqualTo(expectedUpdate);
  }

  @Test
  public void shouldReturnEmailBlacklistOptionalById() {
    ObjectId blacklistId = new ObjectId("62bec37d21d8c96a1dff30cb");
    EmailBlacklist emailBlacklist =
        new EmailBlacklist(
            blacklistId, EmailBlacklist.encryptEmail("email@otto.com"), Collections.emptyList());
    Mockito.when(mongoTemplate.findById(blacklistId, EmailBlacklist.class))
        .thenReturn(emailBlacklist);

    Optional<EmailBlacklist> emailBlacklistOptional = repository.findById(blacklistId);

    assertThat(emailBlacklistOptional.get()).isEqualTo(emailBlacklist);
    verify(mongoTemplate).findById(blacklistId, EmailBlacklist.class);
  }

  @Test
  public void shouldReturnNullableOptionalWhenNotFoundById() {
    ObjectId blacklistId = new ObjectId("62bec37d21d8c96a1dff30cb");
    Mockito.when(mongoTemplate.findById(blacklistId, EmailBlacklist.class)).thenReturn(null);

    Optional<EmailBlacklist> emailBlacklistOptional = repository.findById(blacklistId);

    assertTrue(emailBlacklistOptional.isEmpty());
    verify(mongoTemplate).findById(blacklistId, EmailBlacklist.class);
  }

  @Test
  public void shouldReturnEmailBlacklistOptionalByEmailAddress() {
    String email = "email@otto.com";
    EmailBlacklist emailBlacklist =
        new EmailBlacklist(
            new ObjectId("62bec37d21d8c96a1dff30cb"),
            EmailBlacklist.encryptEmail(email),
            Collections.emptyList());

    ArgumentCaptor<Query> queryCaptor = ArgumentCaptor.forClass(Query.class);
    Query expectedQuery =
        Query.query(Criteria.where("emailAddress").is(EmailBlacklist.encryptEmail(email)));

    Mockito.when(mongoTemplate.find(queryCaptor.capture(), eq(EmailBlacklist.class)))
        .thenReturn(List.of(emailBlacklist));

    Optional<List<EmailBlacklist>> emailBlacklistOptional = repository.findByEmail(email);

    assertThat(emailBlacklistOptional.get())
        .usingRecursiveComparison()
        .isEqualTo(List.of(emailBlacklist));
    assertThat(queryCaptor.getValue()).usingRecursiveComparison().isEqualTo(expectedQuery);
    verify(mongoTemplate).find(queryCaptor.capture(), eq(EmailBlacklist.class));
  }

  @Test
  public void shouldReturnNullableOptionalWhenNotFoundByEmailAddress() {
    String email = "email@otto.com";
    ArgumentCaptor<Query> queryCaptor = ArgumentCaptor.forClass(Query.class);
    Mockito.when(mongoTemplate.find(queryCaptor.capture(), eq(EmailBlacklist.class)))
        .thenReturn(Collections.emptyList());

    Optional<List<EmailBlacklist>> emailBlacklistOptional = repository.findByEmail(email);

    assertThat(emailBlacklistOptional.get()).isEqualTo(Collections.emptyList());
    verify(mongoTemplate).find(queryCaptor.capture(), eq(EmailBlacklist.class));
  }
}
