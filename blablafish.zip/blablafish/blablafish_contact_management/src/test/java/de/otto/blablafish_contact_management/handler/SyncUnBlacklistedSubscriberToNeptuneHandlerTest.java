package de.otto.blablafish_contact_management.handler;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;

import de.otto.blablafish_contact_management.model.dto.EventType;
import de.otto.blablafish_contact_management.model.entity.Status;
import de.otto.blablafish_contact_management.model.entity.UserType;
import de.otto.blablafish_contact_management.testDataConfig.SubscriberTestConfig;
import de.otto.blablafish_email.model.dto.blacklist.EmailBlacklistNotice;
import de.otto.blablafish_email.publishers.SNSPublisher;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class SyncUnBlacklistedSubscriberToNeptuneHandlerTest {

  @Mock private SNSPublisher snsPublisher;

  private SyncUnBlacklistedSubscriberToNeptuneHandler syncUnBlacklistedSubscriberToNeptuneHandler;

  @BeforeEach
  void setup() {
    syncUnBlacklistedSubscriberToNeptuneHandler =
        new SyncUnBlacklistedSubscriberToNeptuneHandler(snsPublisher);
  }

  @Test
  void shouldSendUnBlacklistedEventToNeptune() {
    var subscriber =
        new SubscriberTestConfig()
            .subscriberBuilder()
            .status(Status.ENABLED)
            .userType(UserType.COOPERATION)
            .build();

    syncUnBlacklistedSubscriberToNeptuneHandler.handle(subscriber);

    verify(snsPublisher)
        .publish(any(EmailBlacklistNotice.class), eq(EventType.EMAIL_UNBLACKLISTED));
  }
}
