package de.otto.blablafish_contact_management.respository;

import static org.assertj.core.api.Assertions.assertThat;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import de.otto.blablafish_contact_management.model.entity.Topic;
import de.otto.blablafish_contact_management.model.entity.TopicOptions;
import de.otto.blablafish_email.listener.AbstractContainerIT;
import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.List;
import org.bson.Document;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

class TopicRepositoryIT extends AbstractContainerIT {

  @Autowired private TopicRepository topicRepository;

  private ObjectMapper objectMapper =
      new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

  @Test
  void shouldVerifyInsertedTopicsFromJson() throws IOException {
    File topicsJsonFile = readFile("topics/test_data.json");
    List<Topic> topics =
        objectMapper.readValue(
            topicsJsonFile,
            objectMapper.getTypeFactory().constructCollectionType(List.class, Topic.class));
    topicRepository.insert(topics);
    Topic expectedTopic =
        Topic.builder()
            .id(100)
            .name("test-topic")
            .description("Test topic created for local testing")
            .mandatorySubscriberRoles(Collections.emptyList())
            .emailSubject(
                "Otto Market test for ${user.firstName} ${user.lastName}, ${user.partnerId}!!!")
            .emailHtmlTemplate("/test-topic/html.ftl")
            .emailPlainTextTemplate("/test-topic/text.ftl")
            .emailSchema(new Document())
            .options(
                TopicOptions.builder()
                    .archiving(true)
                    .displayOnEmailConfigUI(false)
                    .canUnsubscribe(false)
                    .isSubscribedByDefault(true)
                    .displayOnContactManagementUI(true)
                    .build())
            .build();

    Topic topic = topicRepository.findById(100).orElseThrow();

    assertThat(topic)
        .usingRecursiveComparison()
        .ignoringFields("emailSchema")
        .isEqualTo(expectedTopic);
  }
}
