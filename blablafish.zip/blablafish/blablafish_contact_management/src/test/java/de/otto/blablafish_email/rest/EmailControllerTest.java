package de.otto.blablafish_email.rest;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import de.otto.blablafish_contact_management.model.dto.UserPrincipal;
import de.otto.blablafish_contact_management.utils.Helper;
import de.otto.blablafish_email.config.ApplicationProperties;
import de.otto.blablafish_email.service.EmailAttachmentService;
import de.otto.blablafish_email.service.EmailRequestService;
import de.otto.blablafish_email.service.EmailService;
import java.io.FileInputStream;
import java.io.InputStream;
import java.security.Principal;
import java.util.Collections;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.multipart.MultipartFile;

@TestInstance(Lifecycle.PER_CLASS)
@WebMvcTest(EmailController.class)
class EmailControllerTest {

  public static final String UPLOAD_URI = "/v1/uploads";

  @Autowired private WebApplicationContext webApplicationContext;

  @MockBean private EmailAttachmentService emailAttachmentService;

  @MockBean private EmailRequestService mailService;

  @MockBean private EmailService emailService;

  @MockBean private ApplicationProperties applicationProperties;

  private MockMvc mockMvc;

  @BeforeEach
  void setUp() {
    mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
  }

  @Test
  void shouldUploadEmailAttachment() throws Exception {
    InputStream inputStream = new FileInputStream("src/test/resources/uploadForEmail.txt");
    MockMultipartFile fileToUpload = new MockMultipartFile("uploadForEmail.txt", inputStream);
    Principal mockPrincipal = mock(Principal.class);
    UserPrincipal userPrincipal =
        new UserPrincipal("subject", "clientId", "partnerId", Collections.emptySet(), "userName");
    mockStatic(Helper.class)
        .when(() -> Helper.toUserPrincipal(mockPrincipal))
        .thenReturn(userPrincipal);
    when(emailAttachmentService.upload(any(MultipartFile.class), any(), any())).thenReturn("");

    mockMvc
        .perform(
            multipart(UPLOAD_URI).file("file", fileToUpload.getBytes()).principal(mockPrincipal))
        .andExpect(status().isCreated())
        .andReturn();
  }
}
