package de.otto.blablafish_contact_management.respository;

import static de.otto.blablafish_contact_management.model.Actions.SYNC_USER_DATA_TO_EMARSYS;
import static de.otto.blablafish_contact_management.model.entity.CommunicationSubscriptionStatus.UNSUBSCRIBED;
import static de.otto.blablafish_contact_management.model.entity.Subscriber.*;
import static de.otto.blablafish_contact_management.model.entity.UserType.COOPERATION;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.data.mongodb.core.query.Criteria.where;

import com.mongodb.client.result.UpdateResult;
import de.otto.blablafish_contact_management.model.dto.EventType;
import de.otto.blablafish_contact_management.model.encryption.EncryptedString;
import de.otto.blablafish_contact_management.model.entity.CommunicationSubscription;
import de.otto.blablafish_contact_management.model.entity.Requester;
import de.otto.blablafish_contact_management.model.entity.Status;
import de.otto.blablafish_contact_management.model.entity.Subscriber;
import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.data.mongodb.core.query.UpdateDefinition;

class SubscriberRepositoryTest {

  private final MongoTemplate mongoTemplate = mock(MongoTemplate.class);
  private final UpdateResult updateResult = mock(UpdateResult.class);
  private final SubscriberRepository subscriberRepository = new SubscriberRepository(mongoTemplate);

  private ArgumentCaptor<Query> queryCaptor;

  @BeforeEach
  void beforeEach() {
    queryCaptor = ArgumentCaptor.forClass(Query.class);
  }

  @Test
  void shouldFindUserById() {
    var subscriberId = new ObjectId();
    subscriberRepository.findById(subscriberId);

    var expectedQuery =
        Query.query(
            where(FIELD_SUBSCRIBER_ID).is(subscriberId).and(FIELD_MARKED_FOR_DELETION).ne(true));
    verify(mongoTemplate).findOne(queryCaptor.capture(), eq(Subscriber.class));
    assertThat(queryCaptor.getValue()).isEqualTo(expectedQuery);
  }

  @Test
  void shouldGetCountOfUsersWithGivenTopicIdAndPartnerId() {
    Integer topicId = 1;
    String partnerId = "partner-id";
    Query expectedQuery =
        Query.query(
            Criteria.where(FIELD_TOPIC_IDS)
                .in(topicId)
                .and(FIELD_PARTNER_ID)
                .is(partnerId)
                .and(FIELD_MARKED_FOR_DELETION)
                .ne(true));

    subscriberRepository.getCountOfUsersWith(topicId, partnerId);

    verify(mongoTemplate).count(queryCaptor.capture(), eq(Subscriber.class));
    assertThat(queryCaptor.getValue()).isEqualTo(expectedQuery);
  }

  @Test
  void shouldAddGivenTopicsToUsersWithGivenRole() {
    var topicIds = List.of(1, 2, 3);
    var userRole = "contact.management.write.role.test";
    var partnerId = "partner-id";
    var updateDefinitionCaptor = ArgumentCaptor.forClass(UpdateDefinition.class);
    var expectedQuery =
        Query.query(
            Criteria.where(FIELD_EFFECTIVE_ROLE_IDS)
                .in(userRole)
                .and(FIELD_MARKED_FOR_DELETION)
                .ne(true)
                .and(FIELD_PARTNER_ID)
                .is(partnerId));
    var requester = Requester.ofEventType(EventType.NEPTUNE_USER_DELETED);
    var expectedUpdateDefinition =
        new Update().addToSet(FIELD_TOPIC_IDS).each(topicIds).set(FIELD_LAST_UPDATED_BY, requester);

    subscriberRepository.subscribeAllAdmins(topicIds, userRole, partnerId, requester);

    verify(mongoTemplate)
        .updateMulti(queryCaptor.capture(), updateDefinitionCaptor.capture(), eq(Subscriber.class));
    assertThat(queryCaptor.getValue()).isEqualTo(expectedQuery);
    assertThat(updateDefinitionCaptor.getValue()).isEqualTo(expectedUpdateDefinition);
  }

  @Test
  void shouldReturnCountOfSuccessfulSubscriptionsWhenUsersSubscribeToTopic() {
    String partnerId = "partner-id";
    List<ObjectId> userIds = List.of(new ObjectId("629089ba391a524f0b687f4a"));
    int topicId = 1;
    var requester = Requester.of(new ObjectId(), partnerId, "user-agent");

    ArgumentCaptor<UpdateDefinition> updateDefinitionCaptor =
        ArgumentCaptor.forClass(UpdateDefinition.class);
    Query expectedQuery1 =
        Query.query(
            Criteria.where(FIELD_PARTNER_ID).is(partnerId).and(FIELD_SUBSCRIBER_ID).in(userIds));
    Update updateDefinition =
        new Update()
            .addToSet(FIELD_TOPIC_IDS, topicId)
            .set(Subscriber.FIELD_LAST_UPDATED_BY, requester);

    when(mongoTemplate.updateMulti(expectedQuery1, updateDefinition, Subscriber.class))
        .thenReturn(updateResult);
    when(updateResult.getModifiedCount()).thenReturn(1L);

    Long count = subscriberRepository.subscribeTopicForUsers(userIds, topicId, requester);

    assertThat(count).isEqualTo(1L);
    verify(mongoTemplate)
        .updateMulti(queryCaptor.capture(), updateDefinitionCaptor.capture(), eq(Subscriber.class));
    assertThat(queryCaptor.getValue()).isEqualTo(expectedQuery1);
    assertThat(updateDefinitionCaptor.getValue()).isEqualTo(updateDefinition);
  }

  @Test
  void shouldFilterSubscribedUsersWhenFilterCalledForTopicAndUsers() {
    String partnerId = "partner-id";
    List<ObjectId> userIds = List.of(new ObjectId("629089ba391a524f0b687f4a"));
    Subscriber user = getSubscriberWith(new ObjectId("629089ba391a524f0b687f4a"), Instant.now());
    int topicId = 1;

    Query expectedQuery =
        Query.query(
            Criteria.where(FIELD_PARTNER_ID)
                .is(partnerId)
                .and(FIELD_SUBSCRIBER_ID)
                .in(userIds)
                .and(FIELD_TOPIC_IDS)
                .in(topicId)
                .and(FIELD_MARKED_FOR_DELETION)
                .ne(true));

    when(mongoTemplate.find(expectedQuery, Subscriber.class)).thenReturn(List.of(user));

    List<Subscriber> actualUsers =
        subscriberRepository.filterSubscribedUsersForTopic(userIds, topicId, partnerId);
    List<Subscriber> expectedUsers = List.of(user);

    assertThat(actualUsers).usingRecursiveComparison().isEqualTo(expectedUsers);

    verify(mongoTemplate).find(queryCaptor.capture(), eq(Subscriber.class));
    assertThat(queryCaptor.getValue()).isEqualTo(expectedQuery);
  }

  @Test
  void shouldFindAllUsersForGivenPartner() {
    Query expectedQuery =
        Query.query(where(FIELD_PARTNER_ID).is("123").and(FIELD_MARKED_FOR_DELETION).ne(true));

    subscriberRepository.findAllByPartner("123");
    verify(mongoTemplate).find(queryCaptor.capture(), eq(Subscriber.class));
    assertThat(queryCaptor.getValue()).isEqualTo(expectedQuery);
  }

  @Test
  void shouldFindAllUsersForGivenPartnerAndEmail() {
    Query expectedQuery =
        Query.query(
            where(FIELD_PARTNER_ID)
                .is("123")
                .and(FIELD_EMAIL)
                .is(encryptedString("email@otto.de"))
                .and(FIELD_MARKED_FOR_DELETION)
                .ne(true));

    subscriberRepository.findAllByEmailAndPartner("email@otto.de", "123");
    verify(mongoTemplate).find(queryCaptor.capture(), eq(Subscriber.class));
    assertThat(queryCaptor.getValue()).usingRecursiveComparison().isEqualTo(expectedQuery);
  }

  @Test
  void shouldFindUserForGivenEmail() {
    Query expectedQuery =
        Query.query(
            where(FIELD_EMAIL)
                .is(encryptedString("email@otto.de"))
                .and(FIELD_MARKED_FOR_DELETION)
                .ne(true));
    Subscriber user =
        Subscriber.builder()
            .partnerId("partner-id")
            .eventTime(Instant.now())
            .firstName(encryptedString("first"))
            .lastName(encryptedString("last"))
            .email(encryptedString(FIELD_EMAIL))
            .effectiveRoleIds(Set.of("foobar"))
            .groups(Set.of("services", "analytics"))
            .status(Status.DISABLED)
            .updatedAt(Instant.now())
            .lastUpdatedBy(Requester.ofEventType(EventType.NEPTUNE_USER_SET))
            .build();
    Optional<Subscriber> expectedUser =
        Optional.of(
            Subscriber.builder()
                .partnerId("partner-id")
                .eventTime(Instant.now())
                .firstName(encryptedString("first"))
                .lastName(encryptedString("last"))
                .email(encryptedString(FIELD_EMAIL))
                .effectiveRoleIds(Set.of("foobar"))
                .groups(Set.of("services", "analytics"))
                .status(Status.DISABLED)
                .updatedAt(Instant.now())
                .lastUpdatedBy(Requester.ofEventType(EventType.NEPTUNE_USER_SET))
                .build());
    when(mongoTemplate.findOne(any(Query.class), eq(Subscriber.class))).thenReturn(user);

    Optional<Subscriber> actualUser = subscriberRepository.findByEmail("email@otto.de");

    verify(mongoTemplate).findOne(queryCaptor.capture(), eq(Subscriber.class));
    assertThat(queryCaptor.getValue()).usingRecursiveComparison().isEqualTo(expectedQuery);
    assertThat(actualUser)
        .usingRecursiveComparison()
        .ignoringFields("value.eventTime", "value.updatedAt", "value.lastUpdatedBy.date")
        .isEqualTo(expectedUser);
  }

  @Test
  void shouldFindAllUsersByPartnerForStatusEnabledAndNotBlacklisted() {
    Query expectedQuery =
        Query.query(
            where(FIELD_PARTNER_ID)
                .is("123")
                .and(FIELD_TOPIC_IDS)
                .in(123)
                .and(FIELD_MARKED_FOR_DELETION)
                .ne(true)
                .and(FIELD_STATUS)
                .is(Status.ENABLED)
                .and(FIELD_IS_USER_BLACKLISTED)
                .ne(true));

    subscriberRepository.findAllByPartnerForStatusEnabledAndNotBlacklisted("123", 123);
    verify(mongoTemplate).find(queryCaptor.capture(), eq(Subscriber.class));
    assertThat(queryCaptor.getValue()).usingRecursiveComparison().isEqualTo(expectedQuery);
  }

  @Test
  void shouldFindUserByEmailAddressAndSetIsUserBlacklistedToTrue() {
    var requester = Requester.ofEventType(EventType.EMAIL_BLACKLISTED_MONGO_TRIGGER);
    var updateCaptor = ArgumentCaptor.forClass(Update.class);
    var expectedQuery =
        Query.query(where(FIELD_EMAIL).is(Subscriber.encryptEmail("email@otto.com")));
    var expectedUpdate =
        new Update().set(FIELD_IS_USER_BLACKLISTED, true).set(FIELD_LAST_UPDATED_BY, requester);

    subscriberRepository.blacklistSubscriber("email@otto.com", requester);

    verify(mongoTemplate)
        .updateFirst(queryCaptor.capture(), updateCaptor.capture(), eq(Subscriber.class));
    assertThat(queryCaptor.getValue()).usingRecursiveComparison().isEqualTo(expectedQuery);
    assertThat(updateCaptor.getValue()).usingRecursiveComparison().isEqualTo(expectedUpdate);
  }

  @Test
  void shouldMarkSubscriberForDeletion() {
    var subscriberId = new ObjectId("629089ba391a524f0b687f4a");
    var updateDefinitionCaptor = ArgumentCaptor.forClass(UpdateDefinition.class);
    var requester = Requester.ofEventType(EventType.NEPTUNE_USER_DELETED);
    var expectedUpdateDefinition = new Document(FIELD_MARKED_FOR_DELETION, Boolean.TRUE);
    expectedUpdateDefinition.put(FIELD_LAST_UPDATED_BY, requester);

    subscriberRepository.markForDeletion(
        subscriberId, List.of(SYNC_USER_DATA_TO_EMARSYS), requester);

    verify(mongoTemplate)
        .upsert(queryCaptor.capture(), updateDefinitionCaptor.capture(), eq(Subscriber.class));
    assertThat(queryCaptor.getValue().getQueryObject().get(FIELD_SUBSCRIBER_ID))
        .isEqualTo(subscriberId);
    assertThat(updateDefinitionCaptor.getValue().getUpdateObject().get("$set"))
        .isEqualTo(expectedUpdateDefinition);
  }

  @Test
  void shouldUnsubscribeCommunications() {
    var subscriberId = "629089ba391a524f0b687f4a";
    var updateDefinitionCaptor = ArgumentCaptor.forClass(UpdateDefinition.class);

    subscriberRepository.unsubscribeCommunication(subscriberId, List.of(SYNC_USER_DATA_TO_EMARSYS));

    verify(mongoTemplate)
        .upsert(queryCaptor.capture(), updateDefinitionCaptor.capture(), eq(Subscriber.class));
    var updatedDefinition =
        (Document) updateDefinitionCaptor.getValue().getUpdateObject().get("$set");
    var communicationSubscription =
        (CommunicationSubscription) updatedDefinition.get(FIELD_COMMUNICATION_SUBSCRIPTION);
    assertThat(communicationSubscription.getStatus()).isEqualTo(UNSUBSCRIBED);
    assertThat(communicationSubscription.getTime()).isNotNull();
    assertThat(queryCaptor.getValue().getQueryObject().get("_id").toString())
        .isEqualTo(subscriberId);
  }

  @Test
  void shouldFindByPartnerWhereStatusEnabledAndNotBlacklisted() {
    Criteria criteriaDefinition =
        where(FIELD_EMAIL)
            .is(Subscriber.encryptEmail("emailAddress"))
            .and(FIELD_PARTNER_ID)
            .is(FIELD_PARTNER_ID)
            .and(FIELD_TOPIC_IDS)
            .in(1)
            .and(FIELD_MARKED_FOR_DELETION)
            .ne(true)
            .and(FIELD_STATUS)
            .is(Status.ENABLED)
            .and(FIELD_IS_USER_BLACKLISTED)
            .ne(true);
    Query expectedQuery = Query.query(criteriaDefinition);

    subscriberRepository.findByPartnerWhereStatusEnabledAndNotBlacklisted(
        FIELD_PARTNER_ID, 1, "emailAddress");

    verify(mongoTemplate).findOne(queryCaptor.capture(), eq(Subscriber.class));
    assertThat(queryCaptor.getValue()).usingRecursiveComparison().isEqualTo(expectedQuery);
  }

  private Subscriber getSubscriberWith(ObjectId userId, Instant time) {
    return Subscriber.builder()
        .userId(userId)
        .partnerId("partner-id")
        .eventTime(time)
        .userType(COOPERATION)
        .firstName(encryptedString("first"))
        .lastName(encryptedString("last"))
        .email(encryptedString(FIELD_EMAIL))
        .effectiveRoleIds(Set.of("foobar"))
        .status(Status.DISABLED)
        .updatedAt(time)
        .lastUpdatedBy(Requester.ofEventType(EventType.NEPTUNE_USER_SET))
        .groups(Set.of("services", "analytics"))
        .build();
  }

  private EncryptedString encryptedString(String value) {
    return new EncryptedString(value, "User.email", true);
  }
}
