package de.otto.blablafish_contact_management.service;

import static de.otto.blablafish_contact_management.model.Actions.SYNC_USER_DATA_TO_EMARSYS;
import static de.otto.blablafish_contact_management.model.entity.NewsletterSubscriptionStatus.SUBSCRIBED;
import static de.otto.blablafish_contact_management.model.entity.NewsletterSubscriptionStatus.statusFrom;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyInt;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import de.otto.blablafish_contact_management.exception.BlaBlaFishError;
import de.otto.blablafish_contact_management.exception.BlaBlaFishException;
import de.otto.blablafish_contact_management.exception.SubscriberDoesNotExistException;
import de.otto.blablafish_contact_management.exception.TopicNotFoundException;
import de.otto.blablafish_contact_management.model.dto.SubscriberDTO;
import de.otto.blablafish_contact_management.model.entity.EmailPreference;
import de.otto.blablafish_contact_management.model.entity.NewsletterSubscription;
import de.otto.blablafish_contact_management.model.entity.NewsletterSubscriptionStatus;
import de.otto.blablafish_contact_management.model.entity.Requester;
import de.otto.blablafish_contact_management.model.entity.Subscriber;
import de.otto.blablafish_contact_management.model.entity.Topic;
import de.otto.blablafish_contact_management.respository.SubscriberChangeEntryRepository;
import de.otto.blablafish_contact_management.respository.SubscriberRepository;
import de.otto.blablafish_contact_management.testDataConfig.SubscriberTestConfig;
import de.otto.blablafish_contact_management.testDataConfig.TopicTestBuilder;
import de.otto.blablafish_email.exception.EmailNotProcessableException;
import de.otto.blablafish_email.model.entity.EmailBlacklist;
import de.otto.blablafish_email.respository.EmailBlacklistRepository;
import de.otto.newsletter.model.entity.SubscriberChangeEntry;
import de.otto.newsletter.model.entity.SubscriberChangeEventType;
import java.time.Instant;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class SubscriberServiceTest {

  private final String contactManagementWriteRole = "test.contact.management.write.role";
  private final ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());
  private SubscriberService subscriberService;
  @Mock private SubscriberRepository subscriberRepository;
  @Mock private TopicService topicService;
  @Mock private EmailBlacklistRepository blacklistRepository;
  @Mock private SubscriberChangeEntryRepository subscriberChangeEntryRepository;
  @Mock private EmailPreferenceService emailPreferenceService;
  @Mock private Requester requester;

  @BeforeEach
  public void setService() {
    subscriberService =
        new SubscriberService(
            subscriberRepository,
            contactManagementWriteRole,
            true,
            topicService,
            blacklistRepository,
            subscriberChangeEntryRepository,
            emailPreferenceService,
            objectMapper);
  }

  @Test
  void shouldNotSetDefaultTopicForNonAdmins() throws SubscriberDoesNotExistException {
    Subscriber subscriber = new SubscriberTestConfig().build();
    subscriberService.handleUserSetEvent(subscriber);
    verify(subscriberRepository).upsert(subscriber);
    verify(subscriberRepository, never()).subscribeUserToTopics(any(), any());
  }

  @Test
  void shouldSetDefaultTopicIdsForAdmins() throws SubscriberDoesNotExistException {
    Topic topic1 = mock(Topic.class);
    when(topic1.getId()).thenReturn(1);
    List<Topic> defaultTopics = Collections.singletonList(topic1);
    List<Integer> defaultTopicIds = Collections.singletonList(1);
    ObjectId userId = new ObjectId("62bec37d21d8c96a1dff30cb");
    Subscriber subscriber =
        new SubscriberTestConfig()
            .subscriberBuilder()
            .effectiveRoleIds(Set.of(contactManagementWriteRole))
            .topicIds(Collections.emptySet())
            .build();
    when(subscriberRepository.findById(userId)).thenReturn(Optional.of(subscriber));
    when(topicService.findAllByMandatorySubscriberRole(contactManagementWriteRole))
        .thenReturn(defaultTopics);
    subscriberService.handleUserSetEvent(subscriber);

    verify(subscriberRepository).upsert(subscriber);
    verify(subscriberRepository)
        .subscribeUserToTopics(eq(subscriber.getUserId()), eq(defaultTopicIds));
  }

  @Test
  void shouldNotSetDefaultTopicIdsWhenFeatureToggleSetDefaultTopicsForAdminOnUSER_SET_IsFalse()
      throws SubscriberDoesNotExistException {
    subscriberService =
        new SubscriberService(
            subscriberRepository,
            "1234",
            false,
            topicService,
            blacklistRepository,
            subscriberChangeEntryRepository,
            emailPreferenceService,
            objectMapper);
    Subscriber subscriber = new SubscriberTestConfig().build();
    subscriberService.handleUserSetEvent(subscriber);

    verify(subscriberRepository).upsert(subscriber);
    verify(subscriberRepository, never()).subscribeUserToTopics(any(), any());
  }

  @Test
  void shouldDeleteSubscriberWithGivenSubscriberId()
      throws SubscriberDoesNotExistException, JsonProcessingException {
    ObjectId subscriberId = new ObjectId("62bec37d21d8c96a1dff30cb");
    Subscriber subscriber = new SubscriberTestConfig().build();
    when(subscriberRepository.findById(any())).thenReturn(Optional.ofNullable(subscriber));

    subscriberService.handleUserDeletedEvent(subscriberId.toHexString(), requester);

    verify(subscriberRepository)
        .markForDeletion(subscriberId, List.of(SYNC_USER_DATA_TO_EMARSYS), requester);
  }

  @Test
  void shouldSubscribeAdminUsersWhenLastUserIsDeleted()
      throws SubscriberDoesNotExistException, JsonProcessingException {
    int topicId = 1;
    Subscriber subscriber =
        new SubscriberTestConfig()
            .subscriberBuilder()
            .topicIds(Set.of(topicId))
            .effectiveRoleIds(Set.of(contactManagementWriteRole))
            .build();
    when(subscriberRepository.findById(any())).thenReturn(Optional.of(subscriber));
    when(subscriberRepository.getCountOfUsersWith(topicId, "1008941")).thenReturn(1L);

    subscriberService.handleUserDeletedEvent("62bec37d21d8c96a1dff30cb", requester);

    ArgumentCaptor<List<Integer>> captor = ArgumentCaptor.forClass(List.class);
    verify(subscriberRepository)
        .subscribeAllAdmins(
            captor.capture(), eq(contactManagementWriteRole), eq("1008941"), eq(requester));
    assertThat(captor.getValue()).contains(1);
    verify(subscriberRepository)
        .markForDeletion(subscriber.getUserId(), List.of(SYNC_USER_DATA_TO_EMARSYS), requester);
  }

  @Test
  void shouldNotSubscribeAdminsWhenDeletedSubscriberIsNotLastSubscribererInTopic()
      throws SubscriberDoesNotExistException, JsonProcessingException {
    ObjectId subscriberId = new ObjectId("629089ba391a524f0b687f4a");
    int topicId = 1;
    Subscriber subscriber = new SubscriberTestConfig().build();
    when(subscriberRepository.findById(any())).thenReturn(Optional.ofNullable(subscriber));
    when(subscriberRepository.getCountOfUsersWith(topicId, "1008941")).thenReturn(2L);

    subscriberService.handleUserDeletedEvent(subscriberId.toHexString(), requester);

    verify(subscriberRepository, never()).subscribeAllAdmins(any(), any(), any(), eq(requester));
    verify(subscriberRepository)
        .markForDeletion(subscriberId, List.of(SYNC_USER_DATA_TO_EMARSYS), requester);
  }

  @Test
  void shouldUnsubscribeUserFromTopic()
      throws TopicNotFoundException, SubscriberDoesNotExistException, BlaBlaFishException {
    ObjectId userId = new ObjectId("62bec37d21d8c96a1dff30cb");
    int topicId = 1;
    Subscriber subscriber = new SubscriberTestConfig().build();
    when(topicService.findByTopicId(anyInt())).thenReturn(mock(Topic.class));
    when(subscriberRepository.findById(any())).thenReturn(Optional.ofNullable(subscriber));
    subscriberService.unSubscribe(userId.toString(), topicId, requester);

    verify(subscriberRepository, times(1))
        .unsubscribeSubscriberFromTopic(userId, topicId, requester);
  }

  @Test
  void shouldNotTryToUnsubscribeWhenUserIsNotSubscribedToGivenTopic()
      throws TopicNotFoundException, SubscriberDoesNotExistException, BlaBlaFishException {
    ObjectId userId = new ObjectId("62bec37d21d8c96a1dff30cb");
    int topicId1 = 1;
    int topicId2 = 2;
    Subscriber subscriber =
        new SubscriberTestConfig().subscriberBuilder().topicIds(Set.of(topicId1)).build();
    when(subscriberRepository.findById(any())).thenReturn(Optional.ofNullable(subscriber));
    when(topicService.findByTopicId(anyInt())).thenReturn(mock(Topic.class));
    subscriberService.unSubscribe(userId.toString(), topicId2, requester);

    verify(subscriberRepository, times(0))
        .unsubscribeSubscriberFromTopic(userId, topicId2, requester);
  }

  @Test
  void shouldThrowSubscriberDoesNotExistExceptionWhenUnsubscribingUserFromTopic()
      throws TopicNotFoundException {
    ObjectId inValidUserId = new ObjectId("629089ba391a524f0b687f4b");
    int topicId = 1;
    Optional<Subscriber> userAsNull = Optional.empty();
    when(topicService.findByTopicId(topicId)).thenReturn(mock(Topic.class));
    when(subscriberRepository.findById(any())).thenReturn(userAsNull);

    SubscriberDoesNotExistException ex =
        assertThrows(
            SubscriberDoesNotExistException.class,
            () -> subscriberService.unSubscribe(inValidUserId.toString(), topicId, requester));

    assertEquals("Subscriber with id: " + inValidUserId + " does not exists", ex.getMessage());
    verify(subscriberRepository, times(1)).findById(inValidUserId);
    verify(topicService, times(1)).findByTopicId(topicId);
    verify(subscriberRepository, times(0))
        .unsubscribeSubscriberFromTopic(inValidUserId, topicId, requester);
  }

  @Test
  void shouldThrowTopicNotFoundExceptionGivenInvalidTopicId() throws TopicNotFoundException {
    ObjectId userId = new ObjectId("629089ba391a524f0b687f4a");
    int invalidTopicId = 100000000;
    doThrow(
            new TopicNotFoundException(
                String.format("Topic with id %s does not exists", invalidTopicId)))
        .when(topicService)
        .findByTopicId(invalidTopicId);

    Exception ex =
        assertThrows(
            TopicNotFoundException.class,
            () -> subscriberService.unSubscribe(userId.toString(), invalidTopicId, requester));

    assertEquals("Topic with id " + invalidTopicId + " does not exists", ex.getMessage());
    verify(topicService, times(1)).findByTopicId(invalidTopicId);
    verify(subscriberRepository, times(0)).findById(userId);
    verify(subscriberRepository, times(0))
        .unsubscribeSubscriberFromTopic(userId, invalidTopicId, requester);
  }

  @Test
  void shouldGetAllUsersForGivenPartnerAndEmail() {
    List<Subscriber> users = List.of(new SubscriberTestConfig().build());
    List<SubscriberDTO> expectedDtos =
        List.of(
            SubscriberDTO.builder()
                .id(users.get(0).getUserId().toString())
                .firstName("TestUser1FirstName")
                .lastName("TestUser1LastName")
                .email("testuser1mail@otto.de")
                .build());
    when(subscriberRepository.findAllByEmailAndPartner("email@otto.de", "123")).thenReturn(users);

    List<SubscriberDTO> actualDtos =
        subscriberService.getAllUsersByEmailAndPartner("123", "email@otto.de");

    verify(subscriberRepository).findAllByEmailAndPartner("email@otto.de", "123");
    assertThat(actualDtos).usingRecursiveComparison().isEqualTo(expectedDtos);
  }

  @Test
  void shouldGetAllUsersForGivenPartner() {
    List<Subscriber> users = List.of(new SubscriberTestConfig().build());
    List<SubscriberDTO> expectedDtos =
        List.of(
            SubscriberDTO.builder()
                .id(users.get(0).getUserId().toString())
                .firstName("TestUser1FirstName")
                .lastName("TestUser1LastName")
                .email("testuser1mail@otto.de")
                .build());
    when(subscriberRepository.findAllByPartner("123")).thenReturn(users);

    List<SubscriberDTO> actualDtos = subscriberService.getAllUsersByEmailAndPartner("123", null);

    verify(subscriberRepository).findAllByPartner("123");
    assertThat(actualDtos).usingRecursiveComparison().isEqualTo(expectedDtos);
  }

  @Test
  void shouldFindAllUsersByPartnerForTopic() throws EmailNotProcessableException {
    Subscriber subscriber = new SubscriberTestConfig().build();
    List<Subscriber> users = List.of(subscriber);
    Topic topic = new TopicTestBuilder().topicBuilder().build();
    EmailPreference emailPreference =
        EmailPreference.builder()
            .subscriberId(subscriber.getUserId())
            .topicId(1)
            .optIn(true)
            .lastUpdatedAt(Instant.now())
            .build();
    when(subscriberRepository.findAllByPartnerForStatusEnabledAndNotBlacklisted("123", 1))
        .thenReturn(users);
    when(emailPreferenceService.getPreferencesForSubscribers(1, Set.of(subscriber.getUserId())))
        .thenReturn(List.of(emailPreference));

    List<Subscriber> actualUsers =
        subscriberService.getSubscribersByValidatingRolesAndPreferences("123", topic);

    verify(subscriberRepository).findAllByPartnerForStatusEnabledAndNotBlacklisted("123", 1);
    assertThat(actualUsers).usingRecursiveComparison().isEqualTo(users);
  }

  @Test
  void shouldFindAllUsersByPartnerForTopicWhenDisplayOnContactMgmtUiIsFalseAndMandatoryRolesEmpty()
      throws EmailNotProcessableException {
    Subscriber subscriber = new SubscriberTestConfig().build();
    List<Subscriber> users = List.of(subscriber);
    EmailPreference emailPreference =
        EmailPreference.builder()
            .subscriberId(subscriber.getUserId())
            .topicId(1)
            .optIn(true)
            .lastUpdatedAt(Instant.now())
            .build();
    Topic topic =
        new TopicTestBuilder()
            .topicBuilder()
            .options(
                TopicTestBuilder.topicOptionsBuilder()
                    .displayOnContactManagementUI(false)
                    .displayOnEmailConfigUI(true)
                    .build())
            .build();
    when(subscriberRepository.findAllUsersByPartnerWithStatusEnabledAndNotBlacklisted(
            "123", Collections.emptyList()))
        .thenReturn(users);
    when(emailPreferenceService.getPreferencesForSubscribers(1, Set.of(subscriber.getUserId())))
        .thenReturn(List.of(emailPreference));

    List<Subscriber> actualUsers =
        subscriberService.getSubscribersByValidatingRolesAndPreferences("123", topic);

    verify(subscriberRepository)
        .findAllUsersByPartnerWithStatusEnabledAndNotBlacklisted("123", Collections.emptyList());
    assertThat(actualUsers).usingRecursiveComparison().isEqualTo(users);
  }

  @Test
  public void shouldThrowEmailNotProcessableExceptionWhenUsersAreNotSubscribedToTopic() {
    var topic = new TopicTestBuilder().topicBuilder().build();

    when(subscriberRepository.findAllByPartnerForStatusEnabledAndNotBlacklisted(
            "123", topic.getId()))
        .thenReturn(Collections.emptyList());
    var ex =
        assertThrows(
            EmailNotProcessableException.class,
            () -> subscriberService.getSubscribersByValidatingRolesAndPreferences("123", topic));
    assertThat(ex.getBlaBlaFishError())
        .isEqualTo(BlaBlaFishError.FOUND_NO_USER_WITH_REQUIRED_PERMISSIONS);
    assertThat(ex.getBlaBlaFishError().getCode()).isEqualTo(1012);
  }

  @Test
  public void shouldThrowEmailNotProcessableExceptionWhenUsersAreNotOptedToTopic() {
    var subscriber = new SubscriberTestConfig().build();
    var topic = new TopicTestBuilder().topicBuilder().build();
    var emailPreference =
        EmailPreference.builder()
            .subscriberId(subscriber.getUserId())
            .topicId(topic.getId())
            .optIn(false)
            .lastUpdatedAt(Instant.now())
            .build();
    var users = List.of(subscriber);
    when(subscriberRepository.findAllByPartnerForStatusEnabledAndNotBlacklisted("123", 1))
        .thenReturn(users);
    when(emailPreferenceService.getPreferencesForSubscribers(
            topic.getId(), Set.of(subscriber.getUserId())))
        .thenReturn(List.of(emailPreference));

    var ex =
        assertThrows(
            EmailNotProcessableException.class,
            () -> subscriberService.getSubscribersByValidatingRolesAndPreferences("123", topic));
    assertThat(ex.getBlaBlaFishError())
        .isEqualTo(BlaBlaFishError.FOUND_NO_USER_SUBSCRIBED_TO_TOPIC);
    assertThat(ex.getBlaBlaFishError().getCode()).isEqualTo(1013);
  }

  @Test
  void shouldFindAllUsersByPartnerForTopicWhenDisplayOnContactMgmtUiIsFalseAndWithMandatoryRoles()
      throws EmailNotProcessableException {
    Subscriber subscriber =
        new SubscriberTestConfig()
            .subscriberBuilder()
            .effectiveRoleIds(Set.of("1", "2", "3"))
            .build();
    List<Subscriber> users = List.of(subscriber);
    EmailPreference emailPreference =
        EmailPreference.builder()
            .subscriberId(subscriber.getUserId())
            .topicId(1)
            .optIn(true)
            .lastUpdatedAt(Instant.now())
            .build();
    Topic topic =
        new TopicTestBuilder()
            .topicBuilder()
            .mandatorySubscriberRoles(List.of("1", "2"))
            .options(
                TopicTestBuilder.topicOptionsBuilder()
                    .displayOnContactManagementUI(false)
                    .displayOnEmailConfigUI(true)
                    .build())
            .build();
    when(subscriberRepository.findAllUsersByPartnerWithStatusEnabledAndNotBlacklisted(
            "1008941", List.of("1", "2")))
        .thenReturn(users);
    when(emailPreferenceService.getPreferencesForSubscribers(1, Set.of(subscriber.getUserId())))
        .thenReturn(List.of(emailPreference));

    List<Subscriber> actualUsers =
        subscriberService.getSubscribersByValidatingRolesAndPreferences("1008941", topic);

    verify(subscriberRepository)
        .findAllUsersByPartnerWithStatusEnabledAndNotBlacklisted("1008941", List.of("1", "2"));
    assertThat(actualUsers).usingRecursiveComparison().isEqualTo(users);
  }

  @Test
  void shouldGetUserByEmail() {
    String emailAddress = "my-email@test.otto";
    Optional<Subscriber> user = Optional.of(new SubscriberTestConfig().build());
    when(subscriberRepository.findByEmail(emailAddress)).thenReturn(user);

    Optional<Subscriber> actualUser = subscriberService.getUserByEmail(emailAddress);

    verify(subscriberRepository).findByEmail(emailAddress);
    assertThat(actualUser).usingRecursiveComparison().isEqualTo(user);
  }

  @Test
  void shouldSetIsUserBlacklistedToTrue() {
    ObjectId blacklistId = new ObjectId("62bec37d21d8c96a1dff30cb");
    EmailBlacklist emailBlacklist =
        new EmailBlacklist(
            blacklistId, EmailBlacklist.encryptEmail("email@otto.com"), Collections.emptyList());
    when(blacklistRepository.findById(blacklistId)).thenReturn(Optional.of(emailBlacklist));
    doNothing().when(subscriberRepository).blacklistSubscriber("email@otto.com", requester);

    subscriberService.setIsUserBlacklistedToTrue(blacklistId, requester);
    verify(blacklistRepository).findById(blacklistId);
    verify(subscriberRepository).blacklistSubscriber("email@otto.com", requester);
  }

  @Test
  void shouldGetSubscriberById() throws SubscriberDoesNotExistException {
    String subscriberId = "62bec37d21d8c96a1dff30cb";
    Subscriber expectedSubscriber = new SubscriberTestConfig().build();
    when(subscriberRepository.findById(new ObjectId(subscriberId)))
        .thenReturn(Optional.of(expectedSubscriber));

    Subscriber actualSubscriber = subscriberService.getSubscriberById(subscriberId);

    verify(subscriberRepository).findById(new ObjectId(subscriberId));
    assertThat(actualSubscriber).usingRecursiveComparison().isEqualTo(expectedSubscriber);
  }

  @Test
  void shouldThrowSubscriberDoesNotExistException() {
    String subscriberId = "62bec37d21d8c96a1dff30cb";
    when(subscriberRepository.findById(new ObjectId(subscriberId))).thenReturn(Optional.empty());
    SubscriberDoesNotExistException ex =
        assertThrows(
            SubscriberDoesNotExistException.class,
            () -> subscriberService.getSubscriberById(subscriberId));
    assertEquals(
        String.format("Subscriber with id: %s does not exists", subscriberId), ex.getMessage());
    verify(subscriberRepository).findById(new ObjectId(subscriberId));
  }

  @Test
  void shouldReturnUnsubscribedStatusWhenNewsletterSubscriptionDoesNotExist()
      throws SubscriberDoesNotExistException {
    String email = "email";
    NewsletterSubscription newsletterSubscriptionAsNull = null;
    Subscriber expectedSubscriber =
        new SubscriberTestConfig()
            .subscriberBuilder()
            .newsletterSubscription(newsletterSubscriptionAsNull)
            .build();

    when(subscriberRepository.findByEmail(email)).thenReturn(Optional.of(expectedSubscriber));

    NewsletterSubscription expected =
        new NewsletterSubscription(NewsletterSubscriptionStatus.UNSUBSCRIBED, "", Instant.now());
    NewsletterSubscription actual =
        subscriberService.getNewsletterSubscriptionByEmailAddress(email);
    assertThat(actual).usingRecursiveComparison().ignoringFields("time").isEqualTo(expected);

    verify(subscriberRepository).findByEmail(email);
  }

  @ParameterizedTest
  @ValueSource(booleans = {true, false})
  void shouldUpdateNewsletterSubscriptionStatus(boolean newStatus)
      throws SubscriberDoesNotExistException {
    var subscriberId = "62bec37d21d8c96a1dff30cb";
    var captor = ArgumentCaptor.forClass(NewsletterSubscription.class);
    var subscriber = mock(Subscriber.class);
    when(subscriber.getNewsletterSubscription()).thenReturn(mock(NewsletterSubscription.class));
    when(subscriberRepository.findByEmail(any())).thenReturn(Optional.of(subscriber));

    subscriberService.handleNewsletterSubscription(
        subscriberId, newStatus, "subscription text", requester);

    verify(subscriberRepository)
        .updateSubscription(
            eq(subscriberId),
            captor.capture(),
            eq(List.of(SYNC_USER_DATA_TO_EMARSYS)),
            eq(requester));
    var expectedSubscription =
        new NewsletterSubscription(statusFrom(newStatus), "subscription text", Instant.now());
    assertThat(captor.getValue())
        .usingRecursiveComparison()
        .ignoringFields("time")
        .isEqualTo(expectedSubscription);
  }

  @Test
  void shouldReturnNewsletterBySubscriberEmailAddress() throws SubscriberDoesNotExistException {
    Instant time = Instant.now();
    String emailAddress = "testuser1mail@otto.de";
    Subscriber subscriber =
        new SubscriberTestConfig()
            .subscriberBuilder()
            .newsletterSubscription(
                new NewsletterSubscription(SUBSCRIBED, "Subscription text", time))
            .build();
    when(subscriberRepository.findByEmail(emailAddress))
        .thenReturn(Optional.ofNullable(subscriber));

    NewsletterSubscription actualNewsletterSubscription =
        subscriberService.getNewsletterSubscriptionByEmailAddress(emailAddress);

    NewsletterSubscription expectedSubscription =
        new NewsletterSubscription(SUBSCRIBED, "Subscription text", time);
    assertThat(actualNewsletterSubscription)
        .usingRecursiveComparison()
        .ignoringFields("time")
        .isEqualTo(expectedSubscription);
  }

  @Test
  void shouldUpdateNewsletterStatusWhenNewStatusIsLatestThanExisting()
      throws SubscriberDoesNotExistException, JsonProcessingException {
    String subscriberId = "62bec37d21d8c96a1dff30cb";
    Subscriber subscriber = new SubscriberTestConfig().subscriberBuilder().build();
    NewsletterSubscription newsletterSubscription =
        new NewsletterSubscription(
            NewsletterSubscriptionStatus.SUBSCRIBED,
            "new_text",
            Instant.parse("2022-09-12T07:17:00.077Z"));
    ArgumentCaptor<NewsletterSubscription> captor =
        ArgumentCaptor.forClass(NewsletterSubscription.class);
    when(subscriberRepository.findById(eq(new ObjectId(subscriberId))))
        .thenReturn(Optional.of(subscriber));
    subscriberService.updateNewsletterSubscriptionStatus(
        subscriberId, newsletterSubscription, Instant.now());

    verify(subscriberRepository)
        .updateSubscriptionBySubscriberId(
            eq(subscriberId),
            captor.capture(),
            eq(subscriber.getVersion()),
            eq(List.of(SYNC_USER_DATA_TO_EMARSYS)));
    assertThat(captor.getValue()).usingRecursiveComparison().isEqualTo(newsletterSubscription);
  }

  @Test
  void shouldUpdateNewsletterStatusWhenExistingStatusIsNull()
      throws SubscriberDoesNotExistException, JsonProcessingException {
    String subscriberId = "62bec37d21d8c96a1dff30cb";
    NewsletterSubscription currentStatusAsNull = null;
    Subscriber subscriber =
        new SubscriberTestConfig()
            .subscriberBuilder()
            .newsletterSubscription(currentStatusAsNull)
            .build();
    NewsletterSubscription newsletterSubscription =
        new NewsletterSubscription(
            NewsletterSubscriptionStatus.SUBSCRIBED,
            "new_text",
            Instant.parse("2022-09-12T07:17:00.077Z"));
    ArgumentCaptor<NewsletterSubscription> captor =
        ArgumentCaptor.forClass(NewsletterSubscription.class);
    when(subscriberRepository.findById(eq(new ObjectId(subscriberId))))
        .thenReturn(Optional.of(subscriber));
    subscriberService.updateNewsletterSubscriptionStatus(
        subscriberId, newsletterSubscription, Instant.now());

    verify(subscriberRepository)
        .updateSubscriptionBySubscriberId(
            eq(subscriberId),
            captor.capture(),
            eq(subscriber.getVersion()),
            eq(List.of(SYNC_USER_DATA_TO_EMARSYS)));
    assertThat(captor.getValue()).usingRecursiveComparison().isEqualTo(newsletterSubscription);
  }

  @Test
  void shouldNotUpdateNewsletterStatusWhenNewStatusIsOlderThanExisting()
      throws SubscriberDoesNotExistException, JsonProcessingException {
    String subscriberId = "62bec37d21d8c96a1dff30cb";
    Subscriber subscriber = new SubscriberTestConfig().subscriberBuilder().build();
    Instant olderTimeStamp = Instant.parse("2018-09-12T07:17:00.077Z");
    NewsletterSubscription newStatus =
        new NewsletterSubscription(
            NewsletterSubscriptionStatus.SUBSCRIBED, "new_text", olderTimeStamp);

    when(subscriberRepository.findById(eq(new ObjectId(subscriberId))))
        .thenReturn(Optional.of(subscriber));
    subscriberService.updateNewsletterSubscriptionStatus(subscriberId, newStatus, Instant.now());

    verify(subscriberRepository, times(0))
        .updateSubscriptionBySubscriberId(
            any(), any(), any(), eq(List.of(SYNC_USER_DATA_TO_EMARSYS)));
  }

  @Test
  void shouldInsertSubscriberChangeEntry() throws SubscriberDoesNotExistException {
    String subscriberId = "62bec37d21d8c96a1dff30cb";
    String eventAsString = "{\"version\":\"0\",\"id\":\"ab3cda69-ce95-61d8-a8c1-1e8e2c16135b\"}";
    Instant subscriptionTimeStamp = Instant.parse("2018-09-12T07:17:00.077Z");
    Instant eventTime = Instant.now();
    NewsletterSubscription newStatus =
        new NewsletterSubscription(
            NewsletterSubscriptionStatus.SUBSCRIBED, "new_text", subscriptionTimeStamp);
    when(subscriberRepository.exists(subscriberId)).thenReturn(true);
    when(subscriberChangeEntryRepository.exists(
            subscriberId,
            SubscriberChangeEventType.SUBSCRIBER_SUBSCRIBED_TO_NEWSLETTER,
            subscriptionTimeStamp))
        .thenReturn(false);

    subscriberService.handleNewsletterSubscriptionChanged(
        subscriberId, newStatus, eventTime, eventAsString);

    ArgumentCaptor<SubscriberChangeEntry> captor =
        ArgumentCaptor.forClass(SubscriberChangeEntry.class);
    verify(subscriberChangeEntryRepository).insert(captor.capture());
    assertThat(captor.getValue().getEventTime()).isEqualTo(eventTime);
    assertThat(captor.getValue().getSubscriberId()).isEqualTo(subscriberId);
    assertThat(captor.getValue().getSubscriberChangeEventType())
        .isEqualTo(SubscriberChangeEventType.SUBSCRIBER_SUBSCRIBED_TO_NEWSLETTER);
    assertThat(captor.getValue().getEvent().getValue()).isEqualTo(Document.parse(eventAsString));
  }

  @Test
  void shouldNotInsertDuplicateSubscriberChangeEntry() throws SubscriberDoesNotExistException {
    String subscriberId = "62bec37d21d8c96a1dff30cb";
    String eventAsString = "{\"key\": \"value\"}";
    Instant eventTime = Instant.now();
    Instant subscriptionTimeStamp = Instant.parse("2018-09-12T07:17:00.077Z");
    NewsletterSubscription newStatus =
        new NewsletterSubscription(
            NewsletterSubscriptionStatus.SUBSCRIBED, "new_text", subscriptionTimeStamp);

    when(subscriberRepository.exists(subscriberId)).thenReturn(true);
    when(subscriberChangeEntryRepository.exists(
            subscriberId,
            SubscriberChangeEventType.SUBSCRIBER_SUBSCRIBED_TO_NEWSLETTER,
            subscriptionTimeStamp))
        .thenReturn(true);

    subscriberService.handleNewsletterSubscriptionChanged(
        subscriberId, newStatus, eventTime, eventAsString);

    verify(subscriberChangeEntryRepository, times(0)).insert(any());
  }

  @Test
  void shouldUnsubscribeCommunications() {
    String subscriberId = "62bec37d21d8c96a1dff30cb";
    subscriberService.unsubscribeCommunication(subscriberId);

    verify(subscriberRepository)
        .unsubscribeCommunication(subscriberId, List.of(SYNC_USER_DATA_TO_EMARSYS));
  }
}
