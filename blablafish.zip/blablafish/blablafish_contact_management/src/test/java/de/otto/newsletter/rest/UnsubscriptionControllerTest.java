package de.otto.newsletter.rest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.http.HttpStatus.OK;

import de.otto.blablafish_contact_management.service.SubscriberService;
import de.otto.newsletter.exception.JWTActionNotFoundException;
import de.otto.newsletter.model.JWTActions;
import de.otto.newsletter.service.JWTService;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.Resource;

@ExtendWith(MockitoExtension.class)
class UnsubscriptionControllerTest {

  @Mock private SubscriberService subscriberService;

  @Mock private JWTService jwtService;

  @Mock private Claims claims;

  @Mock private Resource newsletterUnsubscriptionPage;

  @Mock private Resource communicationUnsubscriptionPage;

  @Mock private Resource newsletterUnsubscriptionErrorPage;

  @Mock private Resource communicationUnsubscriptionErrorPage;

  private UnsubscriptionController unsubscriptionController;

  @BeforeEach
  void setUp() {
    unsubscriptionController =
        new UnsubscriptionController(
            jwtService,
            subscriberService,
            newsletterUnsubscriptionPage,
            communicationUnsubscriptionPage,
            newsletterUnsubscriptionErrorPage,
            communicationUnsubscriptionErrorPage);
  }

  @ParameterizedTest(name = "#{index} - when type={0}")
  @NullSource
  @ValueSource(strings = {"newsletter"})
  void shouldUnsubscribeNewsletterWhenType(String type) throws IOException {
    var subscriberId = "62bec37d21d8c96a1dff30cb";
    var responseBody = "Newsletter Unsubscription success";
    when(jwtService.getClaims("some-jwt-key")).thenReturn(claims);
    when(claims.getSubject()).thenReturn(subscriberId);
    when(newsletterUnsubscriptionPage.getInputStream())
        .thenReturn(new ByteArrayInputStream(responseBody.getBytes()));

    var responseEntity = unsubscriptionController.handleUnsubscriptionByJWT("some-jwt-key", type);

    verify(jwtService).verifyClaimAction(claims, JWTActions.UNSUBSCRIBE_NEWSLETTER);
    verify(subscriberService).unsubscribeNewsletter(subscriberId);
    assertThat(responseEntity.getStatusCode()).isEqualTo(OK);
    assertThat(responseEntity.getBody()).isEqualTo(responseBody);
  }

  @Test
  void shouldUnsubscribeCommunication() throws IOException {
    var subscriberId = "62bec37d21d8c96a1dff30cb";
    var responseBody = "Communication Unsubscription success";
    when(jwtService.getClaims("some-jwt-key")).thenReturn(claims);
    when(claims.getSubject()).thenReturn(subscriberId);
    when(communicationUnsubscriptionPage.getInputStream())
        .thenReturn(new ByteArrayInputStream(responseBody.getBytes()));

    var responseEntity =
        unsubscriptionController.handleUnsubscriptionByJWT("some-jwt-key", "communication");

    verify(jwtService).verifyClaimAction(claims, JWTActions.UNSUBSCRIBE_COMMUNICATIONS);
    verify(subscriberService).unsubscribeCommunication(subscriberId);
    assertThat(responseEntity.getStatusCode()).isEqualTo(OK);
    assertThat(responseEntity.getBody()).isEqualTo(responseBody);
  }

  @ParameterizedTest(name = "#{index} - when type={0}")
  @NullSource
  @ValueSource(strings = {"newsletter"})
  void shouldReturnErrorPageResponseWhenNewsletterJwtIsExpired(String type) throws IOException {
    var errorResponseBody = "Unsubscription Error";
    when(newsletterUnsubscriptionErrorPage.getInputStream())
        .thenReturn(new ByteArrayInputStream(errorResponseBody.getBytes()));
    when(jwtService.getClaims("some-jwt-key")).thenThrow(ExpiredJwtException.class);

    var responseEntity = unsubscriptionController.handleUnsubscriptionByJWT("some-jwt-key", type);

    assertThat(responseEntity.getStatusCode()).isEqualTo(OK);
    assertThat(responseEntity.getBody()).isEqualTo(errorResponseBody);
  }

  @Test
  void shouldReturnErrorPageResponseWhenCommunicationJwtIsExpired() throws IOException {
    var errorResponseBody = "Communication Unsubscription Error";
    when(communicationUnsubscriptionErrorPage.getInputStream())
        .thenReturn(new ByteArrayInputStream(errorResponseBody.getBytes()));
    when(jwtService.getClaims("some-jwt-key")).thenThrow(ExpiredJwtException.class);

    var responseEntity =
        unsubscriptionController.handleUnsubscriptionByJWT("some-jwt-key", "communication");

    assertThat(responseEntity.getStatusCode()).isEqualTo(OK);
    assertThat(responseEntity.getBody()).isEqualTo(errorResponseBody);
  }

  @ParameterizedTest(name = "#{index} - when type={0}")
  @NullSource
  @ValueSource(strings = {"newsletter"})
  void shouldReturnErrorPageResponseWhenInvalidActionPresentInJwtForNewsletter(String type)
      throws IOException {
    var errorResponse = "Unsubscription error";
    when(newsletterUnsubscriptionErrorPage.getInputStream())
        .thenReturn(new ByteArrayInputStream(errorResponse.getBytes()));
    when(jwtService.getClaims("some-jwt-key")).thenReturn(claims);
    doThrow(JWTActionNotFoundException.class)
        .when(jwtService)
        .verifyClaimAction(eq(claims), any(JWTActions.class));

    var responseEntity = unsubscriptionController.handleUnsubscriptionByJWT("some-jwt-key", type);

    assertThat(responseEntity.getStatusCode()).isEqualTo(OK);
    assertThat(responseEntity.getBody()).isEqualTo(errorResponse);
  }

  @Test
  void shouldReturnErrorPageResponseWhenInvalidActionPresentInJwtCommunication()
      throws IOException {
    var errorResponse = "Unsubscription error";
    when(communicationUnsubscriptionErrorPage.getInputStream())
        .thenReturn(new ByteArrayInputStream(errorResponse.getBytes()));
    when(jwtService.getClaims("some-jwt-key")).thenReturn(claims);
    doThrow(JWTActionNotFoundException.class)
        .when(jwtService)
        .verifyClaimAction(eq(claims), any(JWTActions.class));

    var responseEntity =
        unsubscriptionController.handleUnsubscriptionByJWT("some-jwt-key", "communication");

    assertThat(responseEntity.getStatusCode()).isEqualTo(OK);
    assertThat(responseEntity.getBody()).isEqualTo(errorResponse);
  }
}
