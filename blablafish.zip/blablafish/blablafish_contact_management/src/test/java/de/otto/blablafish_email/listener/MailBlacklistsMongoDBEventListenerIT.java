package de.otto.blablafish_email.listener;

import static com.mongodb.assertions.Assertions.assertTrue;
import static org.assertj.core.api.Assertions.assertThat;
import static org.testcontainers.shaded.org.awaitility.Awaitility.await;

import com.amazonaws.services.sqs.AmazonSQS;
import de.otto.blablafish_contact_management.model.dto.EventType;
import de.otto.blablafish_contact_management.model.entity.Requester;
import de.otto.blablafish_contact_management.model.entity.Status;
import de.otto.blablafish_contact_management.model.entity.Subscriber;
import de.otto.blablafish_contact_management.respository.SubscriberRepository;
import de.otto.blablafish_contact_management.testDataConfig.SubscriberTestConfig;
import de.otto.blablafish_email.respository.EmailBlacklistRepository;
import de.otto.blablafish_email.testDataConfig.EmailBlacklistsTestConfig;
import java.time.Instant;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

class MailBlacklistsMongoDBEventListenerIT extends AbstractContainerIT {

  @Autowired private EmailBlacklistRepository blacklistRepository;

  @Autowired private SubscriberRepository subscriberRepository;

  @Autowired private AmazonSQS sqs;

  @Value("${mongoDbTrigger.mailBlacklists.queueUrl}")
  private String blacklistTriggerQueueName;

  @Test
  void
      shouldListenToTriggerOnEmailBlacklistsCollectionAndSetIsUserBlacklistedFlagToTrueForSubscriber() {
    var blacklistId = "62fcd877f97efa66b63ec1ea";
    insertInEmailBlacklistsCollection(blacklistId);
    insertInUsersCollection();
    var queueUrl = sqs.getQueueUrl(blacklistTriggerQueueName).getQueueUrl();
    var mongoTriggerMessage =
        "{\"version\":\"0\",\"id\":\"d094eef7-6619-377c-888e-a7315c6b855f\",\"detail-type\":\"MongoDB Database Trigger for contactmanagement_db.mailBlacklists\",\"source\":\"aws.partner/mongodb.com/stitch.trigger/62fcb5203a91751883303316\",\"account\":\"353449567674\",\"time\":\"2022-08-17T12:01:17Z\",\"region\":\"eu-central-1\",\"resources\":[\"arn:aws:events:eu-central-1::event-source/aws.partner/mongodb.com/stitch.trigger/62fcb5203a91751883303316\"],\"detail\":{\"_id\":{\"_data\":\"8262FCD88D000000012B022C0100296E5A10045F9186C02297464183B31948CBD3B44446645F6964006462FCD877F97EFA66B63EC1EA0004\"},\"operationType\":\"insert\",\"clusterTime\":{\"T\":1660737677,\"I\":1},\"fullDocument\":{\"_id\":\"62fcd877f97efa66b63ec1ea\",\"emailAddress\":{\"Subtype\":6,\"Data\":\"ATq2rjjimkr1gZix81Hd6kICYSyMKZF+Rz92TSWqzWbN3DjJiRZ8S1X/+GjUqI32l776Vue+NO6ej+XiyytXkuoeJOejEZqdRsUF+OiVGORBdekhywLqmNhH3LYEAdZxuP7P8okwOFaL7nRqDQifpjP7\"},\"reasons\":[{\"sourceType\":\"SES_EVENT\",\"awsMessageId\":\"010701828275d011-ae50c64d-8ad5-4d65-bef1-38c4c86a120c-000000\",\"description\":\"received event type of COMPLAINT\",\"timestamp\":\"2022-08-17T08:27:28.397Z\"},{\"sourceType\":\"SES_EVENT\",\"awsMessageId\":\"010701828275d011-ae50c64d-8ad5-4d65-bef1-38c4c86a120c-000000\",\"description\":\"received event type of COMPLAINT\",\"timestamp\":\"2022-08-10T07:30:36.94Z\"}]},\"ns\":{\"db\":\"contactmanagement_db\",\"coll\":\"mailBlacklists\"},\"documentKey\":{\"_id\":\"62fcd877f97efa66b63ec1ea\"}}}";

    sqs.sendMessage(queueUrl, mongoTriggerMessage);

    await()
        .atMost(5, TimeUnit.SECONDS)
        .untilAsserted(
            () -> {
              assertThat(sqs.receiveMessage(queueUrl).getMessages()).isEmpty();
              var blacklist = blacklistRepository.findById(new ObjectId(blacklistId)).orElseThrow();
              var user =
                  subscriberRepository
                      .findByEmail(blacklist.getEmailAddress().getValue())
                      .orElseThrow();

              assertTrue(user.getIsUserBlacklisted());
            });
  }

  private void insertInUsersCollection() {
    final ObjectId user1Id = new ObjectId("62bec37d21d8c96a1dff30cb");
    final String partnerId = "partner1";
    final int topic2Id = 2;
    final int topic1Id = 1;
    Subscriber user1 =
        SubscriberTestConfig.createSubscriber(
            user1Id,
            partnerId,
            new HashSet<>(Arrays.asList(topic1Id, topic2Id)),
            "TestUser1FirstName",
            "TestUser1LastName",
            "testuser1mail@otto.de",
            new HashSet<>(List.of("1627cc31ea20d40a10388febc")),
            Status.ENABLED,
            Instant.now(),
            Instant.now(),
            Requester.ofEventType(EventType.NEPTUNE_USER_SET),
            null);
    mongoTemplate.save(user1);
  }

  private void insertInEmailBlacklistsCollection(String blacklistId) {
    mongoTemplate.save(
        EmailBlacklistsTestConfig.createEmailBlacklist(
            blacklistId, "testuser1mail@otto.de", Collections.emptyList()));
  }
}
