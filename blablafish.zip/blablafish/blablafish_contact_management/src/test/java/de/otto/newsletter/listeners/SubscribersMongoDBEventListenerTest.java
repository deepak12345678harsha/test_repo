package de.otto.newsletter.listeners;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import de.otto.blablafish_contact_management.config.Features;
import de.otto.blablafish_contact_management.handler.SubscriberChangedEventHandler;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.togglz.junit5.AllEnabled;

@AllEnabled(Features.class)
@ExtendWith(MockitoExtension.class)
public class SubscribersMongoDBEventListenerTest {

  private final ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());
  @Mock private SubscriberChangedEventHandler subscriberChangedEventHandler;

  private SubscribersMongoDBEventListener listener;

  @BeforeEach
  public void setup() {
    listener = new SubscribersMongoDBEventListener(objectMapper, subscriberChangedEventHandler);
  }

  @Test
  void shouldHandleNewsletterSubscriptionChangedEvent() throws JsonProcessingException {
    String subscriberId = "62bec37d21d8c96a1dff30cb";
    String text =
        "Ja, ich möchte den OTTO-Market-Newsletter der Otto (GmbH & Co KG) erhalten und Informationen über Angebote, neue Services und Updates von OTTO Market erhalten. Diese Einwilligung kann jederzeit mit Wirkung für die Zukunft unter https://portal.otto.market/settings?section=newsletter oder am Ende jeder E-Mail widerrufen werden.";
    String eventAsString =
        "{\"version\":\"0\",\"id\":\"ab3cda69-ce95-61d8-a8c1-1e8e2c16135b\",\"detail-type\":\"MongoDB Database Trigger for contactmanagement_db.subscribers\",\"source\":\"aws.partner/mongodb.com/stitch.trigger/6311a64cf2a2c8bc65d5a4c2\",\"account\":\"353449567674\",\"time\":\"2022-10-11T07:20:26Z\",\"region\":\"eu-central-1\",\"resources\":[\"arn:aws:events:eu-central-1::event-source/aws.partner/mongodb.com/stitch.trigger/6311a64cf2a2c8bc65d5a4c2\"],\"detail\":{\"_id\":{\"_data\":\"826345193A000000012B022C0100296E5A10046B912311B15441BA9DC150E99E43751946645F6964006462B1AF5EBBBB2C5701BF4C970004\"},\"operationType\":\"update\",\"clusterTime\":{\"T\":1665472826,\"I\":1},\"ns\":{\"db\":\"contactmanagement_db\",\"coll\":\"subscribers\"},\"documentKey\":{\"_id\":\""
            + subscriberId
            + "\"},\"updateDescription\":{\"updatedFields\":{\"newsletterSubscription\":{\"status\":\"UNSUBSCRIBED\",\"text\":\""
            + text
            + "\",\"time\":\"2022-10-11T07:20:26.707Z\"}},\"removedFields\":[],\"truncatedArrays\":[]}}}";

    listener.listenToSubscribersMongoDbTriggersForChangeHistory(eventAsString);

    verify(subscriberChangedEventHandler).handleEvent(eq(eventAsString), any(), eq(subscriberId));
  }
}
