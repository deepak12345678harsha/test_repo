package de.otto.blablafish_contact_management.integrationtest.config;

import de.otto.blablafish_contact_management.config.Features;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.togglz.core.manager.EnumBasedFeatureProvider;
import org.togglz.core.repository.StateRepository;
import org.togglz.core.repository.mem.InMemoryStateRepository;
import org.togglz.core.spi.FeatureProvider;
import org.togglz.core.user.SimpleFeatureUser;
import org.togglz.core.user.UserProvider;

@TestConfiguration
@EnableAutoConfiguration
public class LocalTogglesConfig {
  @Bean
  public StateRepository getStateRepository() {
    return new InMemoryStateRepository();
  }

  @Bean
  public UserProvider getUserProvider() {
    return () -> new SimpleFeatureUser("admin", true);
  }

  @Bean
  public FeatureProvider featureProvider() {
    return new EnumBasedFeatureProvider(Features.class);
  }
}
