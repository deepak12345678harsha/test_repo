package de.otto.blablafish_email.respository;

import static org.mockito.Mockito.*;

import de.otto.blablafish_contact_management.model.encryption.EncryptedDocument;
import de.otto.blablafish_email.model.entity.EmailRequest;
import de.otto.blablafish_email.model.entity.EmailRequestStatus;
import de.otto.blablafish_email.model.entity.EmailRequester;
import java.time.Instant;
import java.util.List;
import org.assertj.core.api.Assertions;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.Test;
import org.springframework.data.mongodb.core.MongoTemplate;

class EmailRequestRepositoryTest {
  private final MongoTemplate mongoTemplate = mock(MongoTemplate.class);
  private final EmailRequestRepository emailRequestRepository =
      new EmailRequestRepository(mongoTemplate);

  @Test
  void shouldFindEmailRequestByRequestId() {
    ObjectId requestId = new ObjectId();
    Instant time = Instant.now();
    EmailRequest request = getRequest(requestId, time);
    when(mongoTemplate.findById(requestId, EmailRequest.class)).thenReturn(request);
    EmailRequest expectedRequest = getRequest(requestId, time);

    EmailRequest actualRequest = emailRequestRepository.findById(requestId).orElseThrow();

    verify(mongoTemplate).findById(requestId, EmailRequest.class);
    Assertions.assertThat(actualRequest).usingRecursiveComparison().isEqualTo(expectedRequest);
  }

  private EmailRequest getRequest(ObjectId requestId, Instant time) {
    return EmailRequest.builder()
        .requestId(requestId)
        .topicId(1)
        .createdAt(time)
        .recipients(List.of())
        .payload(new EncryptedDocument(null, "emailRequests.payload"))
        .requester(new EmailRequester("", ""))
        .status(EmailRequestStatus.ACCEPTED)
        .build();
  }
}
