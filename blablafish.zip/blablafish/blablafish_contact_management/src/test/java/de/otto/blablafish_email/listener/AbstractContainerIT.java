package de.otto.blablafish_email.listener;

import static org.assertj.core.api.Assertions.assertThat;

import com.amazonaws.services.sqs.AmazonSQS;
import de.otto.BlablafishContactManagementApplication;
import de.otto.blablafish_contact_management.integrationtest.config.AwsTestConfig;
import de.otto.blablafish_contact_management.integrationtest.config.LocalTogglesConfig;
import de.otto.blablafish_contact_management.integrationtest.config.MongoConfiguration;
import de.otto.blablafish_contact_management.integrationtest.config.MongoTestContainerConfig;
import de.otto.blablafish_contact_management.integrationtest.config.WebSecurityConfig;
import de.otto.blablafish_contact_management.model.entity.Subscriber;
import de.otto.blablafish_contact_management.model.entity.Topic;
import de.otto.blablafish_email.model.entity.Email;
import de.otto.blablafish_email.model.entity.EmailAttachment;
import de.otto.blablafish_email.model.entity.EmailBlacklist;
import de.otto.blablafish_email.model.entity.EmailMigrationRequest;
import de.otto.blablafish_email.model.entity.EmailRequest;
import de.otto.blablafish_email.model.entity.SESEvent;
import de.otto.newsletter.model.entity.RSAKeyPair;
import de.otto.newsletter.model.entity.SubscriberChangeEntry;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Collections;
import org.bson.Document;
import org.junit.jupiter.api.BeforeEach;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.context.annotation.Import;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.BasicQuery;
import org.springframework.test.context.ActiveProfiles;

@ActiveProfiles("integration")
@Import({
  MongoConfiguration.class,
  WebSecurityConfig.class,
  AwsTestConfig.class,
  MongoTestContainerConfig.class,
  LocalTogglesConfig.class
})
@SpringBootTest(
    webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
    classes = BlablafishContactManagementApplication.class)
public abstract class AbstractContainerIT {

  protected String BASE_PATH = "/contact-management";

  @LocalServerPort protected int port;

  @Autowired protected MongoTemplate mongoTemplate;

  protected static void assertThatQueueHasConsumedAllMessages(AmazonSQS sqs, String queueUrl) {
    int messageCount =
        Integer.parseInt(
            sqs.getQueueAttributes(
                    queueUrl, Collections.singletonList("ApproximateNumberOfMessages"))
                .getAttributes()
                .get("ApproximateNumberOfMessages"));
    assertThat(messageCount).isEqualTo(0);
  }

  @BeforeEach
  void tearDown() {
    mongoTemplate.remove(new BasicQuery(new Document()), Topic.class);
    mongoTemplate.remove(new BasicQuery(new Document()), Subscriber.class);
    mongoTemplate.remove(new BasicQuery(new Document()), EmailRequest.class);
    mongoTemplate.remove(new BasicQuery(new Document()), EmailAttachment.class);
    mongoTemplate.remove(new BasicQuery(new Document()), EmailBlacklist.class);
    mongoTemplate.remove(new BasicQuery(new Document()), Email.class);
    mongoTemplate.remove(new BasicQuery(new Document()), SESEvent.class);
    mongoTemplate.remove(new BasicQuery(new Document()), RSAKeyPair.class);
    mongoTemplate.remove(new BasicQuery(new Document()), SubscriberChangeEntry.class);
    mongoTemplate.remove(new BasicQuery(new Document()), EmailMigrationRequest.class);
  }

  protected String readFileAsString(String fileName) throws IOException {
    final File file = new ClassPathResource(fileName).getFile();
    return new String(Files.readAllBytes(file.toPath()));
  }

  protected File readFile(String fileName) throws IOException {
    return new ClassPathResource(fileName).getFile();
  }
}
