package de.otto.blablafish_email.listener;

import static org.assertj.core.api.Assertions.assertThat;
import static org.testcontainers.shaded.org.awaitility.Awaitility.given;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.sqs.AmazonSQS;
import de.otto.blablafish_contact_management.model.encryption.EncryptedString;
import de.otto.blablafish_email.model.dto.mail.EmailAttachmentDetail;
import de.otto.blablafish_email.model.entity.EmailAttachment;
import de.otto.blablafish_email.respository.EmailAttachmentRepository;
import de.otto.blablafish_email.service.EmailAttachmentService;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.time.Instant;
import java.util.concurrent.TimeUnit;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.MongoTemplate;

class EmailAttachmentEventsListenerIT extends AbstractContainerIT {

  @Value("${emailAttachmentEvents.queueUrl}")
  private String emailAttachmentEventsQueue;

  @Autowired private EmailAttachmentRepository emailAttachmentRepository;

  @Autowired private EmailAttachmentService emailAttachmentService;

  @Autowired private AmazonSQS sqs;

  @Autowired private AmazonS3 s3;

  @Autowired private MongoTemplate mongoTemplate;

  @Test
  void shouldListenToEmailAttachmentEvents() throws FileNotFoundException {
    String queueUrl = sqs.getQueueUrl(emailAttachmentEventsQueue).getQueueUrl();

    s3.createBucket("attachments20211018125151464200000001");
    s3.putObject(
        new PutObjectRequest(
            "attachments20211018125151464200000001",
            "2022-07-04/06-36-52.2768-neptune-email-test-client",
            new FileInputStream("src/test/resources/uploadForEmail.txt"),
            new ObjectMetadata()));

    String emailAttachmentEvent =
        """
            {
              "eventId": "51d56b61-149a-4df7-8d55-cebbab8f2211",
              "traceId": "d6215f5c-eca2-44b5-9b44-751e5d37d1bc",
              "type": "neptune-email_service.EMAIL_ATTACHMENT_CREATED",
              "context": "neptune-email-service",
              "eventTime": "2022-11-04T06:36:53.178Z",
              "data": {
                "attachmentId": "6364b304fb4bd2660420a34d",
                "s3BucketName": "attachments20211018125151464200000001",
                "s3UploadKey": "2022-07-04/06-36-52.2768-neptune-email-test-client",
                "fileName": "test_12345.csv",
                "contentType": "application/octet-stream",
                "fileSizeInBytes": 705,
                "clientId": "neptune-email-test-client",
                "subject": "b624ce5a-9367-4045-a2de-acadea7d21f0",
                "createdAt": "2022-07-04T06:36:53.178Z"
              }
            }
            """;
    sqs.sendMessage(queueUrl, emailAttachmentEvent);

    given()
        .await()
        .atMost(15, TimeUnit.SECONDS)
        .untilAsserted(
            () -> {
              assertThat(sqs.receiveMessage(queueUrl).getMessages()).isEmpty();
              assertThat(mongoTemplate.findAll(EmailAttachment.class)).hasSize(1);
            });

    EmailAttachment emailAttachment =
        emailAttachmentRepository.fetchOne("6364b304fb4bd2660420a34d");
    EmailAttachmentDetail attachment =
        emailAttachmentService.getAttachment("6364b304fb4bd2660420a34d");

    assertThat(emailAttachment.getOldS3BucketName())
        .isEqualTo("attachments20211018125151464200000001");
    assertThat(emailAttachment.getOldS3UploadKey())
        .isEqualTo("2022-07-04/06-36-52.2768-neptune-email-test-client");
    assertThat(attachment.getFileName()).isEqualTo("test_12345.csv");
  }

  @Test
  void shouldNotSyncAttachmentIfAlreadyExists() {
    var attachment =
        EmailAttachment.builder()
            .id("6364b304fb4bd2660420a34d")
            .s3BucketName("attachments20211018125151464200000001")
            .s3UploadKey("2022-07-04/06-36-52.2768-neptune-email-test-client")
            .fileName(new EncryptedString("test_12345.csv", "mailAttachments.fileName", false))
            .contentType("application/octet-stream")
            .fileSizeInBytes(705L)
            .clientId("neptune-email-test-client")
            .subject("b624ce5a-9367-4045-a2de-acadea7d21f0")
            .createdAt(Instant.now())
            .build();

    mongoTemplate.insert(attachment);

    String queueUrl = sqs.getQueueUrl(emailAttachmentEventsQueue).getQueueUrl();
    String emailAttachmentEvent =
        """
                {
                  "eventId": "51d56b61-149a-4df7-8d55-cebbab8f2211",
                  "traceId": "d6215f5c-eca2-44b5-9b44-751e5d37d1bc",
                  "type": "neptune-email_service.EMAIL_ATTACHMENT_CREATED",
                  "context": "neptune-email-service",
                  "eventTime": "2022-11-04T06:36:53.178Z",
                  "data": {
                    "attachmentId": "6364b304fb4bd2660420a34d",
                    "s3BucketName": "attachments20211018125151464200000001",
                    "s3UploadKey": "2022-07-04/06-36-52.2768-neptune-email-test-client",
                    "fileName": "test_12345.csv",
                    "contentType": "application/octet-stream",
                    "fileSizeInBytes": 705,
                    "clientId": "neptune-email-test-client",
                    "subject": "b624ce5a-9367-4045-a2de-acadea7d21f0",
                    "createdAt": "2022-07-04T06:36:53.178Z"
                  }
                }
                """;
    sqs.sendMessage(queueUrl, emailAttachmentEvent);

    given()
        .await()
        .atMost(15, TimeUnit.SECONDS)
        .untilAsserted(
            () -> {
              assertThat(sqs.receiveMessage(queueUrl).getMessages()).isEmpty();
              assertThat(mongoTemplate.findAll(EmailAttachment.class)).hasSize(1);
            });

    EmailAttachment emailAttachment =
        emailAttachmentRepository.fetchOne("6364b304fb4bd2660420a34d");

    assertThat(emailAttachment.getOldS3BucketName()).isNull();
    assertThat(emailAttachment.getOldS3UploadKey()).isNull();
  }
}
