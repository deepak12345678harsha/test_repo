package de.otto.blablafish_email.listener;

import static java.util.concurrent.TimeUnit.SECONDS;
import static org.assertj.core.api.Assertions.assertThat;
import static org.testcontainers.shaded.org.awaitility.Awaitility.await;

import com.amazonaws.services.sqs.AmazonSQS;
import de.otto.blablafish_email.model.entity.Email;
import de.otto.blablafish_email.model.entity.EmailStatus;
import de.otto.blablafish_email.model.entity.EmailStatusHistoryEntry;
import de.otto.blablafish_email.respository.EmailRepository;
import de.otto.blablafish_email.testDataConfig.EmailTestConfig;
import java.time.Instant;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

class EmailsMongoDbEventListenerIT extends AbstractContainerIT {

  @Autowired private EmailRepository emailRepository;

  @Autowired private AmazonSQS sqs;

  @Value("${mongoDbTrigger.mails.queueUrl}")
  private String emailTriggerQueueName;

  @Test
  void shouldListenToTriggerOnEmailsCollectionAndSendEmail() {
    var emailId = "100";
    insertInEmailCollection(emailId);
    var queueUrl = sqs.getQueueUrl(emailTriggerQueueName).getQueueUrl();

    var mongoTriggerMessage =
        "{\"version\":\"0\",\"id\":\"b1ca348e-e63e-6612-2945-cb295bdebc96\",\"detail-type\":\"MongoDB Database Trigger for contactmanagement_db.topics\",\"source\":\"aws.partner/mongodb.com/stitch.trigger/62d8e3ce630cf0df56e11470\",\"account\":\"353449567674\",\"time\":\"2022-07-21T06:29:09Z\",\"region\":\"eu-central-1\",\"resources\":[\"arn:aws:events:eu-central-1::event-source/aws.partner/mongodb.com/stitch.trigger/62d8e3ce630cf0df56e11470\"],\"detail\":{\"_id\":{\"_data\":\"8262D8F235000000012B022C0100296E5A1004C78B687AEE09431E90F03FFA907F1B91461E5F6964002BC80004\"},\"operationType\":\"update\",\"clusterTime\":{\"T\":1658384949,\"I\":1},\"ns\":{\"db\":\"contactmanagement_db\",\"coll\":\"topics\"},"
            + "\"documentKey\":{\"_id\":"
            + emailId
            + "},\"updateDescription\":{\"updatedFields\":{\"name\":\"test-topic-trigger\"},\"removedFields\":[],\"truncatedArrays\":[]}}}";
    sqs.sendMessage(queueUrl, mongoTriggerMessage);

    await().atMost(5, SECONDS).until(() -> mongoTemplate.findAll(Email.class).size() == 1);

    assertThatQueueHasConsumedAllMessages(sqs, queueUrl);
    var savedEmails = mongoTemplate.findAll(Email.class);
    assertThat(savedEmails).hasSize(1);
    var savedEmail = savedEmails.get(0);
    assertThat(savedEmail.getId()).isEqualTo(emailId);
    assertThat(savedEmail.getStatus()).isEqualTo(EmailStatus.SENDING);
    assertThat(savedEmail.getStatusHistory().get(0))
        .usingRecursiveComparison()
        .isEqualTo(
            EmailStatusHistoryEntry.of(EmailStatus.SENDING, savedEmail.getStatusTimestamp()));
    assertThat(savedEmail.getAwsMessageId()).isEqualTo("success-message-id");
  }

  private void insertInEmailCollection(String emailId) {
    var email =
        EmailTestConfig.createEmail(
            emailId,
            "no-reply@nonlive.partner-info.otto.market",
            "blablafish@otto.de",
            "html",
            "text",
            "subject",
            "62bec37d21d8c96a1dff30cb",
            Instant.now(),
            EmailStatus.READY_TO_SEND,
            Instant.now(),
            "foobar");

    emailRepository.insert(email);
  }
}
