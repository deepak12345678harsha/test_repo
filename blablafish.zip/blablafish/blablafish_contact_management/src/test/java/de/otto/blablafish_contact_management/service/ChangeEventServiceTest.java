package de.otto.blablafish_contact_management.service;

import static de.otto.blablafish_contact_management.utils.Constants.EVENT_EXPIRATION_IN_YEARS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import de.otto.blablafish_contact_management.encryption.EncryptionHelper;
import de.otto.blablafish_contact_management.model.entity.ChangeEvent;
import de.otto.blablafish_contact_management.model.entity.ClusterTime;
import de.otto.blablafish_contact_management.respository.ChangeEventRepository;
import de.otto.blablafish_email.model.dto.MongoDbTriggerEvent;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.UUID;
import org.bson.Document;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

class ChangeEventServiceTest {

  @Test
  void shouldPersistChangeEvent() throws JsonProcessingException {
    String eventAsJson =
        "{\"id\":\"event-1\",\"source\":\"source-1\",\"account\":\"account1\",\"time\":1663150041.694608000,\"resources\":[\"aws/email-trigger-123494\"],\"detail\":{\"operationType\":\"UPDATE\",\"clusterTime\":{\"i\":76554,\"t\":1234587},\"documentKey\":{\"_id\":\"62dfb73cf65bfa1ec6f05fe0\"},\"updateDescription\":{\"removedFields\":null,\"updatedFields\":null,\"truncatedArrays\":null},\"ns\":{\"db\":\"db\",\"coll\":\"emailRequests\"}},\"detail-type\":\"detailType\"}";
    Document eventAsDocument = Document.parse(eventAsJson);
    ChangeEventRepository changeEventRepository = mock(ChangeEventRepository.class);
    ChangeEventService changeEventService =
        new ChangeEventService(changeEventRepository, mock(EncryptionHelper.class));
    ObjectMapper mapper = new ObjectMapper().registerModule(new JavaTimeModule());
    MongoDbTriggerEvent event = mapper.readValue(eventAsJson, MongoDbTriggerEvent.class);
    ChangeEvent expectedChangeEvent = getChangeEvent(event, eventAsDocument);

    changeEventService.handleEvent(event, eventAsJson);

    ArgumentCaptor<ChangeEvent> argumentCaptor = ArgumentCaptor.forClass(ChangeEvent.class);
    verify(changeEventRepository).insert(argumentCaptor.capture());
    org.assertj.core.api.Assertions.assertThat(argumentCaptor.getValue())
        .usingRecursiveComparison()
        .ignoringFields("expiresAt", "id")
        .isEqualTo(expectedChangeEvent);
  }

  private ChangeEvent getChangeEvent(MongoDbTriggerEvent event, Document eventAsDocument) {
    final Instant expiresAt = Instant.now().plus(EVENT_EXPIRATION_IN_YEARS * 365, ChronoUnit.DAYS);
    ChangeEvent changeEvent =
        ChangeEvent.builder()
            .id(UUID.randomUUID().toString())
            .eventDescription(event.getDetailType())
            .source(event.getSource())
            .db(event.getDetail().getNs().getDb())
            .collection(event.getDetail().getNs().getColl())
            .operationType(event.getDetail().getOperationType())
            .documentKey(new Document("_id", event.getDetail().getDocumentKey().get_id()))
            .expiresAt(expiresAt)
            .event(ChangeEvent.encryptDocument(eventAsDocument))
            .time(event.getTime())
            .clusterTime(ClusterTime.fromDTO(event.getDetail().getClusterTime()))
            .build();
    return changeEvent;
  }
}
