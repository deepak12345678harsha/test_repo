package de.otto.blablafish_contact_management.service;

import static de.otto.blablafish_contact_management.model.dto.SubscriptionResponse.SUBSCRIPTION_SUCCESSFUL;
import static de.otto.blablafish_contact_management.model.dto.SubscriptionResponse.SUBSCRIPTION_UNSUCCESSFUL;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.anyInt;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import de.otto.blablafish_contact_management.exception.TopicNotFoundException;
import de.otto.blablafish_contact_management.model.dto.AddSubscriberResponse;
import de.otto.blablafish_contact_management.model.dto.AddSubscribersResponse;
import de.otto.blablafish_contact_management.model.dto.TopicDTO;
import de.otto.blablafish_contact_management.model.entity.Requester;
import de.otto.blablafish_contact_management.model.entity.Subscriber;
import de.otto.blablafish_contact_management.model.entity.Topic;
import de.otto.blablafish_contact_management.model.entity.TopicOptions;
import de.otto.blablafish_contact_management.respository.SubscriberRepository;
import de.otto.blablafish_contact_management.respository.TopicRepository;
import de.otto.blablafish_contact_management.testDataConfig.SubscriberTestConfig;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class TopicServiceTest {

  private TopicService topicService;

  @Mock private TopicRepository topicRepository;

  @Mock private SubscriberRepository subscriberRepository;

  public static List<Topic> getAllTopics(boolean displayOnContactManagement) {
    Topic topic1 =
        Topic.builder()
            .id(1)
            .name("topic 1")
            .description("description 1")
            .mandatorySubscriberRoles(Arrays.asList("mandatory role 1", "mandatory role 2"))
            .emailSubject("")
            .emailPlainTextTemplate("")
            .emailHtmlTemplate("")
            .emailSchema(new Document())
            .options(
                TopicOptions.builder()
                    .displayOnEmailConfigUI(!displayOnContactManagement)
                    .displayOnContactManagementUI(displayOnContactManagement)
                    .isSubscribedByDefault(true)
                    .canUnsubscribe(false)
                    .archiving(true)
                    .build())
            .build();
    Topic topic2 =
        Topic.builder()
            .id(2)
            .name("topic 2")
            .description("description 2")
            .mandatorySubscriberRoles(Arrays.asList("mandatory role 3", "mandatory role 4"))
            .emailSubject("")
            .emailPlainTextTemplate("")
            .emailHtmlTemplate("")
            .emailSchema(new Document())
            .options(
                TopicOptions.builder()
                    .displayOnEmailConfigUI(!displayOnContactManagement)
                    .displayOnContactManagementUI(displayOnContactManagement)
                    .isSubscribedByDefault(true)
                    .canUnsubscribe(false)
                    .archiving(true)
                    .build())
            .build();
    return Arrays.asList(topic1, topic2);
  }

  @BeforeEach
  public void setUserService() {
    topicService = new TopicService(topicRepository, subscriberRepository);
  }

  @Test
  public void shouldGetAllSubscribersForAllTopics() {
    when(topicRepository.findAll()).thenReturn(getAllTopics(true));
    when(subscriberRepository.findAllByPartner(anyString()))
        .thenReturn(List.of(getSubscriber(new ObjectId("629089ba391a524f0b687f4a"), "partner1")));

    List<TopicDTO> topicSubscribers = topicService.getTopicSubscribers("partner1");

    assertThat(topicSubscribers.size()).isEqualTo(2);
    assertThat(topicSubscribers.get(0).getName()).isEqualTo("topic 1");
    assertThat(topicSubscribers.get(0).getSubscribers().get(0).getEmail())
        .isEqualTo("testuser1mail@otto.de");
    verify(topicRepository, times(1)).findAll();
    verify(subscriberRepository).findAllByPartner("partner1");
  }

  @Test
  public void shouldGetNoSubscribersForTopicsWhenPartnerIdIsNotPresent() {
    when(topicRepository.findAll()).thenReturn(getAllTopics(true));
    when(subscriberRepository.findAllByPartner(anyString())).thenReturn(new ArrayList<>());

    List<TopicDTO> topicSubscribers = topicService.getTopicSubscribers("partner1");

    assertThat(topicSubscribers.size()).isEqualTo(2);
    assertThat(topicSubscribers.get(0).getName()).isEqualTo("topic 1");
    assertThat(topicSubscribers.get(0).getSubscribers()).isEqualTo(new ArrayList<>());
    assertThat(topicSubscribers.get(1).getSubscribers()).isEqualTo(new ArrayList<>());
    verify(topicRepository, times(1)).findAll();
    verify(subscriberRepository).findAllByPartner("partner1");
  }

  @Test
  void shouldNotReturnSubscriberForTopicsWithWhenDisplayOnContactManagementFlagIsDisabled() {
    Boolean displayOnContactManagement = false;
    when(topicRepository.findAll())
        .thenReturn(
            List.of(
                Topic.builder()
                    .id(1)
                    .name("topic2")
                    .description("description2")
                    .mandatorySubscriberRoles(Collections.emptyList())
                    .emailSubject("")
                    .emailPlainTextTemplate("")
                    .emailHtmlTemplate("")
                    .emailSchema(new Document())
                    .options(
                        TopicOptions.builder()
                            .archiving(true)
                            .canUnsubscribe(false)
                            .isSubscribedByDefault(true)
                            .displayOnEmailConfigUI(true)
                            .displayOnContactManagementUI(displayOnContactManagement)
                            .build())
                    .build()));

    List<TopicDTO> topicSubscribers = topicService.getTopicSubscribers("partner1");

    assertThat(topicSubscribers).isEmpty();
  }

  @Test
  void shouldNotReturnSubscriberForTopicsWithWhenTopicOptionsAreNull() {
    TopicOptions topicOptionsAsNull = null;
    when(topicRepository.findAll())
        .thenReturn(
            List.of(
                Topic.builder()
                    .id(1)
                    .name("topic2")
                    .description("description2")
                    .mandatorySubscriberRoles(Collections.emptyList())
                    .emailSubject("")
                    .emailPlainTextTemplate("")
                    .emailHtmlTemplate("")
                    .emailSchema(new Document())
                    .options(topicOptionsAsNull)
                    .build()));

    List<TopicDTO> topicSubscribers = topicService.getTopicSubscribers("partner1");

    assertThat(topicSubscribers).isEmpty();
  }

  @Test
  public void shouldUpdateSuccessfulSubscriptionWhenUserSubscriberToTopic()
      throws TopicNotFoundException {
    ObjectId userId1 = new ObjectId("629089ba391a524f0b687f4a");
    ObjectId userId2 = new ObjectId("629089ba391a524f0b687f4b");
    var requester = mock(Requester.class);
    when(topicRepository.findById(anyInt())).thenReturn(Optional.of(getAllTopics(true).get(0)));
    when(subscriberRepository.subscribeTopicForUsers(List.of(userId1, userId2), 1, requester))
        .thenReturn(2L);

    List<AddSubscriberResponse> responses = new ArrayList<>();
    responses.add(
        new AddSubscriberResponse(
            SUBSCRIPTION_SUCCESSFUL, Set.of(userId1.toString(), userId2.toString())));
    responses.add(new AddSubscriberResponse(SUBSCRIPTION_UNSUCCESSFUL, new HashSet<>()));
    AddSubscribersResponse expectedResponse = new AddSubscribersResponse(responses);

    AddSubscribersResponse actualResponse =
        topicService.addTopicSubscribers(
            1, List.of("629089ba391a524f0b687f4a", "629089ba391a524f0b687f4b"), requester);

    assertThat(actualResponse).usingRecursiveComparison().isEqualTo(expectedResponse);
    verify(subscriberRepository).subscribeTopicForUsers(List.of(userId1, userId2), 1, requester);
  }

  @Test
  public void shouldUpdateUnSuccessFulSubscriptionWhenUserSubscriberToTopic()
      throws TopicNotFoundException {
    var userId1 = new ObjectId("629089ba391a524f0b687f4a");
    var userId2 = new ObjectId("629089ba391a524f0b687f4b");
    var userId3 = new ObjectId("629089ba391a524f0b687f4c");
    var partnerId = "1";
    var user1 = getSubscriber(userId1, partnerId);
    var user2 = getSubscriber(userId2, partnerId);
    var requester = Requester.of(new ObjectId(), partnerId, "user-agent");
    when(topicRepository.findById(anyInt())).thenReturn(Optional.of(getAllTopics(true).get(0)));
    when(subscriberRepository.subscribeTopicForUsers(
            List.of(userId1, userId2, userId3), 1, requester))
        .thenReturn(2L);
    when(subscriberRepository.filterSubscribedUsersForTopic(
            List.of(userId1, userId2, userId3), 1, partnerId))
        .thenReturn(List.of(user1, user2));

    List<AddSubscriberResponse> responses = new ArrayList<>();
    responses.add(
        new AddSubscriberResponse(
            SUBSCRIPTION_SUCCESSFUL,
            Set.of("629089ba391a524f0b687f4a", "629089ba391a524f0b687f4b")));
    responses.add(
        new AddSubscriberResponse(SUBSCRIPTION_UNSUCCESSFUL, Set.of("629089ba391a524f0b687f4c")));
    var expectedResponse = new AddSubscribersResponse(responses);

    var actualResponse =
        topicService.addTopicSubscribers(
            1,
            List.of(
                "629089ba391a524f0b687f4a", "629089ba391a524f0b687f4b", "629089ba391a524f0b687f4c"),
            requester);

    assertThat(actualResponse).usingRecursiveComparison().isEqualTo(expectedResponse);
    verify(subscriberRepository)
        .subscribeTopicForUsers(List.of(userId1, userId2, userId3), 1, requester);
  }

  @Test
  public void shouldThrow404WhenTopicNotFoundWhileSubscribingUsersToTopic() {
    when(topicRepository.findById(1)).thenReturn(Optional.empty());
    try {
      topicService.addTopicSubscribers(1, List.of("1", "2", "3"), mock(Requester.class));
    } catch (TopicNotFoundException e) {
      assertThat(e.getMessage()).isEqualTo("Topic with id 1 does not exists");
    }
  }

  private Subscriber getSubscriber(ObjectId userId, String partnerId) {
    return new SubscriberTestConfig()
        .subscriberBuilder()
        .userId(userId)
        .partnerId(partnerId)
        .build();
  }
}
