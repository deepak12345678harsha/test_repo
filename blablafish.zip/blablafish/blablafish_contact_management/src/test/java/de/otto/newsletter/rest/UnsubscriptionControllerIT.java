package de.otto.newsletter.rest;

import static io.restassured.RestAssured.with;
import static org.assertj.core.api.Assertions.assertThat;

import de.otto.blablafish_contact_management.model.entity.CommunicationSubscription;
import de.otto.blablafish_contact_management.model.entity.CommunicationSubscriptionStatus;
import de.otto.blablafish_contact_management.model.entity.NewsletterSubscriptionStatus;
import de.otto.blablafish_contact_management.model.entity.Subscriber;
import de.otto.blablafish_contact_management.testDataConfig.SubscriberTestConfig;
import de.otto.blablafish_email.listener.AbstractContainerIT;
import de.otto.newsletter.model.JWTActions;
import de.otto.newsletter.service.JWTService;
import io.restassured.http.ContentType;
import java.time.Instant;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

class UnsubscriptionControllerIT extends AbstractContainerIT {

  @Autowired private JWTService jwtService;

  @Test
  void shouldUnsubscribeNewsletter() {
    var subscriber = new SubscriberTestConfig().subscriberBuilder().build();
    mongoTemplate.insert(subscriber);
    var response =
        with()
            .given()
            .port(port)
            .basePath(BASE_PATH)
            .when()
            .queryParam(
                "key", jwtService.getJWT(subscriber.getUserId(), JWTActions.UNSUBSCRIBE_NEWSLETTER))
            .request("GET", "/v1/subscribers/unsubscribe-newsletter")
            .then()
            .statusCode(200)
            .contentType(ContentType.HTML)
            .extract()
            .body()
            .asPrettyString();

    var actualSubscriber = mongoTemplate.findById(subscriber.getUserId(), Subscriber.class);
    assertThat(actualSubscriber.getNewsletterSubscription().getStatus())
        .isEqualTo(NewsletterSubscriptionStatus.UNSUBSCRIBED);
    assertThat(response).contains("Ihre Newsletter-Abmeldung war erfolgreich");
  }

  @Test
  void shouldUnsubscribeCommunications() {
    var subscriber =
        new SubscriberTestConfig()
            .subscriberBuilder()
            .communicationSubscription(
                new CommunicationSubscription(
                    CommunicationSubscriptionStatus.SUBSCRIBED, Instant.now()))
            .build();
    mongoTemplate.insert(subscriber);
    var response =
        with()
            .given()
            .port(port)
            .basePath(BASE_PATH)
            .when()
            .queryParam(
                "key",
                jwtService.getJWT(subscriber.getUserId(), JWTActions.UNSUBSCRIBE_COMMUNICATIONS))
            .queryParam("type", "communication")
            .request("GET", "/v1/subscribers/unsubscribe")
            .then()
            .statusCode(200)
            .contentType(ContentType.HTML)
            .extract()
            .body()
            .asPrettyString();

    var actualSubscriber = mongoTemplate.findById(subscriber.getUserId(), Subscriber.class);
    assertThat(actualSubscriber.getCommunicationSubscription().getStatus())
        .isEqualTo(CommunicationSubscriptionStatus.UNSUBSCRIBED);
    assertThat(response).contains("Ihre Newsletter-Abmeldung war erfolgreich");
  }
}
