package de.otto.blablafish_email.testDataConfig;

import de.otto.blablafish_email.model.entity.SESEvent;
import java.time.Instant;
import org.bson.Document;
import org.bson.types.ObjectId;

public class SESEventTestConfig {
  public static SESEvent createSesEvent(
      String id, String eventType, String awsMessageId, Document body, String mailRequestId) {
    return new SESEvent(
        new ObjectId(id),
        eventType,
        awsMessageId,
        SESEvent.encryptedBody(body),
        Instant.now(),
        new ObjectId(mailRequestId));
  }
}
