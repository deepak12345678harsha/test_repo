package de.otto.blablafish_contact_management.respository;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

import de.otto.blablafish_contact_management.model.entity.ChangeEvent;
import de.otto.blablafish_contact_management.model.entity.ClusterTime;
import java.time.Instant;
import org.bson.Document;
import org.junit.jupiter.api.Test;
import org.springframework.data.mongodb.core.MongoTemplate;

class ChangeEventRepositoryTest {

  @Test
  void shouldInsertChangeEvent() {
    MongoTemplate mongoTemplate = mock(MongoTemplate.class);
    ChangeEventRepository changeEventRepository = new ChangeEventRepository(mongoTemplate);
    Document eventAsDocument = new Document("key", "value");
    ChangeEvent changeEvent =
        ChangeEvent.builder()
            .id("62bec37d21d8c96a1dff30cb")
            .db("db")
            .collection("subscriber")
            .documentKey(new Document("key", "value"))
            .expiresAt(Instant.now().minusMillis(1000))
            .time(Instant.now())
            .clusterTime(new ClusterTime())
            .operationType("REPLACE")
            .event(ChangeEvent.encryptDocument(eventAsDocument))
            .build();
    changeEventRepository.insert(changeEvent);
    verify(mongoTemplate).insert(changeEvent);
  }
}
