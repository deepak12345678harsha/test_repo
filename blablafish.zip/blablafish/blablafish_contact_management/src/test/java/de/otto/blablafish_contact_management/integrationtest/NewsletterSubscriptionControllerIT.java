package de.otto.blablafish_contact_management.integrationtest;

import static de.otto.blablafish_contact_management.model.entity.NewsletterSubscriptionStatus.SUBSCRIBED;
import static io.restassured.RestAssured.with;
import static org.assertj.core.api.Assertions.assertThat;

import de.otto.blablafish_contact_management.integrationtest.helpers.JwtHelper;
import de.otto.blablafish_contact_management.model.Actions;
import de.otto.blablafish_contact_management.model.dto.ErrorResponse;
import de.otto.blablafish_contact_management.model.dto.EventType;
import de.otto.blablafish_contact_management.model.dto.NewsletterSubscriptionDTO;
import de.otto.blablafish_contact_management.model.entity.*;
import de.otto.blablafish_contact_management.respository.SubscriberRepository;
import de.otto.blablafish_contact_management.testDataConfig.SubscriberTestConfig;
import de.otto.blablafish_email.listener.AbstractContainerIT;
import io.restassured.common.mapper.TypeRef;
import io.restassured.http.ContentType;
import java.time.Instant;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.UUID;
import org.assertj.core.api.Assertions;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.BasicQuery;
import org.springframework.http.HttpStatus;

class NewsletterSubscriptionControllerIT extends AbstractContainerIT {

  private final String COOPERATION_BASIC_ROLE = "cooperation_basic";
  private final String partnerId = "partner1";
  private final ObjectId subscriberId1 = new ObjectId("62bec37d21d8c96a1dff30cb");
  private final ObjectId subscriberId2 = new ObjectId("62bec37d21d8c96a1dff30cc");
  private final String username = "testuser1mail@otto.de";
  private final String username2 = "testuser2mail@otto.de";

  @Autowired private SubscriberRepository subscriberRepository;

  @AfterEach
  void tearDown() {
    this.mongoTemplate.remove(new BasicQuery(new Document()), Topic.class);
    this.mongoTemplate.remove(new BasicQuery(new Document()), Subscriber.class);
  }

  @Test
  void shouldReturn403WhenRequiredRoleIsNotPresentForGetNewsletterSubscription() {
    final String requesterKeycloakId = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken(
            "test-client", requesterKeycloakId, List.of("foobar"), partnerId, username);
    final ErrorResponse errorResponse =
        with()
            .given()
            .header("Authorization", jwt)
            .port(port)
            .basePath(BASE_PATH)
            .when()
            .request("GET", "/v1/subscribers/newsletter-subscription-status")
            .then()
            .statusCode(HttpStatus.FORBIDDEN.value())
            .and()
            .extract()
            .body()
            .as(new TypeRef<>() {});
    Assertions.assertThat(errorResponse.getMessage()).isEqualTo("Access is denied");
  }

  @Test
  void shouldReturnNewsletterSubscriptionForSubscriberById() {
    createSubscribers();
    final String requesterKeycloakId = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken(
            "test-client",
            requesterKeycloakId,
            List.of(COOPERATION_BASIC_ROLE),
            partnerId,
            username);
    NewsletterSubscriptionDTO newsletter =
        with()
            .given()
            .header("Authorization", jwt)
            .port(port)
            .basePath(BASE_PATH)
            .when()
            .request("GET", "/v1/subscribers/newsletter-subscription-status")
            .then()
            .statusCode(200)
            .and()
            .extract()
            .body()
            .as(new TypeRef<>() {});

    assertThat(newsletter).usingRecursiveComparison().isEqualTo(getNewsletterForSubscriber1());
  }

  @Test
  void shouldReturnUnsubscribedStatusWhenNoSubscriptionFoundForSubscriber() {
    createSubscribers();
    final String requesterKeycloakId = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken(
            "test-client",
            requesterKeycloakId,
            List.of(COOPERATION_BASIC_ROLE),
            partnerId,
            username2);

    NewsletterSubscriptionDTO newsletter =
        with()
            .given()
            .header("Authorization", jwt)
            .port(port)
            .basePath(BASE_PATH)
            .when()
            .request("GET", "/v1/subscribers/newsletter-subscription-status")
            .then()
            .statusCode(200)
            .and()
            .extract()
            .body()
            .as(new TypeRef<>() {});

    assertThat(newsletter)
        .usingRecursiveComparison()
        .ignoringFields("time")
        .isEqualTo(new NewsletterSubscriptionDTO(false, "", Instant.now()));
  }

  @Test
  void shouldReturn403WhenRequiredRoleIsNotPresentForUpdateNewsletterSusbcription() {
    final String requesterKeycloakId = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken(
            "test-client", requesterKeycloakId, List.of("foobar"), partnerId, username);
    final ErrorResponse errorResponse =
        with()
            .given()
            .header("Authorization", jwt)
            .port(port)
            .basePath(BASE_PATH)
            .contentType(ContentType.JSON)
            .body("{\"isSubscribed\":true, \"text\":\"some text changed\", \"time\":1660809625}")
            .when()
            .request("PUT", "/v1/subscribers/newsletter-subscription-status")
            .then()
            .statusCode(HttpStatus.FORBIDDEN.value())
            .and()
            .extract()
            .body()
            .as(new TypeRef<>() {});
    Assertions.assertThat(errorResponse.getMessage()).isEqualTo("Access is denied");
  }

  @Test
  void shouldSaveNewsletterSubscriptionForSubscriberById() {
    createSubscribers();
    final String requesterKeycloakId = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken(
            "test-client",
            requesterKeycloakId,
            List.of(COOPERATION_BASIC_ROLE),
            partnerId,
            username);
    NewsletterSubscriptionDTO newsletter =
        with()
            .given()
            .header("Authorization", jwt)
            .port(port)
            .basePath(BASE_PATH)
            .contentType(ContentType.JSON)
            .body("{\"isSubscribed\":true, \"text\":\"some text changed\"}")
            .when()
            .request("PUT", "/v1/subscribers/newsletter-subscription-status")
            .then()
            .statusCode(200)
            .and()
            .extract()
            .body()
            .as(new TypeRef<>() {});

    assertThat(newsletter)
        .usingRecursiveComparison()
        .ignoringFields("time")
        .isEqualTo(new NewsletterSubscriptionDTO(true, "some text changed", Instant.now()));

    var subscriber = subscriberRepository.findByEmail(username).orElseThrow();
    assertThat(subscriber.getActions()).hasSize(1).contains(Actions.SYNC_USER_DATA_TO_EMARSYS);
    assertThat(subscriber.getLastUpdatedBy().getSubscriberId()).isEqualTo(subscriberId1);
  }

  @Test
  void shouldUpdateNewsletterSubscriptionForSubscriberById() {
    createSubscribers();
    final String requesterKeycloakId = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken(
            "test-client",
            requesterKeycloakId,
            List.of(COOPERATION_BASIC_ROLE),
            partnerId,
            username);
    NewsletterSubscriptionDTO newsletter =
        with()
            .given()
            .header("Authorization", jwt)
            .port(port)
            .basePath(BASE_PATH)
            .contentType(ContentType.JSON)
            .body("{\"isSubscribed\":false, \"text\":\"some text changed\"}")
            .when()
            .request("PUT", "/v1/subscribers/newsletter-subscription-status")
            .then()
            .statusCode(200)
            .and()
            .extract()
            .body()
            .as(new TypeRef<>() {});

    assertThat(newsletter)
        .usingRecursiveComparison()
        .ignoringFields("time")
        .isEqualTo(new NewsletterSubscriptionDTO(false, "some text changed", Instant.now()));
  }

  private void createSubscribers() {
    Subscriber subscriber =
        SubscriberTestConfig.createSubscriber(
            subscriberId1,
            partnerId,
            new HashSet<>(Collections.emptyList()),
            "TestUser1FirstName",
            "TestUser1LastName",
            username,
            new HashSet<>(List.of("1627cc31ea20d40a10388febc")),
            Status.ENABLED,
            Instant.now(),
            Instant.now(),
            Requester.ofEventType(EventType.NEPTUNE_USER_SET),
            new NewsletterSubscription(SUBSCRIBED, "some text", Instant.ofEpochSecond(1660809625)));
    Subscriber subscriber2 =
        SubscriberTestConfig.createSubscriber(
            subscriberId2,
            partnerId,
            new HashSet<>(Collections.emptyList()),
            "TestUser2FirstName",
            "TestUser2LastName",
            username2,
            new HashSet<>(List.of("1234")),
            Status.ENABLED,
            Instant.now(),
            Instant.now(),
            Requester.ofEventType(EventType.NEPTUNE_USER_SET),
            null);
    mongoTemplate.save(subscriber);
    mongoTemplate.save(subscriber2);
  }

  private NewsletterSubscriptionDTO getNewsletterForSubscriber1() {
    return new NewsletterSubscriptionDTO(true, "some text", Instant.ofEpochSecond(1660809625));
  }
}
