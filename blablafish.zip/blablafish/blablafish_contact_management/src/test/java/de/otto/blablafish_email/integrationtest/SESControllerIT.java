package de.otto.blablafish_email.integrationtest;

import static de.otto.blablafish_email.utils.Constants.CONTACT_MANAGEMENT_EMAIL_READ_ROLE;
import static io.restassured.RestAssured.with;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import de.otto.blablafish_contact_management.integrationtest.helpers.JwtHelper;
import de.otto.blablafish_contact_management.model.dto.ErrorResponse;
import de.otto.blablafish_email.listener.AbstractContainerIT;
import de.otto.blablafish_email.model.dto.ses.SESEventDTO;
import de.otto.blablafish_email.model.entity.SESEvent;
import de.otto.blablafish_email.testDataConfig.SESEventTestConfig;
import io.restassured.common.mapper.TypeRef;
import io.restassured.http.ContentType;
import java.time.Instant;
import java.util.List;
import java.util.UUID;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;

class SESControllerIT extends AbstractContainerIT {
  private final String partnerId = "partner1";
  private final String awsMessageId =
      "010701828275d011-ae50c64d-8ad5-4d65-bef1-38c4c86a120c-000000";

  @Test
  void shouldReturn403WhenRequiredRoleIsNotPresentForGetSesEventsByAWSMessageId() {
    var jwt =
        JwtHelper.createToken(
            "test-client", UUID.randomUUID().toString(), List.of("foobar"), partnerId);

    final var errorResponse =
        with()
            .given()
            .header("Authorization", jwt)
            .port(port)
            .basePath(BASE_PATH)
            .contentType(ContentType.JSON)
            .queryParam("aws_message_id", awsMessageId)
            .when()
            .request("GET", "/v1/mails-events")
            .then()
            .statusCode(HttpStatus.FORBIDDEN.value())
            .and()
            .extract()
            .body()
            .as(new TypeRef<ErrorResponse>() {});
    assertThat(errorResponse.getMessage()).isEqualTo("Access is denied");
  }

  @Test
  void shouldGetSesEventsByAWSMessageId() {
    createSesEvent();

    var jwt =
        JwtHelper.createToken(
            "test-client",
            UUID.randomUUID().toString(),
            List.of(CONTACT_MANAGEMENT_EMAIL_READ_ROLE),
            partnerId);

    final var sesEvents =
        with()
            .given()
            .header("Authorization", jwt)
            .port(port)
            .basePath(BASE_PATH)
            .contentType(ContentType.JSON)
            .queryParam("aws_message_id", awsMessageId)
            .when()
            .request("GET", "/v1/mails-events")
            .then()
            .statusCode(HttpStatus.OK.value())
            .and()
            .extract()
            .body()
            .as(new TypeRef<List<SESEventDTO>>() {});
    assertEquals(2, sesEvents.size());

    var expectedEvents =
        List.of(
            SESEventDTO.from(
                new SESEvent(
                    new ObjectId("62bec37d21d8c96a1dff3012"),
                    "Delivery",
                    awsMessageId,
                    SESEvent.encryptedBody(new Document()),
                    Instant.now(),
                    new ObjectId("62bec37d21d8c96a1dff30cb"))),
            SESEventDTO.from(
                new SESEvent(
                    new ObjectId("62bec37d21d8c96a1dff3013"),
                    "Open",
                    awsMessageId,
                    SESEvent.encryptedBody(new Document()),
                    Instant.now(),
                    new ObjectId("62bec37d21d8c96a1dff30cb"))));

    assertThat(sesEvents)
        .usingRecursiveComparison()
        .ignoringFieldsOfTypes(Instant.class)
        .isEqualTo(expectedEvents);
  }

  private void createSesEvent() {
    var sesEvents =
        List.of(
            SESEventTestConfig.createSesEvent(
                "62bec37d21d8c96a1dff3012",
                "Delivery",
                awsMessageId,
                new Document(),
                "62bec37d21d8c96a1dff30cb"),
            SESEventTestConfig.createSesEvent(
                "62bec37d21d8c96a1dff3013",
                "Open",
                awsMessageId,
                new Document(),
                "62bec37d21d8c96a1dff30cb"));
    mongoTemplate.insertAll(sesEvents);
  }
}
