package de.otto.blablafish_contact_management.respository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.mongodb.client.result.UpdateResult;
import de.otto.blablafish_contact_management.model.Actions;
import de.otto.blablafish_contact_management.model.Lock;
import de.otto.blablafish_contact_management.model.entity.ActionError;
import de.otto.blablafish_contact_management.model.entity.NewsletterSubscription;
import de.otto.blablafish_contact_management.model.entity.NewsletterSubscriptionStatus;
import de.otto.blablafish_contact_management.model.entity.Status;
import de.otto.blablafish_contact_management.model.entity.Subscriber;
import de.otto.blablafish_contact_management.model.entity.UserType;
import de.otto.blablafish_contact_management.testDataConfig.SubscriberTestConfig;
import de.otto.blablafish_email.listener.AbstractContainerIT;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.assertj.core.api.Assertions;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.OptimisticLockingFailureException;

public class SubscriberRepositoryIT extends AbstractContainerIT {

  @Autowired private SubscriberRepository subscriberRepository;

  @Test
  void shouldInsertSubscriber() {
    var subscriber = new SubscriberTestConfig().subscriberBuilder().build();
    subscriberRepository.upsert(subscriber);

    var expectedSubscriber = subscriberRepository.findById(subscriber.getUserId()).orElseThrow();

    assertThat(expectedSubscriber.getEffectiveRoleIds())
        .isEqualTo(subscriber.getEffectiveRoleIds());
    assertThat(expectedSubscriber.getUserId()).isEqualTo(subscriber.getUserId());
    assertThat(expectedSubscriber.getGroups()).isEqualTo(subscriber.getGroups());
    assertThat(expectedSubscriber.getCommunicationSubscription().isSubscribed()).isTrue();
  }

  @Test
  void shouldUpdateNewsletterSubscription() {
    Subscriber subscriber = new SubscriberTestConfig().subscriberBuilder().build();
    String subscriberId = subscriber.getUserId().toHexString();
    subscriberRepository.upsert(subscriber);
    Instant timestamp = Instant.parse("2022-09-12T07:17:00.077Z");
    NewsletterSubscription expectedSubscription =
        new NewsletterSubscription(NewsletterSubscriptionStatus.SUBSCRIBED, "new_text", timestamp);

    subscriberRepository.updateSubscriptionBySubscriberId(
        subscriberId,
        expectedSubscription,
        subscriber.getVersion(),
        List.of(Actions.SYNC_USER_DATA_TO_EMARSYS));

    Subscriber updatedSubscriber =
        subscriberRepository.findById(subscriber.getUserId()).orElseThrow();
    Assertions.assertThat(updatedSubscriber.getNewsletterSubscription())
        .usingRecursiveComparison()
        .isEqualTo(expectedSubscription);
  }

  @Test
  void shouldThrowOptimisticLockingFailureExceptionWhenNewsletterIsUpdatedForOlderSubscriber() {
    Subscriber subscriber = new SubscriberTestConfig().subscriberBuilder().build();
    long oldSubscriberVersion = subscriber.getVersion() - 1;
    String subscriberId = subscriber.getUserId().toHexString();
    subscriberRepository.upsert(subscriber);
    Instant timestamp = Instant.parse("2022-09-12T07:17:00.077Z");
    NewsletterSubscription expectedSubscription =
        new NewsletterSubscription(NewsletterSubscriptionStatus.SUBSCRIBED, "new_text", timestamp);

    assertThatThrownBy(
            () ->
                subscriberRepository.updateSubscriptionBySubscriberId(
                    subscriberId,
                    expectedSubscription,
                    oldSubscriberVersion,
                    List.of(Actions.SYNC_USER_DATA_TO_EMARSYS)))
        .isInstanceOf(OptimisticLockingFailureException.class)
        .hasMessage(
            "An error occurred while updating newsletter subscription for subscriber: 62bec37d21d8c96a1dff30cb");
  }

  @Test
  void shouldUpdateSubscriberActionError() {
    Subscriber subscriber = new SubscriberTestConfig().subscriberBuilder().build();
    String subscriberId = subscriber.getUserId().toHexString();
    subscriberRepository.upsert(subscriber);
    ActionError actionError =
        ActionError.builder()
            .errorName("name")
            .errorMessage("message")
            .attemptedAt(Instant.parse("2022-09-14T07:17:00.077Z"))
            .stackTrace("stacktrace")
            .errorCount(1)
            .build();

    subscriberRepository.updateSubscriberActionError(subscriberId, actionError);

    Subscriber updatedSubscriber =
        subscriberRepository.findById(subscriber.getUserId()).orElseThrow();
    Assertions.assertThat(updatedSubscriber.getActionError())
        .usingRecursiveComparison()
        .isEqualTo(actionError);
  }

  @Test
  void shouldAcquireLockWhenActionsExists() {
    Subscriber subscriber =
        new SubscriberTestConfig()
            .subscriberBuilder()
            .actions(new LinkedList<>(List.of(Actions.SYNC_USER_DATA_TO_EMARSYS)))
            .build();
    String subscriberId = subscriber.getUserId().toHexString();
    subscriberRepository.upsert(subscriber);

    Subscriber updatedSubscriber =
        subscriberRepository.acquireLockAndReturnSubscriberById(subscriberId, 60000).orElseThrow();

    Lock lock = updatedSubscriber.getLock();
    Assertions.assertThat(lock).isNotNull();
    assertThat(lock.getAcquiredBy()).isNotNull();
    assertThat(ChronoUnit.MILLIS.between(lock.getAcquiredAt(), lock.getExpiresAt()))
        .isEqualTo(60000);
  }

  @Test
  void shouldNotAcquireLockWhenActionsDoesNotExists() {
    Subscriber subscriberWithNoActions = new SubscriberTestConfig().subscriberBuilder().build();
    String subscriberId = subscriberWithNoActions.getUserId().toHexString();
    mongoTemplate.insert(subscriberWithNoActions);

    Optional<Subscriber> subscriberOptional =
        subscriberRepository.acquireLockAndReturnSubscriberById(subscriberId, 60000);

    Lock updatedLock =
        subscriberRepository.findById(subscriberWithNoActions.getUserId()).orElseThrow().getLock();
    assertThat(subscriberOptional).isEmpty();
    assertThat(updatedLock).isNull();
  }

  @Test
  void shouldReleaseLock() {
    Subscriber subscriber =
        new SubscriberTestConfig()
            .subscriberBuilder()
            .actions(new LinkedList<>(List.of(Actions.SYNC_USER_DATA_TO_EMARSYS)))
            .build();
    String subscriberId = subscriber.getUserId().toHexString();
    subscriberRepository.upsert(subscriber);
    Subscriber lockedSubscriber =
        subscriberRepository.acquireLockAndReturnSubscriberById(subscriberId, 60000).orElseThrow();

    UpdateResult updateResult =
        subscriberRepository.releaseLockBySubscriberId(subscriberId, lockedSubscriber.getLock());

    Subscriber updatedSubscriber =
        subscriberRepository.findById(subscriber.getUserId()).orElseThrow();

    assertThat(updateResult.getModifiedCount()).isEqualTo(1);
    assertThat(updatedSubscriber.getLock()).isNull();
  }

  @Test
  void shouldReleaseLockPopAction() {
    Subscriber subscriber =
        new SubscriberTestConfig()
            .subscriberBuilder()
            .actions(new LinkedList<>(List.of(Actions.SYNC_USER_DATA_TO_EMARSYS)))
            .build();
    String subscriberId = subscriber.getUserId().toHexString();
    subscriberRepository.upsert(subscriber);
    Subscriber lockedSubscriber =
        subscriberRepository.acquireLockAndReturnSubscriberById(subscriberId, 60000).orElseThrow();

    boolean result =
        subscriberRepository.releaseLockPopActionUpdateSubscriberAttributes(
            subscriberId, lockedSubscriber.getLock(), Map.of());
    Subscriber updatedSubscriber =
        subscriberRepository.findById(subscriber.getUserId()).orElseThrow();

    assertTrue(result);
    assertNull(updatedSubscriber.getLock());
    assertNull(updatedSubscriber.getActionError());
    assertThat(updatedSubscriber.getActions()).isEmpty();
  }

  @Test
  void shouldReleaseLockPopActionAndUpdateSubscriberAttributes() {
    Subscriber subscriber =
        new SubscriberTestConfig()
            .subscriberBuilder()
            .actions(new LinkedList<>(List.of(Actions.SYNC_USER_DATA_TO_EMARSYS)))
            .build();
    String subscriberId = subscriber.getUserId().toHexString();
    subscriberRepository.upsert(subscriber);
    Subscriber lockedSubscriber =
        subscriberRepository.acquireLockAndReturnSubscriberById(subscriberId, 60000).orElseThrow();
    Map<String, Object> subscriberAttributes = new HashMap<>();
    subscriberAttributes.put("status", "DISABLED");
    subscriberAttributes.put("topicIds", null);

    boolean result =
        subscriberRepository.releaseLockPopActionUpdateSubscriberAttributes(
            subscriberId, lockedSubscriber.getLock(), subscriberAttributes);
    Subscriber updatedSubscriber =
        subscriberRepository.findById(subscriber.getUserId()).orElseThrow();

    assertTrue(result);
    assertNull(updatedSubscriber.getLock());
    assertNull(updatedSubscriber.getActionError());
    assertThat(updatedSubscriber.getActions()).isEmpty();
    assertNull(updatedSubscriber.getTopicIds());
    assertEquals(Status.DISABLED, updatedSubscriber.getStatus());
  }

  @Test
  void
      shouldReturnAllSubscribersByPartnerWithStatusEnabledAndNotBlacklistedAndMandatoryRolesEmpty() {
    var serviceSubscriber =
        new SubscriberTestConfig()
            .subscriberBuilder()
            .userType(UserType.SERVICE_PROVIDER)
            .userId(new ObjectId())
            .email(Subscriber.encryptEmail("user1@otto.de"))
            .build();
    subscriberRepository.upsert(serviceSubscriber);
    var cooperationSubscriber =
        new SubscriberTestConfig()
            .subscriberBuilder()
            .userType(UserType.COOPERATION)
            .userId(new ObjectId())
            .email(Subscriber.encryptEmail("user2@otto.de"))
            .build();
    subscriberRepository.upsert(cooperationSubscriber);

    var subscribersResult =
        subscriberRepository.findAllUsersByPartnerWithStatusEnabledAndNotBlacklisted(
            "1008941", Collections.emptyList());

    assertThat(subscribersResult).hasSize(2);
    assertThat(subscribersResult.get(0).getUserId()).isEqualTo(serviceSubscriber.getUserId());
    assertThat(subscribersResult.get(1).getUserId()).isEqualTo(cooperationSubscriber.getUserId());
  }

  @Test
  public void shouldFindAllUsersByStatusEnabledAndNotBlacklisted() {
    var subscriber =
        new SubscriberTestConfig()
            .subscriberBuilder()
            .status(Status.ENABLED)
            .isUserBlacklisted(false)
            .email(Subscriber.encryptEmail("user-1@otto.de"))
            .build();
    mongoTemplate.insert(subscriber);

    var subscribersResult =
        subscriberRepository
            .findUserByStatusEnabledAndNotBlacklisted(
                "1008941", Collections.emptyList(), "user-1@otto.de")
            .orElseThrow();

    assertThat(subscribersResult.getUserId()).isEqualTo(subscriber.getUserId());
    assertThat(subscribersResult.getUserId()).isEqualTo(subscriber.getUserId());
  }
}
