package de.otto.newsletter.repository;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

import de.otto.newsletter.model.entity.RSAKeyPair;
import org.junit.jupiter.api.Test;
import org.springframework.data.mongodb.core.MongoTemplate;

class RSAKeyPairRepositoryTest {

  @Test
  void shouldInsert() {
    MongoTemplate mongoTemplate = mock(MongoTemplate.class);
    RSAKeyPairRepository rsaKeyPairRepository = new RSAKeyPairRepository(mongoTemplate);
    RSAKeyPair rsaKeyPair = RSAKeyPair.asSigningKey("key", "privateKey");

    rsaKeyPairRepository.insert(rsaKeyPair);

    verify(mongoTemplate).insert(rsaKeyPair);
  }
}
