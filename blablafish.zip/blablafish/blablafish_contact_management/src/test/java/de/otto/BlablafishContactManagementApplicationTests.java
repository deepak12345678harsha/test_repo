package de.otto;

import de.otto.blablafish_contact_management.encryption.EncryptionHelper;
import de.otto.blablafish_contact_management.integrationtest.config.LocalTogglesConfig;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;

@Import({LocalTogglesConfig.class})
@SpringBootTest(properties = "spring.data.mongodb.auto-index-creation: false")
class BlablafishContactManagementApplicationTests {

  @MockBean private EncryptionHelper encryptionHelper;

  @Test
  void contextLoads() {}
}
