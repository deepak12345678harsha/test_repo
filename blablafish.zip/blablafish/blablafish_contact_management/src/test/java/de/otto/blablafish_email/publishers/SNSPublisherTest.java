package de.otto.blablafish_email.publishers;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.model.PublishRequest;
import com.amazonaws.services.sns.model.PublishResult;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import de.otto.blablafish_contact_management.model.dto.DeepSeaEvent;
import de.otto.blablafish_contact_management.model.dto.EventType;
import java.util.HashMap;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class SNSPublisherTest {

  private SNSPublisher snsPublisher;

  @Mock ObjectMapper objectMapper;

  @Mock AmazonSNS amazonSNS;

  @BeforeEach
  public void setEmailService() {
    snsPublisher = new SNSPublisher(amazonSNS, "topic-Arn", objectMapper);
  }

  @Test
  void shouldPublishTopicToSns() throws JsonProcessingException {

    when(objectMapper.convertValue(any(), any(TypeReference.class))).thenReturn(getDataToPublish());
    when(objectMapper.writeValueAsString(any(DeepSeaEvent.class))).thenReturn("data to publish");
    when(amazonSNS.publish(any(PublishRequest.class))).thenReturn(new PublishResult());

    snsPublisher.publish("data to publish", EventType.EMAIL_REQUEST_SUCCESS);

    verify(objectMapper).convertValue(any(), any(TypeReference.class));
    verify(objectMapper).writeValueAsString(any(DeepSeaEvent.class));
    verify(amazonSNS).publish(any(PublishRequest.class));
  }

  @Test
  void shouldHandleJsonProcessingExceptionDuringPublish() throws JsonProcessingException {
    when(objectMapper.convertValue(any(), any(TypeReference.class))).thenReturn(getDataToPublish());
    doThrow(new JsonProcessingException("") {})
        .when(objectMapper)
        .writeValueAsString(any(DeepSeaEvent.class));

    assertThrows(
        RuntimeException.class,
        () -> snsPublisher.publish("data to publish", EventType.EMAIL_REQUEST_SUCCESS));
    verify(amazonSNS, never()).publish(any(PublishRequest.class));
  }

  private Map<String, Object> getDataToPublish() {
    Map<String, Object> dataMap = new HashMap<>();
    dataMap.put("key 1", "value 1");
    return dataMap;
  }
}
