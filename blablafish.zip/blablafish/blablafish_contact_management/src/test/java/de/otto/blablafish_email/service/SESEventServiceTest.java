package de.otto.blablafish_email.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import de.otto.blablafish_email.model.dto.ses.SESEventDTO;
import de.otto.blablafish_email.model.dto.ses.SESEventType;
import de.otto.blablafish_email.model.entity.SESEvent;
import de.otto.blablafish_email.respository.SESEventRepository;
import java.util.List;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class SESEventServiceTest {

  private SESEventService service;

  @Mock private SESEventRepository repository;

  @BeforeEach
  public void setService() {
    service = new SESEventService(repository);
  }

  @Test
  void shouldGetSesEventsByAWSMessageID() {
    var awsMessageId = "010701828275d011-ae50c64d-8ad5-4d65-bef1-38c4c86a120c-000000";
    var emailRequestId = new ObjectId("62bec37d21d8c96a1dff30cb");
    var sesEvent = SESEvent.of(SESEventType.BOUNCE, awsMessageId, emailRequestId, new Document());

    when(repository.findByAWSMessageId(awsMessageId)).thenReturn(List.of(sesEvent));

    var sesEvents = service.getByAWSMessageId(awsMessageId);

    assertThat(sesEvents).usingRecursiveComparison().isEqualTo(List.of(SESEventDTO.from(sesEvent)));
    verify(repository).findByAWSMessageId(awsMessageId);
  }
}
