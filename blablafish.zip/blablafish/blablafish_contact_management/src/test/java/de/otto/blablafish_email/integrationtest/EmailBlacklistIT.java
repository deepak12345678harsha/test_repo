package de.otto.blablafish_email.integrationtest;

import static de.otto.blablafish_contact_management.model.Actions.SEND_UNBLACKLIST_EVENT_TO_NEPTUNE;
import static de.otto.blablafish_email.model.entity.EmailBlacklist.FIELD_EMAIL_ADDRESS;
import static de.otto.blablafish_email.utils.Constants.CONTACT_MANAGEMENT_EMAIL_BLACKLIST_READ_ROLE;
import static de.otto.blablafish_email.utils.Constants.CONTACT_MANAGEMENT_EMAIL_SUPPORT_WRITE_ROLE;
import static io.restassured.RestAssured.with;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.data.mongodb.core.query.Criteria.where;

import de.otto.blablafish_contact_management.integrationtest.helpers.JwtHelper;
import de.otto.blablafish_contact_management.model.dto.ErrorResponse;
import de.otto.blablafish_contact_management.model.dto.EventType;
import de.otto.blablafish_contact_management.model.entity.Requester;
import de.otto.blablafish_contact_management.model.entity.Status;
import de.otto.blablafish_contact_management.model.entity.Subscriber;
import de.otto.blablafish_contact_management.respository.SubscriberRepository;
import de.otto.blablafish_contact_management.rest.ResponseCollection;
import de.otto.blablafish_contact_management.testDataConfig.SubscriberTestConfig;
import de.otto.blablafish_email.listener.AbstractContainerIT;
import de.otto.blablafish_email.model.dto.blacklist.EmailBlacklistDTO;
import de.otto.blablafish_email.model.dto.blacklist.EmailBlacklistResponse;
import de.otto.blablafish_email.model.entity.EmailBlacklist;
import de.otto.blablafish_email.testDataConfig.EmailBlacklistsTestConfig;
import io.restassured.common.mapper.TypeRef;
import io.restassured.http.ContentType;
import java.time.Instant;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.assertj.core.api.Assertions;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.HttpStatus;

class EmailBlacklistIT extends AbstractContainerIT {

  private final String partnerId = "partner1";
  private final ObjectId subscriberId = new ObjectId("62bec37d21d8c96a1dff30cb");
  @Autowired private SubscriberRepository subscriberRepository;

  @Test
  void shouldThrow403WhenRequiredRoleIsNotPresent() {
    final String requesterKeycloakId = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken("test-client", requesterKeycloakId, List.of("foobar"), partnerId);

    final ErrorResponse errorResponse =
        with()
            .given()
            .header("Authorization", jwt)
            .port(port)
            .basePath(BASE_PATH)
            .queryParam("emailAddress", "email@otto.com")
            .contentType(ContentType.JSON)
            .when()
            .request("GET", "/v1/mail-blacklists")
            .then()
            .statusCode(HttpStatus.FORBIDDEN.value())
            .and()
            .extract()
            .body()
            .as(new TypeRef<>() {});
    Assertions.assertThat(errorResponse.getMessage()).isEqualTo("Access is denied");
  }

  @Test
  void shouldGetEmailBlacklistByEmailAddress() {
    createBlacklist();

    final String requesterKeycloakId = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken(
            "test-client",
            requesterKeycloakId,
            List.of(CONTACT_MANAGEMENT_EMAIL_BLACKLIST_READ_ROLE),
            partnerId);

    String emailAddress = "email@otto.com";
    final ResponseCollection<EmailBlacklistDTO> savedBlacklists =
        with()
            .given()
            .header("Authorization", jwt)
            .port(port)
            .basePath(BASE_PATH)
            .queryParam("emailAddress", "email@otto.com")
            .contentType(ContentType.JSON)
            .when()
            .request("GET", "/v1/mail-blacklists")
            .then()
            .statusCode(HttpStatus.OK.value())
            .and()
            .extract()
            .body()
            .as(new TypeRef<>() {});
    assertEquals(1, savedBlacklists.getCount());

    EmailBlacklistDTO expectedBlacklist =
        new EmailBlacklistDTO("62bec37d21d8c96a1dff30cb", emailAddress, Collections.emptyList());
    ResponseCollection<EmailBlacklistDTO> expectedBlacklists =
        new ResponseCollection<>(List.of(expectedBlacklist));
    Assertions.assertThat(savedBlacklists).usingRecursiveComparison().isEqualTo(expectedBlacklists);
  }

  @Test
  void shouldReturnBadRequestWhenRequestParameterIsMissing() {
    final String requesterKeycloakId = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken(
            "test-client",
            requesterKeycloakId,
            List.of(CONTACT_MANAGEMENT_EMAIL_BLACKLIST_READ_ROLE),
            partnerId);

    final ErrorResponse errorResponse =
        with()
            .given()
            .header("Authorization", jwt)
            .port(port)
            .basePath(BASE_PATH)
            .contentType(ContentType.JSON)
            .when()
            .request("GET", "/v1/mail-blacklists")
            .then()
            .statusCode(HttpStatus.BAD_REQUEST.value())
            .and()
            .extract()
            .body()
            .as(new TypeRef<>() {});
    Assertions.assertThat(errorResponse.getMessage())
        .isEqualTo(
            "Required request parameter 'emailAddress' for method parameter type String is not present");
  }

  @Test
  void shouldGetEmailBlacklistById() {
    EmailBlacklist savedEmailBlacklist = createBlacklist();

    final String requesterKeycloakId = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken(
            "test-client",
            requesterKeycloakId,
            List.of(CONTACT_MANAGEMENT_EMAIL_BLACKLIST_READ_ROLE),
            partnerId);

    String emailAddress = "email@otto.com";
    final EmailBlacklistDTO savedBlacklist =
        with()
            .given()
            .header("Authorization", jwt)
            .port(port)
            .basePath(BASE_PATH)
            .contentType(ContentType.JSON)
            .when()
            .request("GET", "/v1/mail-blacklists/" + savedEmailBlacklist.getId())
            .then()
            .statusCode(HttpStatus.OK.value())
            .and()
            .extract()
            .body()
            .as(new TypeRef<>() {});

    EmailBlacklistDTO expectedBlacklist =
        new EmailBlacklistDTO("62bec37d21d8c96a1dff30cb", emailAddress, Collections.emptyList());
    Assertions.assertThat(savedBlacklist).usingRecursiveComparison().isEqualTo(expectedBlacklist);
  }

  @Test
  void shouldReturn404GetEmailBlacklistById() {
    String invalidId = "62bec37d21d8c96a1dff30cb";
    final String requesterKeycloakId = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken(
            "test-client",
            requesterKeycloakId,
            List.of(CONTACT_MANAGEMENT_EMAIL_BLACKLIST_READ_ROLE),
            partnerId);

    final ErrorResponse errorResponse =
        with()
            .given()
            .header("Authorization", jwt)
            .port(port)
            .basePath(BASE_PATH)
            .contentType(ContentType.JSON)
            .when()
            .request("GET", "/v1/mail-blacklists/" + invalidId)
            .then()
            .statusCode(HttpStatus.NOT_FOUND.value())
            .and()
            .extract()
            .body()
            .as(new TypeRef<>() {});
    Assertions.assertThat(errorResponse.getMessage())
        .isEqualTo(
            "Email blacklist with  mailBlacklistsId : 62bec37d21d8c96a1dff30cb does not exists");
  }

  @Test
  void shouldReturnBlacklistedEmailsWithSubscriberDetails() {
    createBlacklist();
    createSubscriber();

    final String requesterKeycloakId = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken(
            "test-client",
            requesterKeycloakId,
            List.of(CONTACT_MANAGEMENT_EMAIL_SUPPORT_WRITE_ROLE),
            partnerId);

    final var jsonResponse =
        with()
            .given()
            .header("Authorization", jwt)
            .port(port)
            .basePath(BASE_PATH)
            .queryParam("search", "email@otto.com")
            .contentType(ContentType.JSON)
            .when()
            .request("GET", "/v1/blacklisted-mails")
            .then()
            .statusCode(HttpStatus.OK.value())
            .and()
            .extract()
            .body()
            .jsonPath();
    var emailsSupportResponse = jsonResponse.getList("content", EmailBlacklistResponse.class);
    assertThat(emailsSupportResponse).hasSize(1);
    assertThat(jsonResponse.getInt("totalElements")).isEqualTo(1);
    assertThat(jsonResponse.getInt("totalPages")).isEqualTo(1);
  }

  @Test
  void shouldDeleteBlacklistedEmailAndUpdateSubscriber() {
    createBlacklist();
    createSubscriber();

    final String requesterKeycloakId = UUID.randomUUID().toString();
    var jwt =
        JwtHelper.createToken(
            "test-client",
            requesterKeycloakId,
            List.of(CONTACT_MANAGEMENT_EMAIL_SUPPORT_WRITE_ROLE),
            partnerId,
            "email@otto.com");

    var email = "email@otto.com";
    var body = """
        ["email@otto.com"]
        """;

    with()
        .given()
        .header("Authorization", jwt)
        .header("user-agent", "agent-value")
        .port(port)
        .basePath(BASE_PATH)
        .body(body)
        .contentType(ContentType.JSON)
        .when()
        .request("PUT", "/v1/blacklisted-mails")
        .then()
        .statusCode(HttpStatus.OK.value());

    var query =
        Query.query(Criteria.where(FIELD_EMAIL_ADDRESS).is(EmailBlacklist.encryptEmail(email)));
    var emailBlacklist = Optional.ofNullable(mongoTemplate.findOne(query, EmailBlacklist.class));
    assertThat(emailBlacklist).isEmpty();

    query = Query.query(where("email").is(Subscriber.encryptEmail(email)));
    var subscriber = Optional.ofNullable(mongoTemplate.findOne(query, Subscriber.class));
    assertThat(subscriber).isPresent();
    assertThat(subscriber.get().getIsUserBlacklisted()).isFalse();
    assertThat(subscriber.get().getActions()).contains(SEND_UNBLACKLIST_EVENT_TO_NEPTUNE);
    assertThat(subscriber.get().getLastUpdatedBy().getSubscriberId()).isEqualTo(subscriberId);
  }

  private void createSubscriber() {
    Subscriber user1 =
        SubscriberTestConfig.createSubscriber(
            subscriberId,
            partnerId,
            new HashSet<>(Arrays.asList(1, 2)),
            "TestUser1FirstName",
            "TestUser1LastName",
            "email@otto.com",
            new HashSet<>(List.of("1627cc31ea20d40a10388febc")),
            Status.ENABLED,
            Instant.now(),
            Instant.now(),
            Requester.ofEventType(EventType.NEPTUNE_USER_SET),
            true,
            null);
    subscriberRepository.upsert(user1);
  }

  private EmailBlacklist createBlacklist() {
    EmailBlacklist blacklist =
        EmailBlacklistsTestConfig.createEmailBlacklist(
            "62bec37d21d8c96a1dff30cb", "email@otto.com", Collections.emptyList());
    return mongoTemplate.save(blacklist);
  }
}
