package de.otto.blablafish_contact_management.integrationtest.config;

import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.wireMockConfig;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.WireMock;
import org.junit.jupiter.api.extension.AfterAllCallback;
import org.junit.jupiter.api.extension.AfterEachCallback;
import org.junit.jupiter.api.extension.BeforeAllCallback;
import org.junit.jupiter.api.extension.ExtensionContext;

public class WireMockExtension implements BeforeAllCallback, AfterAllCallback, AfterEachCallback {

  private WireMockServer server;

  @Override
  public void beforeAll(ExtensionContext context) {
    server = new WireMockServer(wireMockConfig().port(8443));
    server.start();
    WireMock.configureFor("localhost", server.port());
  }

  @Override
  public void afterEach(ExtensionContext context) {
    server.resetAll();
  }

  @Override
  public void afterAll(ExtensionContext context) {
    server.stop();
  }
}
