package de.otto.blablafish_email.testDataConfig;

import de.otto.blablafish_email.model.entity.EmailBlackListReason;
import de.otto.blablafish_email.model.entity.EmailBlacklist;
import java.util.List;
import org.bson.types.ObjectId;

public class EmailBlacklistsTestConfig {
  public static EmailBlacklist createEmailBlacklist(
      String blacklistId, String emailAddress, List<EmailBlackListReason> reasons) {
    return new EmailBlacklist(
        new ObjectId(blacklistId), EmailBlacklist.encryptEmail(emailAddress), reasons);
  }
}
