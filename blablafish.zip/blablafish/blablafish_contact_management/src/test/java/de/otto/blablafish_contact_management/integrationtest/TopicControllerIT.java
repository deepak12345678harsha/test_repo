package de.otto.blablafish_contact_management.integrationtest;

import static de.otto.blablafish_contact_management.utils.Constants.CONTACT_MANAGEMENT_TOPIC_READ_ROLE;
import static io.restassured.RestAssured.with;
import static org.junit.jupiter.api.Assertions.assertEquals;

import de.otto.blablafish_contact_management.integrationtest.helpers.JwtHelper;
import de.otto.blablafish_contact_management.model.dto.ErrorResponse;
import de.otto.blablafish_contact_management.model.dto.EventType;
import de.otto.blablafish_contact_management.model.dto.SubscriberDTO;
import de.otto.blablafish_contact_management.model.dto.TopicDTO;
import de.otto.blablafish_contact_management.model.entity.*;
import de.otto.blablafish_contact_management.respository.SubscriberRepository;
import de.otto.blablafish_contact_management.respository.TopicRepository;
import de.otto.blablafish_contact_management.rest.ResponseCollection;
import de.otto.blablafish_contact_management.testDataConfig.SubscriberTestConfig;
import de.otto.blablafish_email.listener.AbstractContainerIT;
import io.restassured.common.mapper.TypeRef;
import java.time.Instant;
import java.util.*;
import org.assertj.core.api.Assertions;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

class TopicControllerIT extends AbstractContainerIT {

  private final int topic1Id = 1;
  private final int topic2Id = 2;
  private final ObjectId id1 = new ObjectId();
  private final ObjectId id2 = new ObjectId();
  private final String partnerId = "partner1";
  private Topic topic1;
  private Topic topic2;
  @Autowired private SubscriberRepository subscriberRepository;

  @Autowired private TopicRepository topicRepository;

  @Test
  void shouldReturn403WhenRequiredRoleIsNotPresentForGetTopics() {
    final String requesterKeycloakId = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken("test-client", requesterKeycloakId, List.of("foobar"), partnerId);

    final ErrorResponse errorResponse =
        with()
            .given()
            .header("Authorization", jwt)
            .port(port)
            .basePath(BASE_PATH)
            .when()
            .request("GET", "/v1/topics")
            .then()
            .statusCode(HttpStatus.FORBIDDEN.value())
            .and()
            .extract()
            .body()
            .as(new TypeRef<>() {});
    Assertions.assertThat(errorResponse.getMessage()).isEqualTo("Access is denied");
  }

  @Test
  void shouldReturnAllTopicsWithSubscribers() {
    insertTopics();
    insertSubscribers();

    ResponseCollection<TopicDTO> expectedSubscribers = new ResponseCollection<>(getTopicDTOs());
    final String requesterKeycloakId = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken(
            "test-client",
            requesterKeycloakId,
            List.of(CONTACT_MANAGEMENT_TOPIC_READ_ROLE),
            partnerId);

    ResponseCollection<TopicDTO> actualTopicsWithSubscribers =
        with()
            .given()
            .header("Authorization", jwt)
            .port(port)
            .basePath(BASE_PATH)
            .when()
            .request("GET", "/v1/topics")
            .then()
            .statusCode(200)
            .and()
            .extract()
            .body()
            .as(new TypeRef<>() {});

    assertEquals(2, actualTopicsWithSubscribers.getCount());
    Assertions.assertThat(actualTopicsWithSubscribers)
        .usingRecursiveComparison()
        .isEqualTo(expectedSubscribers);
    assertEquals(2, actualTopicsWithSubscribers.getItems().get(0).getSubscribers().size());
    assertEquals(
        "TestUser1FirstName",
        actualTopicsWithSubscribers.getItems().get(0).getSubscribers().get(0).getFirstName());
  }

  private void insertTopics() {
    topic1 =
        Topic.builder()
            .id(topic1Id)
            .name("topic1")
            .description("description1")
            .mandatorySubscriberRoles(Collections.emptyList())
            .emailSubject("")
            .emailPlainTextTemplate("")
            .emailHtmlTemplate("")
            .emailSchema(new Document())
            .options(
                TopicOptions.builder()
                    .archiving(true)
                    .canUnsubscribe(false)
                    .isSubscribedByDefault(true)
                    .displayOnEmailConfigUI(false)
                    .displayOnContactManagementUI(true)
                    .build())
            .build();
    topic2 =
        Topic.builder()
            .id(topic2Id)
            .name("topic2")
            .description("description2")
            .mandatorySubscriberRoles(Collections.emptyList())
            .emailSubject("")
            .emailPlainTextTemplate("")
            .emailHtmlTemplate("")
            .emailSchema(new Document())
            .options(
                TopicOptions.builder()
                    .archiving(true)
                    .canUnsubscribe(false)
                    .isSubscribedByDefault(true)
                    .displayOnEmailConfigUI(false)
                    .displayOnContactManagementUI(true)
                    .build())
            .build();

    topicRepository.save(topic1);
    topicRepository.save(topic2);
  }

  private void insertSubscribers() {
    Subscriber user1 =
        SubscriberTestConfig.createSubscriber(
            id1,
            partnerId,
            new HashSet<>(Arrays.asList(topic1Id, topic2Id)),
            "TestUser1FirstName",
            "TestUser1LastName",
            "testuser1mail@otto.de",
            new HashSet<>(List.of("1627cc31ea20d40a10388febc")),
            Status.ENABLED,
            Instant.now(),
            Instant.now(),
            Requester.ofEventType(EventType.NEPTUNE_USER_SET),
            null);
    Subscriber user2 =
        SubscriberTestConfig.createSubscriber(
            id2,
            partnerId,
            new HashSet<>(List.of(topic1Id)),
            "TestUser2FirstName",
            "TestUser2LastName",
            "testuser2mail@otto.de",
            new HashSet<>(List.of("1234")),
            Status.ENABLED,
            Instant.now(),
            Instant.now(),
            Requester.ofEventType(EventType.NEPTUNE_USER_SET),
            null);
    subscriberRepository.upsert(user1);
    subscriberRepository.upsert(user2);
  }

  private List<TopicDTO> getTopicDTOs() {
    SubscriberDTO subscriberDTO1 =
        SubscriberDTO.builder()
            .id(id1.toString())
            .email("testuser1mail@otto.de")
            .firstName("TestUser1FirstName")
            .lastName("TestUser1LastName")
            .build();
    SubscriberDTO subscriberDTO2 =
        SubscriberDTO.builder()
            .id(id2.toString())
            .email("testuser2mail@otto.de")
            .firstName("TestUser2FirstName")
            .lastName("TestUser2LastName")
            .build();
    TopicDTO topic1 =
        new TopicDTO("1", "topic1", "description1", List.of(subscriberDTO1, subscriberDTO2));
    TopicDTO topic2 =
        new TopicDTO("2", "topic2", "description2", Collections.singletonList(subscriberDTO1));
    return Arrays.asList(topic1, topic2);
  }
}
