package de.otto.blablafish_contact_management.service;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.*;

import de.otto.BlablafishContactManagementApplication;
import de.otto.blablafish_contact_management.encryption.EncryptionHelper;
import de.otto.blablafish_contact_management.integrationtest.config.LocalTogglesConfig;
import de.otto.blablafish_contact_management.model.Actions;
import de.otto.blablafish_contact_management.model.entity.NewsletterSubscription;
import de.otto.blablafish_contact_management.model.entity.NewsletterSubscriptionStatus;
import de.otto.blablafish_contact_management.model.entity.Subscriber;
import de.otto.blablafish_contact_management.respository.SubscriberChangeEntryRepository;
import de.otto.blablafish_contact_management.respository.SubscriberRepository;
import de.otto.blablafish_contact_management.testDataConfig.SubscriberTestConfig;
import de.otto.blablafish_email.respository.EmailBlacklistRepository;
import java.time.Instant;
import java.util.List;
import java.util.Optional;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.dao.OptimisticLockingFailureException;

@Import({LocalTogglesConfig.class})
@SpringBootTest(
    classes = BlablafishContactManagementApplication.class,
    properties = "spring.data.mongodb.auto-index-creation: false")
public class SubscriberServiceIT {

  @MockBean private SubscriberRepository subscriberRepository;

  @MockBean private TopicService topicService;

  @MockBean private EmailBlacklistRepository emailBlacklistRepository;

  @MockBean private SubscriberChangeEntryRepository subscriberChangeEntryRepository;

  @MockBean private EncryptionHelper encryptionHelper;

  @Autowired private SubscriberService subscriberService;

  @Test
  void shouldRetrySaveWhenOptimisticLockingFailureExceptionIsThrown() {
    String subscriberId = "62bec37d21d8c96a1dff30cb";
    Instant subscriptionTimeStamp = Instant.parse("2018-09-12T07:17:00.077Z");
    Subscriber subscriber =
        new SubscriberTestConfig().subscriberBuilder().newsletterSubscription(null).build();
    when(subscriberRepository.findById(new ObjectId(subscriberId)))
        .thenReturn(Optional.of(subscriber));
    doThrow(OptimisticLockingFailureException.class)
        .when(subscriberRepository)
        .updateSubscriptionBySubscriberId(
            eq(subscriberId),
            any(NewsletterSubscription.class),
            any(),
            eq(List.of(Actions.SYNC_USER_DATA_TO_EMARSYS)));
    NewsletterSubscription newStatus =
        new NewsletterSubscription(
            NewsletterSubscriptionStatus.SUBSCRIBED, "new_text", subscriptionTimeStamp);

    assertThatThrownBy(
            () ->
                subscriberService.updateNewsletterSubscriptionStatus(
                    subscriberId, newStatus, Instant.now()))
        .isInstanceOf(OptimisticLockingFailureException.class);
    verify(subscriberRepository, times(3))
        .updateSubscriptionBySubscriberId(
            any(), any(), any(), eq(List.of(Actions.SYNC_USER_DATA_TO_EMARSYS)));
  }
}
