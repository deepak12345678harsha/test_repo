package de.otto.blablafish_email.service;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.PutObjectResult;
import com.amazonaws.services.s3.model.S3Object;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import de.otto.blablafish_contact_management.model.dto.UserPrincipal;
import de.otto.blablafish_contact_management.model.encryption.EncryptedField;
import de.otto.blablafish_email.exception.FileUploadException;
import de.otto.blablafish_email.model.dto.EmailAttachmentDTO;
import de.otto.blablafish_email.model.entity.EmailAttachment;
import de.otto.blablafish_email.respository.EmailAttachmentRepository;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Instant;
import java.util.Collections;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

@ExtendWith(MockitoExtension.class)
class EmailAttachmentServiceTest {

  private EmailAttachmentService emailAttachmentService;

  @Mock private AmazonS3 amazonS3;

  @Mock private EmailAttachmentRepository emailAttachmentRepository;

  @BeforeEach
  public void setEmailService() {
    emailAttachmentService =
        new EmailAttachmentService(
            amazonS3, "develop-email-file-uploads", emailAttachmentRepository, new ObjectMapper());
  }

  @Test
  void shouldUploadFileAndSaveEmailAttachment() throws IOException, FileUploadException {
    var inputStream = new FileInputStream("src/test/resources/uploadForEmail.txt");
    var fileToUpload =
        new MockMultipartFile(
            "uploadForEmail.txt",
            "uploadForEmail.txt",
            MediaType.APPLICATION_OCTET_STREAM_VALUE,
            inputStream);
    var userPrincipal =
        new UserPrincipal("subject", "clientId", "partnerId", Collections.emptySet(), "userName");
    when(emailAttachmentRepository.insertOne(any(EmailAttachment.class)))
        .thenReturn(mock(EmailAttachment.class));

    emailAttachmentService.upload(
        fileToUpload, userPrincipal.getClientId(), userPrincipal.getSubject());

    verify(emailAttachmentRepository).insertOne(any(EmailAttachment.class));
  }

  @Test
  void shouldThrowFileUploadExceptionWhenErrorWithUploadFile() throws IOException {
    UserPrincipal userPrincipal = mock(UserPrincipal.class);
    MultipartFile file = mock(MultipartFile.class);

    when(file.getInputStream()).thenThrow(new IOException());

    assertThrows(
        FileUploadException.class,
        () ->
            emailAttachmentService.upload(
                file, userPrincipal.getClientId(), userPrincipal.getSubject()));
  }

  @Test
  void shouldGetAttachmentDetails() throws FileNotFoundException {

    S3Object s3Object = new S3Object();
    s3Object.setObjectContent(new FileInputStream("src/test/resources/uploadForEmail.txt"));
    EmailAttachment attachment = mock(EmailAttachment.class);
    EncryptedField<String> encryptedField = mock(EncryptedField.class);
    when(attachment.getFileName()).thenReturn(encryptedField);
    when(attachment.getS3BucketName()).thenReturn("develop-email-file-uploads");
    when(attachment.getS3UploadKey()).thenReturn("2022-02-25/01-30-02.0112-test-upload");
    when(encryptedField.getValue()).thenReturn("uploadForEmail.txt");
    when(emailAttachmentRepository.fetchOne(anyString())).thenReturn(attachment);
    when(amazonS3.getObject(anyString(), anyString())).thenReturn(s3Object);

    emailAttachmentService.getAttachment("1234");

    verify(emailAttachmentRepository).fetchOne("1234");
    verify(amazonS3)
        .getObject("develop-email-file-uploads", "2022-02-25/01-30-02.0112-test-upload");
  }

  @Test
  void shouldSyncAttachment()
      throws FileNotFoundException, JsonProcessingException, FileUploadException {
    var emailAttachmentDTO = buildEmailAttachmentDTO();
    when(emailAttachmentRepository.attachmentExists(emailAttachmentDTO.getAttachmentId()))
        .thenReturn(false);
    S3Object s3Object = new S3Object();
    s3Object.setObjectContent(new FileInputStream("src/test/resources/uploadForEmail.txt"));
    when(amazonS3.getObject(anyString(), anyString())).thenReturn(s3Object);
    when(amazonS3.putObject(any(PutObjectRequest.class))).thenReturn(new PutObjectResult());
    when(emailAttachmentRepository.insertOne(any(EmailAttachment.class)))
        .thenReturn(mock(EmailAttachment.class));

    emailAttachmentService.syncAttachment(emailAttachmentDTO);

    verify(amazonS3).putObject(any(PutObjectRequest.class));
    verify(emailAttachmentRepository).insertOne(any(EmailAttachment.class));
  }

  private EmailAttachmentDTO buildEmailAttachmentDTO() {
    return EmailAttachmentDTO.builder()
        .attachmentId("6364b304fb4bd2660420a34d")
        .s3BucketName("attachments20211018125151464200000001")
        .s3UploadKey("2022-07-04/06-36-52.2768-neptune-email-test-client")
        .fileName("test_12345.csv")
        .contentType("application/octet-stream")
        .fileSizeInBytes(705L)
        .clientId("neptune-email-test-client")
        .subject("b624ce5a-9367-4045-a2de-acadea7d21f0")
        .createdAt(Instant.now())
        .build();
  }

  @Test
  void shouldNotSyncAttachmentIfAlreadyExistsWithSameId()
      throws JsonProcessingException, FileUploadException {
    var emailAttachmentDTO = buildEmailAttachmentDTO();
    when(emailAttachmentRepository.attachmentExists(emailAttachmentDTO.getAttachmentId()))
        .thenReturn(true);

    emailAttachmentService.syncAttachment(emailAttachmentDTO);

    verify(amazonS3, never()).getObject(anyString(), anyString());
    verify(amazonS3, never()).putObject(any(PutObjectRequest.class));
    verify(emailAttachmentRepository, never()).insertOne(any(EmailAttachment.class));
  }
}
