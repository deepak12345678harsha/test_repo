package de.otto.blablafish_email.testDataConfig;

import de.otto.blablafish_email.model.entity.Email;
import de.otto.blablafish_email.model.entity.EmailStatus;
import de.otto.blablafish_email.model.entity.EmailStatusHistoryEntry;
import java.time.Instant;
import java.util.List;
import org.bson.types.ObjectId;

public class EmailTestConfig {
  private String emailId = "62bec37d21d8c96a1dff30cb";
  private String fromAddress = "no-reply@nonlive.partner-info.otto.market";
  private String toAddress = "blablafish@otto.de";
  private String htmlBody;
  private String textBody;
  private String subject = "subject";
  private String mailRequestId = "62bec37d21d8c96a1dff30cb";
  private Instant sendDate = Instant.ofEpochSecond(1660809625);
  private Instant createdAt = Instant.ofEpochSecond(1660809620);
  private EmailStatus status = EmailStatus.AWS_DELIVERY;
  private Instant statusTimestamp = Instant.ofEpochSecond(1660809650);
  private String awsMessageId = "01070182461f368b-81b26a39-0e8b-49db-8015-7c1d493fb767-000000";
  private List<EmailStatusHistoryEntry> emailStatusHistoryEntry =
      List.of(new EmailStatusHistoryEntry(EmailStatus.AWS_OPEN, Instant.ofEpochSecond(1660809625)));
  ;

  public static Email createEmail(
      String emailId,
      String fromAddress,
      String toAddress,
      String htmlBody,
      String textBody,
      String subject,
      String mailRequestId,
      Instant createdAt,
      EmailStatus status,
      Instant statusTimestamp,
      String awsMessageId) {
    return Email.builder()
        .id(emailId)
        .fromAddress(Email.encryptedFromAddress(fromAddress))
        .toAddress(Email.encryptedToAddress(toAddress))
        .htmlBody(Email.encryptedHtmlBody(htmlBody))
        .textBody(Email.encryptedTextBody(textBody))
        .subject(Email.encryptedSubject(subject))
        .mailRequestId(new ObjectId(mailRequestId))
        .createdAt(createdAt)
        .status(status)
        .statusTimestamp(statusTimestamp)
        .awsMessageId(awsMessageId)
        .sendDate(Instant.now())
        .build();
  }

  public EmailTestConfig emailStatusHistoryEntry(
      List<EmailStatusHistoryEntry> emailStatusHistoryEntry) {
    this.emailStatusHistoryEntry = emailStatusHistoryEntry;
    return this;
  }

  public Email build() {
    return Email.builder()
        .id(emailId)
        .fromAddress(Email.encryptedFromAddress(fromAddress))
        .toAddress(Email.encryptedToAddress(toAddress))
        .htmlBody(Email.encryptedHtmlBody(htmlBody))
        .textBody(Email.encryptedTextBody(textBody))
        .subject(Email.encryptedSubject(subject))
        .mailRequestId(new ObjectId(mailRequestId))
        .createdAt(createdAt)
        .status(status)
        .statusTimestamp(statusTimestamp)
        .statusHistory(emailStatusHistoryEntry)
        .awsMessageId(awsMessageId)
        .sendDate(sendDate)
        .build();
  }
}
