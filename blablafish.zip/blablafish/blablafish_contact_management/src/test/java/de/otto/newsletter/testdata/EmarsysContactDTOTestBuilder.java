package de.otto.newsletter.testdata;

import com.fasterxml.jackson.annotation.JsonProperty;
import de.otto.newsletter.model.dto.EmarsysContactDTO;
import de.otto.newsletter.model.dto.EmarsysContactFields;
import java.util.Set;

public class EmarsysContactDTOTestBuilder {
  @JsonProperty(EmarsysContactFields.KEY_ID)
  private static String keyId = EmarsysContactFields.USER_ID;

  @JsonProperty(EmarsysContactFields.USER_ID)
  private static String userId = "62bec37d21d8c96a1dff30cb";

  @JsonProperty(EmarsysContactFields.FIRSTNAME)
  private static String firstName = "TestUser1FirstName";

  @JsonProperty(EmarsysContactFields.LASTNAME)
  private static String lastName = "TestUser1LastName";

  @JsonProperty(EmarsysContactFields.EMAIL)
  private static String email = "testuser1mail@otto.de";

  @JsonProperty(EmarsysContactFields.PARTNER_ID)
  private static String partnerId = "1008941";

  @JsonProperty(EmarsysContactFields.NEWSLETTER_UNSUBSCRIBE_KEY)
  private static String unsubscribeKey = "demo_unsubscribe_key_jwt";

  @JsonProperty(EmarsysContactFields.NEWSLETTER_OPT_IN)
  private static Integer optIn = 1;

  @JsonProperty(EmarsysContactFields.ACCOUNT_STATUS)
  private static String accountStatus = "ACTIVE";

  @JsonProperty(EmarsysContactFields.ROLES)
  private static Set<String> groups = Set.of("4", "7");

  public static EmarsysContactDTO.EmarsysContactDTOBuilder emarsysContactBuilder() {
    return EmarsysContactDTO.builder()
        .keyId(keyId)
        .userId(userId)
        .firstName(firstName)
        .lastName(lastName)
        .email(email)
        .partnerId(partnerId)
        .newsletterUnsubscribeKey(unsubscribeKey)
        .newsletterOptIn(optIn)
        .groups(groups)
        .accountStatus(accountStatus);
  }
}
