package de.otto.blablafish_email.service;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

import de.otto.blablafish_contact_management.exception.TopicNotFoundException;
import de.otto.blablafish_contact_management.model.entity.Topic;
import de.otto.blablafish_contact_management.respository.TopicRepository;
import de.otto.blablafish_email.exception.EmailRequestNotFoundException;
import de.otto.blablafish_email.model.entity.EmailRequest;
import de.otto.blablafish_email.model.entity.EmailRequestStatus;
import de.otto.blablafish_email.respository.EmailRepository;
import de.otto.blablafish_email.respository.EmailRequestRepository;
import java.util.Collections;
import java.util.Optional;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.Test;
import org.springframework.web.servlet.view.freemarker.FreeMarkerConfigurer;

class EmailTemplateServiceTest {

  private final String sesSenderDomain = "nonlive.partner-info.otto.market";
  private final EmailRequestRepository emailRequestRepository = mock(EmailRequestRepository.class);
  private final EmailRepository emailRepository = mock(EmailRepository.class);
  private final TopicRepository topicRepository = mock(TopicRepository.class);
  private final FreeMarkerConfigurer freeMarkerConfigurer = mock(FreeMarkerConfigurer.class);
  private final EmailTemplateService emailTemplateService =
      new EmailTemplateService(
          emailRequestRepository,
          emailRepository,
          topicRepository,
          freeMarkerConfigurer,
          sesSenderDomain);

  @Test
  void shouldThrowEmailRequestNotFoundExceptionWhenRequestIdIsInvalid() {
    ObjectId invalidEmailRequestId = new ObjectId();
    when(emailRequestRepository.findById(invalidEmailRequestId)).thenReturn(Optional.empty());

    assertThrows(
        EmailRequestNotFoundException.class,
        () -> emailTemplateService.handleRenderEmailTrigger(invalidEmailRequestId));
  }

  @Test
  void shouldThrowTopicNotFoundExceptionWhenEmailRequestHasInvalidTopicId() {
    Integer topicId = 1;
    ObjectId emailRequestId = new ObjectId();
    EmailRequest emailRequest = mock(EmailRequest.class);
    when(emailRequest.getTopicId()).thenReturn(topicId);
    when(emailRequestRepository.findById(emailRequestId)).thenReturn(Optional.of(emailRequest));
    when(emailRequest.getStatus()).thenReturn(EmailRequestStatus.ACCEPTED);
    when(topicRepository.findById(topicId)).thenReturn(Optional.empty());

    assertThrows(
        TopicNotFoundException.class,
        () -> emailTemplateService.handleRenderEmailTrigger(emailRequestId));
    verify(topicRepository).findById(topicId);
  }

  @Test
  void shouldThrowRuntimeExceptionIfEmailRequestDoesNotHaveRecipients() {
    Integer topicId = 1;
    ObjectId emailRequestId = new ObjectId();
    EmailRequest emailRequest = mock(EmailRequest.class);
    Topic topic = mock(Topic.class);
    when(emailRequest.getTopicId()).thenReturn(topicId);
    when(emailRequestRepository.findById(emailRequestId)).thenReturn(Optional.of(emailRequest));
    when(emailRequest.getStatus()).thenReturn(EmailRequestStatus.ACCEPTED);
    when(topicRepository.findById(topicId)).thenReturn(Optional.of(topic));
    when(emailRequest.getRecipients()).thenReturn(Collections.emptyList());

    assertThrows(
        RuntimeException.class,
        () -> emailTemplateService.handleRenderEmailTrigger(emailRequestId));
  }
}
