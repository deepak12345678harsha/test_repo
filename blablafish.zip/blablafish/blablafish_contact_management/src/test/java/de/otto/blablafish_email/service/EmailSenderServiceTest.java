package de.otto.blablafish_email.service;

import static de.otto.blablafish_email.model.entity.Email.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.simpleemailv2.AmazonSimpleEmailServiceV2;
import com.amazonaws.services.simpleemailv2.model.AmazonSimpleEmailServiceV2Exception;
import com.amazonaws.services.simpleemailv2.model.SendEmailRequest;
import com.amazonaws.services.simpleemailv2.model.SendEmailResult;
import de.otto.blablafish_contact_management.model.dto.EventType;
import de.otto.blablafish_email.model.dto.mail.EmailAttachmentDetail;
import de.otto.blablafish_email.model.dto.ses.EmailRequestNotice;
import de.otto.blablafish_email.model.entity.Email;
import de.otto.blablafish_email.model.entity.EmailStatus;
import de.otto.blablafish_email.model.entity.EmailStatusHistoryEntry;
import de.otto.blablafish_email.publishers.SNSPublisher;
import de.otto.blablafish_email.respository.EmailAttachmentRepository;
import de.otto.blablafish_email.respository.EmailRepository;
import de.otto.blablafish_email.utils.FileUtils;
import java.io.*;
import java.time.Instant;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class EmailSenderServiceTest {

  private EmailSenderService emailSenderService;

  @Mock private EmailRepository emailRepository;

  @Mock private AmazonSimpleEmailServiceV2 client;

  @Mock private SNSPublisher snsPublisher;

  @Mock private EmailAttachmentService emailAttachmentService;

  @Mock private EmailAttachmentRepository emailAttachmentRepository;

  @Mock private AmazonS3 amazonS3;

  @BeforeEach
  public void setEmailService() {
    emailSenderService =
        new EmailSenderService(
            emailRepository, client, emailAttachmentService, snsPublisher, "", "");
  }

  @Test
  void shouldReturnNullWhenEmailNotFoundToSend() {
    String emailId = "629089ba391a524f0b687f4a";
    when(emailRepository.findByIdStatusAndSaveEmailStatusHistory(
            eq(emailId), eq(EmailStatus.READY_TO_SEND), any(EmailStatusHistoryEntry.class)))
        .thenReturn(null);

    emailSenderService.send(emailId);

    verify(emailRepository)
        .findByIdStatusAndSaveEmailStatusHistory(
            eq(emailId), eq(EmailStatus.READY_TO_SEND), any(EmailStatusHistoryEntry.class));
  }

  @Test
  void shouldSendEmailWhenEmailFoundToSend() {
    String emailId = "629089ba391a524f0b687f4a";
    Email savedEmail = getEmailWithNoAttachments(emailId, Instant.now());
    SendEmailResult emailResult = new SendEmailResult().withMessageId("awsMessageId");

    when(emailRepository.findByIdStatusAndSaveEmailStatusHistory(
            eq(emailId), eq(EmailStatus.READY_TO_SEND), any(EmailStatusHistoryEntry.class)))
        .thenReturn(savedEmail);
    when(client.sendEmail(any(SendEmailRequest.class))).thenReturn(emailResult);
    when(emailRepository.findByIdAndSetAwsMessageId(emailId, "awsMessageId"))
        .thenReturn(savedEmail);

    emailSenderService.send(emailId);

    verify(emailRepository)
        .findByIdStatusAndSaveEmailStatusHistory(
            eq(emailId), eq(EmailStatus.READY_TO_SEND), any(EmailStatusHistoryEntry.class));
    verify(client).sendEmail(any(SendEmailRequest.class));
    verify(emailRepository).findByIdAndSetAwsMessageId(emailId, emailResult.getMessageId());
  }

  @Test
  void shouldHandleAmazonSimpleEmailServiceV2ExceptionWhenClientThrowsSESException() {
    String emailId = "629089ba391a524f0b687f4a";
    Email savedEmail = getEmailWithNoAttachments(emailId, Instant.now());
    when(emailRepository.findByIdStatusAndSaveEmailStatusHistory(
            eq(emailId), eq(EmailStatus.READY_TO_SEND), any(EmailStatusHistoryEntry.class)))
        .thenReturn(savedEmail);
    doThrow(new AmazonSimpleEmailServiceV2Exception(""))
        .when(client)
        .sendEmail(any(SendEmailRequest.class));

    emailSenderService.send(emailId);

    verify(emailRepository, never()).findByIdAndSetAwsMessageId(anyString(), anyString());
    verify(emailRepository)
        .findByIdStatusAndSaveEmailStatusHistory(
            eq(emailId), eq(EmailStatus.SENDING), any(EmailStatusHistoryEntry.class));
    verify(snsPublisher)
        .publish(any(EmailRequestNotice.class), eq(EventType.EMAIL_PRECONDITION_FAILED));
  }

  @Test
  void shouldHandleExceptionWhenClientThrowsExceptSESException() {
    String emailId = "629089ba391a524f0b687f4a";
    Email savedEmail = getEmailWithNoAttachments(emailId, Instant.now());

    when(emailRepository.findByIdStatusAndSaveEmailStatusHistory(
            eq(emailId), eq(EmailStatus.READY_TO_SEND), any(EmailStatusHistoryEntry.class)))
        .thenReturn(savedEmail);
    doThrow(new RuntimeException("")).when(client).sendEmail(any(SendEmailRequest.class));

    emailSenderService.send(emailId);

    verify(emailRepository, never()).findByIdAndSetAwsMessageId(anyString(), anyString());
    verify(emailRepository)
        .findByIdStatusAndSaveEmailStatusHistory(
            eq(emailId), eq(EmailStatus.SENDING), any(EmailStatusHistoryEntry.class));
    verify(snsPublisher).publish(any(EmailRequestNotice.class), eq(EventType.EMAIL_REQUEST_FAILED));
  }

  @Test
  void shouldHandleExceptionWhenRepoThrowsException() {
    String emailId = "629089ba391a524f0b687f4a";
    Email savedEmail = getEmailWithNoAttachments(emailId, Instant.now());
    SendEmailResult emailResult = new SendEmailResult().withMessageId("awsMessageId");

    when(emailRepository.findByIdStatusAndSaveEmailStatusHistory(
            eq(emailId), eq(EmailStatus.READY_TO_SEND), any(EmailStatusHistoryEntry.class)))
        .thenReturn(savedEmail);
    when(client.sendEmail(any(SendEmailRequest.class))).thenReturn(emailResult);

    doThrow(new RuntimeException(""))
        .when(emailRepository)
        .findByIdAndSetAwsMessageId(emailId, "awsMessageId");

    emailSenderService.send(emailId);
    verify(emailRepository).findByIdAndSetAwsMessageId(anyString(), anyString());
    verify(emailRepository)
        .findByIdStatusAndSaveEmailStatusHistory(
            eq(emailId), eq(EmailStatus.SENDING), any(EmailStatusHistoryEntry.class));
    verify(snsPublisher).publish(any(EmailRequestNotice.class), eq(EventType.EMAIL_REQUEST_FAILED));
  }

  @Test
  void shouldSendEmailWithAttachmentDownloaded() {
    String emailId = "629089ba391a524f0b687f4a";
    Email savedEmail = getEmailWithAttachment(emailId, Instant.now());

    when(emailRepository.findByIdStatusAndSaveEmailStatusHistory(
            eq(emailId), eq(EmailStatus.READY_TO_SEND), any(EmailStatusHistoryEntry.class)))
        .thenReturn(savedEmail);
    when(emailAttachmentService.getAttachment(any())).thenReturn(getEmailAttachmentDetail());
    SendEmailResult emailResult = new SendEmailResult().withMessageId("awsMessageId");
    when(client.sendEmail(any(SendEmailRequest.class))).thenReturn(emailResult);
    when(emailRepository.findByIdAndSetAwsMessageId(emailId, "awsMessageId"))
        .thenReturn(savedEmail);

    emailSenderService.send(emailId);

    verify(emailAttachmentService).getAttachment(anyString());
    verify(emailRepository)
        .findByIdStatusAndSaveEmailStatusHistory(
            eq(emailId), eq(EmailStatus.READY_TO_SEND), any(EmailStatusHistoryEntry.class));
    verify(client).sendEmail(any(SendEmailRequest.class));
    verify(emailRepository).findByIdAndSetAwsMessageId(emailId, emailResult.getMessageId());
  }

  private Email getEmailWithNoAttachments(String emailId, Instant time) {
    return Email.builder()
        .id(emailId)
        .awsMessageId("awsMessageId")
        .mailRequestId(new ObjectId(emailId))
        .htmlBody(encryptedHtmlBody("htmlBody"))
        .textBody(encryptedTextBody("textBody"))
        .subject(encryptedSubject("subject"))
        .toAddress(encryptedToAddress("toAddress"))
        .fromAddress(Email.encryptedFromAddress("fromAddress"))
        .createdAt(time)
        .sendDate(time)
        .status(EmailStatus.READY_TO_SEND)
        .statusTimestamp(time)
        .statusHistory(List.of(EmailStatusHistoryEntry.of(EmailStatus.READY_TO_SEND, time)))
        .attachmentIds(Collections.emptySet())
        .build();
  }

  private Email getEmailWithAttachment(String emailId, Instant time) {
    return Email.builder()
        .id(emailId)
        .awsMessageId("awsMessageId")
        .mailRequestId(new ObjectId(emailId))
        .htmlBody(encryptedHtmlBody("htmlBody"))
        .textBody(encryptedTextBody("textBody"))
        .subject(encryptedSubject("subject"))
        .toAddress(encryptedToAddress("toAddress"))
        .fromAddress(Email.encryptedFromAddress("fromAddress"))
        .createdAt(time)
        .sendDate(time)
        .status(EmailStatus.READY_TO_SEND)
        .statusTimestamp(time)
        .statusHistory(List.of(EmailStatusHistoryEntry.of(EmailStatus.READY_TO_SEND, time)))
        .attachmentIds(Set.of("1234"))
        .build();
  }

  private EmailAttachmentDetail getEmailAttachmentDetail() {
    File file = FileUtils.createTempFile("uploadForEmail", ".txt");
    return new EmailAttachmentDetail("uploadForEmail.txt", file);
  }
}
