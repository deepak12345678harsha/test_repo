package de.otto.blablafish_email.integrationtest;

import static de.otto.blablafish_email.utils.Constants.CONTACT_MANAGEMENT_EMAIL_READ_ROLE;
import static de.otto.blablafish_email.utils.Constants.CONTACT_MANAGEMENT_PARTNER_EMAIL_WRITE_ROLE;
import static io.restassured.RestAssured.with;
import static org.assertj.core.api.Assertions.assertThat;

import de.otto.blablafish_contact_management.integrationtest.helpers.JwtHelper;
import de.otto.blablafish_contact_management.model.dto.ErrorResponse;
import de.otto.blablafish_email.listener.AbstractContainerIT;
import de.otto.blablafish_email.model.dto.mail.EmailDTO;
import de.otto.blablafish_email.model.entity.Email;
import de.otto.blablafish_email.testDataConfig.EmailDTOTestBuilder;
import de.otto.blablafish_email.testDataConfig.EmailTestConfig;
import io.restassured.common.mapper.TypeRef;
import java.util.List;
import java.util.UUID;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;

public class EmailControllerIT extends AbstractContainerIT {

  private final String partnerId = "partner1";

  @Test
  public void shouldReturn403WhenRequiredRoleIsNotPresentForGetPartnerMails() {
    final String requesterKeycloakId = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken(
            "test-client",
            requesterKeycloakId,
            List.of(CONTACT_MANAGEMENT_PARTNER_EMAIL_WRITE_ROLE),
            partnerId);
    final ErrorResponse errorResponse =
        with()
            .given()
            .header(HttpHeaders.AUTHORIZATION, jwt)
            .port(port)
            .basePath(BASE_PATH)
            .when()
            .request(HttpMethod.GET.name(), "/v1/mails/629089ba391a524f0b687f4a")
            .then()
            .statusCode(HttpStatus.FORBIDDEN.value())
            .and()
            .extract()
            .body()
            .as(new TypeRef<>() {});
    Assertions.assertThat(errorResponse.getMessage()).isEqualTo("Access is denied");
  }

  @Test
  void shouldGetEmailByEmailId() {
    Email email = new EmailTestConfig().build();
    Email savedEmail = mongoTemplate.insert(email);
    final String requesterKeycloakId = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken(
            "test-client",
            requesterKeycloakId,
            List.of(CONTACT_MANAGEMENT_EMAIL_READ_ROLE),
            partnerId);

    EmailDTO actualEmail =
        with()
            .header(HttpHeaders.AUTHORIZATION, jwt)
            .port(port)
            .basePath(BASE_PATH)
            .when()
            .request(HttpMethod.GET.name(), "/v1/mails/" + savedEmail.getId())
            .then()
            .statusCode(HttpStatus.OK.value())
            .and()
            .extract()
            .body()
            .as(new TypeRef<EmailDTO>() {});

    EmailDTO expectedEmail = new EmailDTOTestBuilder().build();
    Assertions.assertThat(actualEmail).usingRecursiveComparison().isEqualTo(expectedEmail);
  }

  @Test
  void shouldReturn404WhenEmailDoesNotExists() {
    String invalidEmailId = "62e2b5628b9529672c6cbd9a";
    final String requesterKeycloakId = UUID.randomUUID().toString();
    String jwt =
        JwtHelper.createToken(
            "test-client",
            requesterKeycloakId,
            List.of(CONTACT_MANAGEMENT_EMAIL_READ_ROLE),
            partnerId);

    ErrorResponse errorResponse =
        with()
            .header(HttpHeaders.AUTHORIZATION, jwt)
            .port(port)
            .basePath(BASE_PATH)
            .when()
            .request(HttpMethod.GET.name(), "/v1/mails/" + invalidEmailId)
            .then()
            .statusCode(HttpStatus.NOT_FOUND.value())
            .and()
            .extract()
            .body()
            .as(new TypeRef<>() {});

    assertThat(errorResponse.getMessage())
        .isEqualTo("Email with id 62e2b5628b9529672c6cbd9a not found");
  }
}
