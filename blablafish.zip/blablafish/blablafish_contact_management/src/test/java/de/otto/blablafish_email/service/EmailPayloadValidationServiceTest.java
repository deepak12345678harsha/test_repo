package de.otto.blablafish_email.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import com.fasterxml.jackson.databind.ObjectMapper;
import de.otto.blablafish_contact_management.model.entity.Topic;
import de.otto.blablafish_email.exception.ValidationException;
import de.otto.blablafish_email.model.dto.ValidationReason;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.Map;
import org.bson.Document;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.core.io.ClassPathResource;

class EmailPayloadValidationServiceTest {
  private final ObjectMapper mapper = new ObjectMapper();
  private final EmailPayloadValidationService service = new EmailPayloadValidationService(mapper);

  @ParameterizedTest
  @ValueSource(
      strings = {
        "emailPayloads/validPayload_exampleA.json",
        "emailPayloads/validPayload_exampleB.json",
        "emailPayloads/validPayload_exampleC.json"
      })
  void shouldNotThrowExceptionWhenPayloadIsValid(String payload) throws IOException {
    final Topic emailTopic = getTopic();
    service.validate(requestOf(payload), emailTopic);
  }

  @ParameterizedTest
  @ValueSource(
      strings = {
        "emailPayloads/validPayload_exampleA.json",
        "emailPayloads/validPayload_exampleB.json",
        "emailPayloads/validPayload_exampleC.json"
      })
  void shouldNotThrowExceptionWhenInternalPayloadIsValid(String internalPayload)
      throws IOException {
    final Topic emailTopic = getTopic();
    service.validate(
        requestOf("emailPayloads/validPayload_exampleA.json"),
        requestOf(internalPayload),
        emailTopic);
  }

  @ParameterizedTest
  @ValueSource(
      strings = {
        "emailPayloads/validPayload_exampleA.json",
        "emailPayloads/validPayload_exampleB.json",
        "emailPayloads/validPayload_exampleC.json"
      })
  void shouldNotThrowExceptionWhenInternalPayloadSchemaIsEmptyForTopic(String internalPayload)
      throws IOException {
    final Topic emailTopic = getTopicWithEmptyInternalSchema();
    service.validate(
        requestOf("emailPayloads/validPayload_exampleA.json"),
        requestOf(internalPayload),
        emailTopic);
  }

  @ParameterizedTest
  @ValueSource(
      strings = {
        "emailPayloads/invalidPayload_exampleA.json",
        "emailPayloads/invalidPayload_exampleB.json",
        "emailPayloads/invalidPayload_exampleC.json"
      })
  void shouldThrowExceptionWhenPayloadIsNotValid(String payload) throws IOException {
    final Topic emailTopic = getTopic();
    ValidationException validationException =
        assertThrows(
            ValidationException.class, () -> service.validate(requestOf(payload), emailTopic));
    assertEquals(
        ValidationReason.PAYLOAD_DOES_NOT_MATCH_TOPIC_SCHEMA, validationException.getReason());
  }

  @ParameterizedTest
  @ValueSource(
      strings = {
        "emailPayloads/invalidPayload_exampleA.json",
        "emailPayloads/invalidPayload_exampleB.json",
        "emailPayloads/invalidPayload_exampleC.json"
      })
  void shouldThrowExceptionWhenInternalPayloadIsNotValid(String internalPayload)
      throws IOException {
    final Topic emailTopic = getTopic();
    ValidationException validationException =
        assertThrows(
            ValidationException.class,
            () ->
                service.validate(
                    requestOf("emailPayloads/validPayload_exampleA.json"),
                    requestOf(internalPayload),
                    emailTopic));
    assertEquals(
        ValidationReason.INTERNAL_PAYLOAD_DOES_NOT_MATCH_TOPIC_INTERNAL_SCHEMA,
        validationException.getReason());
  }

  private Map<String, Object> requestOf(String fileName) throws IOException {
    final File file = new ClassPathResource(fileName).getFile();
    final String jsonSchema = new String(Files.readAllBytes(file.toPath()));
    return mapper.readValue(jsonSchema, Map.class);
  }

  private Topic getTopic() throws IOException {
    return Topic.builder()
        .id(1)
        .name("contract")
        .description("description 1")
        .mandatorySubscriberRoles(Arrays.asList("mandatory role 1", "mandatory role 2"))
        .emailSubject("")
        .emailHtmlTemplate("")
        .emailPlainTextTemplate("")
        .emailSchema(schemaOf("emailPayloads/schemaExample.json"))
        .internalDescription("")
        .internalSubject("")
        .internalEmailSchema(schemaOf("emailPayloads/internalSchemaExample.json"))
        .build();
  }

  private Topic getTopicWithEmptyInternalSchema() throws IOException {
    return Topic.builder()
        .id(1)
        .name("contract")
        .description("description 1")
        .mandatorySubscriberRoles(Arrays.asList("mandatory role 1", "mandatory role 2"))
        .emailSubject("")
        .emailHtmlTemplate("")
        .emailPlainTextTemplate("")
        .emailSchema(schemaOf("emailPayloads/schemaExample.json"))
        .build();
  }

  private Document schemaOf(String fileName) throws IOException {
    final File file = new ClassPathResource(fileName).getFile();
    final String jsonSchema = new String(Files.readAllBytes(file.toPath()));
    return mapper.readValue(jsonSchema, Document.class);
  }
}
