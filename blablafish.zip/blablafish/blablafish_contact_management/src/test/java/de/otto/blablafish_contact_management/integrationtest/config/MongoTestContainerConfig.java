package de.otto.blablafish_contact_management.integrationtest.config;

import java.util.List;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.testcontainers.containers.MongoDBContainer;
import org.testcontainers.containers.wait.strategy.Wait;
import org.testcontainers.utility.DockerImageName;

@Configuration
@Profile("integration")
public class MongoTestContainerConfig {

  private static final Integer MONGODB_PORT = 27017;

  static {
    MongoDBContainer mongoDBContainer =
        new MongoDBContainer(DockerImageName.parse("mongo:4.4.1"))
            .withExposedPorts(MONGODB_PORT)
            .withCommand("--bind_ip", "0.0.0.0", "--replSet", "docker-rs")
            .waitingFor(Wait.forLogMessage("(?i).*waiting for connections.*", 1));

    mongoDBContainer.setPortBindings(List.of(MONGODB_PORT + ":" + MONGODB_PORT));
    mongoDBContainer.withExposedPorts(MONGODB_PORT);
    mongoDBContainer.start();
    mongoDBContainer.waitingFor(Wait.forListeningPort());

    String mongoUri =
        "mongodb://"
            + mongoDBContainer.getContainerIpAddress()
            + ":"
            + mongoDBContainer.getMappedPort(MONGODB_PORT)
            + "/tests";
    System.setProperty("spring.data.mongodb.uri", mongoUri);
    System.setProperty("spring.data.mongodb.dataBase", "test");
  }
}
