package de.otto.newsletter.listeners;

import static org.testcontainers.shaded.org.awaitility.Awaitility.await;

import com.amazonaws.services.sqs.AmazonSQS;
import de.otto.blablafish_contact_management.config.Features;
import de.otto.blablafish_contact_management.integrationtest.config.WireMockExtension;
import de.otto.blablafish_contact_management.model.entity.Subscriber;
import de.otto.blablafish_contact_management.testDataConfig.SubscriberTestConfig;
import de.otto.blablafish_email.listener.AbstractContainerIT;
import de.otto.newsletter.model.entity.SubscriberChangeEntry;
import de.otto.newsletter.model.entity.SubscriberChangeEventType;
import java.time.Instant;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.assertj.core.api.Assertions;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.togglz.junit5.AllEnabled;

@AllEnabled(Features.class)
@ExtendWith({WireMockExtension.class})
class SubscribersMongoDBEventListenerIT extends AbstractContainerIT {
  @Value("${mongoDbTrigger.subscribers.changeEvents.queueUrl}")
  private String subscribersMongoDBTriggerChangeEventQueueName;

  @Autowired private AmazonSQS sqs;

  @Test
  void shouldCreateSubscriberChangedEntryWhenOldNewsletterUpdateEventReceived() {
    String subscriberId = "629089ba391a524f0b687f4a";
    Subscriber subscriber =
        new SubscriberTestConfig().subscriberBuilder().userId(new ObjectId(subscriberId)).build();
    mongoTemplate.insert(subscriber);
    String queueUrl = sqs.getQueueUrl(subscribersMongoDBTriggerChangeEventQueueName).getQueueUrl();

    String text =
        "Ja, ich möchte den OTTO-Market-Newsletter der Otto (GmbH & Co KG) erhalten und Informationen über Angebote, neue Services und Updates von OTTO Market erhalten. Diese Einwilligung kann jederzeit mit Wirkung für die Zukunft unter https://portal.otto.market/settings?section=newsletter oder am Ende jeder E-Mail widerrufen werden.";
    String eventAsString =
        "{\"version\":\"0\",\"id\":\"ab3cda69-ce95-61d8-a8c1-1e8e2c16135b\",\"detail-type\":\"MongoDB Database Trigger for contactmanagement_db.subscribers\",\"source\":\"aws.partner/mongodb.com/stitch.trigger/6311a64cf2a2c8bc65d5a4c2\",\"account\":\"353449567674\",\"time\":\"2022-10-11T07:20:26Z\",\"region\":\"eu-central-1\",\"resources\":[\"arn:aws:events:eu-central-1::event-source/aws.partner/mongodb.com/stitch.trigger/6311a64cf2a2c8bc65d5a4c2\"],\"detail\":{\"_id\":{\"_data\":\"826345193A000000012B022C0100296E5A10046B912311B15441BA9DC150E99E43751946645F6964006462B1AF5EBBBB2C5701BF4C970004\"},\"operationType\":\"update\",\"clusterTime\":{\"T\":1665472826,\"I\":1},\"ns\":{\"db\":\"contactmanagement_db\",\"coll\":\"subscribers\"},\"documentKey\":{\"_id\":\""
            + subscriberId
            + "\"},\"updateDescription\":{\"updatedFields\":{\"newsletterSubscription\":{\"status\":\"UNSUBSCRIBED\",\"text\":\""
            + text
            + "\",\"time\":\"2022-10-11T07:20:26.707Z\"}},\"removedFields\":[],\"truncatedArrays\":[]}}}";

    sqs.sendMessage(queueUrl, eventAsString);

    await()
        .atMost(5, TimeUnit.SECONDS)
        .until(() -> mongoTemplate.findAll(SubscriberChangeEntry.class).size() == 1);
    assertThatQueueHasConsumedAllMessages(sqs, queueUrl);

    List<SubscriberChangeEntry> allEntries = mongoTemplate.findAll(SubscriberChangeEntry.class);
    Assertions.assertThat(allEntries).hasSize(1);
    SubscriberChangeEntry entry = allEntries.get(0);
    Assertions.assertThat(entry.getEventTime()).isEqualTo(Instant.parse("2022-10-11T07:20:26Z"));
    Assertions.assertThat(entry.getSubscriberId()).isEqualTo(subscriberId);
    Assertions.assertThat(entry.getSubscriberChangeEventType())
        .isEqualTo(SubscriberChangeEventType.SUBSCRIBER_UNSUBSCRIBED_TO_NEWSLETTER);
  }

  @Test
  void shouldCreateSubscriberChangedEntryWhenCommunicationSubscriptionChanged() {
    var subscriberId = "629089ba391a524f0b687f4a";
    var subscriber =
        new SubscriberTestConfig().subscriberBuilder().userId(new ObjectId(subscriberId)).build();
    mongoTemplate.insert(subscriber);
    var queueUrl = sqs.getQueueUrl(subscribersMongoDBTriggerChangeEventQueueName).getQueueUrl();

    var eventAsString =
        "{\"version\":\"0\",\"id\":\"ab3cda69-ce95-61d8-a8c1-1e8e2c16135b\",\"detail-type\":\"MongoDB Database Trigger for contactmanagement_db.subscribers\",\"source\":\"aws.partner/mongodb.com/stitch.trigger/6311a64cf2a2c8bc65d5a4c2\",\"account\":\"353449567674\",\"time\":\"2022-10-11T07:20:26Z\",\"region\":\"eu-central-1\",\"resources\":[\"arn:aws:events:eu-central-1::event-source/aws.partner/mongodb.com/stitch.trigger/6311a64cf2a2c8bc65d5a4c2\"],\"detail\":{\"_id\":{\"_data\":\"826345193A000000012B022C0100296E5A10046B912311B15441BA9DC150E99E43751946645F6964006462B1AF5EBBBB2C5701BF4C970004\"},\"operationType\":\"update\",\"clusterTime\":{\"T\":1665472826,\"I\":1},\"ns\":{\"db\":\"contactmanagement_db\",\"coll\":\"subscribers\"},\"documentKey\":{\"_id\":\""
            + subscriberId
            + "\"},\"updateDescription\":{\"updatedFields\":{\"communicationSubscription\":{\"status\":\"UNSUBSCRIBED\", \"time\":\"2022-10-11T07:20:26.707Z\"}},\"removedFields\":[],\"truncatedArrays\":[]}}}";

    sqs.sendMessage(queueUrl, eventAsString);

    await()
        .atMost(5, TimeUnit.SECONDS)
        .until(() -> mongoTemplate.findAll(SubscriberChangeEntry.class).size() == 1);

    assertThatQueueHasConsumedAllMessages(sqs, queueUrl);

    List<SubscriberChangeEntry> allEntries = mongoTemplate.findAll(SubscriberChangeEntry.class);
    Assertions.assertThat(allEntries).hasSize(1);
    SubscriberChangeEntry entry = allEntries.get(0);
    Assertions.assertThat(entry.getEventTime()).isEqualTo(Instant.parse("2022-10-11T07:20:26Z"));
    Assertions.assertThat(entry.getSubscriberId()).isEqualTo(subscriberId);
    Assertions.assertThat(entry.getSubscriberChangeEventType())
        .isEqualTo(SubscriberChangeEventType.SUBSCRIBER_UNSUBSCRIBED_TO_COMMUNICATION);
  }
}
