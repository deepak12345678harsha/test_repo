package de.otto.blablafish_email.testDataConfig;

import de.otto.blablafish_email.model.dto.mail.EmailDTO;
import de.otto.blablafish_email.model.dto.mail.EmailStatusHistoryEntryDTO;
import de.otto.blablafish_email.model.entity.EmailStatus;
import java.time.Instant;
import java.util.List;
import java.util.Set;

public class EmailDTOTestBuilder {

  private String emailId = "62bec37d21d8c96a1dff30cb";
  private String fromAddress = "no-reply@nonlive.partner-info.otto.market";
  private String toAddress = "blablafish@otto.de";
  private String htmlBody;
  private String textBody;
  private String subject = "subject";
  private String mailRequestId = "62bec37d21d8c96a1dff30cb";
  private Instant sendDate = Instant.ofEpochSecond(1660809625);
  private Instant createdAt = Instant.ofEpochSecond(1660809620);
  private EmailStatus status = EmailStatus.AWS_DELIVERY;
  private Instant statusTimestamp = Instant.ofEpochSecond(1660809650);
  private String awsMessageId = "01070182461f368b-81b26a39-0e8b-49db-8015-7c1d493fb767-000000";
  private List<EmailStatusHistoryEntryDTO> emailStatusHistoryEntry =
      List.of(
          new EmailStatusHistoryEntryDTO(EmailStatus.AWS_OPEN, Instant.ofEpochSecond(1660809625)));
  private Set<String> attachmentIds;

  public EmailDTOTestBuilder emailStatusHistoryEntryDTO(
      List<EmailStatusHistoryEntryDTO> emailStatusHistoryEntry) {
    this.emailStatusHistoryEntry = emailStatusHistoryEntry;
    return this;
  }

  public EmailDTOTestBuilder attachmentIds(Set<String> attachmentIds) {
    this.attachmentIds = attachmentIds;
    return this;
  }

  public EmailDTO build() {
    return EmailDTO.builder()
        .mailId(emailId)
        .awsMessageId(awsMessageId)
        .subject(subject)
        .toAddress(toAddress)
        .fromAddress(fromAddress)
        .sendDate(sendDate)
        .createdAt(createdAt)
        .emailRequestId(mailRequestId)
        .status(status)
        .statusTimestamp(statusTimestamp)
        .statusHistory(emailStatusHistoryEntry)
        .attachmentIds(attachmentIds)
        .build();
  }
}
