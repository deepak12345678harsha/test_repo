package de.otto.blablafish_contact_management.listeners;

import static de.otto.blablafish_contact_management.utils.Constants.EVENT_EXPIRATION_IN_YEARS;
import static java.util.concurrent.TimeUnit.SECONDS;
import static org.assertj.core.api.Assertions.assertThat;
import static org.testcontainers.shaded.org.awaitility.Awaitility.await;

import com.amazonaws.services.sqs.AmazonSQS;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import de.otto.blablafish_contact_management.model.entity.ChangeEvent;
import de.otto.blablafish_email.listener.AbstractContainerIT;
import de.otto.blablafish_email.model.dto.ClusterTime;
import de.otto.blablafish_email.model.dto.DocumentKey;
import de.otto.blablafish_email.model.dto.MongoDbTriggerEvent;
import de.otto.blablafish_email.model.dto.MongoDbTriggerEventDetail;
import de.otto.blablafish_email.model.dto.MongoNamespace;
import de.otto.blablafish_email.model.dto.UpdateDescription;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.UUID;
import org.bson.Document;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.MongoTemplate;

class MongoDBChangeEventsListenerIT extends AbstractContainerIT {

  @Value("${mongoDbTrigger.changeEvents.queueUrl}")
  private String mongoChangeEventQueueName;

  @Autowired private MongoTemplate mongoTemplate;

  @Autowired private AmazonSQS sqs;

  @Test
  void shouldInsertChangeEventWhenSubscriberIsUpdated() throws JsonProcessingException {
    var mongoDbTriggerEventDetail =
        new MongoDbTriggerEventDetail(
            "UPDATE",
            new ClusterTime(1234587L, 76554L),
            new DocumentKey("62dfb73cf65bfa1ec6f05fe0"),
            new UpdateDescription(),
            new MongoNamespace("contact_management_db", "subscribers"));
    var time = Instant.ofEpochMilli(1234587L);
    var mongoDbTriggerEvent =
        new MongoDbTriggerEvent(
            "event-1",
            "detailType",
            "mongodb/trigger/sub1234",
            "account1",
            time,
            List.of("aws/trigger/sub1234"),
            mongoDbTriggerEventDetail);

    var queueUrl = sqs.getQueueUrl(mongoChangeEventQueueName).getQueueUrl();
    var objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());
    sqs.sendMessage(queueUrl, objectMapper.writeValueAsString(mongoDbTriggerEvent));

    await().atMost(5, SECONDS).until(() -> mongoTemplate.findAll(ChangeEvent.class).size() == 1);

    assertThatQueueHasConsumedAllMessages(sqs, queueUrl);
    var expectedEvent = getChangeEvent(mongoDbTriggerEvent);
    var changeEvents = mongoTemplate.findAll(ChangeEvent.class);
    assertThat(changeEvents.size()).isEqualTo(1);
    assertThat(changeEvents.get(0))
        .usingRecursiveComparison()
        .ignoringFields(
            "expiresAt",
            "id",
            "clusterTime.I",
            "clusterTime.T",
            "event.bsonBinary",
            "event.keyAltName",
            "event.isSearchable")
        .isEqualTo(expectedEvent);
  }

  private ChangeEvent getChangeEvent(MongoDbTriggerEvent event) {
    String eventAsString =
        "{\"account\":\"account1\", \"detail\":{\"clusterTime\":{\"i\":76554, \"t\":1234587}, \"documentKey\":{\"_id\":\"62dfb73cf65bfa1ec6f05fe0\"}, \"ns\":{\"coll\":\"subscribers\", \"db\":\"contact_management_db\"}, \"operationType\":\"UPDATE\", \"updateDescription\":{\"removedFields\":null, \"truncatedArrays\":null, \"updatedFields\":null}}, \"detail-type\":\"detailType\", \"id\":\"event-1\", \"resources\":[\"aws/trigger/sub1234\"], \"source\":\"mongodb/trigger/sub1234\", \"time\":1234.587}";
    final Instant expiresAt = Instant.now().plus(EVENT_EXPIRATION_IN_YEARS * 365, ChronoUnit.DAYS);
    return ChangeEvent.builder()
        .id(UUID.randomUUID().toString())
        .eventDescription(event.getDetailType())
        .source(event.getSource())
        .db(event.getDetail().getNs().getDb())
        .collection(event.getDetail().getNs().getColl())
        .operationType(event.getDetail().getOperationType())
        .clusterTime(
            new de.otto.blablafish_contact_management.model.entity.ClusterTime(
                event.getDetail().getClusterTime().getT(),
                event.getDetail().getClusterTime().getI()))
        .documentKey(new Document("_id", event.getDetail().getDocumentKey().get_id()))
        .expiresAt(expiresAt)
        .time(event.getTime())
        .event(ChangeEvent.encryptDocument(Document.parse(eventAsString)))
        .clusterTime(
            de.otto.blablafish_contact_management.model.entity.ClusterTime.fromDTO(
                event.getDetail().getClusterTime()))
        .build();
  }
}
