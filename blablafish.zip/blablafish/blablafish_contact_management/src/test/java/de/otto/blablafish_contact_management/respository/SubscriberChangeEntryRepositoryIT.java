package de.otto.blablafish_contact_management.respository;

import static org.assertj.core.api.Assertions.assertThat;

import de.otto.blablafish_email.listener.AbstractContainerIT;
import de.otto.newsletter.model.entity.SubscriberChangeEntry;
import de.otto.newsletter.model.entity.SubscriberChangeEventType;
import java.time.Instant;
import org.bson.Document;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

class SubscriberChangeEntryRepositoryIT extends AbstractContainerIT {

  @Autowired private SubscriberChangeEntryRepository subscriberChangeEntryRepository;

  @Test
  void shouldReturnTrueWhenSubscriberChangeEntryExists() {
    String subscriberId = "62bec37d21d8c96a1dff30cb";
    Instant eventTime = Instant.now();
    Instant subscriberChangeTime = Instant.parse("2022-09-14T07:17:00.077Z");
    SubscriberChangeEntry subscriberChangeEntry =
        SubscriberChangeEntry.of(
            subscriberId,
            SubscriberChangeEventType.SUBSCRIBER_SUBSCRIBED_TO_NEWSLETTER,
            subscriberChangeTime,
            eventTime,
            eventTime.plusMillis(10000),
            new Document("version", "1"));
    subscriberChangeEntryRepository.insert(subscriberChangeEntry);

    boolean exists =
        subscriberChangeEntryRepository.exists(
            subscriberId,
            SubscriberChangeEventType.SUBSCRIBER_SUBSCRIBED_TO_NEWSLETTER,
            subscriberChangeTime);

    assertThat(exists).isTrue();
  }

  @Test
  void shouldReturnFalseWhenSubscriberChangeEntryDoesNotExists() {
    String subscriberId = "62bec37d21d8c96a1dff30cb";
    Instant subscriberChangeTime = Instant.parse("2022-09-14T07:17:00.077Z");

    boolean exists =
        subscriberChangeEntryRepository.exists(
            subscriberId,
            SubscriberChangeEventType.SUBSCRIBER_SUBSCRIBED_TO_NEWSLETTER,
            subscriberChangeTime);

    assertThat(exists).isFalse();
  }
}
