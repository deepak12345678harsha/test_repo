package de.otto.blablafish_contact_management.listeners;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import de.otto.blablafish_contact_management.exception.SubscriberDoesNotExistException;
import de.otto.blablafish_contact_management.model.dto.EventType;
import de.otto.blablafish_contact_management.model.entity.*;
import de.otto.blablafish_contact_management.service.SubscriberService;
import java.time.Instant;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class UserManagementEventsListenerTest {
  private UserManagementEventsListener listener;

  @Mock private SubscriberService subscriberService;

  private ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());

  @BeforeEach
  public void setListener() {
    listener = new UserManagementEventsListener(subscriberService, objectMapper);
  }

  @Test
  void shouldListenToUserSetEvent()
      throws JsonProcessingException, SubscriberDoesNotExistException {
    String message =
        """
                {
                  "eventId": "9a60261b-93a2-4602-9735-96f9366c5fb8",
                  "traceId": "def8ec70-70b3-464d-8ee3-82abf042a807",
                  "context": "bla-bla-user-mgmt",
                  "type": "neptune-usermanagement.USER_SET",
                  "eventTime": "2020-10-12T07:17:00.077Z",
                  "data": {
                    "partnerId": "1008941",
                    "neptuneUserId": "629089ba391a524f0b687f4a",
                    "userType": "COOPERATION",
                    "contact": {
                      "email": "email-id.com",
                      "firstName": "my-first-name",
                      "lastName": "my-last-name"
                    },
                    "effectiveRoleIds": ["001"],
                    "groups": ["services", "analytics", null],
                    "state": "ENABLED"
                  }
                }""";

    listener.listen(message);
    ArgumentCaptor<Subscriber> argumentCaptor = ArgumentCaptor.forClass(Subscriber.class);

    verify(subscriberService, times(1)).handleUserSetEvent(argumentCaptor.capture());

    assertThat(argumentCaptor.getValue().getGroups()).isEqualTo(Set.of("services", "analytics"));
    assertThat(argumentCaptor.getValue().getPartnerId()).isEqualTo("1008941");
    assertThat(argumentCaptor.getValue().getUserType()).isEqualTo(UserType.COOPERATION);
  }

  @Test
  void shouldListenToNewsletterStatusChangedEventWhenNewStatusIsSubscribed()
      throws JsonProcessingException, SubscriberDoesNotExistException {
    String newsLetterChangedEvent =
        """
                    {
                      "eventId": "9a60261b-93a2-4602-9735-96f9366c5fb8",
                      "traceId": "def8ec70-70b3-464d-8ee3-82abf042a807",
                      "context": "neptune-usermanagement",
                      "type": "neptune-usermanagement.NEWSLETTER_STATUS_CHANGED",
                      "eventTime": "2020-10-12T07:17:00.077Z",
                      "data": {
                        "neptuneUserId": "0051q000003lHwdABC",
                        "status" : "SUBSCRIBED",
                        "newsletterAcceptedText" : "randomText",
                        "timestamp": "2022-09-12T07:17:00.077Z"
                      }
                    }
                """;

    listener.listen(newsLetterChangedEvent);

    ArgumentCaptor<NewsletterSubscription> argumentCaptor =
        ArgumentCaptor.forClass(NewsletterSubscription.class);
    verify(subscriberService)
        .updateNewsletterSubscriptionStatus(
            eq("0051q000003lHwdABC"),
            argumentCaptor.capture(),
            eq(Instant.parse("2020-10-12T07:17:00.077Z")));
    NewsletterSubscription expectedNewsletterSubscription =
        new NewsletterSubscription(
            NewsletterSubscriptionStatus.SUBSCRIBED,
            "randomText",
            Instant.parse("2022-09-12T07:17:00.077Z"));
    assertThat(argumentCaptor.getValue())
        .usingRecursiveComparison()
        .isEqualTo(expectedNewsletterSubscription);
  }

  @Test
  void shouldListenToNewsletterStatusChangedEventWhenNewStatusIsUnSubscribed()
      throws JsonProcessingException, SubscriberDoesNotExistException {
    String newsLetterChangedEvent =
        """
                    {
                      "eventId": "9a60261b-93a2-4602-9735-96f9366c5fb8",
                      "traceId": "def8ec70-70b3-464d-8ee3-82abf042a807",
                      "context": "neptune-usermanagement",
                      "type": "neptune-usermanagement.NEWSLETTER_STATUS_CHANGED",
                      "eventTime": "2020-10-12T07:17:00.077Z",
                      "data": {
                        "neptuneUserId": "629089ba391a524f0b687f4a",
                        "status" : "UNSUBSCRIBED",
                        "newsletterAcceptedText" : "randomText",
                        "timestamp": "2022-09-12T07:17:00.077Z"
                      }
                    }
                """;

    listener.listen(newsLetterChangedEvent);

    ArgumentCaptor<NewsletterSubscription> argumentCaptor =
        ArgumentCaptor.forClass(NewsletterSubscription.class);
    verify(subscriberService)
        .updateNewsletterSubscriptionStatus(
            eq("629089ba391a524f0b687f4a"),
            argumentCaptor.capture(),
            eq(Instant.parse("2020-10-12T07:17:00.077Z")));
    NewsletterSubscription expectedNewsletterSubscription =
        new NewsletterSubscription(
            NewsletterSubscriptionStatus.UNSUBSCRIBED,
            "randomText",
            Instant.parse("2022-09-12T07:17:00.077Z"));
    assertThat(argumentCaptor.getValue())
        .usingRecursiveComparison()
        .isEqualTo(expectedNewsletterSubscription);
  }

  @Test
  void shouldListenToNeptuneUserDeletedEvent()
      throws JsonProcessingException, SubscriberDoesNotExistException {
    String message =
        """
                {
                    "eventId": "8e77488d-047a-47d6-822a-c0977c00b7c9",
                    "traceId": "b83877c9-366f-48ad-ba13-eea8a8b19c7a",
                    "type": "neptune-usermanagement.USER_DELETED",
                    "context": "neptune-usermanagement",
                    "eventTime": "2022-05-27T09:16:43.543Z",
                    "data": {
                        "partnerId": "1007438",
                        "neptuneUserId": "629089ba391a524f0b687f4a",
                        "jellyfishUserId": null,
                        "username": "complaint@simulator.amazonses.com"
                    }
                }""";
    listener.listen(message);
    var captor = ArgumentCaptor.forClass(Requester.class);
    verify(subscriberService, times(1))
        .handleUserDeletedEvent(eq("629089ba391a524f0b687f4a"), captor.capture());
    assertThat(captor.getValue().getEventType()).isEqualTo(EventType.NEPTUNE_USER_DELETED);
  }
}
