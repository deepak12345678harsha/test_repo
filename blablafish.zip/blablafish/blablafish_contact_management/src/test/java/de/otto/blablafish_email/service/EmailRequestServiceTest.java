package de.otto.blablafish_email.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

import com.fasterxml.jackson.databind.ObjectMapper;
import de.otto.blablafish_contact_management.exception.BlaBlaFishException;
import de.otto.blablafish_contact_management.exception.TopicNotFoundException;
import de.otto.blablafish_contact_management.model.dto.UserPrincipal;
import de.otto.blablafish_contact_management.model.entity.Subscriber;
import de.otto.blablafish_contact_management.model.entity.Topic;
import de.otto.blablafish_contact_management.service.SubscriberService;
import de.otto.blablafish_contact_management.service.TopicService;
import de.otto.blablafish_contact_management.testDataConfig.SubscriberTestConfig;
import de.otto.blablafish_contact_management.testDataConfig.TopicTestBuilder;
import de.otto.blablafish_email.exception.EmailNotProcessableException;
import de.otto.blablafish_email.exception.FileUploadException;
import de.otto.blablafish_email.exception.MultiPartnerEmailException;
import de.otto.blablafish_email.exception.ValidationException;
import de.otto.blablafish_email.model.dto.PostEmailToInternalRequest;
import de.otto.blablafish_email.model.dto.PostEmailToPartnerRequest;
import de.otto.blablafish_email.model.dto.PostEmailToUserRequest;
import de.otto.blablafish_email.model.entity.EmailRequest;
import de.otto.blablafish_email.model.entity.EmailRequestStatus;
import de.otto.blablafish_email.model.entity.EmailRequester;
import de.otto.blablafish_email.respository.EmailRequestRepository;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Instant;
import java.util.*;
import org.assertj.core.api.Assertions;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;

@ExtendWith(MockitoExtension.class)
class EmailRequestServiceTest {
  private EmailRequestService emailRequestService;
  @Mock private TopicService topicService;
  @Mock private EmailRequestRepository emailRequestRepository;
  @Mock private SubscriberService subscriberService;
  @Mock private EmailPayloadValidationService validationService;
  @Mock private EmailAttachmentService emailAttachmentService;

  @BeforeEach
  public void setEmailService() {
    emailRequestService =
        new EmailRequestService(
            topicService,
            emailRequestRepository,
            subscriberService,
            validationService,
            emailAttachmentService,
            new ObjectMapper());
  }

  @Test
  void shouldReturnRequestIdWhenSendEmailToPartner()
      throws TopicNotFoundException, BlaBlaFishException {
    PostEmailToPartnerRequest emailRequestDto = createPostEmailRequest();
    Topic topic = createTopic(1);
    ObjectId userId = new ObjectId("629089ba391a524f0b687f4a");
    Subscriber user = insertSubscriber(userId);
    when(topicService.findByTopicId(1)).thenReturn(topic);
    doNothing().when(validationService).validate(anyMap(), anyMap(), eq(topic));
    when(subscriberService.getSubscribersByValidatingRolesAndPreferences("1", topic))
        .thenReturn(List.of(user));

    emailRequestService.sendEmailToPartner(
        emailRequestDto,
        new UserPrincipal("subject", "client-id", "1", Collections.emptySet(), "first"));
    verify(emailRequestRepository).insert(any(EmailRequest.class));
  }

  @Test
  void shouldThrowTopicNotFoundWhenSendEmailToPartnerForInvalidTopic()
      throws BlaBlaFishException, TopicNotFoundException {
    PostEmailToPartnerRequest emailRequestDto = createPostEmailRequest();
    when(topicService.findByTopicId(1))
        .thenThrow(new TopicNotFoundException("Topic with id 1 does not exists"));
    try {
      emailRequestService.sendEmailToPartner(
          emailRequestDto,
          new UserPrincipal("subject", "client-id", "1", Collections.emptySet(), "first"));
    } catch (TopicNotFoundException exception) {
      assertEquals("Topic with id 1 does not exists", exception.getMessage());
      verify(emailRequestRepository, never()).insert(any(EmailRequest.class));
    }
  }

  @Test
  void shouldThrowValidationExceptionWhenSendEmailToPartnerForNoSubscribers()
      throws TopicNotFoundException, BlaBlaFishException {
    PostEmailToPartnerRequest emailRequestDto = createPostEmailRequest();
    Topic topic = createTopic(1);
    insertSubscriber(new ObjectId("629089ba391a524f0b687f4a"));
    when(topicService.findByTopicId(1)).thenReturn(topic);
    doNothing().when(validationService).validate(anyMap(), anyMap(), eq(topic));
    when(subscriberService.getSubscribersByValidatingRolesAndPreferences("1", topic))
        .thenReturn(Collections.emptyList());

    try {
      emailRequestService.sendEmailToPartner(
          emailRequestDto,
          new UserPrincipal("subject", "client-id", "1", Collections.emptySet(), "first"));
    } catch (ValidationException exception) {
      assertEquals(
          "Validation error: Reason: FOUND_NO_USER_SUBSCRIBED_TO_TOPIC | Description: null",
          exception.getMessage());
      verify(emailRequestRepository, never()).insert(any(EmailRequest.class));
    }
  }

  @Test
  void shouldReturnRequestIdWhenSendInternalEmailToUser()
      throws BlaBlaFishException, TopicNotFoundException {
    var request = createPostInternalEmailToUserRequest();
    doNothing().when(topicService).validateTopicExists(1);

    emailRequestService.sendInternalEmail(
        request, new UserPrincipal("subject", "client-id", "1", Collections.emptySet(), "first"));
    verify(emailRequestRepository).insert(any(EmailRequest.class));
  }

  @Test
  void shouldThrowTopicNotFoundWhenSendInternalEmailToUser()
      throws BlaBlaFishException, TopicNotFoundException {
    var request = createPostInternalEmailToUserRequest();
    doThrow(new TopicNotFoundException("Topic Not Found"))
        .when(topicService)
        .validateTopicExists(1);

    try {
      emailRequestService.sendInternalEmail(
          request, new UserPrincipal("subject", "client-id", "1", Collections.emptySet(), "first"));
    } catch (TopicNotFoundException e) {
      assertEquals("Topic Not Found", e.getMessage());
    }
    verify(emailRequestRepository, never()).insert(any(EmailRequest.class));
  }

  @Test
  void shouldGetEmailRequestForGivenRequestId() {
    ObjectId requestId = new ObjectId("629089ba391a524f0b687f4a");
    EmailRequest emailRequest = createEmailRequest(requestId);
    when(emailRequestRepository.findById(requestId)).thenReturn(Optional.of(emailRequest));
    emailRequestService.getRequestById("629089ba391a524f0b687f4a");
    verify(emailRequestRepository).findById(requestId);
  }

  @Test
  void shouldThrowGetEmailRequestForGivenRequestId() {
    ObjectId requestId = new ObjectId("629089ba391a524f0b687f4a");
    EmailRequest emailRequest = createEmailRequest(requestId);
    when(emailRequestRepository.findById(requestId)).thenReturn(Optional.ofNullable(emailRequest));
    emailRequestService.getRequestById("629089ba391a524f0b687f4a");
    verify(emailRequestRepository).findById(requestId);
  }

  @Test
  void shouldSendMailsToMultiplePartners()
      throws IOException, MultiPartnerEmailException, FileUploadException, TopicNotFoundException,
          EmailNotProcessableException {
    var partnerIds = List.of("1", "2");
    var inputStream = new FileInputStream("src/test/resources/uploadForEmail.txt");
    var fileToUpload =
        new MockMultipartFile(
            "uploadForEmail.txt",
            "uploadForEmail.txt",
            MediaType.APPLICATION_OCTET_STREAM_VALUE,
            inputStream);
    var userPrincipal =
        new UserPrincipal("subject", "clientId", "partnerId", Collections.emptySet(), "userName");
    var subscriber = insertSubscriber(new ObjectId());
    var topic = createTopic(9999);

    when(subscriberService.getUserByEmail(anyString())).thenReturn(Optional.of(subscriber));
    when(emailAttachmentService.upload(any(), anyString(), anyString())).thenReturn("12345");
    when(topicService.findByTopicId(9999)).thenReturn(topic);
    doNothing().when(validationService).validate(anyMap(), eq(null), eq(topic));
    when(subscriberService.getSubscribersByValidatingRolesAndPreferences("1", topic))
        .thenReturn(List.of(subscriber));
    when(emailRequestRepository.insertAll(anyList())).thenReturn(List.of("emailRequestId1"));

    var response =
        emailRequestService.sendEmailToPartners(
            partnerIds, "emailBodyText", fileToUpload, userPrincipal);
    Assertions.assertThat(response.getAttachmentId()).isEqualTo("12345");
    Assertions.assertThat(response.getEmailRequestIds()).isEqualTo(List.of("emailRequestId1"));
  }

  private EmailRequest createEmailRequest(ObjectId emailRequestId) {
    return EmailRequest.builder()
        .topicId(1)
        .requestId(emailRequestId)
        .createdAt(Instant.now())
        .requester(EmailRequester.of("client-id", "subject"))
        .payload(EmailRequest.encryptPayload(new Document()))
        .recipients(Collections.emptyList())
        .status(EmailRequestStatus.ACCEPTED)
        .build();
  }

  private PostEmailToPartnerRequest createPostEmailRequest() {
    final Map<String, Object> payload = Map.of("test", "yes");
    return PostEmailToPartnerRequest.builder()
        .topicId(1)
        .partnerId("1")
        .payload(payload)
        .internalPayload(Map.of())
        .build();
  }

  @Test
  void shouldThrowTopicNotFoundExceptionWhenInvalidTopicForUserMails()
      throws TopicNotFoundException {
    var postEmailToUserRequest = createPostEmailToUserRequest();
    when(topicService.findByTopicId(postEmailToUserRequest.getTopicId()))
        .thenThrow(TopicNotFoundException.class);

    assertThrows(
        TopicNotFoundException.class,
        () ->
            emailRequestService.sendEmailToUser(postEmailToUserRequest, mock(UserPrincipal.class)));
  }

  private PostEmailToUserRequest createPostEmailToUserRequest() {
    final Map<String, Object> payload = Map.of("test", "yes");
    return PostEmailToUserRequest.builder()
        .topicId(1)
        .partnerId("1")
        .payload(payload)
        .firstName("firstName")
        .lastName("lastName")
        .toAddress("testemail@address.com")
        .build();
  }

  private PostEmailToInternalRequest createPostInternalEmailToUserRequest() {
    final Map<String, Object> payload = Map.of("test", "yes");
    return PostEmailToInternalRequest.builder()
        .topicId(1)
        .payload(payload)
        .firstName("firstName")
        .lastName("lastName")
        .toAddress("testemail@address.com")
        .build();
  }

  private Topic createTopic(int topicId) {
    return Topic.builder()
        .id(topicId)
        .name("topic 2")
        .description("description 2")
        .mandatorySubscriberRoles(Arrays.asList("mandatory role 3", "mandatory role 4"))
        .emailSubject("")
        .emailPlainTextTemplate("")
        .emailHtmlTemplate("")
        .emailSchema(new Document())
        .options(TopicTestBuilder.topicOptionsBuilder().build())
        .build();
  }

  private Subscriber insertSubscriber(ObjectId userId) {
    return new SubscriberTestConfig().subscriberBuilder().userId(userId).build();
  }
}
