package de.otto.blablafish_email.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import de.otto.blablafish_contact_management.service.SubscriberService;
import de.otto.blablafish_email.exception.EmailBlacklistNotFoundException;
import de.otto.blablafish_email.model.dto.blacklist.EmailBlacklistDTO;
import de.otto.blablafish_email.model.entity.EmailBlacklist;
import de.otto.blablafish_email.publishers.SNSPublisher;
import de.otto.blablafish_email.respository.EmailBlacklistRepository;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class EmailBlacklistServiceTest {

  EmailBlacklistService service;

  @Mock EmailBlacklistRepository emailBlacklistRepository;

  @Mock SubscriberService subscriberService;

  @Mock SNSPublisher snsPublisher;

  @BeforeEach
  public void setEmailBlacklistService() {
    service = new EmailBlacklistService(emailBlacklistRepository, subscriberService, snsPublisher);
  }

  @Test
  void shouldGetBlacklistByEmailAddress() throws EmailBlacklistNotFoundException {
    String email = "email@otto.com";
    EmailBlacklist savedBlacklist =
        new EmailBlacklist(
            new ObjectId("62bec37d21d8c96a1dff30cb"),
            EmailBlacklist.encryptEmail(email),
            Collections.emptyList());
    when(emailBlacklistRepository.findByEmail(email))
        .thenReturn(Optional.of(List.of(savedBlacklist)));

    List<EmailBlacklistDTO> emailBlacklists = service.getByEmailAddress(email);

    assertThat(emailBlacklists)
        .usingRecursiveComparison()
        .isEqualTo(List.of(EmailBlacklistDTO.from(savedBlacklist)));
    verify(emailBlacklistRepository).findByEmail(email);
  }

  @Test
  void shouldThrowEmailBlacklistDoesNotExistExceptionWhenBlacklistDoesnotExistForEmailAddress() {
    String email = "email@otto.com";
    when(emailBlacklistRepository.findByEmail(email)).thenReturn(Optional.empty());

    EmailBlacklistNotFoundException ex =
        assertThrows(EmailBlacklistNotFoundException.class, () -> service.getByEmailAddress(email));
    assertEquals(
        "Email blacklist with email address: email@otto.com does not exists", ex.getMessage());
  }
}
