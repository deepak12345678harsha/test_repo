package de.otto.blablafish_contact_management.listeners;

import static org.mockito.Mockito.*;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import de.otto.blablafish_contact_management.service.SubscriberActionService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class SubscriberActionsMongoDBTriggerListenerTest {

  private final ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());

  @Mock private SubscriberActionService subscriberActionService;

  private SubscriberActionsMongoDBTriggerListener actionsMongoDBTriggerListener;

  @BeforeEach
  void setUp() {
    actionsMongoDBTriggerListener =
        new SubscriberActionsMongoDBTriggerListener(subscriberActionService, objectMapper);
  }

  @Test
  void shouldExecuteAnAction() {
    String subscriberId = "62bec37d21d8c96a1dff30cb";
    String eventAsString =
        "{\"id\":\"event-1\",\"source\":\"mongodb/trigger/sub1234\",\"account\":\"account1\",\"time\":1234.587000000,\"resources\":[\"aws/trigger/sub1234\"],\"detail\":{\"operationType\":\"UPDATE\",\"clusterTime\":{\"i\":76554,\"t\":1234587},\"documentKey\":{\"_id\":\""
            + subscriberId
            + "\"},\"updateDescription\":{\"removedFields\":null,\"updatedFields\":null,\"truncatedArrays\":null},\"ns\":{\"db\":\"contact_management_db\",\"coll\":\"subscribers\"}},\"detail-type\":\"detailType\"}";

    doNothing().when(subscriberActionService).executeAction(subscriberId);
    actionsMongoDBTriggerListener.listenToSubscribersMongoDbTriggersForActions(eventAsString);

    verify(subscriberActionService, times(1)).executeAction(subscriberId);
  }
}
