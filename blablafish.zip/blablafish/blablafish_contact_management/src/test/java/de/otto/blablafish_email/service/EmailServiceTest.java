package de.otto.blablafish_email.service;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import de.otto.blablafish_email.exception.EmailNotFoundException;
import de.otto.blablafish_email.model.dto.mail.EmailDTO;
import de.otto.blablafish_email.model.dto.mail.EmailStatusHistoryEntryDTO;
import de.otto.blablafish_email.model.entity.Email;
import de.otto.blablafish_email.model.entity.EmailStatus;
import de.otto.blablafish_email.model.entity.EmailStatusHistoryEntry;
import de.otto.blablafish_email.respository.EmailRepository;
import de.otto.blablafish_email.testDataConfig.EmailDTOTestBuilder;
import de.otto.blablafish_email.testDataConfig.EmailTestConfig;
import java.time.Instant;
import java.util.List;
import java.util.Optional;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;

class EmailServiceTest {

  EmailRepository emailRepository = mock(EmailRepository.class);

  EmailService emailService = new EmailService(emailRepository);

  @Test
  void shouldReturnEmailWhenExists() throws EmailNotFoundException {
    String emailId = "62bec37d21d8c96a1dff30cb";
    Instant historyTimeStamp = Instant.now().minusMillis(60000);
    Email email =
        new EmailTestConfig()
            .emailStatusHistoryEntry(
                List.of(new EmailStatusHistoryEntry(EmailStatus.READY_TO_SEND, historyTimeStamp)))
            .build();
    EmailStatusHistoryEntryDTO emailStatusHistoryEntryDTO =
        new EmailStatusHistoryEntryDTO(EmailStatus.READY_TO_SEND, historyTimeStamp);
    EmailDTO expectedEmail =
        new EmailDTOTestBuilder()
            .emailStatusHistoryEntryDTO(List.of(emailStatusHistoryEntryDTO))
            .build();
    when(emailRepository.findById(emailId)).thenReturn(Optional.of(email));

    EmailDTO actualEmail = emailService.getEmailById(emailId);

    Assertions.assertThat(actualEmail).usingRecursiveComparison().isEqualTo(expectedEmail);
  }

  @Test
  void shouldThrowEmailNotFoundExceptionWhenEmailDoesNotExists() {
    String emailId = "62bec37d21d8c96a1dff30cb";
    when(emailRepository.findById(emailId)).thenReturn(Optional.empty());
    assertThrows(EmailNotFoundException.class, () -> emailService.getEmailById(emailId));
  }
}
