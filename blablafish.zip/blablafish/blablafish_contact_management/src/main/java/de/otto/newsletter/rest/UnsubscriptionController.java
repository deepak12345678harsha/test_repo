package de.otto.newsletter.rest;

import static org.springframework.http.HttpStatus.OK;

import com.amazonaws.util.IOUtils;
import de.otto.blablafish_contact_management.service.SubscriberService;
import de.otto.newsletter.exception.JWTActionNotFoundException;
import de.otto.newsletter.exception.RSAKeyPairDoesNotExistException;
import de.otto.newsletter.model.JWTActions;
import de.otto.newsletter.service.JWTService;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import java.io.IOException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping({"/v1/subscribers/unsubscribe-newsletter", "/v1/subscribers/unsubscribe"})
public class UnsubscriptionController {

  private final Resource newsletterUnsubscriptionPage;

  private final Resource communicationUnsubscriptionPage;

  private final Resource newsletterUnsubscriptionErrorPage;

  private final Resource communicationUnsubscriptionErrorPage;

  private final JWTService jwtService;

  private final SubscriberService subscriberService;

  public UnsubscriptionController(
      JWTService jwtService,
      SubscriberService subscriberService,
      @Value("classpath:static/newsletter/unsubscribe.html") Resource newsletterUnsubscriptionPage,
      @Value("classpath:static/communication/unsubscribe.html")
          Resource communicationUnsubscriptionPage,
      @Value("classpath:static/newsletter/unsubscribe_error.html")
          Resource newsletterUnsubscriptionErrorPage,
      @Value("classpath:static/communication/unsubscribe_error.html")
          Resource communicationUnsubscriptionErrorPage) {
    this.jwtService = jwtService;
    this.subscriberService = subscriberService;
    this.newsletterUnsubscriptionPage = newsletterUnsubscriptionPage;
    this.communicationUnsubscriptionPage = communicationUnsubscriptionPage;
    this.newsletterUnsubscriptionErrorPage = newsletterUnsubscriptionErrorPage;
    this.communicationUnsubscriptionErrorPage = communicationUnsubscriptionErrorPage;
  }

  @GetMapping(produces = MediaType.TEXT_HTML_VALUE)
  public ResponseEntity<String> handleUnsubscriptionByJWT(
      @RequestParam String key, @RequestParam(required = false) String type) throws IOException {
    Resource errorPage = newsletterUnsubscriptionErrorPage;
    try {
      if (type == null || "newsletter".equalsIgnoreCase(type)) {
        unsubscribeNewsletter(jwtService.getClaims(key));
        return responseEntityOf(newsletterUnsubscriptionPage);
      } else if ("communication".equalsIgnoreCase(type)) {
        errorPage = communicationUnsubscriptionErrorPage;
        unsubscribeCommunication(jwtService.getClaims(key));
        return responseEntityOf(communicationUnsubscriptionPage);
      }
    } catch (ExpiredJwtException e) {
      log.error("JWT Expired for Unsubscribing {}", type);
    } catch (JWTActionNotFoundException | RSAKeyPairDoesNotExistException e) {
      log.error(e.getMessage());
    } catch (Exception e) {
      log.error("Exception in Unsubscribing {}: {}", type, e.getMessage());
    }
    return responseEntityOf(errorPage);
  }

  private ResponseEntity<String> responseEntityOf(Resource responsePage) throws IOException {
    return ResponseEntity.status(OK).body(IOUtils.toString(responsePage.getInputStream()));
  }

  private void unsubscribeCommunication(Claims claims) {
    jwtService.verifyClaimAction(claims, JWTActions.UNSUBSCRIBE_COMMUNICATIONS);
    log.info("ExpiresAt: {}, action: {}", claims.getExpiration(), claims.get("action"));
    subscriberService.unsubscribeCommunication(claims.getSubject());
  }

  private void unsubscribeNewsletter(Claims claims) {
    jwtService.verifyClaimAction(claims, JWTActions.UNSUBSCRIBE_NEWSLETTER);
    log.info("ExpiresAt: {}, action: {}", claims.getExpiration(), claims.get("action"));
    subscriberService.unsubscribeNewsletter(claims.getSubject());
  }
}
