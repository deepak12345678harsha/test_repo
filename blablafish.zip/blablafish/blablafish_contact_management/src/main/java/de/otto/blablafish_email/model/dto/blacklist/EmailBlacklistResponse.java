package de.otto.blablafish_email.model.dto.blacklist;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;

@NoArgsConstructor
@AllArgsConstructor
@Getter
public class EmailBlacklistResponse {

  @NonNull private String id;

  private String userFirstName;

  private String userLastName;

  @NonNull private String emailAddress;

  public EmailBlacklistResponse(@NonNull String id, @NonNull String emailAddress) {
    this.id = id;
    this.emailAddress = emailAddress;
    this.userFirstName = null;
    this.userLastName = null;
  }
}
