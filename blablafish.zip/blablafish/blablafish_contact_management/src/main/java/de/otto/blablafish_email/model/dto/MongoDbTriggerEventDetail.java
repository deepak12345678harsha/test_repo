package de.otto.blablafish_email.model.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@JsonIgnoreProperties(ignoreUnknown = true)
public class MongoDbTriggerEventDetail {

  private String operationType;

  private ClusterTime clusterTime;

  private DocumentKey documentKey;

  private UpdateDescription updateDescription;

  private MongoNamespace ns;
}
