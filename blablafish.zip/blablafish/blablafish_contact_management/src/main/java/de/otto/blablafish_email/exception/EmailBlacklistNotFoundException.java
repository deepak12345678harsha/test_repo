package de.otto.blablafish_email.exception;

import de.otto.blablafish_contact_management.exception.BlaBlaFishError;
import de.otto.blablafish_contact_management.exception.BlaBlaFishException;

public class EmailBlacklistNotFoundException extends BlaBlaFishException {
  public EmailBlacklistNotFoundException(String message) {
    super(message, BlaBlaFishError.EMAIL_BLACKLIST_NOT_FOUND_ERROR);
  }
}
