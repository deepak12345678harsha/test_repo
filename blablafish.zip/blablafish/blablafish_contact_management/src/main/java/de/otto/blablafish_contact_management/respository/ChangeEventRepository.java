package de.otto.blablafish_contact_management.respository;

import de.otto.blablafish_contact_management.model.entity.ChangeEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

@Repository
@Slf4j
public class ChangeEventRepository {
  private final MongoTemplate mongoTemplate;

  public ChangeEventRepository(MongoTemplate mongoTemplate) {
    this.mongoTemplate = mongoTemplate;
  }

  public void insert(ChangeEvent changeEvent) {
    mongoTemplate.insert(changeEvent);
  }
}
