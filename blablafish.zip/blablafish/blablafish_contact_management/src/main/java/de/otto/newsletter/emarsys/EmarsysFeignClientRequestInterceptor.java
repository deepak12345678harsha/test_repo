package de.otto.newsletter.emarsys;

import feign.RequestInterceptor;
import feign.RequestTemplate;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Random;
import javax.xml.bind.DatatypeConverter;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.digest.DigestUtils;

public class EmarsysFeignClientRequestInterceptor implements RequestInterceptor {

  private static final String DATE_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ssZ";
  private final String emarsysApiUsername;
  private final String emarsysApiPassword;

  public EmarsysFeignClientRequestInterceptor(
      String emarsysApiUsername, String emarsysApiPassword) {
    this.emarsysApiUsername = emarsysApiUsername;
    this.emarsysApiPassword = emarsysApiPassword;
  }

  @Override
  public void apply(RequestTemplate requestTemplate) {
    requestTemplate.removeHeader("X-WSSE");
    requestTemplate.header("X-WSSE", generateSignature());
  }

  private String generateSignature() {
    String timestamp = getUTCTimestamp();
    String nonce = getNonce();
    String digest = getPasswordDigest(nonce, timestamp);
    return String.format(
        "UsernameToken Username=\"%s\", PasswordDigest=\"%s\", Nonce=\"%s\", Created=\"%s\"",
        emarsysApiUsername, digest, nonce, timestamp);
  }

  private String getUTCTimestamp() {
    DateTimeFormatter dateTimeFormatter =
        DateTimeFormatter.ofPattern(DATE_TIME_FORMAT).withZone(ZoneOffset.UTC);

    return dateTimeFormatter.format(Instant.now());
  }

  private String getNonce() {
    byte[] nonceBytes = new byte[16];
    new Random().nextBytes(nonceBytes);
    return Hex.encodeHexString(nonceBytes);
  }

  private String getPasswordDigest(String nonce, String timestamp) {
    String hashedString = String.format("%s%s%s", nonce, timestamp, emarsysApiPassword);
    String sha1CheckSum = DigestUtils.sha1Hex(hashedString.getBytes(StandardCharsets.UTF_8));
    return DatatypeConverter.printBase64Binary(sha1CheckSum.getBytes(StandardCharsets.UTF_8));
  }
}
