package de.otto.blablafish_contact_management.listeners;

import static de.otto.blablafish_contact_management.model.entity.Subscriber.encryptEmail;
import static de.otto.blablafish_contact_management.model.entity.Subscriber.encryptFirstName;
import static de.otto.blablafish_contact_management.model.entity.Subscriber.encryptLastName;
import static de.otto.blablafish_email.utils.Constants.EVENT_ID;
import static de.otto.blablafish_email.utils.Constants.EVENT_LABEL;
import static de.otto.blablafish_email.utils.Constants.SERVICE_NAME;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import de.otto.blablafish_contact_management.cdc.EventMessageValidator;
import de.otto.blablafish_contact_management.exception.SubscriberDoesNotExistException;
import de.otto.blablafish_contact_management.model.dto.DeepSeaEvent;
import de.otto.blablafish_contact_management.model.dto.EventType;
import de.otto.blablafish_contact_management.model.dto.UserDeleteDTO;
import de.otto.blablafish_contact_management.model.dto.UserSetDTO;
import de.otto.blablafish_contact_management.model.entity.NewsletterSubscription;
import de.otto.blablafish_contact_management.model.entity.NewsletterSubscriptionStatus;
import de.otto.blablafish_contact_management.model.entity.Requester;
import de.otto.blablafish_contact_management.model.entity.Status;
import de.otto.blablafish_contact_management.model.entity.Subscriber;
import de.otto.blablafish_contact_management.model.entity.UserType;
import de.otto.blablafish_contact_management.service.SubscriberService;
import de.otto.newsletter.model.dto.NewsletterStatusDTO;
import io.awspring.cloud.messaging.config.annotation.NotificationMessage;
import io.awspring.cloud.messaging.listener.SqsMessageDeletionPolicy;
import io.awspring.cloud.messaging.listener.annotation.SqsListener;
import java.time.Instant;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.bson.types.ObjectId;
import org.jboss.logging.MDC;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

@Slf4j
@Component
public class UserManagementEventsListener {

  private final SubscriberService subscriberService;
  private final ObjectMapper objectMapper;

  public UserManagementEventsListener(
      SubscriberService subscriberService, ObjectMapper objectMapper) {
    this.subscriberService = subscriberService;
    this.objectMapper = objectMapper;
  }

  @SqsListener(
      value = "${userManagementEvents.queueUrl}",
      deletionPolicy = SqsMessageDeletionPolicy.ON_SUCCESS)
  void listen(@NotificationMessage String message) throws JsonProcessingException {

    try {
      EventMessageValidator.validateMessage(message);
      final DeepSeaEvent deepSeaEvent = objectMapper.readValue(message, DeepSeaEvent.class);
      MDC.put(SERVICE_NAME, "contact-management");
      MDC.put(EVENT_LABEL, deepSeaEvent.getType());
      MDC.put(EVENT_ID, deepSeaEvent.getEventId());
      log.info("DeepSeaEvent Message received. EventType: {} ", deepSeaEvent.getType());

      switch (deepSeaEvent.getType()) {
        case NEPTUNE_USER_SET -> handleUserSetEvent(deepSeaEvent);
        case NEPTUNE_USER_DELETED -> handleUserDeletedEvent(deepSeaEvent);
        case NEWSLETTER_STATUS_CHANGED -> handleNewsletterStatusChangedEvent(deepSeaEvent);
        default -> log.warn(
            "Invalid event type: {}, User management user-event ignored", deepSeaEvent.getType());
      }
    } catch (Exception e) {
      JsonNode event = objectMapper.readValue(message, JsonNode.class);
      String errorMessage =
          String.format("Failed to process event: %s Error: %s", event.get("type"), e.getMessage());
      log.error(errorMessage);
      // TODO: verify if message goes in DLQ [Integration test]
      throw new RuntimeException(errorMessage);
    } finally {
      MDC.remove(SERVICE_NAME);
      MDC.remove(EVENT_LABEL);
      MDC.remove(EVENT_ID);
    }
  }

  private void handleNewsletterStatusChangedEvent(DeepSeaEvent deepSeaEvent)
      throws SubscriberDoesNotExistException, JsonProcessingException {
    NewsletterStatusDTO newsletterStatusDTO =
        objectMapper.convertValue(deepSeaEvent.getData(), NewsletterStatusDTO.class);
    String subscriberId = newsletterStatusDTO.getNeptuneUserId();

    MDC.put("subscriberId", subscriberId);
    log.info("Received NEWSLETTER_STATUS_CHANGED for subscriberId : {}", subscriberId);
    NewsletterSubscription updatedSubscriptionStatus =
        mapToNewsletterSubscription(newsletterStatusDTO);
    subscriberService.updateNewsletterSubscriptionStatus(
        subscriberId, updatedSubscriptionStatus, deepSeaEvent.getEventTime());
    MDC.remove("subscriberId");
  }

  private void handleUserSetEvent(DeepSeaEvent deepSeaEvent)
      throws SubscriberDoesNotExistException {
    UserSetDTO userDTO = objectMapper.convertValue(deepSeaEvent.getData(), UserSetDTO.class);
    log.info("Received USER_SET for neptuneUserId: {}", userDTO.getNeptuneUserId());
    validate(userDTO);
    Subscriber user = mapToUserSetDTO(userDTO, deepSeaEvent.getEventTime());
    subscriberService.handleUserSetEvent(user);
  }

  private void handleUserDeletedEvent(DeepSeaEvent deepSeaEvent)
      throws SubscriberDoesNotExistException, JsonProcessingException {
    UserDeleteDTO userDTO = objectMapper.convertValue(deepSeaEvent.getData(), UserDeleteDTO.class);
    log.info("Received USER_DELETED for neptuneUserId: {}", userDTO.getNeptuneUserId());
    validate(userDTO);
    subscriberService.handleUserDeletedEvent(
        userDTO.getNeptuneUserId(), Requester.ofEventType(EventType.NEPTUNE_USER_DELETED));
  }

  private NewsletterSubscription mapToNewsletterSubscription(
      NewsletterStatusDTO newsletterStatusDTO) {
    NewsletterSubscriptionStatus status =
        NewsletterSubscriptionStatus.valueOf(newsletterStatusDTO.getStatus());
    return new NewsletterSubscription(
        status,
        newsletterStatusDTO.getNewsletterAcceptedText(),
        newsletterStatusDTO.getTimestamp());
  }

  private Subscriber mapToUserSetDTO(UserSetDTO userSetDTO, Instant eventTime) {
    Set<String> groups = userSetDTO.getGroups();
    groups.remove(null);
    return Subscriber.builder()
        .userId(new ObjectId(userSetDTO.getNeptuneUserId()))
        .partnerId(userSetDTO.getPartnerId())
        .firstName(encryptFirstName(userSetDTO.getContact().getFirstName()))
        .lastName(encryptLastName(userSetDTO.getContact().getLastName()))
        .email(encryptEmail(userSetDTO.getContact().getEmail()))
        .effectiveRoleIds(userSetDTO.getEffectiveRoleIds())
        .groups(groups)
        .status(Status.valueOf(userSetDTO.getState().name()))
        .userType(UserType.valueOf(userSetDTO.getUserType().name()))
        .updatedAt(Instant.now())
        .lastUpdatedBy(Requester.ofEventType(EventType.NEPTUNE_USER_SET))
        .eventTime(eventTime)
        .markedForDeletion(false)
        .build();
  }

  private void validate(UserSetDTO userSetDTO) {
    Assert.notNull(userSetDTO, "User set should not be null");
  }

  private void validate(UserDeleteDTO userDeleteDTO) {
    Assert.notNull(userDeleteDTO, "User delete should not be null");
  }
}
