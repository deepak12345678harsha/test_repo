package de.otto.blablafish_email.model.dto;

import de.otto.blablafish_email.model.entity.EmailRecipient;
import de.otto.blablafish_email.model.entity.EmailStatusHistoryEntry;
import lombok.*;
import org.springframework.lang.NonNull;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Getter
@Builder(access = AccessLevel.PUBLIC)
public class EmailRecipientDTO {

  @NonNull private String emailId;
  @NonNull private String firstName;
  @NonNull private String lastName;
  @NonNull private String email;
  @NonNull private EmailStatusHistoryEntry emailStatus;

  @NonNull private String partnerId;

  public static EmailRecipientDTO of(EmailRecipient recipient) {
    return EmailRecipientDTO.builder()
        .emailId(recipient.getEmailId())
        .firstName(recipient.getFirstName().getValue())
        .lastName(recipient.getLastName().getValue())
        .email(recipient.getEmailAddress().getValue())
        .emailStatus(recipient.getEmailStatusHistoryEntry())
        .partnerId(recipient.getPartnerId())
        .build();
  }
}
