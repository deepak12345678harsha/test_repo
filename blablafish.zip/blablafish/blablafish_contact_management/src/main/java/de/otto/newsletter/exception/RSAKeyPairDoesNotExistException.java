package de.otto.newsletter.exception;

public class RSAKeyPairDoesNotExistException extends RuntimeException {

  public RSAKeyPairDoesNotExistException(String keyId) {
    super("RSA Key Pair Doesn't Exist for the keyId: " + keyId);
  }
}
