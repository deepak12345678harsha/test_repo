package de.otto.blablafish_contact_management.respository;

import de.otto.blablafish_contact_management.model.entity.Topic;
import java.util.List;
import java.util.Set;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface TopicRepository extends MongoRepository<Topic, Integer> {
  @Query("{ 'mandatorySubscriberRoles' : ?0 }")
  List<Topic> findAllByMandatorySubscriberRole(String role);

  @Query(
      value =
          """
            {$and: [
                {'options.displayOnEmailConfigUI': ?0},
                {'options.canUnsubscribe': ?1},
                {$or: [
                    {mandatorySubscriberRoles: {$eq: []}},
                    {mandatorySubscriberRoles: {$in: ?2}}
                      ]}
                 ]}
                 """)
  List<Topic> findAll(
      boolean displayOnEmailConfigUI,
      boolean canUnsubscribe,
      Set<String> subscriberEffectiveRoleIds);

  @Query(
      value =
          """
                    {$and: [
                        {'options.displayOnEmailConfigUI': ?0},
                        {$or: [
                            {mandatorySubscriberRoles: {$eq: []}},
                            {mandatorySubscriberRoles: {$in: ?1}}
                              ]}
                         ]}
                         """)
  List<Topic> findAll(boolean displayOnEmailConfigUI, Set<String> subscriberEffectiveRoleIds);
}
