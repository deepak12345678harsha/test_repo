package de.otto.blablafish_contact_management.model.encryption;

import org.bson.BsonBinary;
import org.bson.BsonValue;

public class EncryptedByteArray extends EncryptedField<byte[]> {
  public EncryptedByteArray(byte[] value, String keyAltName, Boolean isSearchable) {
    super(value, keyAltName, isSearchable);
  }

  public EncryptedByteArray(byte[] value, BsonBinary bsonBinary) {
    super(value, bsonBinary);
  }

  @Override
  public BsonValue toBsonValue() {
    return getValue() == null ? null : new BsonBinary(getValue());
  }
}
