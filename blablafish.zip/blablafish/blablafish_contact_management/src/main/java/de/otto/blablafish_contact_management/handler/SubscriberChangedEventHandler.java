package de.otto.blablafish_contact_management.handler;

import com.fasterxml.jackson.core.JsonProcessingException;
import de.otto.blablafish_contact_management.respository.SubscriberChangeEntryRepository;
import de.otto.blablafish_email.model.dto.MongoDbTriggerEvent;
import de.otto.newsletter.model.entity.SubscriberChangeEntry;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.bson.Document;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class SubscriberChangedEventHandler {

  private static final int EXPIRATION_TIME_IN_DAYS = 4 * 365;

  private final SubscriberEventIdentifierFactory subscriberEventIdentifierFactory;

  private final SubscriberChangeEntryRepository subscriberChangeEntryRepository;

  public void handleEvent(String eventAsString, MongoDbTriggerEvent event, String subscriberId)
      throws JsonProcessingException {
    var subscriberEventIdentifierOptional = subscriberEventIdentifierFactory.identifiedEvent(event);

    if (subscriberEventIdentifierOptional.isEmpty()) {
      log.info(
          "Subscriber change event with id {} is ignored as it could not be identified",
          event.getId());
      return;
    }

    var identifier = subscriberEventIdentifierOptional.get();
    var subscriberChangeEntry =
        SubscriberChangeEntry.of(
            subscriberId,
            identifier.getEventType(event),
            identifier.getSubscriberUpdatedTime(event),
            identifier.getEventTime(event),
            getExpirationTime(),
            Document.parse(eventAsString));
    addSubscriberChangeEntry(subscriberChangeEntry);
  }

  private void addSubscriberChangeEntry(SubscriberChangeEntry subscriberChangeEntry) {
    log.info("adding SubscriberChanged Entry : {}", subscriberChangeEntry);
    if (subscriberChangeEntryRepository.exists(
        subscriberChangeEntry.getSubscriberId(),
        subscriberChangeEntry.getSubscriberChangeEventType(),
        subscriberChangeEntry.getSubscriberChangeTime())) {
      log.info(
          "SubscriberChangedEventHandler : SubscriberChangeEntry entry with same values already exist. Skipping this duplicate entry {}",
          subscriberChangeEntry);
      return;
    }
    subscriberChangeEntryRepository.insert(subscriberChangeEntry);
    log.info("Added SubscriberChanged Entry");
  }

  private Instant getExpirationTime() {
    return Instant.now().plus(EXPIRATION_TIME_IN_DAYS, ChronoUnit.DAYS);
  }
}
