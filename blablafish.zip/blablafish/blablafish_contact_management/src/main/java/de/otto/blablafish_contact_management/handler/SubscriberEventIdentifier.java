package de.otto.blablafish_contact_management.handler;

import de.otto.blablafish_email.model.dto.MongoDbTriggerEvent;
import de.otto.newsletter.model.entity.SubscriberChangeEventType;
import java.time.Instant;

public interface SubscriberEventIdentifier {
  boolean canIdentifyEvent(MongoDbTriggerEvent event);

  Instant getEventTime(MongoDbTriggerEvent event);

  SubscriberChangeEventType getEventType(MongoDbTriggerEvent event);

  Instant getSubscriberUpdatedTime(MongoDbTriggerEvent event);
}
