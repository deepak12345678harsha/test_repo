package de.otto.blablafish_email.model.dto.ses;

import static de.otto.blablafish_email.utils.Constants.GENERAL_SOFT_BOUNCE_SUB_TYPE;
import static de.otto.blablafish_email.utils.Constants.SOFT_BOUNCE_TYPE;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.springframework.lang.NonNull;
import org.springframework.lang.Nullable;

@AllArgsConstructor
@NoArgsConstructor
@Getter
public class SESEventMessageDTO {

  @NonNull private SESEventType eventType;

  private SESEventType notificationType;

  @NonNull private SESEventMail mail;

  @Nullable private SESEventBounce bounce;

  @Nullable private SESEventComplaint complaint;

  @Nullable private SESEventDelivery delivery;

  @Nullable private SESEventSend send;

  @Nullable private SESEventReject reject;

  @Nullable private SESEventOpen open;

  @Nullable private SESEventClick click;

  @Nullable private SESEventDeliveryDelay deliveryDelay;

  private boolean isBounce() {
    return getBounce() != null;
  }

  public boolean isTypeSoftBounce() {
    return isBounce() && SOFT_BOUNCE_TYPE.equals(getBounce().getBounceType());
  }

  public boolean isTypeAutoReply() {
    return isBounce()
        && SOFT_BOUNCE_TYPE.equals(getBounce().getBounceType())
        && GENERAL_SOFT_BOUNCE_SUB_TYPE.equals(getBounce().getBounceSubType());
  }

  public SESEventType getEventType() {
    return eventType != null ? eventType : notificationType;
  }
}
