package de.otto.blablafish_email.model.entity;

import static com.fasterxml.jackson.annotation.JsonFormat.Shape.STRING;

import com.fasterxml.jackson.annotation.JsonFormat;
import de.otto.blablafish_email.model.dto.ses.SESEventMessageDTO;
import java.time.Instant;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.springframework.lang.NonNull;

@AllArgsConstructor
@NoArgsConstructor
@Getter
public class EmailStatusHistoryEntry {

  @NonNull private EmailStatus status;

  @NonNull
  @JsonFormat(shape = STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSX", timezone = "UTC")
  private Instant date;

  public static EmailStatusHistoryEntry of(EmailStatus status, Instant date) {
    return new EmailStatusHistoryEntry(status, date);
  }

  public static EmailStatusHistoryEntry of(SESEventMessageDTO sesEventDTO) {
    switch (sesEventDTO.getEventType()) {
      case BOUNCE:
        return EmailStatusHistoryEntry.of(
            EmailStatus.AWS_BOUNCE, sesEventDTO.getBounce().getTimestamp());
      case CLICK:
        return EmailStatusHistoryEntry.of(
            EmailStatus.AWS_CLICK, sesEventDTO.getClick().getTimestamp());
      case COMPLAINT:
        return EmailStatusHistoryEntry.of(
            EmailStatus.AWS_COMPLAINT, sesEventDTO.getComplaint().getTimestamp());
      case DELIVERY:
        return EmailStatusHistoryEntry.of(
            EmailStatus.AWS_DELIVERY, sesEventDTO.getDelivery().getTimestamp());
      case DELIVERY_DELAY:
        return EmailStatusHistoryEntry.of(
            EmailStatus.AWS_DELIVERY_DELAY, sesEventDTO.getDeliveryDelay().getTimestamp());
      case OPEN:
        return EmailStatusHistoryEntry.of(
            EmailStatus.AWS_OPEN, sesEventDTO.getOpen().getTimestamp());
      case REJECT:
        return EmailStatusHistoryEntry.of(EmailStatus.AWS_REJECT, Instant.now());
      case SEND:
        return EmailStatusHistoryEntry.of(
            EmailStatus.AWS_SEND, sesEventDTO.getMail().getTimestamp());
      default:
        throw new IllegalArgumentException(
            "Failed to translate SESEventType to EmailStatus. SESEventType is: "
                + sesEventDTO.getEventType());
    }
  }
}
