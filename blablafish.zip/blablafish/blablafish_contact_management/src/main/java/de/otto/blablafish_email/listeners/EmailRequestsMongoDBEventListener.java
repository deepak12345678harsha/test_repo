package de.otto.blablafish_email.listeners;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import de.otto.blablafish_email.model.dto.MongoDbTriggerEvent;
import de.otto.blablafish_email.service.EmailMigrationService;
import de.otto.blablafish_email.service.EmailTemplateService;
import io.awspring.cloud.messaging.listener.SqsMessageDeletionPolicy;
import io.awspring.cloud.messaging.listener.annotation.SqsListener;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.bson.types.ObjectId;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class EmailRequestsMongoDBEventListener {

  private final ObjectMapper objectMapper;
  private final EmailTemplateService templateService;
  private final EmailMigrationService emailMigrationService;

  @SqsListener(
      value = "${mongoDbTrigger.emailRequests.queueUrl}",
      deletionPolicy = SqsMessageDeletionPolicy.ON_SUCCESS)
  public void emailRequestsListener(String mongoTriggerMessage) {
    log.debug("MongoDB Trigger is initiated for email request");
    ObjectId requestId;
    try {
      final MongoDbTriggerEvent event =
          objectMapper.readValue(mongoTriggerMessage, MongoDbTriggerEvent.class);
      String requestIdAsString = event.getDetail().getDocumentKey().get_id();
      requestId = new ObjectId(requestIdAsString);

      // TODO: remove this block after migration is complete.
      if (emailMigrationService.migrationRequestExists(requestIdAsString)) {
        log.info(
            "Email Migration is in progress. Skipping EmailRequestEvent for mailRequestId : {}",
            requestId);
        return;
      }

      log.info("mongodb trigger received emailRequest with id: {}", requestId);
    } catch (JsonProcessingException | RuntimeException e) {
      log.error("Failed to parse message", e);
      throw new RuntimeException("Failed to parse message.", e);
    }

    try {
      templateService.handleRenderEmailTrigger(requestId);
    } catch (Exception e) {
      log.error("Failed to process email request for id: {}", requestId.toHexString(), e);
      throw new RuntimeException(
          String.format("Failed to process email request with id: %s", requestId.toHexString()), e);
    }
  }
}
