package de.otto.blablafish_contact_management.model.dto;

import java.util.List;
import lombok.*;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ErrorResponse {

  private String message;

  private int errorCode;

  @Singular private List<String> details;
}
