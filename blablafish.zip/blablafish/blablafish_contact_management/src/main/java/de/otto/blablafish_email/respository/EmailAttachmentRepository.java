package de.otto.blablafish_email.respository;

import de.otto.blablafish_email.model.entity.EmailAttachment;
import java.util.List;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

@Slf4j
@Repository
public class EmailAttachmentRepository {

  private final MongoTemplate mongoTemplate;

  public EmailAttachmentRepository(MongoTemplate mongoTemplate) {
    this.mongoTemplate = mongoTemplate;
  }

  public EmailAttachment insertOne(EmailAttachment attachment) {
    return mongoTemplate.insert(attachment);
  }

  public List<EmailAttachment> fetchAll(Set<String> attachmentIds) {
    Query query = new Query(Criteria.where("id").in(attachmentIds));
    return mongoTemplate.find(query, EmailAttachment.class);
  }

  public EmailAttachment fetchOne(String attachmentId) {
    Query query = new Query(Criteria.where("id").is(attachmentId));
    return mongoTemplate.findOne(query, EmailAttachment.class);
  }

  public boolean attachmentExists(String attachmentId) {
    Query query = new Query(Criteria.where("id").is(attachmentId));
    return mongoTemplate.exists(query, EmailAttachment.class);
  }
}
