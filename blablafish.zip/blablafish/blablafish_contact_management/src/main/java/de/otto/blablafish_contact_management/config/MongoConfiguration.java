package de.otto.blablafish_contact_management.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.ClientEncryptionSettings;
import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.model.IndexOptions;
import com.mongodb.client.vault.ClientEncryption;
import com.mongodb.client.vault.ClientEncryptions;
import de.otto.blablafish_contact_management.encryption.EncryptionHelper;
import de.otto.blablafish_contact_management.encryption.MongoBinaryToEncryptedFieldConverter;
import de.otto.blablafish_contact_management.encryption.MongoEncryptedFieldToBinaryConverter;
import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.bson.Document;
import org.bson.UuidRepresentation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.data.mongodb.core.convert.MongoCustomConversions;
import org.springframework.data.repository.init.Jackson2RepositoryPopulatorFactoryBean;

@Slf4j
@Configuration
@Profile("!test")
@ConditionalOnProperty(name = "integrationtest.enabled", havingValue = "false")
public class MongoConfiguration {
  private static final String REGION = "eu-central-1";
  private final String connectionString;
  private final String keyVaultDatabase;
  private final String keyVaultCollection;
  private final String masterKeyArn;
  private final String localMasterKey;
  private final String accessKey;
  private final String accessToken;
  private final String kmsProvider;

  @Autowired Environment environment;

  public MongoConfiguration(
      @Value("${spring.data.mongodb.uri}") String connectionString,
      @Value("${application.keyVault.database}") String keyVaultDatabase,
      @Value("${application.keyVault.collection}") String keyVaultCollection,
      @Value("${mongo.kms.masterKeyArn}") String masterKeyArn,
      @Value("${mongo.kms.localMasterKey:default}") String localMasterKey,
      @Value("${aws.accessKey}") String accessKey,
      @Value("${aws.accessToken}") String accessToken,
      @Value("${aws.kmsProvider}") String kmsProvider) {
    log.info("Initializing mongo configuration");
    this.connectionString = connectionString;
    this.keyVaultDatabase = keyVaultDatabase;
    this.keyVaultCollection = keyVaultCollection;
    this.masterKeyArn = masterKeyArn;
    this.localMasterKey = localMasterKey;
    this.accessKey = accessKey;
    this.accessToken = accessToken;
    this.kmsProvider = kmsProvider;
  }

  @PostConstruct
  public void initKeyVaultIndexes() {
    createIndexOnKeyVault();
  }

  @Bean
  @Profile("!local")
  public ClientEncryption clientEncryption() {
    log.debug("Setting client encryption");
    final ClientEncryptionSettings clientEncryptionSettings =
        ClientEncryptionSettings.builder()
            .keyVaultMongoClientSettings(mongoClientSettings())
            .keyVaultNamespace(this.keyVaultDatabase + "." + this.keyVaultCollection)
            .kmsProviders(kmsProviders())
            .build();
    return ClientEncryptions.create(clientEncryptionSettings);
  }

  @Bean
  @Profile("local")
  public ClientEncryption localClientEncryption() {
    final ClientEncryptionSettings clientEncryptionSettings =
        ClientEncryptionSettings.builder()
            .keyVaultMongoClientSettings(mongoClientSettings())
            .keyVaultNamespace(this.keyVaultDatabase + "." + this.keyVaultCollection)
            .kmsProviders(localKmsProviders())
            .build();
    return ClientEncryptions.create(clientEncryptionSettings);
  }

  @Bean
  public MongoCustomConversions customConversions(
      ClientEncryption clientEncryption, EncryptionHelper encryptionHelper) {
    List<Object> converters = new ArrayList<>();
    converters.add(new MongoBinaryToEncryptedFieldConverter(encryptionHelper));
    converters.add(new MongoEncryptedFieldToBinaryConverter(encryptionHelper));
    return new MongoCustomConversions(converters);
  }

  @Bean
  public EncryptionHelper encryptionHelper(ClientEncryption clientEncryption) {
    final EncryptionHelper encryptionHelper =
        new EncryptionHelper(clientEncryption, kmsProvider, REGION, masterKeyArn);
    return encryptionHelper;
  }

  @Bean("jsonRepositoryPopulator")
  @ConditionalOnProperty(value = "environment", havingValue = "develop")
  public Jackson2RepositoryPopulatorFactoryBean populateTopicsCollection(
      final ObjectMapper objectMapper) {
    log.info("Populating topics collection in {}", environment);
    Jackson2RepositoryPopulatorFactoryBean bean = new Jackson2RepositoryPopulatorFactoryBean();
    bean.setMapper(objectMapper);
    bean.setResources(new Resource[] {new ClassPathResource("/topics/develop_data.json")});
    return bean;
  }

  @Bean("jsonRepositoryPopulator")
  @ConditionalOnProperty(value = "environment", havingValue = "live")
  public Jackson2RepositoryPopulatorFactoryBean populateCollectionsWhenLiveEnvironment(
      final ObjectMapper objectMapper) {
    log.info("Populating topics collection in {}", environment);
    Jackson2RepositoryPopulatorFactoryBean bean = new Jackson2RepositoryPopulatorFactoryBean();
    bean.setMapper(objectMapper);
    bean.setResources(new Resource[] {new ClassPathResource("/topics/live_data.json")});
    return bean;
  }

  private MongoClientSettings mongoClientSettings() {
    final ConnectionString connectionString = new ConnectionString(this.connectionString);
    return MongoClientSettings.builder()
        .applyConnectionString(connectionString)
        .uuidRepresentation(UuidRepresentation.JAVA_LEGACY)
        .build();
  }

  private Map<String, Map<String, Object>> localKmsProviders() {
    Map<String, Map<String, Object>> kmsProviders = new HashMap<>();
    Map<String, Object> providerDetails = new HashMap<>();

    byte[] bytes = new byte[96];
    new ByteArrayInputStream(this.localMasterKey.getBytes(StandardCharsets.UTF_8))
        .readNBytes(bytes, 0, 96);
    providerDetails.put("key", bytes);

    kmsProviders.put(kmsProvider, providerDetails);
    return kmsProviders;
  }

  private Map<String, Map<String, Object>> kmsProviders() {
    Map<String, Map<String, Object>> kmsProviders = new HashMap<>();
    Map<String, Object> providerDetails = new HashMap<>();

    providerDetails.put("accessKeyId", accessKey);
    providerDetails.put("secretAccessKey", accessToken);

    kmsProviders.put(kmsProvider, providerDetails);
    return kmsProviders;
  }

  @Bean
  public MongoClient mongoClient() {
    return MongoClients.create(mongoClientSettings());
  }

  private void createIndexOnKeyVault() {
    final MongoClient mongoClient = MongoClients.create(mongoClientSettings());
    mongoClient
        .getDatabase(this.keyVaultDatabase)
        .getCollection(this.keyVaultCollection)
        .createIndex(
            new Document("keyAltNames", 1),
            new IndexOptions()
                .unique(true)
                .partialFilterExpression(
                    new Document("keyAltNames", new Document("$exists", true))));
  }
}
