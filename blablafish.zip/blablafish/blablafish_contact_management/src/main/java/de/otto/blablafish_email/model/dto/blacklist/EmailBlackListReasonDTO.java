package de.otto.blablafish_email.model.dto.blacklist;

import de.otto.blablafish_email.model.entity.EmailBlackListReasonSourceType;
import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public class EmailBlackListReasonDTO {
  private EmailBlackListReasonSourceType sourceType;
  private String awsMessageId;
  private String description;
  private String timestamp;
}
