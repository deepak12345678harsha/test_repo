package de.otto.blablafish_email.model.entity;

public enum EmailMigrationStatus {
  UNPROCESSED,
  PROCESSED;
}
