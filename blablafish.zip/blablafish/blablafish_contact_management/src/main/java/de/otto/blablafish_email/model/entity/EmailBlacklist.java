package de.otto.blablafish_email.model.entity;

import de.otto.blablafish_contact_management.model.encryption.EncryptedField;
import de.otto.blablafish_contact_management.model.encryption.EncryptedString;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.lang.NonNull;

@AllArgsConstructor
@Getter
@Document(collection = "mailBlacklists")
public class EmailBlacklist {

  public static final String FIELD_EMAIL_ADDRESS = "emailAddress";

  @Id private ObjectId id;

  @NonNull private EncryptedField<String> emailAddress;

  @NonNull private List<EmailBlackListReason> reasons;

  public static EncryptedField<String> encryptEmail(String email) {
    return new EncryptedString(email, "blacklists.emailAddress", true);
  }
}
