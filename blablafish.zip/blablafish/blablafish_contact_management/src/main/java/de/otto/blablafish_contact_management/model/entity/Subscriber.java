package de.otto.blablafish_contact_management.model.entity;

import static de.otto.blablafish_contact_management.model.entity.UserType.COOPERATION;

import de.otto.blablafish_contact_management.model.Actions;
import de.otto.blablafish_contact_management.model.Lock;
import de.otto.blablafish_contact_management.model.encryption.EncryptedField;
import de.otto.blablafish_contact_management.model.encryption.EncryptedString;
import java.time.Instant;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NonNull;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Version;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@AllArgsConstructor
@Builder(toBuilder = true)
@Document(collection = "subscribers")
@Getter
public class Subscriber {

  public static final String FIELD_SUBSCRIBER_ID = "userId";
  public static final String FIELD_PARTNER_ID = "partnerId";
  public static final String FIELD_FIRST_NAME = "firstName";
  public static final String FIELD_LAST_NAME = "lastName";
  public static final String FIELD_EMAIL = "email";
  public static final String FIELD_EFFECTIVE_ROLE_IDS = "effectiveRoleIds";
  public static final String FIELD_GROUPS = "groups";
  public static final String FIELD_STATUS = "status";
  public static final String FIELD_EVENT_TIME = "eventTime";
  public static final String FIELD_USER_TYPE = "userType";
  public static final String FIELD_TOPIC_IDS = "topicIds";
  public static final String FIELD_IS_USER_BLACKLISTED = "isUserBlacklisted";
  public static final String FIELD_ACTIONS = "actions";
  public static final String FIELD_ACTION_ERROR = "actionError";
  public static final String FIELD_MARKED_FOR_DELETION = "markedForDeletion";
  public static final String FIELD_NEWSLETTER_SUBSCRIPTION = "newsletterSubscription";
  public static final String FIELD_COMMUNICATION_SUBSCRIPTION = "communicationSubscription";
  public static final String FIELD_CREATED_AT = "createdAt";
  public static final String FIELD_UPDATED_AT = "updatedAt";
  public static final String FIELD_LAST_UPDATED_BY = "lastUpdatedBy";
  public static final List<String> ADMIN_GROUPS =
      List.of("administration", "onboardingAdministration");

  @Id private ObjectId userId;

  @Indexed @NonNull private String partnerId;

  private Set<Integer> topicIds;

  @NonNull private EncryptedField<String> firstName;

  @NonNull private EncryptedField<String> lastName;

  @Indexed(unique = true)
  @NonNull
  private EncryptedField<String> email;

  private Set<String> effectiveRoleIds;
  @NonNull private Status status;

  private Instant createdAt;

  @NonNull private Instant updatedAt;

  private Requester lastUpdatedBy;

  @NonNull private Instant eventTime;

  private Boolean isUserBlacklisted;

  private Boolean markedForDeletion;

  private NewsletterSubscription newsletterSubscription;

  private CommunicationSubscription communicationSubscription;

  private UserType userType;

  private LinkedList<Actions> actions;

  private List<Actions> actionsHistory;

  private ActionError actionError;

  private Lock lock;

  private Set<String> groups;

  @Version private Long version;

  public static EncryptedField<String> encryptFirstName(String firstName) {
    return new EncryptedString(firstName, "User.firstName", true);
  }

  public static EncryptedField<String> encryptLastName(String lastName) {
    return new EncryptedString(lastName, "User.lastName", true);
  }

  public static EncryptedField<String> encryptEmail(String email) {
    return new EncryptedString(email, "User.email", true);
  }

  public boolean hasTopics() {
    return this.getTopicIds() != null && !this.getTopicIds().isEmpty();
  }

  public boolean isAdmin(String role) {
    return this.getEffectiveRoleIds().contains(role);
  }

  public boolean hasTopic(Integer topicId) {
    return this.getTopicIds().contains(topicId);
  }

  public boolean isCooperationSubscriber() {
    return COOPERATION.equals(userType);
  }

  public boolean isSubscribedToNewsletter() {
    if (Objects.isNull(this.newsletterSubscription)) {
      return false;
    }
    return NewsletterSubscriptionStatus.statusOf(this.newsletterSubscription.getStatus());
  }

  public boolean isSubscribedToCommunications() {
    if (Objects.isNull(this.communicationSubscription)) {
      return true;
    }
    return communicationSubscription.isSubscribed();
  }

  public boolean isActive() {
    return Status.ENABLED.equals(this.status);
  }

  public boolean isAnActiveCooperationSubscriber() {
    return isCooperationSubscriber() && isActive();
  }

  public String getSubscriberIdAsString() {
    return userId.toString();
  }
}
