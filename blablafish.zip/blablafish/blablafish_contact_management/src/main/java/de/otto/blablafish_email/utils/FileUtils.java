package de.otto.blablafish_email.utils;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

public class FileUtils {

  public static void copyFile(Path path, InputStream inputStream) {
    try {
      Files.copy(inputStream, path, StandardCopyOption.REPLACE_EXISTING);
    } catch (IOException e) {
      throw new RuntimeException("Error while copying file from input stream");
    }
  }

  public static File createTempFile(String prefix, String suffix) {
    try {
      return File.createTempFile(prefix, suffix);
    } catch (Exception ex) {
      throw new RuntimeException("Error while creating temp file");
    }
  }
}
