package de.otto.blablafish_contact_management.rest;

import static de.otto.blablafish_contact_management.utils.Constants.CONTACT_MANAGEMENT;
import static de.otto.blablafish_contact_management.utils.Constants.CONTACT_MANAGEMENT_SERVICE_SUBSCRIBER_READ_ROLE;
import static de.otto.blablafish_contact_management.utils.Constants.CONTACT_MANAGEMENT_SUBSCRIBER_WRITE_ROLE;
import static de.otto.blablafish_contact_management.utils.Constants.SERVICE_NAME;

import de.otto.blablafish_contact_management.exception.BlaBlaFishException;
import de.otto.blablafish_contact_management.exception.SubscriberDoesNotExistException;
import de.otto.blablafish_contact_management.exception.TopicNotFoundException;
import de.otto.blablafish_contact_management.model.dto.AddSubscribersRequest;
import de.otto.blablafish_contact_management.model.dto.AddSubscribersResponse;
import de.otto.blablafish_contact_management.model.dto.SubscriberDTO;
import de.otto.blablafish_contact_management.model.dto.UserPrincipal;
import de.otto.blablafish_contact_management.service.SubscriberService;
import de.otto.blablafish_contact_management.service.TopicService;
import de.otto.blablafish_contact_management.utils.Helper;
import java.security.Principal;
import lombok.extern.slf4j.Slf4j;
import org.jboss.logging.MDC;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping("/v1")
public class SubscriberController {

  static final String SUBSCRIBER_URI = "/topics/{topicId}/subscribers";
  static final String SUBSCRIBER_SELF_URI = SUBSCRIBER_URI + "/{subscriberId}";

  private final TopicService topicService;
  private final SubscriberService subscriberService;

  public SubscriberController(TopicService topicService, SubscriberService subscriberService) {
    this.topicService = topicService;
    this.subscriberService = subscriberService;
  }

  @GetMapping(value = "/subscribers", produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseStatus(HttpStatus.OK)
  @PreAuthorize("hasAuthority('" + CONTACT_MANAGEMENT_SUBSCRIBER_WRITE_ROLE + "')")
  public ResponseCollection<SubscriberDTO> getAllSubscribers(
      Principal principal, @RequestParam(required = false) String search) {
    MDC.put(SERVICE_NAME, CONTACT_MANAGEMENT);
    UserPrincipal userPrincipal = Helper.toUserPrincipal(principal);
    log.info("Get users for a partner - Controller Layer");
    var users =
        subscriberService.getAllUsersByEmailAndPartner(userPrincipal.getPartnerId(), search);
    MDC.remove(SERVICE_NAME);
    return new ResponseCollection<>(users);
  }

  @GetMapping(
      value = "/subscribers",
      produces = MediaType.APPLICATION_JSON_VALUE,
      params = "emailAddress")
  @PreAuthorize("hasAuthority('" + CONTACT_MANAGEMENT_SERVICE_SUBSCRIBER_READ_ROLE + "')")
  @ResponseStatus(HttpStatus.OK)
  public SubscriberDTO getSubscriberByEmailAddress(@RequestParam String emailAddress)
      throws SubscriberDoesNotExistException {
    MDC.put(SERVICE_NAME, CONTACT_MANAGEMENT);
    var user = subscriberService.getUserByEmail(emailAddress);
    MDC.remove(SERVICE_NAME);
    return SubscriberDTO.from(
        user.orElseThrow(
            () ->
                new SubscriberDoesNotExistException(
                    String.format("User with email address: %s does not exists", emailAddress))));
  }

  @GetMapping(value = "/subscribers/{subscriberId}", produces = MediaType.APPLICATION_JSON_VALUE)
  @PreAuthorize("hasAuthority('" + CONTACT_MANAGEMENT_SERVICE_SUBSCRIBER_READ_ROLE + "')")
  @ResponseStatus(HttpStatus.OK)
  public SubscriberDTO getSubscriberById(@PathVariable String subscriberId)
      throws SubscriberDoesNotExistException {
    MDC.put(SERVICE_NAME, CONTACT_MANAGEMENT);
    var subscriberById = subscriberService.getSubscriberById(subscriberId);
    MDC.remove(SERVICE_NAME);
    return SubscriberDTO.from(subscriberById);
  }

  @PutMapping(
      value = SUBSCRIBER_URI,
      produces = MediaType.APPLICATION_JSON_VALUE,
      consumes = MediaType.APPLICATION_JSON_VALUE)
  @ResponseStatus(HttpStatus.OK)
  @PreAuthorize("hasAuthority('" + CONTACT_MANAGEMENT_SUBSCRIBER_WRITE_ROLE + "')")
  public AddSubscribersResponse addTopicSubscribers(
      @PathVariable int topicId,
      @RequestBody AddSubscribersRequest request,
      @RequestHeader("User-Agent") String userAgent,
      Principal principal)
      throws TopicNotFoundException, SubscriberDoesNotExistException {
    MDC.put(SERVICE_NAME, CONTACT_MANAGEMENT);
    log.info("Add subscribers to topic {} - Controller Layer", topicId);
    var requester = subscriberService.requesterOf(Helper.toUserPrincipal(principal), userAgent);
    var addSubscribersResponse =
        topicService.addTopicSubscribers(topicId, request.getUserIds(), requester);
    MDC.remove(SERVICE_NAME);
    return addSubscribersResponse;
  }

  @DeleteMapping(SUBSCRIBER_SELF_URI)
  @PreAuthorize("hasAuthority('" + CONTACT_MANAGEMENT_SUBSCRIBER_WRITE_ROLE + "')")
  @ResponseStatus(HttpStatus.OK)
  public void deleteSubscriber(
      @PathVariable Integer topicId,
      @PathVariable String subscriberId,
      @RequestHeader("User-Agent") String userAgent,
      Principal principal)
      throws TopicNotFoundException, SubscriberDoesNotExistException, BlaBlaFishException {
    var requester = subscriberService.requesterOf(Helper.toUserPrincipal(principal), userAgent);
    MDC.put(SERVICE_NAME, CONTACT_MANAGEMENT);
    log.info("Unsubscribe a subscriber {} from topic {} - Controller layer", subscriberId, topicId);
    subscriberService.unSubscribe(subscriberId, topicId, requester);
    MDC.remove(SERVICE_NAME);
  }
}
