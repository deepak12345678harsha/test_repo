package de.otto.blablafish_email.model.entity;

public enum EmailStatus {
  READY_TO_SEND,
  SENDING,
  SES_API_INVOCATION_FAILED,
  WAITING,
  AWS_SEND,
  AWS_REJECT,
  AWS_DELIVERY,
  AWS_OPEN,
  AWS_CLICK,
  AWS_BOUNCE,
  AWS_COMPLAINT,
  AWS_DELIVERY_DELAY
}
