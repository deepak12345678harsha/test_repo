package de.otto.blablafish_contact_management.model.entity;

public enum UserType {
  COOPERATION,
  COMMISSION,
  API,
  SERVICE_PROVIDER
}
