package de.otto.blablafish_contact_management.model;

public enum Actions {
  SYNC_USER_DATA_TO_EMARSYS,
  SEND_UNBLACKLIST_EVENT_TO_NEPTUNE,
  REMOVE_EMAIL_FROM_SES_SUPPRESSION_LIST
}
