package de.otto.blablafish_email.model.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.springframework.lang.NonNull;

@NoArgsConstructor
@AllArgsConstructor
@Getter
public class EmailRequester {

  @NonNull private String jwtClientId;
  @NonNull private String jwtSub;

  public static EmailRequester of(String jwtClientId, String subject) {
    return new EmailRequester(jwtClientId, subject);
  }
}
