package de.otto.blablafish_contact_management.utils;

public class Constants {
  public static final String SERVICE_ACCOUNT_ATTRIBUTE_APP_ID = "app_id";
  public static final String CONTACT_MANAGEMENT_SUBSCRIBER_WRITE_ROLE = "cm.sub.w";
  public static final String CONTACT_MANAGEMENT_TOPIC_READ_ROLE = "cm.top.r";
  public static final String CONTACT_MANAGEMENT_SERVICE_SUBSCRIBER_READ_ROLE = "cms.sub.r";
  public static final Long EVENT_EXPIRATION_IN_YEARS = 4L;

  public static final String SERVICE_NAME = "serviceName";
  public static final String CONTACT_MANAGEMENT = "contact-management";
}
