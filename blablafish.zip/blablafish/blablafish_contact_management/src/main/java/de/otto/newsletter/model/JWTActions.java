package de.otto.newsletter.model;

public enum JWTActions {
  UNSUBSCRIBE_NEWSLETTER,
  UNSUBSCRIBE_COMMUNICATIONS
}
