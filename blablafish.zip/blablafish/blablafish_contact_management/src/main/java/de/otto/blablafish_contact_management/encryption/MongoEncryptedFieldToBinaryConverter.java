package de.otto.blablafish_contact_management.encryption;

import de.otto.blablafish_contact_management.model.encryption.EncryptedField;
import org.bson.BsonBinary;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.WritingConverter;

@WritingConverter
public class MongoEncryptedFieldToBinaryConverter
    implements Converter<EncryptedField<?>, BsonBinary> {
  private final EncryptionHelper clientEncryption;

  public MongoEncryptedFieldToBinaryConverter(EncryptionHelper clientEncryption) {
    this.clientEncryption = clientEncryption;
  }

  @Override
  public BsonBinary convert(EncryptedField<?> encryptedField) {
    return encryptedField.getBsonBinary().orElse(this.clientEncryption.encrypt(encryptedField));
  }
}
