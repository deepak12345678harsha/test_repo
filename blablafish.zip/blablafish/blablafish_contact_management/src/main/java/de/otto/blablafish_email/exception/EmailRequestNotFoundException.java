package de.otto.blablafish_email.exception;

import de.otto.blablafish_contact_management.exception.BlaBlaFishError;
import de.otto.blablafish_contact_management.exception.BlaBlaFishException;

public class EmailRequestNotFoundException extends BlaBlaFishException {
  public EmailRequestNotFoundException(String message) {
    super(message, BlaBlaFishError.EMAIL_REQUEST_NOT_FOUND_ERROR);
  }
}
