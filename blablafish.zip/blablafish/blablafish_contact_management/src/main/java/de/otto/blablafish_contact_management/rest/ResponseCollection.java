package de.otto.blablafish_contact_management.rest;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@AllArgsConstructor
@NoArgsConstructor
public class ResponseCollection<T> {
  private List<T> items;
  private int count;

  public ResponseCollection(List<T> items) {
    this.items = items;
    this.count = items.size();
  }
}
