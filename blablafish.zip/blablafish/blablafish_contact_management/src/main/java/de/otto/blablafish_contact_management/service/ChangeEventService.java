package de.otto.blablafish_contact_management.service;

import static de.otto.blablafish_contact_management.utils.Constants.EVENT_EXPIRATION_IN_YEARS;

import de.otto.blablafish_contact_management.encryption.EncryptionHelper;
import de.otto.blablafish_contact_management.model.entity.ChangeEvent;
import de.otto.blablafish_contact_management.model.entity.ClusterTime;
import de.otto.blablafish_contact_management.respository.ChangeEventRepository;
import de.otto.blablafish_email.model.dto.MongoDbTriggerEvent;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.UUID;
import lombok.extern.slf4j.Slf4j;
import org.bson.Document;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class ChangeEventService {
  private final ChangeEventRepository changeEventRepository;
  private final EncryptionHelper helper;

  public ChangeEventService(ChangeEventRepository changeEventRepository, EncryptionHelper helper) {
    this.changeEventRepository = changeEventRepository;
    this.helper = helper;
  }

  public void handleEvent(MongoDbTriggerEvent event, String eventJsonAsString) {
    final Document eventAsDocument = Document.parse(eventJsonAsString);
    helper.decryptBsonBinariesAndReplace(eventAsDocument);
    final Instant expiresAt = Instant.now().plus(EVENT_EXPIRATION_IN_YEARS * 365, ChronoUnit.DAYS);
    ChangeEvent changeEvent =
        ChangeEvent.builder()
            .id(UUID.randomUUID().toString())
            .eventDescription(event.getDetailType())
            .source(event.getSource())
            .db(event.getDetail().getNs().getDb())
            .collection(event.getDetail().getNs().getColl())
            .operationType(event.getDetail().getOperationType())
            .documentKey(new Document("_id", event.getDetail().getDocumentKey().get_id()))
            .expiresAt(expiresAt)
            .time(event.getTime())
            .event(ChangeEvent.encryptDocument(eventAsDocument))
            .clusterTime(ClusterTime.fromDTO(event.getDetail().getClusterTime()))
            .build();
    changeEventRepository.insert(changeEvent);
  }
}
