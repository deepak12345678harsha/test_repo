package de.otto.blablafish_contact_management.handler;

import de.otto.blablafish_contact_management.model.entity.CommunicationSubscription;
import de.otto.blablafish_contact_management.model.entity.CommunicationSubscriptionStatus;
import de.otto.blablafish_contact_management.respository.SubscriberRepository;
import de.otto.blablafish_email.model.dto.MongoDbTriggerEvent;
import de.otto.newsletter.model.entity.SubscriberChangeEventType;
import java.time.Instant;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class CommunicationSubscriptionChangedEventIdentifier
    extends SubscriberChangedEventIdentifier {

  public CommunicationSubscriptionChangedEventIdentifier(
      SubscriberRepository subscriberRepository) {
    super(subscriberRepository);
  }

  @Override
  public SubscriberChangeEventType getEventType(MongoDbTriggerEvent event) {
    return SubscriberChangeEventType.from(
        mapToCommunicationSubscription(event.getUpdatedFieldValues("communicationSubscription"))
            .getStatus());
  }

  @Override
  public Instant getSubscriberUpdatedTime(MongoDbTriggerEvent event) {
    return mapToCommunicationSubscription(event.getUpdatedFieldValues("communicationSubscription"))
        .getTime();
  }

  @Override
  public boolean canIdentifyEvent(MongoDbTriggerEvent event) {
    return event.isUpdateEvent() && event.hasUpdatedField("communicationSubscription");
  }

  private CommunicationSubscription mapToCommunicationSubscription(Map<String, Object> map) {
    return new CommunicationSubscription(
        CommunicationSubscriptionStatus.valueOf(map.get("status").toString()),
        Instant.parse(map.get("time").toString()));
  }
}
