package de.otto.newsletter.emarsys;

import feign.Response;
import feign.RetryableException;
import feign.codec.ErrorDecoder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;

@Slf4j
public class EmarsysFeignErrorDecoder implements ErrorDecoder {

  private final ErrorDecoder defaultErrorDecoder = new Default();

  @Override
  public Exception decode(String methodKey, Response response) {
    HttpStatus responseStatus = HttpStatus.valueOf(response.status());
    if (responseStatus.is5xxServerError() || responseStatus.is4xxClientError()) {
      log.error(
          "An error occurred while invoking API : Status {} |  reason : {} | request detail:  {}",
          responseStatus,
          response.reason(),
          getRequestLogs(response));
      return new RetryableException(
          responseStatus.value(),
          response.reason(),
          response.request().httpMethod(),
          null,
          response.request());
    }
    return defaultErrorDecoder.decode(methodKey, response);
  }

  private String getRequestLogs(Response response) {
    return String.format("%s %s", response.request().httpMethod(), response.request().url());
  }
}
