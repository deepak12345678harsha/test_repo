package de.otto.blablafish_contact_management.config;

import com.mongodb.WriteConcern;
import com.mongodb.client.MongoClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.servlet.ServletContextInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.togglz.core.manager.EnumBasedFeatureProvider;
import org.togglz.core.repository.StateRepository;
import org.togglz.core.spi.FeatureProvider;
import org.togglz.core.user.SingleUserProvider;
import org.togglz.core.user.UserProvider;
import org.togglz.mongodb.MongoStateRepository;
import org.togglz.servlet.TogglzFilter;

@Configuration
@Profile("!test")
@ConditionalOnProperty(name = "integrationtest.enabled", havingValue = "false")
public class TogglesConfig {

  @Value("${spring.togglz.collection-name}")
  private String collectionName;

  @Value("${spring.data.mongodb.database}")
  private String database;

  @Bean
  public StateRepository getStateRepository(MongoClient mongoClient) {
    return MongoStateRepository.newBuilder(mongoClient, database)
        .collection(collectionName)
        .writeConcern(WriteConcern.MAJORITY)
        .build();
  }

  @Bean
  public UserProvider getUserProvider() {
    return new SingleUserProvider("admin", true);
  }

  @Bean
  public FeatureProvider featureProvider() {
    return new EnumBasedFeatureProvider(Features.class);
  }

  @Bean
  public FilterRegistrationBean registerTogglzFilter() {
    FilterRegistrationBean filterRegistrationBean = new FilterRegistrationBean();
    filterRegistrationBean.setFilter(new TogglzFilter());
    filterRegistrationBean.addUrlPatterns("/toggles-console/*");
    return filterRegistrationBean;
  }

  @Bean
  public ServletContextInitializer servletContextInitializer() {
    return servletContext ->
        servletContext.setInitParameter("org.togglz.FEATURE_MANAGER_PROVIDED", "true");
  }
}
