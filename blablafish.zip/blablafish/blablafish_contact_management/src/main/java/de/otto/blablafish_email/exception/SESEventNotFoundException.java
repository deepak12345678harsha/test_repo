package de.otto.blablafish_email.exception;

import de.otto.blablafish_contact_management.exception.BlaBlaFishError;
import de.otto.blablafish_contact_management.exception.BlaBlaFishException;

public class SESEventNotFoundException extends BlaBlaFishException {
  public SESEventNotFoundException(String message) {
    super(message, BlaBlaFishError.SES_EVENT_NOT_FOUND_ERROR);
  }
}
