package de.otto.blablafish_contact_management.respository;

import static de.otto.blablafish_contact_management.model.Actions.*;
import static de.otto.blablafish_contact_management.model.entity.Subscriber.*;
import static org.springframework.data.mongodb.core.query.Criteria.where;

import com.mongodb.client.result.UpdateResult;
import de.otto.blablafish_contact_management.model.Actions;
import de.otto.blablafish_contact_management.model.Lock;
import de.otto.blablafish_contact_management.model.encryption.EncryptedField;
import de.otto.blablafish_contact_management.model.entity.ActionError;
import de.otto.blablafish_contact_management.model.entity.CommunicationSubscription;
import de.otto.blablafish_contact_management.model.entity.CommunicationSubscriptionStatus;
import de.otto.blablafish_contact_management.model.entity.NewsletterSubscription;
import de.otto.blablafish_contact_management.model.entity.NewsletterSubscriptionStatus;
import de.otto.blablafish_contact_management.model.entity.Requester;
import de.otto.blablafish_contact_management.model.entity.Status;
import de.otto.blablafish_contact_management.model.entity.Subscriber;
import java.time.Instant;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.BasicQuery;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;

@Repository
@Slf4j
public class SubscriberRepository {

  private final MongoTemplate mongoTemplate;

  public SubscriberRepository(MongoTemplate mongoTemplate) {
    this.mongoTemplate = mongoTemplate;
  }

  public void upsert(Subscriber subscriber) {
    Query query =
        Query.query(Criteria.where(FIELD_SUBSCRIBER_ID).is(subscriber.getUserId()))
            .addCriteria(Criteria.where(FIELD_EVENT_TIME).lt(subscriber.getEventTime()));

    Document document = new Document();
    mongoTemplate.getConverter().write(subscriber, document);

    Update updateDefinition = getUpdateDefinition(subscriber);
    mongoTemplate.upsert(query, updateDefinition, Subscriber.class);
    log.info("User with id: {} successfully updated", subscriber.getUserId());
  }

  public List<Subscriber> findAllByEmail(Set<EncryptedField<String>> emailAddresses) {
    Query query = Query.query(Criteria.where(FIELD_EMAIL).in(emailAddresses));
    return mongoTemplate.find(query, Subscriber.class);
  }

  public void unsubscribeSubscriberFromTopic(
      ObjectId subscriberId, Integer topicId, Requester requester) {
    final BasicQuery basicQuery = new BasicQuery(new Document(FIELD_SUBSCRIBER_ID, subscriberId));
    Update update =
        new Update().pull(FIELD_TOPIC_IDS, topicId).set(FIELD_LAST_UPDATED_BY, requester);
    this.mongoTemplate.updateFirst(basicQuery, update, Subscriber.class);
    log.info(
        "Subscriber: {} is successfully unsubscribed from topic id: {}", subscriberId, topicId);
  }

  public boolean exists(String subscriberId) {
    final BasicQuery query = new BasicQuery(new Document(FIELD_SUBSCRIBER_ID, subscriberId));
    return mongoTemplate.exists(query, Subscriber.class);
  }

  public Optional<Subscriber> findById(ObjectId subscriberId) {
    Query query =
        Query.query(
            where(FIELD_SUBSCRIBER_ID).is(subscriberId).and(FIELD_MARKED_FOR_DELETION).ne(true));
    return Optional.ofNullable(mongoTemplate.findOne(query, Subscriber.class));
  }

  public void markForDeletion(ObjectId subscriberId, List<Actions> actions, Requester requester) {
    log.info("Marking subscriber with id: {} for deletion", subscriberId);
    Query query = Query.query(Criteria.where(FIELD_SUBSCRIBER_ID).is(subscriberId));
    Update updateDefinition =
        new Update()
            .set(FIELD_MARKED_FOR_DELETION, Boolean.TRUE)
            .set(FIELD_LAST_UPDATED_BY, requester)
            .push(FIELD_ACTIONS)
            .each(actions);
    mongoTemplate.upsert(query, updateDefinition, Subscriber.class);
    log.info("Subscriber with id : {} marked for deletion", subscriberId);
  }

  public void subscribeUserToTopics(ObjectId userId, List<Integer> topicIds) {
    Query query = Query.query(Criteria.where(FIELD_SUBSCRIBER_ID).is(userId));
    Update updateDefinition = new Update().set(FIELD_TOPIC_IDS, topicIds);

    mongoTemplate.upsert(query, updateDefinition, Subscriber.class);
    log.info("Subscriber {} subscribed to topics : {}", userId, topicIds);
  }

  public long getCountOfUsersWith(Integer topicId, @NonNull String partnerId) {
    log.debug("getCountOfUsersWith for topicId: {}  and partnerId: {}", topicId, partnerId);
    Query query =
        Query.query(
            Criteria.where(FIELD_TOPIC_IDS)
                .in(topicId)
                .and(FIELD_PARTNER_ID)
                .is(partnerId)
                .and(FIELD_MARKED_FOR_DELETION)
                .ne(true));

    long count = mongoTemplate.count(query, Subscriber.class);
    log.debug("Count of subscribers in topic {} is {}", topicId, count);
    return count;
  }

  public void subscribeAllAdmins(
      List<Integer> topicIds, String userRole, String partnerId, Requester requester) {
    log.info(
        "addTopicsToUsersWithRole for topicId: {} and userRole: {} and partnerId: {}",
        topicIds,
        userRole,
        partnerId);
    var query =
        Query.query(
            Criteria.where(FIELD_EFFECTIVE_ROLE_IDS)
                .in(userRole)
                .and(FIELD_MARKED_FOR_DELETION)
                .ne(true)
                .and(FIELD_PARTNER_ID)
                .is(partnerId));
    var updateDefinition =
        new Update().addToSet(FIELD_TOPIC_IDS).each(topicIds).set(FIELD_LAST_UPDATED_BY, requester);

    mongoTemplate.updateMulti(query, updateDefinition, Subscriber.class);
    log.info("Topics : {} successfully added to subscribers with role - {}", topicIds, userRole);
  }

  public Long subscribeTopicForUsers(List<ObjectId> userIds, int topicId, Requester requester) {
    log.info(
        "subscribe users for topicId: {} and partnerId: {}", topicId, requester.getPartnerId());
    Query query =
        Query.query(
            Criteria.where(FIELD_PARTNER_ID)
                .is(requester.getPartnerId())
                .and(FIELD_SUBSCRIBER_ID)
                .in(userIds));
    Update updateDefinition =
        new Update().addToSet(FIELD_TOPIC_IDS, topicId).set(FIELD_LAST_UPDATED_BY, requester);

    UpdateResult result = mongoTemplate.updateMulti(query, updateDefinition, Subscriber.class);
    return result.getModifiedCount();
  }

  public List<Subscriber> filterSubscribedUsersForTopic(
      List<ObjectId> userIds, int topicId, String partnerId) {
    Query query =
        Query.query(
            Criteria.where(FIELD_PARTNER_ID)
                .is(partnerId)
                .and(FIELD_SUBSCRIBER_ID)
                .in(userIds)
                .and(FIELD_TOPIC_IDS)
                .in(topicId)
                .and(FIELD_MARKED_FOR_DELETION)
                .ne(true));
    return mongoTemplate.find(query, Subscriber.class);
  }

  public List<Subscriber> findAllByEmailAndPartner(String email, String partnerId) {
    Query query =
        Query.query(
            where(FIELD_PARTNER_ID)
                .is(partnerId)
                .and(FIELD_EMAIL)
                .is(Subscriber.encryptEmail(email))
                .and(FIELD_MARKED_FOR_DELETION)
                .ne(true));
    return mongoTemplate.find(query, Subscriber.class);
  }

  public Optional<Subscriber> findByEmail(String email) {
    Query query =
        Query.query(
            where(FIELD_EMAIL)
                .is(Subscriber.encryptEmail(email))
                .and(FIELD_MARKED_FOR_DELETION)
                .ne(true));
    return Optional.ofNullable(mongoTemplate.findOne(query, Subscriber.class));
  }

  public List<Subscriber> findAllByPartner(String partnerId) {
    Query query =
        Query.query(where(FIELD_PARTNER_ID).is(partnerId).and(FIELD_MARKED_FOR_DELETION).ne(true));
    return mongoTemplate.find(query, Subscriber.class);
  }

  public List<Subscriber> findAllByPartnerForStatusEnabledAndNotBlacklisted(
      String partnerId, int topicId) {
    Assert.hasText(partnerId, "Missing partnerId.");

    Criteria criteriaDefinition =
        where(FIELD_PARTNER_ID)
            .is(partnerId)
            .and(FIELD_TOPIC_IDS)
            .in(topicId)
            .and(FIELD_MARKED_FOR_DELETION)
            .ne(true);
    Query query = Query.query(addCriteriaStatusEnabledAndNotBlacklisted(criteriaDefinition));
    return mongoTemplate.find(query, Subscriber.class);
  }

  public List<Subscriber> findAdminsByPartnerForStatusEnabledAndNotBlacklisted(String partnerId) {
    Assert.hasText(partnerId, "Missing partnerId.");

    var criteriaDefinition =
        where(FIELD_PARTNER_ID)
            .is(partnerId)
            .and(FIELD_GROUPS)
            .in(ADMIN_GROUPS)
            .and(FIELD_MARKED_FOR_DELETION)
            .ne(true);

    Query query = Query.query(addCriteriaStatusEnabledAndNotBlacklisted(criteriaDefinition));
    return mongoTemplate.find(query, Subscriber.class);
  }

  private Criteria addCriteriaStatusEnabledAndNotBlacklisted(Criteria criteria) {
    return criteria.and(FIELD_STATUS).is(Status.ENABLED).and(FIELD_IS_USER_BLACKLISTED).ne(true);
  }

  public List<Subscriber> findAllUsersByPartnerWithStatusEnabledAndNotBlacklisted(
      String partnerId, List<String> mandatorySubscriberRoles) {
    Assert.hasText(partnerId, "Missing partnerId.");

    Criteria criteriaDefinition =
        where(FIELD_PARTNER_ID).is(partnerId).and(FIELD_MARKED_FOR_DELETION).ne(true);

    if (!mandatorySubscriberRoles.isEmpty()) {
      criteriaDefinition.and(FIELD_EFFECTIVE_ROLE_IDS).all(mandatorySubscriberRoles);
    }

    Query query = Query.query(addCriteriaStatusEnabledAndNotBlacklisted(criteriaDefinition));
    return mongoTemplate.find(query, Subscriber.class);
  }

  // TODO: return value is never used. remove if not needed.
  public Optional<Subscriber> findByPartnerWhereStatusEnabledAndNotBlacklisted(
      String partnerId, int topicId, String emailAddress) {
    Assert.hasText(partnerId, "Missing partnerId.");
    Assert.hasText(emailAddress, "Missing email address.");

    Criteria criteriaDefinition =
        where(FIELD_EMAIL)
            .is(Subscriber.encryptEmail(emailAddress))
            .and(FIELD_PARTNER_ID)
            .is(partnerId)
            .and(FIELD_TOPIC_IDS)
            .in(topicId)
            .and(FIELD_MARKED_FOR_DELETION)
            .ne(true);
    Query query = Query.query(addCriteriaStatusEnabledAndNotBlacklisted(criteriaDefinition));
    return Optional.ofNullable(mongoTemplate.findOne(query, Subscriber.class));
  }

  public Optional<Subscriber> findUserByStatusEnabledAndNotBlacklisted(
      String partnerId, List<String> mandatorySubscriberRoles, String emailAddress) {
    Assert.hasText(partnerId, "Missing partnerId.");

    Criteria criteriaDefinition =
        where(FIELD_EMAIL)
            .is(Subscriber.encryptEmail(emailAddress))
            .and(FIELD_PARTNER_ID)
            .is(partnerId)
            .and(FIELD_MARKED_FOR_DELETION)
            .ne(true);

    if (!mandatorySubscriberRoles.isEmpty()) {
      criteriaDefinition.and(FIELD_EFFECTIVE_ROLE_IDS).all(mandatorySubscriberRoles);
    }
    Query query = Query.query(addCriteriaStatusEnabledAndNotBlacklisted(criteriaDefinition));
    return Optional.ofNullable(mongoTemplate.findOne(query, Subscriber.class));
  }

  public void blacklistSubscriber(String emailAddress, Requester requester) {
    Assert.hasText(emailAddress, "Missing email address.");

    Query query = Query.query(where(FIELD_EMAIL).is(Subscriber.encryptEmail(emailAddress)));
    var update =
        new Update().set(FIELD_IS_USER_BLACKLISTED, true).set(FIELD_LAST_UPDATED_BY, requester);
    this.mongoTemplate.updateFirst(query, update, Subscriber.class);
    log.info("User successfully updated with isUserBlacklisted: {}", true);
  }

  public void unBlacklistSubscribers(Set<String> emailIds, Requester requester) {
    var encryptedEmailIds = emailIds.stream().map(Subscriber::encryptEmail).toList();
    var query = Query.query(Criteria.where(FIELD_EMAIL).in(encryptedEmailIds));
    var update =
        new Update()
            .set(FIELD_IS_USER_BLACKLISTED, false)
            .set(FIELD_LAST_UPDATED_BY, requester)
            .push(FIELD_ACTIONS)
            .each(
                List.of(REMOVE_EMAIL_FROM_SES_SUPPRESSION_LIST, SEND_UNBLACKLIST_EVENT_TO_NEPTUNE));
    mongoTemplate.updateMulti(query, update, Subscriber.class);
    log.info(
        "Subscribers successfully updated with isUserBlacklisted: {}, no: {}",
        false,
        emailIds.size());
  }

  private Update getUpdateDefinition(Subscriber subscriber) {
    Set<Integer> topicIds =
        subscriber.hasTopics() ? subscriber.getTopicIds() : Collections.emptySet();
    return new Update()
        .set(FIELD_SUBSCRIBER_ID, subscriber.getUserId())
        .set(FIELD_PARTNER_ID, subscriber.getPartnerId())
        .set(FIELD_FIRST_NAME, subscriber.getFirstName())
        .set(FIELD_LAST_NAME, subscriber.getLastName())
        .set(FIELD_EMAIL, subscriber.getEmail())
        .set(FIELD_EFFECTIVE_ROLE_IDS, subscriber.getEffectiveRoleIds())
        .set(FIELD_GROUPS, subscriber.getGroups())
        .set(FIELD_STATUS, subscriber.getStatus())
        .set(FIELD_UPDATED_AT, Instant.now())
        .set(FIELD_LAST_UPDATED_BY, subscriber.getLastUpdatedBy())
        .set(FIELD_EVENT_TIME, subscriber.getEventTime())
        .set(FIELD_USER_TYPE, subscriber.getUserType())
        .push(FIELD_ACTIONS)
        .each(List.of(SYNC_USER_DATA_TO_EMARSYS))
        .setOnInsert(FIELD_MARKED_FOR_DELETION, Boolean.FALSE)
        .setOnInsert(
            FIELD_COMMUNICATION_SUBSCRIPTION,
            new CommunicationSubscription(
                CommunicationSubscriptionStatus.SUBSCRIBED, Instant.now()))
        .setOnInsert(FIELD_CREATED_AT, Instant.now())
        .setOnInsert(FIELD_TOPIC_IDS, topicIds)
        .setOnInsert(FIELD_IS_USER_BLACKLISTED, false);
  }

  public void updateSubscription(
      String emailAddress,
      NewsletterSubscription newsletterSubscription,
      List<Actions> actions,
      Requester requester) {
    log.debug("Updating newsletter subscription status to: {}", newsletterSubscription.getStatus());
    Query query =
        Query.query(Criteria.where(FIELD_EMAIL).is(Subscriber.encryptEmail(emailAddress)));
    Update updateDefinition =
        new Update()
            .set(FIELD_NEWSLETTER_SUBSCRIPTION, newsletterSubscription)
            .set(FIELD_LAST_UPDATED_BY, requester)
            .push(FIELD_ACTIONS)
            .each(actions);
    mongoTemplate.upsert(query, updateDefinition, Subscriber.class);
  }

  public void updateSubscriptionBySubscriberId(
      String subscriberId,
      NewsletterSubscription newsletterSubscription,
      Long subscriberVersion,
      List<Actions> actions) {
    log.info(
        "Updating newsletter subscription status to: {} for subscriber {}",
        newsletterSubscription.getStatus(),
        subscriberId);
    try {
      Query query =
          Query.query(
              Criteria.where("_id")
                  .is(new ObjectId(subscriberId))
                  .and("version")
                  .is(subscriberVersion));
      Update updateDefinition =
          new Update()
              .set(FIELD_NEWSLETTER_SUBSCRIPTION, newsletterSubscription)
              .push(FIELD_ACTIONS)
              .each(actions);
      mongoTemplate.upsert(query, updateDefinition, Subscriber.class);
    } catch (DuplicateKeyException e) {
      String errorMessage =
          String.format(
              "An error occurred while updating newsletter subscription for subscriber: %s",
              subscriberId);
      log.error(errorMessage, e);
      throw new OptimisticLockingFailureException(errorMessage);
    }
  }

  public void unsubscribeNewsletter(String subscriberId, List<Actions> actions) {
    log.info(
        "Updating newsletter subscription status to: {}",
        NewsletterSubscriptionStatus.UNSUBSCRIBED);
    var query = Query.query(Criteria.where("_id").is(new ObjectId(subscriberId)));
    var updateDefinition =
        new Update()
            .set(
                FIELD_NEWSLETTER_SUBSCRIPTION,
                new NewsletterSubscription(
                    NewsletterSubscriptionStatus.UNSUBSCRIBED, null, Instant.now()))
            .push(FIELD_ACTIONS)
            .each(actions);
    mongoTemplate.upsert(query, updateDefinition, Subscriber.class);
  }

  public void unsubscribeCommunication(String subscriberId, List<Actions> actions) {
    log.info(
        "Updating communication subscription status to: {}",
        CommunicationSubscriptionStatus.UNSUBSCRIBED);
    var query = Query.query(Criteria.where("_id").is(new ObjectId(subscriberId)));
    var updateDefinition =
        new Update()
            .set(
                FIELD_COMMUNICATION_SUBSCRIPTION,
                new CommunicationSubscription(
                    CommunicationSubscriptionStatus.UNSUBSCRIBED, Instant.now()))
            .push(FIELD_ACTIONS)
            .each(actions);
    mongoTemplate.upsert(query, updateDefinition, Subscriber.class);
  }

  public Optional<Subscriber> acquireLockAndReturnSubscriberById(String subscriberIdAsString) {
    return acquireLockAndReturnSubscriberById(subscriberIdAsString, 600000);
  }

  public Optional<Subscriber> acquireLockAndReturnSubscriberById(
      String subscriberIdAsString, long lockDurationInMillisecond) {

    Assert.notNull(subscriberIdAsString, "Missing subscriber subscriberId");
    ObjectId subscriberId = new ObjectId(subscriberIdAsString);
    log.info("trying to acquire lock and return subscriber by subscriberId : {}", subscriberId);

    Criteria[] actionFieldCriteria = {
      new Criteria().and(FIELD_ACTIONS).exists(true),
      new Criteria().and(FIELD_ACTIONS).ne(null),
      new Criteria().and(FIELD_ACTIONS).ne(List.of())
    };

    Criteria criteriaA =
        where("_id").is(subscriberId).and("lock").exists(false).andOperator(actionFieldCriteria);

    Criteria criteriaB =
        where("_id")
            .is(subscriberId)
            .and("lock.expiresAt")
            .lt(Instant.now())
            .andOperator(actionFieldCriteria);

    Query query = Query.query(new Criteria().orOperator(criteriaA, criteriaB));

    final Instant acquiredAt = Instant.now();
    final Instant expiresAt = acquiredAt.plusMillis(lockDurationInMillisecond);
    Update update = new Update().set("lock", new Lock(UUID.randomUUID(), acquiredAt, expiresAt));

    final Subscriber subscriber =
        mongoTemplate.findAndModify(
            query, update, new FindAndModifyOptions().returnNew(true), Subscriber.class);

    return Optional.ofNullable(subscriber);
  }

  public UpdateResult releaseLockBySubscriberId(String subscriberIdAsString, Lock lock) {
    Assert.notNull(subscriberIdAsString, "Missing subscriberId.");
    Assert.notNull(lock, "Missing lock");
    ObjectId subscriberId = new ObjectId(subscriberIdAsString);

    Query query =
        Query.query(where("_id").is(subscriberId).and("lock.acquiredBy").is(lock.getAcquiredBy()));

    Update update = new Update().unset("lock");

    return mongoTemplate.updateFirst(query, update, Subscriber.class);
  }

  public boolean releaseLockPopActionUpdateSubscriberAttributes(
      String subscriberIdAsString, Lock lock, Map<String, Object> subscriberAttributesToUpdate) {

    Query query =
        Query.query(
            where("_id")
                .is(new ObjectId(subscriberIdAsString))
                .and("lock.acquiredBy")
                .is(lock.getAcquiredBy()));

    Update update =
        new Update().pop(FIELD_ACTIONS, Update.Position.FIRST).unset("lock").unset("actionError");

    if (!CollectionUtils.isEmpty(subscriberAttributesToUpdate)) {
      subscriberAttributesToUpdate.forEach(
          (key, value) -> {
            if (value == null) {
              update.unset(key);
            } else {
              update.set(key, value);
            }
          });
    }

    return mongoTemplate.updateFirst(query, update, Subscriber.class).getModifiedCount() > 0;
  }

  public void updateSubscriberActionError(String subscriberIdAsString, ActionError actionError) {

    Assert.notNull(subscriberIdAsString, "subscriberId is missing");
    Assert.hasText(actionError.getErrorName(), "errorName is missing");

    ObjectId subscriberId = new ObjectId(subscriberIdAsString);
    final BasicQuery basicQuery = new BasicQuery(new Document("_id", subscriberId));
    final Update update = new Update();
    update.set("actionError.errorName", actionError.getErrorName());
    update.set("actionError.errorMessage", actionError.getErrorMessage());
    update.set("actionError.stackTrace", actionError.getStackTrace());
    update.set("actionError.attemptedAt", actionError.getAttemptedAt());
    update.inc("actionError.errorCount");
    mongoTemplate.updateFirst(basicQuery, update, Subscriber.class);
  }
}
