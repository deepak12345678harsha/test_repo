package de.otto.blablafish_contact_management.handler;

import de.otto.blablafish_contact_management.model.entity.Subscriber;
import java.util.Map;

public interface SubscriberActionHandler {
  Map<String, Object> handle(Subscriber user);
}
