package de.otto.blablafish_contact_management.config;

import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.auth.EC2ContainerCredentialsProviderWrapper;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.simpleemailv2.AmazonSimpleEmailServiceV2;
import com.amazonaws.services.simpleemailv2.AmazonSimpleEmailServiceV2ClientBuilder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;

@Slf4j
@Configuration
public class AWSCredentialConfig {

  @Primary
  @Profile("!local")
  @Bean
  public AWSCredentialsProvider containerCredentialsProvider() {
    return new EC2ContainerCredentialsProviderWrapper();
  }

  @Bean
  @Primary
  @Profile("local")
  public AWSCredentialsProvider localCredentialsProvider() {
    log.info("localCredentialsProvider");
    return new DefaultAWSCredentialsProviderChain();
  }

  @Bean
  @Profile("!integration")
  public AmazonSimpleEmailServiceV2 amazonSimpleEmailService(
      AWSCredentialsProvider awsCredentialsProvider) {
    return AmazonSimpleEmailServiceV2ClientBuilder.standard()
        .withCredentials(awsCredentialsProvider)
        .withRegion(Regions.EU_CENTRAL_1)
        .build();
  }

  @Bean
  @Profile("!integration")
  public AmazonS3 amazonS3Client(AWSCredentialsProvider credentialsProvider) {
    return AmazonS3ClientBuilder.standard()
        .withRegion(Regions.EU_CENTRAL_1)
        .withCredentials(credentialsProvider)
        .build();
  }
}
