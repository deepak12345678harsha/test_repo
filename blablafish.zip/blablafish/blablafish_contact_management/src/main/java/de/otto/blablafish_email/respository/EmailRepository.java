package de.otto.blablafish_email.respository;

import de.otto.blablafish_email.model.entity.Email;
import de.otto.blablafish_email.model.entity.EmailStatus;
import de.otto.blablafish_email.model.entity.EmailStatusHistoryEntry;
import io.jsonwebtoken.lang.Assert;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

@Slf4j
@Repository
public class EmailRepository {

  private final MongoTemplate mongoTemplate;

  public EmailRepository(MongoTemplate mongoTemplate) {
    this.mongoTemplate = mongoTemplate;
  }

  public void insert(Email email) {
    mongoTemplate.insert(email);
  }

  public Email findByIdStatusAndSaveEmailStatusHistory(
      String emailId, EmailStatus status, EmailStatusHistoryEntry emailStatusEntry) {
    Assert.hasText(emailId, "Missing email id.");
    Assert.notNull(status, "Missing emailStatus.");
    Assert.notNull(emailStatusEntry, "Missing emailStatusEntry.");

    Query query =
        Query.query(Criteria.where("id").is(emailId))
            .addCriteria(Criteria.where("status").is(status));
    Update updateDefinition =
        new Update()
            .set("status", emailStatusEntry.getStatus())
            .set("statusTimestamp", emailStatusEntry.getDate())
            .addToSet("statusHistory", emailStatusEntry);
    return mongoTemplate.findAndModify(query, updateDefinition, Email.class);
  }

  public Email findByIdAndSetAwsMessageId(String emailId, String awsMessageId) {
    Assert.hasText(emailId, "Missing email id.");
    Assert.hasText(awsMessageId, "Missing AWS Message id");

    Query query = Query.query(Criteria.where("id").is(emailId));
    Update updateDefinition = new Update().set("awsMessageId", awsMessageId);
    return mongoTemplate.findAndModify(query, updateDefinition, Email.class);
  }

  public Optional<Email> findByAWSMessageIdAndSetStatus(
      String awsMessageId, EmailStatusHistoryEntry emailStatusEntry) {
    Assert.hasText(awsMessageId, "Missing email id.");
    Assert.notNull(emailStatusEntry, "Missing email status history-entry.");
    Query query =
        Query.query(Criteria.where("awsMessageId").is(awsMessageId))
            .addCriteria(Criteria.where("statusTimestamp").lt(emailStatusEntry.getDate()));
    Update updateDefinition =
        new Update()
            .set("status", emailStatusEntry.getStatus())
            .set("statusTimestamp", emailStatusEntry.getDate())
            .addToSet("statusHistory", emailStatusEntry);
    final Email mail =
        this.mongoTemplate.findAndModify(
            query, updateDefinition, new FindAndModifyOptions().returnNew(true), Email.class);
    if (!Objects.isNull(mail)) {
      log.info(
          "Email updated : {},  status : {}, statusHistorySize {} , awsMessageId: {}",
          mail.getId(),
          mail.getStatus(),
          mail.getStatusHistory().size(),
          awsMessageId);
    }
    return Optional.ofNullable(mail);
  }

  public Optional<Email> findByAWSMessageIdAndAddStatusEntry(
      String awsMessageId, EmailStatusHistoryEntry emailStatusEntry) {
    Assert.hasText(awsMessageId, "Missing email id.");
    Assert.notNull(emailStatusEntry, "Missing email status history-entry.");
    Query query = Query.query(Criteria.where("awsMessageId").is(awsMessageId));
    Update updateDefinition = new Update().addToSet("statusHistory", emailStatusEntry);

    final Email mail =
        this.mongoTemplate.findAndModify(
            query, updateDefinition, new FindAndModifyOptions().returnNew(true), Email.class);
    if (!Objects.isNull(mail)) {
      log.info(
          "Email updated : {},  status : {}, statusHistorySize {} , awsMessageId: {}",
          mail.getId(),
          mail.getStatus(),
          mail.getStatusHistory().size(),
          awsMessageId);
    }
    return Optional.ofNullable(mail);
  }

  public Optional<Email> findById(String id) {
    return Optional.ofNullable(mongoTemplate.findById(id, Email.class));
  }

  public void saveAll(List<Email> emails) {
    mongoTemplate.insertAll(emails);
  }

  public void deleteAll(List<Email> emails) {
    var emailIds = emails.stream().map(Email::getId).toList();
    mongoTemplate.findAllAndRemove(
        Query.query(Criteria.where(Email.FIELD_ID).in(emailIds)), Email.class);
  }
}
