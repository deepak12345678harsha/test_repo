package de.otto.blablafish_email.model.entity;

import de.otto.blablafish_contact_management.model.encryption.EncryptedField;
import de.otto.blablafish_contact_management.model.encryption.EncryptedString;
import de.otto.blablafish_contact_management.model.entity.Subscriber;
import java.time.Instant;
import java.util.UUID;
import lombok.*;
import org.springframework.lang.NonNull;

@AllArgsConstructor
@ToString
@Getter
@Builder(access = AccessLevel.PUBLIC)
public class EmailRecipient {

  public static final String FIELD_EMAIL_ID = "emailId";
  @NonNull private String emailId;
  @NonNull private EncryptedField<String> firstName;
  @NonNull private EncryptedField<String> lastName;
  @NonNull private EncryptedField<String> emailAddress;
  @NonNull private EmailStatusHistoryEntry emailStatusHistoryEntry;

  private String partnerId;

  private Boolean newsletterAccepted;

  public static EmailRecipient of(Subscriber subscriber) {
    return EmailRecipient.builder()
        .emailAddress(encryptEmail(subscriber.getEmail().getValue()))
        .emailId(UUID.randomUUID().toString())
        .firstName(encryptFirstName(subscriber.getFirstName().getValue()))
        .lastName(encryptLastName(subscriber.getLastName().getValue()))
        .partnerId(subscriber.getPartnerId())
        .emailStatusHistoryEntry(
            EmailStatusHistoryEntry.of(EmailStatus.READY_TO_SEND, Instant.now()))
        .build();
  }

  public static EmailRecipient of(
      String firstName, String lastName, String toAddress, String partnerId) {
    return EmailRecipient.builder()
        .emailAddress(encryptEmail(toAddress))
        .emailId(UUID.randomUUID().toString())
        .firstName(encryptFirstName(firstName))
        .lastName(encryptLastName(lastName))
        .partnerId(partnerId)
        .emailStatusHistoryEntry(
            EmailStatusHistoryEntry.of(EmailStatus.READY_TO_SEND, Instant.now()))
        .build();
  }

  public static EmailRecipient of(String firstName, String lastName, String toAddress) {
    return of(firstName, lastName, toAddress, "");
  }

  public static EncryptedField<String> encryptEmail(String email) {
    return new EncryptedString(email, "requests.recipient.emailAddress", false);
  }

  public static EncryptedField<String> encryptFirstName(String firstName) {
    return new EncryptedString(firstName, "requests.recipient.firstName", false);
  }

  public static EncryptedField<String> encryptLastName(String lastName) {
    return new EncryptedString(lastName, "requests.recipient.lastName", false);
  }
}
