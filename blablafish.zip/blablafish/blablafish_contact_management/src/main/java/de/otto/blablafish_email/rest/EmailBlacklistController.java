package de.otto.blablafish_email.rest;

import static de.otto.blablafish_contact_management.utils.Constants.SERVICE_NAME;
import static de.otto.blablafish_email.utils.Constants.CONTACT_MANAGEMENT_EMAIL_BLACKLIST_READ_ROLE;
import static de.otto.blablafish_email.utils.Constants.CONTACT_MANAGEMENT_EMAIL_SUPPORT_WRITE_ROLE;
import static de.otto.blablafish_email.utils.Constants.EMAIL_SERVICE;

import de.otto.blablafish_contact_management.exception.SubscriberDoesNotExistException;
import de.otto.blablafish_contact_management.rest.ResponseCollection;
import de.otto.blablafish_contact_management.service.SubscriberService;
import de.otto.blablafish_contact_management.utils.Helper;
import de.otto.blablafish_email.exception.EmailBlacklistNotFoundException;
import de.otto.blablafish_email.model.dto.blacklist.EmailBlacklistDTO;
import de.otto.blablafish_email.model.dto.blacklist.EmailBlacklistResponse;
import de.otto.blablafish_email.service.EmailBlacklistService;
import java.security.Principal;
import java.util.Set;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.jboss.logging.MDC;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/v1")
public class EmailBlacklistController {

  private static final String EMAIL_BLACKLISTS_URI = "/mail-blacklists";
  private static final String EMAIL_BLACKLISTS_SELF_URI =
      EMAIL_BLACKLISTS_URI + "/{mailBlacklistsId}";
  private final EmailBlacklistService blacklistService;

  private final SubscriberService subscriberService;

  @GetMapping(value = EMAIL_BLACKLISTS_URI, produces = MediaType.APPLICATION_JSON_VALUE)
  @PreAuthorize("hasAuthority('" + CONTACT_MANAGEMENT_EMAIL_BLACKLIST_READ_ROLE + "')")
  @ResponseStatus(HttpStatus.OK)
  public ResponseCollection<EmailBlacklistDTO> getEmailBlackListByEmailAddress(
      @RequestParam String emailAddress) throws EmailBlacklistNotFoundException {
    MDC.put(SERVICE_NAME, EMAIL_SERVICE);
    log.info("Received get email blacklist by email address");
    var blacklists = blacklistService.getByEmailAddress(emailAddress);
    MDC.remove(SERVICE_NAME);
    return new ResponseCollection<>(blacklists);
  }

  @GetMapping(value = EMAIL_BLACKLISTS_SELF_URI, produces = MediaType.APPLICATION_JSON_VALUE)
  @PreAuthorize("hasAuthority('" + CONTACT_MANAGEMENT_EMAIL_BLACKLIST_READ_ROLE + "')")
  @ResponseStatus(HttpStatus.OK)
  public EmailBlacklistDTO getEmailBlackListById(@PathVariable String mailBlacklistsId)
      throws EmailBlacklistNotFoundException {
    MDC.put(SERVICE_NAME, EMAIL_SERVICE);
    log.info("Received get email blacklist for mailBlacklistsId: {}", mailBlacklistsId);
    var emailBlacklist = blacklistService.getById(mailBlacklistsId);
    MDC.remove(SERVICE_NAME);
    return EmailBlacklistDTO.from(emailBlacklist);
  }

  @GetMapping(value = "/blacklisted-mails", produces = MediaType.APPLICATION_JSON_VALUE)
  @PreAuthorize("hasAuthority('" + CONTACT_MANAGEMENT_EMAIL_SUPPORT_WRITE_ROLE + "')")
  @ResponseStatus(HttpStatus.OK)
  public Page<EmailBlacklistResponse> getBlacklistedEmails(
      @RequestParam(defaultValue = "") String search, Pageable pageable) {
    return blacklistService.getBlacklistedEmails(search, pageable);
  }

  @PutMapping("/blacklisted-mails")
  @PreAuthorize("hasAuthority('" + CONTACT_MANAGEMENT_EMAIL_SUPPORT_WRITE_ROLE + "')")
  @ResponseStatus(HttpStatus.OK)
  public void removeBlacklistedEmails(
      @RequestBody Set<String> emailIds,
      @RequestHeader("User-Agent") String userAgent,
      Principal principal)
      throws SubscriberDoesNotExistException {
    var userPrincipal = Helper.toUserPrincipal(principal);
    var requester = subscriberService.requesterOf(userPrincipal, userAgent);
    log.info("Remove blacklisted emailIds request received.");
    blacklistService.removeBlacklistedEmails(emailIds, requester);
  }
}
