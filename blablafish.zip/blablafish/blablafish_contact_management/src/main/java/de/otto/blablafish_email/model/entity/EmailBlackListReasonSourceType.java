package de.otto.blablafish_email.model.entity;

public enum EmailBlackListReasonSourceType {
  SES_EVENT
}
