package de.otto.blablafish_email.service;

import com.amazonaws.services.simpleemailv2.AmazonSimpleEmailServiceV2;
import com.amazonaws.services.simpleemailv2.model.AmazonSimpleEmailServiceV2Exception;
import com.amazonaws.services.simpleemailv2.model.SendEmailRequest;
import com.amazonaws.services.simpleemailv2.model.SendEmailResult;
import de.otto.blablafish_contact_management.model.dto.EventType;
import de.otto.blablafish_email.model.dto.mail.EmailAttachmentDetail;
import de.otto.blablafish_email.model.dto.mail.EmailBody;
import de.otto.blablafish_email.model.dto.ses.EmailRequestNotice;
import de.otto.blablafish_email.model.entity.Email;
import de.otto.blablafish_email.model.entity.EmailStatus;
import de.otto.blablafish_email.model.entity.EmailStatusHistoryEntry;
import de.otto.blablafish_email.publishers.SNSPublisher;
import de.otto.blablafish_email.respository.EmailRepository;
import java.io.IOException;
import java.nio.file.Files;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import javax.mail.MessagingException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class EmailSenderService {

  private final AmazonSimpleEmailServiceV2 client;
  private final EmailRepository emailRepository;
  private final EmailAttachmentService emailAttachmentService;
  private final SNSPublisher snsPublisher;
  private final String configSetName;
  private final String sesSenderDomain;

  public EmailSenderService(
      EmailRepository emailRepository,
      AmazonSimpleEmailServiceV2 client,
      EmailAttachmentService emailAttachmentService,
      SNSPublisher snsPublisher,
      @Value("${ses-config-set-name}") String configSetName,
      @Value("${ses-sender-domain}") String sesSenderDomain) {
    this.client = client;
    this.emailRepository = emailRepository;
    this.emailAttachmentService = emailAttachmentService;
    this.snsPublisher = snsPublisher;
    this.configSetName = configSetName;
    this.sesSenderDomain = sesSenderDomain;
  }

  public void send(String emailId) {
    log.info("Email Sender Service");
    final Email savedEmail =
        emailRepository.findByIdStatusAndSaveEmailStatusHistory(
            emailId,
            EmailStatus.READY_TO_SEND,
            EmailStatusHistoryEntry.of(EmailStatus.SENDING, Instant.now()));
    if (savedEmail == null) {
      log.warn("Found no email with id: {} and status: {}", emailId, EmailStatus.READY_TO_SEND);
      return;
    }
    send(savedEmail);
  }

  private void send(Email savedEmail) {
    List<EmailAttachmentDetail> emailAttachmentDetails = new ArrayList<>();
    try {
      emailAttachmentDetails = getAttachments(savedEmail.getAttachmentIds());
      SendEmailRequest emailToSend = createEmailToSend(savedEmail, emailAttachmentDetails);
      log.info(
          "Sending email: {} for emailId: {} from email: {}",
          emailToSend,
          savedEmail.getId(),
          savedEmail.getFromAddress().getValue());
      SendEmailResult emailResult = client.sendEmail(emailToSend);
      emailRepository.findByIdAndSetAwsMessageId(savedEmail.getId(), emailResult.getMessageId());
      log.info("Email for emailId: {} sent successfully", savedEmail.getId());
    } catch (AmazonSimpleEmailServiceV2Exception ex) {
      log.error("Mail got rejected from AWS SES API. EmailId: {} ", savedEmail.getId(), ex);
      publishFailureToSns(savedEmail, EventType.EMAIL_PRECONDITION_FAILED);
    } catch (Exception ex) {
      log.error(
          "Something went wrong while sending mail using aws SES API. EmailId: {} ",
          savedEmail.getId(),
          ex);
      publishFailureToSns(savedEmail, EventType.EMAIL_REQUEST_FAILED);
    } finally {
      deleteTempFiles(emailAttachmentDetails);
    }
  }

  private SendEmailRequest createEmailToSend(
      Email savedEmail, List<EmailAttachmentDetail> attachments)
      throws MessagingException, IOException {
    EmailBody emailBody = EmailBody.of(savedEmail, attachments, sesSenderDomain);

    return new SendEmailRequest()
        .withContent(emailBody.build())
        .withConfigurationSetName(configSetName);
  }

  private List<EmailAttachmentDetail> getAttachments(Set<String> attachmentIds) {
    if (ObjectUtils.isEmpty(attachmentIds)) {
      return Collections.emptyList();
    }
    return attachmentIds.stream().map(emailAttachmentService::getAttachment).toList();
  }

  private void publishFailureToSns(Email email, EventType failureEvent) {
    emailRepository.findByIdStatusAndSaveEmailStatusHistory(
        email.getId(),
        EmailStatus.SENDING,
        EmailStatusHistoryEntry.of(EmailStatus.SES_API_INVOCATION_FAILED, Instant.now()));
    snsPublisher.publish(
        new EmailRequestNotice(email.getMailRequestId().toHexString()), failureEvent);
  }

  private void deleteTempFiles(List<EmailAttachmentDetail> mailAttachmentDetails) {
    for (EmailAttachmentDetail emailAttachmentDetail : mailAttachmentDetails) {
      try {
        Files.deleteIfExists(emailAttachmentDetail.getAttachment().toPath());
      } catch (IOException e) {
        log.info("Error while deleting temp files");
      }
    }
  }
}
