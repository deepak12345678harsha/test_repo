package de.otto.blablafish_email.rest;

import static de.otto.blablafish_contact_management.utils.Constants.SERVICE_NAME;
import static de.otto.blablafish_email.utils.Constants.CONTACT_MANAGEMENT_EMAIL_READ_ROLE;
import static de.otto.blablafish_email.utils.Constants.CONTACT_MANAGEMENT_INTERNAL_EMAIL_WRITE_ROLE;
import static de.otto.blablafish_email.utils.Constants.CONTACT_MANAGEMENT_PARTNER_EMAIL_WRITE_ROLE;
import static de.otto.blablafish_email.utils.Constants.CONTACT_MANAGEMENT_SUPPORT_ADMIN_ROLE;
import static de.otto.blablafish_email.utils.Constants.CONTACT_MANAGEMENT_USER_EMAIL_WRITE_ROLE;
import static de.otto.blablafish_email.utils.Constants.EMAIL_SERVICE;
import static org.springframework.web.util.UriComponentsBuilder.fromHttpUrl;

import de.otto.blablafish_contact_management.config.Features;
import de.otto.blablafish_contact_management.exception.BlaBlaFishException;
import de.otto.blablafish_contact_management.exception.TopicNotFoundException;
import de.otto.blablafish_contact_management.model.dto.UserPrincipal;
import de.otto.blablafish_contact_management.utils.Helper;
import de.otto.blablafish_email.config.ApplicationProperties;
import de.otto.blablafish_email.exception.EmailNotFoundException;
import de.otto.blablafish_email.exception.FileUploadException;
import de.otto.blablafish_email.exception.MultiPartnerEmailException;
import de.otto.blablafish_email.model.dto.EmailRequestDTO;
import de.otto.blablafish_email.model.dto.MultiPartnerEmailResponse;
import de.otto.blablafish_email.model.dto.PostEmailToInternalRequest;
import de.otto.blablafish_email.model.dto.PostEmailToPartnerRequest;
import de.otto.blablafish_email.model.dto.PostEmailToUserRequest;
import de.otto.blablafish_email.model.dto.mail.EmailDTO;
import de.otto.blablafish_email.service.EmailAttachmentService;
import de.otto.blablafish_email.service.EmailRequestService;
import de.otto.blablafish_email.service.EmailService;
import java.net.URI;
import java.security.Principal;
import java.util.List;
import javax.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.jboss.logging.MDC;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@Slf4j
@RestController
@RequestMapping("/v1")
public class EmailController {

  static final String EMAIL_REQUEST_URI = "/mails-requests";
  static final String EMAIL_REQUESTS_SELF_URI = EMAIL_REQUEST_URI + "/{request-id}";
  static final String EMAIL_ATTACHMENT_UPLOADS_URI = "/uploads";
  private final EmailRequestService emailRequestService;
  private final ApplicationProperties applicationProperties;
  private final EmailAttachmentService emailAttachmentService;
  private final EmailService emailService;

  public EmailController(
      EmailRequestService emailRequestService,
      ApplicationProperties applicationProperties,
      EmailAttachmentService emailAttachmentService,
      EmailService emailService) {
    this.emailRequestService = emailRequestService;
    this.applicationProperties = applicationProperties;
    this.emailAttachmentService = emailAttachmentService;
    this.emailService = emailService;
  }

  @PostMapping(
      value = "/user-mails",
      produces = MediaType.APPLICATION_JSON_VALUE,
      consumes = MediaType.APPLICATION_JSON_VALUE)
  @ResponseStatus(HttpStatus.CREATED)
  @PreAuthorize("hasAuthority('" + CONTACT_MANAGEMENT_USER_EMAIL_WRITE_ROLE + "')")
  public ResponseEntity<Object> sendEmailRequestToUser(
      @Valid @RequestBody PostEmailToUserRequest userEmailRequest, Principal principal)
      throws TopicNotFoundException, BlaBlaFishException {
    MDC.put(SERVICE_NAME, EMAIL_SERVICE);
    MDC.put("partnerId", userEmailRequest.getPartnerId());
    MDC.put("topicId", userEmailRequest.getTopicId());
    var userPrincipal = Helper.toUserPrincipal(principal);
    var requestId = emailRequestService.sendEmailToUser(userEmailRequest, userPrincipal);
    MDC.remove(SERVICE_NAME);
    MDC.remove("partnerId");
    MDC.remove("topicId");
    var location =
        fromHttpUrl(locationHeader()).pathSegment("{id}").buildAndExpand(requestId).toUri();
    return ResponseEntity.created(location).build();
  }

  @PostMapping(
      value = "/internal-mails",
      produces = MediaType.APPLICATION_JSON_VALUE,
      consumes = MediaType.APPLICATION_JSON_VALUE)
  @ResponseStatus(HttpStatus.CREATED)
  @PreAuthorize("hasAuthority('" + CONTACT_MANAGEMENT_INTERNAL_EMAIL_WRITE_ROLE + "')")
  public ResponseEntity<Object> sendEmailRequestToInternalTeams(
      @Valid @RequestBody PostEmailToInternalRequest internalEmailRequest, Principal principal)
      throws TopicNotFoundException, BlaBlaFishException {
    MDC.put(SERVICE_NAME, EMAIL_SERVICE);
    MDC.put("topicId", internalEmailRequest.getTopicId());
    var userPrincipal = Helper.toUserPrincipal(principal);
    MDC.remove(SERVICE_NAME);
    MDC.remove("topicId");
    var requestId = emailRequestService.sendInternalEmail(internalEmailRequest, userPrincipal);

    var location =
        fromHttpUrl(locationHeader()).pathSegment("{id}").buildAndExpand(requestId).toUri();
    return ResponseEntity.created(location).build();
  }

  @PostMapping(
      value = "/partner-mails",
      produces = MediaType.APPLICATION_JSON_VALUE,
      consumes = MediaType.APPLICATION_JSON_VALUE)
  @ResponseStatus(HttpStatus.CREATED)
  @PreAuthorize("hasAuthority('" + CONTACT_MANAGEMENT_PARTNER_EMAIL_WRITE_ROLE + "')")
  public ResponseEntity<Void> sendEmailRequestToPartner(
      @Valid @RequestBody PostEmailToPartnerRequest email, Principal principal)
      throws TopicNotFoundException, BlaBlaFishException {
    MDC.put(SERVICE_NAME, EMAIL_SERVICE);
    MDC.put("partnerId", email.getPartnerId());
    MDC.put("topicId", email.getTopicId());
    log.info("Received email request");
    UserPrincipal userPrincipal = Helper.toUserPrincipal(principal);
    String requestId = emailRequestService.sendEmailToPartner(email, userPrincipal);
    MDC.remove(SERVICE_NAME);
    MDC.remove("partnerId");
    MDC.remove("topicId");
    URI location =
        fromHttpUrl(locationHeader()).pathSegment("{id}").buildAndExpand(requestId).toUri();
    return ResponseEntity.created(location).build();
  }

  @PostMapping(
      value = "/multi-partner-mails",
      produces = MediaType.APPLICATION_JSON_VALUE,
      consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
  @ResponseStatus(HttpStatus.ACCEPTED)
  @PreAuthorize("hasAuthority('" + CONTACT_MANAGEMENT_SUPPORT_ADMIN_ROLE + "')")
  public ResponseEntity<MultiPartnerEmailResponse> sendEmailToMultiPartner(
      @RequestParam(value = "file", required = false) MultipartFile file,
      @RequestParam("partnerIds") List<String> partnerIds,
      @RequestParam("emailBodyText") String emailBodyText,
      Principal principal)
      throws FileUploadException, MultiPartnerEmailException {
    MDC.put(SERVICE_NAME, EMAIL_SERVICE);
    log.info("Received email request");
    var userPrincipal = Helper.toUserPrincipal(principal);
    var multiPartnerEmailResponse =
        emailRequestService.sendEmailToPartners(partnerIds, emailBodyText, file, userPrincipal);
    MDC.clear();
    return ResponseEntity.accepted().body(multiPartnerEmailResponse);
  }

  @GetMapping(value = "/mails/{mailId}", produces = MediaType.APPLICATION_JSON_VALUE)
  @PreAuthorize("hasAnyAuthority('" + CONTACT_MANAGEMENT_EMAIL_READ_ROLE + "')")
  @ResponseStatus(HttpStatus.OK)
  public EmailDTO getEmail(@PathVariable("mailId") String id) throws EmailNotFoundException {
    MDC.put(SERVICE_NAME, EMAIL_SERVICE);
    var emailDTO = emailService.getEmailById(id);
    MDC.remove(SERVICE_NAME);
    return emailDTO;
  }

  @GetMapping(value = EMAIL_REQUESTS_SELF_URI, produces = MediaType.APPLICATION_JSON_VALUE)
  @PreAuthorize("hasAuthority('" + CONTACT_MANAGEMENT_EMAIL_READ_ROLE + "')")
  @ResponseStatus(HttpStatus.OK)
  public EmailRequestDTO getEmailRequest(@PathVariable("request-id") String requestId) {
    MDC.put(SERVICE_NAME, EMAIL_SERVICE);
    log.info("Received get email request for requestId: {}", requestId);
    var emailRequest = emailRequestService.getRequestById(requestId);
    MDC.remove(SERVICE_NAME);
    return EmailRequestDTO.of(emailRequest);
  }

  @PostMapping(
      value = EMAIL_ATTACHMENT_UPLOADS_URI,
      consumes = MediaType.MULTIPART_FORM_DATA_VALUE,
      produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseStatus(HttpStatus.CREATED)
  @PreAuthorize("hasAuthority('" + CONTACT_MANAGEMENT_PARTNER_EMAIL_WRITE_ROLE + "')")
  public String uploadFileAttachmentsForEmail(
      @RequestParam("file") MultipartFile file, Principal principal) throws FileUploadException {
    MDC.put(SERVICE_NAME, EMAIL_SERVICE);
    var userPrincipal = Helper.toUserPrincipal(principal);
    var attachmentId =
        emailAttachmentService.upload(
            file, userPrincipal.getClientId(), userPrincipal.getSubject());
    MDC.remove(SERVICE_NAME);
    return attachmentId;
  }

  private String locationHeader() {
    if (Features.EXCLUDE_CONTACT_MANAGEMENT_IN_RESPONSE_URI_HEADER.isActive()) {
      return String.format(
          "https://%s/v1/mails-requests", applicationProperties.getInternalApiDomain());
    }
    return String.format(
        "https://%s/%s/v1/mails-requests",
        applicationProperties.getInternalApiDomain(), "contact-management");
  }
}
