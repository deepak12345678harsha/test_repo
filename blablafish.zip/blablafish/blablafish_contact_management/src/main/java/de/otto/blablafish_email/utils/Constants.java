package de.otto.blablafish_email.utils;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class Constants {
  public static final String CONTACT_MANAGEMENT_USER_EMAIL_WRITE_ROLE = "cms.uem.w";
  public static final String CONTACT_MANAGEMENT_INTERNAL_EMAIL_WRITE_ROLE = "cms.iem.w";
  public static final String CONTACT_MANAGEMENT_PARTNER_EMAIL_WRITE_ROLE = "cms.pem.w";
  public static final String CONTACT_MANAGEMENT_EMAIL_READ_ROLE = "cms.mre.r";
  public static final String CONTACT_MANAGEMENT_EMAIL_BLACKLIST_READ_ROLE = "cms.ebl.r";
  public static final String CONTACT_MANAGEMENT_SUPPORT_ADMIN_ROLE =
      "ContactManagementSupportAdmin";
  public static final String CONTACT_MANAGEMENT_EMAIL_SUPPORT_WRITE_ROLE = "cms.ems.w";
  public static final String SOFT_BOUNCE_TYPE = "Transient";
  public static final String GENERAL_SOFT_BOUNCE_SUB_TYPE = "General";
  public static final String COOPERATION_BASIC = "cooperation_basic";
  public static final String EMAIL_SERVICE = "email-service";
  public static final String NEWSLETTER_SERVICE = "newsletter-service";
  public static final String SERVICE_NAME = "serviceName";
  public static final String EVENT_LABEL = "eventLabel";
  public static final String EVENT_ID = "eventId";
}
