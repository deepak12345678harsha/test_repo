package de.otto.blablafish_email.exception;

import de.otto.blablafish_email.model.dto.ValidationReason;
import lombok.Getter;
import org.springframework.util.Assert;

@Getter
public class ValidationException extends RuntimeException {

  private final ValidationReason reason;

  private final String description;

  public ValidationException(ValidationReason reason, String description) {
    super(
        String.format(
            "Validation error: Reason: %s | Description: %s", reason.name(), description));
    this.reason = reason;
    this.description = description;
  }

  public static ValidationException withoutDescription(ValidationReason reason) {
    Assert.notNull(reason, "Missing reason.");
    return new ValidationException(reason, null);
  }
}
