package de.otto.blablafish_email.service;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import de.otto.blablafish_contact_management.exception.BlaBlaFishError;
import de.otto.blablafish_contact_management.exception.BlaBlaFishException;
import de.otto.blablafish_email.exception.FileUploadException;
import de.otto.blablafish_email.model.dto.EmailAttachmentDTO;
import de.otto.blablafish_email.model.dto.SplunkOperationCode;
import de.otto.blablafish_email.model.dto.mail.EmailAttachmentDetail;
import de.otto.blablafish_email.model.entity.EmailAttachment;
import de.otto.blablafish_email.respository.EmailAttachmentRepository;
import de.otto.blablafish_email.utils.FileUtils;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.jboss.logging.MDC;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.web.multipart.MultipartFile;

@Service
@Slf4j
public class EmailAttachmentService {

  private final AmazonS3 amazonS3;

  private final String s3BucketName;

  private final EmailAttachmentRepository emailAttachmentRepository;

  private final int MAX_ALLOWED_ATTACHMENTS_SIZE = (int) 9.5 * 1024 * 1024;
  private final ObjectMapper objectMapper;

  public EmailAttachmentService(
      AmazonS3 amazonS3,
      @Value("${s3-buckets.email-attachments}") String s3BucketName,
      EmailAttachmentRepository emailAttachmentRepository,
      ObjectMapper objectMapper) {
    this.amazonS3 = amazonS3;
    this.s3BucketName = s3BucketName;
    this.emailAttachmentRepository = emailAttachmentRepository;
    this.objectMapper = objectMapper;
  }

  public String upload(MultipartFile file, String clientId, String subject)
      throws FileUploadException {

    loggingForUpload();
    try (InputStream is = file.getInputStream()) {
      var s3UploadKey = buildS3UploadKey(Instant.now());
      uploadToS3(is, s3UploadKey);
      var attachment = saveEmailAttachment(file, s3UploadKey, clientId, subject);
      log.info("File uploaded successfully to S3 with id {}", attachment.getId());
      return attachment.getId();
    } catch (IOException ex) {
      log.error("Error while reading file !! File cannot be uploaded");
      throw new FileUploadException("Error while reading file");
    }
  }

  private void upload(File file, EmailAttachmentDTO attachmentDTO) throws FileUploadException {

    loggingForUpload();
    try (InputStream is = new FileInputStream(file)) {
      String s3UploadKey = buildS3UploadKey(attachmentDTO.getCreatedAt());
      uploadToS3(is, s3UploadKey);
      EmailAttachment attachment = saveEmailAttachment(attachmentDTO, s3UploadKey);
      log.info("File uploaded successfully to S3 with id {}", attachment.getId());
    } catch (IOException ex) {
      log.error("Error while reading file !! File cannot be uploaded");
      throw new FileUploadException("Error while reading file");
    }
  }

  private String buildS3UploadKey(Instant instant) {
    LocalDateTime dateTime = LocalDateTime.ofInstant(instant, ZoneOffset.UTC);
    String formattedDate = DateTimeFormatter.ofPattern("yyyy-MM-dd").format(dateTime);
    String formattedTime = DateTimeFormatter.ofPattern("HH-mm-ss.SSSS").format(dateTime);
    String fileKey = String.format("%s-%s", formattedTime, UUID.randomUUID());
    return String.format("%s/%s", formattedDate, fileKey);
  }

  private void uploadToS3(InputStream is, String s3UploadKey) {
    PutObjectRequest putObjectRequest =
        new PutObjectRequest(s3BucketName, s3UploadKey, is, new ObjectMetadata());
    amazonS3.putObject(putObjectRequest);
  }

  private File download(String s3BucketName, String s3UploadKey, String filename) {
    S3Object s3Object = downloadFromS3(s3BucketName, s3UploadKey);
    String[] fileNamesByExtension = filename.split("\\.");
    File file =
        FileUtils.createTempFile("tmp", fileNamesByExtension[fileNamesByExtension.length - 1]);
    FileUtils.copyFile(file.toPath(), s3Object.getObjectContent());
    return file;
  }

  private S3Object downloadFromS3(String s3Bucket, String s3UploadKey) {
    return amazonS3.getObject(s3Bucket, s3UploadKey);
  }

  public EmailAttachmentDetail getAttachment(String attachmentId) {
    EmailAttachment attachment = emailAttachmentRepository.fetchOne(attachmentId);
    String fileName = attachment.getFileName().getValue();
    File file = download(attachment.getS3BucketName(), attachment.getS3UploadKey(), fileName);
    return new EmailAttachmentDetail(fileName, file);
  }

  private EmailAttachment saveEmailAttachment(
      MultipartFile file, String s3UploadKey, String clientId, String subject) {
    var attachment =
        EmailAttachment.builder()
            .fileName(EmailAttachment.encryptFileName(file.getOriginalFilename()))
            .contentType(file.getContentType())
            .fileSizeInBytes(file.getSize())
            .s3BucketName(s3BucketName)
            .s3UploadKey(s3UploadKey)
            .createdAt(Instant.now())
            .clientId(clientId)
            .subject(subject)
            .build();
    return emailAttachmentRepository.insertOne(attachment);
  }

  private EmailAttachment saveEmailAttachment(
      EmailAttachmentDTO emailAttachmentDTO, String s3UploadKey) {
    EmailAttachment attachment = EmailAttachment.of(s3BucketName, s3UploadKey, emailAttachmentDTO);
    return emailAttachmentRepository.insertOne(attachment);
  }

  public void validateAttachments(Set<String> attachmentIds, String clientId)
      throws BlaBlaFishException {
    if (CollectionUtils.isEmpty(attachmentIds)) {
      return;
    }
    log.debug("Validating email attachments");
    List<EmailAttachment> attachments = emailAttachmentRepository.fetchAll(attachmentIds);
    validateAttachmentIds(attachments, attachmentIds);
    checkIfUserIsAllowedToUseAttachment(attachments, clientId);
    validateAttachmentSize(attachments);
  }

  private void validateAttachmentIds(
      List<EmailAttachment> attachments, Set<String> attachmentIdsFromRequest)
      throws BlaBlaFishException {
    List<String> availableAttachmentIds = attachments.stream().map(EmailAttachment::getId).toList();

    List<String> invalidAttachmentIds =
        attachmentIdsFromRequest.stream()
            .filter(attachmentId -> !availableAttachmentIds.contains(attachmentId))
            .toList();

    if (!invalidAttachmentIds.isEmpty()) {
      String message =
          String.format("Invalid Attachments - [%s]", String.join(",", invalidAttachmentIds));
      throw new BlaBlaFishException(message, BlaBlaFishError.INVALID_EMAIL_ATTACHMENTS_ERROR);
    }
  }

  private void checkIfUserIsAllowedToUseAttachment(
      List<EmailAttachment> attachments, String clientId) throws BlaBlaFishException {
    List<String> unauthorizedAttachments =
        attachments.stream()
            .filter(attachment -> !attachment.getClientId().equals(clientId))
            .map(EmailAttachment::getId)
            .toList();

    if (!unauthorizedAttachments.isEmpty()) {
      String message =
          String.format(
              "You are not allowed to access attachments - [%s]",
              String.join(",", unauthorizedAttachments));
      throw new BlaBlaFishException(message, BlaBlaFishError.ATTACHMENT_ACCESS_DENIED_ERROR);
    }
  }

  private void validateAttachmentSize(List<EmailAttachment> attachments) {
    long totalAttachmentsSize =
        attachments.stream().mapToLong(EmailAttachment::getFileSizeInBytes).sum();

    if (totalAttachmentsSize > MAX_ALLOWED_ATTACHMENTS_SIZE) {
      throw new MaxUploadSizeExceededException(MAX_ALLOWED_ATTACHMENTS_SIZE);
    }
  }

  private void loggingForUpload() {
    try {
      var detailsLogging = new HashMap<>();
      detailsLogging.put(
          "operationCode", List.of(SplunkOperationCode.API_WITH_OTTO_TEAMS_ACCESS.getCode()));
      MDC.put("details", objectMapper.writeValueAsString(detailsLogging));
    } catch (JsonProcessingException e) {
      log.error("An error occurred while logging for file upload | {}", e.getMessage());
    }
    log.info("Attachment Received");
    MDC.remove("details");
  }

  public void syncAttachment(EmailAttachmentDTO emailAttachmentDTO)
      throws JsonProcessingException, FileUploadException {
    var attachmentId = emailAttachmentDTO.getAttachmentId();
    log.info("Attempting to Sync attachment with id: {}", attachmentId);

    if (emailAttachmentRepository.attachmentExists(attachmentId)) {
      log.info("Attachment already exists with id: {}", attachmentId);
      return;
    }

    File file =
        download(
            emailAttachmentDTO.getS3BucketName(),
            emailAttachmentDTO.getS3UploadKey(),
            emailAttachmentDTO.getFileName());
    upload(file, emailAttachmentDTO);
    log.info("Attachment synced successfully with id: {}", attachmentId);
  }
}
