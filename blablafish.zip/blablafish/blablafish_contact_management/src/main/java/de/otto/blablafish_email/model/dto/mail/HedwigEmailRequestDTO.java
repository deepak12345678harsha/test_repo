package de.otto.blablafish_email.model.dto.mail;

import static com.fasterxml.jackson.annotation.JsonFormat.Shape.STRING;

import com.fasterxml.jackson.annotation.JsonFormat;
import de.otto.blablafish_email.model.entity.EmailRequest;
import de.otto.blablafish_email.model.entity.EmailRequestStatus;
import de.otto.blablafish_email.model.entity.EmailRequester;
import java.time.Instant;
import java.util.List;
import java.util.Set;
import javax.validation.constraints.NotNull;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.bson.Document;
import org.bson.types.ObjectId;

@AllArgsConstructor
@Getter
@Builder(access = AccessLevel.PRIVATE)
@NoArgsConstructor
public class HedwigEmailRequestDTO {

  @NotNull private Integer topicId;

  @NotNull private List<HedwigEmailRecipientDTO> recipients;

  @NotNull private Document payload;

  @NotNull
  @JsonFormat(shape = STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSX", timezone = "UTC")
  private Instant createdAt;

  @NotNull private EmailRequestStatus status;

  private EmailRequester requester;

  private Set<String> attachmentIds;

  public static EmailRequest toEmailRequest(HedwigEmailRequestDTO hedwigRequest, String requestId) {

    return EmailRequest.builder()
        .requestId(new ObjectId(requestId))
        .topicId(hedwigRequest.getTopicId())
        .createdAt(hedwigRequest.getCreatedAt())
        .recipients(
            hedwigRequest.getRecipients().stream()
                .map(HedwigEmailRecipientDTO::toEmailRecipient)
                .toList())
        .payload(EmailRequest.encryptPayload(hedwigRequest.getPayload()))
        .status(hedwigRequest.getStatus())
        .requester(hedwigRequest.getRequester())
        .attachmentIds(hedwigRequest.getAttachmentIds())
        .build();
  }
}
