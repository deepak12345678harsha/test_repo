package de.otto.blablafish_contact_management.cdc;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import de.otto.blablafish_contact_management.model.dto.DeepSeaEvent;
import de.otto.blablafish_contact_management.model.dto.EventType;
import de.otto.blablafish_contact_management.model.dto.UserDeleteDTO;
import de.otto.blablafish_contact_management.model.dto.UserSetDTO;
import de.otto.blablafish_email.model.dto.EmailAttachmentDTO;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor(access = AccessLevel.PRIVATE)
public class EventMessageValidator {

  private static final ObjectMapper objectMapper = new ObjectMapper();

  public static void validateMessage(String message) throws Exception {
    objectMapper
        .registerModule(new JavaTimeModule())
        .enable(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_USING_DEFAULT_VALUE)
        .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    try {
      final DeepSeaEvent deepSeaEvent = objectMapper.readValue(message, DeepSeaEvent.class);
      if (deepSeaEvent.getType() == EventType.UNKNOWN) {
        throw new RuntimeException("Unknown EventType, Message: " + message);
      }
      if (deepSeaEvent.getType() == EventType.NEPTUNE_USER_SET) {
        objectMapper.convertValue(deepSeaEvent.getData(), UserSetDTO.class);
      }
      if (deepSeaEvent.getType() == EventType.NEPTUNE_USER_DELETED) {
        objectMapper.convertValue(deepSeaEvent.getData(), UserDeleteDTO.class);
      }
      if (deepSeaEvent.getType().equals(EventType.EMAIL_ATTACHMENT_CREATED)) {
        objectMapper.convertValue(deepSeaEvent.getData(), EmailAttachmentDTO.class);
      }
    } catch (Exception e) {
      throw new Exception("Event does not match", e);
    }
  }
}
