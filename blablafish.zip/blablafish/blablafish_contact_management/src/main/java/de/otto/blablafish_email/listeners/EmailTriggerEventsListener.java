package de.otto.blablafish_email.listeners;

import static de.otto.blablafish_contact_management.utils.Constants.SERVICE_NAME;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import de.otto.blablafish_email.exception.EmailNotFoundException;
import de.otto.blablafish_email.model.dto.MongoDbTriggerEvent;
import de.otto.blablafish_email.service.EmailMigrationService;
import de.otto.blablafish_email.service.EmailSenderService;
import de.otto.blablafish_email.service.EmailService;
import de.otto.blablafish_email.utils.Constants;
import io.awspring.cloud.messaging.listener.SqsMessageDeletionPolicy;
import io.awspring.cloud.messaging.listener.annotation.SqsListener;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.jboss.logging.MDC;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class EmailTriggerEventsListener {

  private final ObjectMapper objectMapper;
  private final EmailSenderService emailSenderService;
  private final EmailMigrationService emailMigrationService;
  private final EmailService emailService;

  @SqsListener(
      value = "${mongoDbTrigger.mails.queueUrl}",
      deletionPolicy = SqsMessageDeletionPolicy.ON_SUCCESS)
  public void listenToEmailMongoDbTriggers(String mongoTriggerMessage) {
    MDC.put(Constants.SERVICE_NAME, Constants.EMAIL_SERVICE);
    log.debug("MongoDB trigger initiated for email sending");
    try {
      final MongoDbTriggerEvent event =
          objectMapper.readValue(mongoTriggerMessage, MongoDbTriggerEvent.class);
      String emailId = event.getDetail().getDocumentKey().get_id();

      // TODO: remove this block after mail migration is complete.
      if (emailMigrationService.migrationRequestExists(
          emailService.getEmailById(emailId).getEmailRequestId())) {
        log.info(
            "Email Migration is in progress. Skipping EmailTriggerEvent for mailId {} : ", emailId);
        return;
      }

      log.info("MongoDB trigger received for email with id: {}", emailId);
      emailSenderService.send(emailId);
    } catch (JsonProcessingException | RuntimeException | EmailNotFoundException e) {
      log.error("Failed to process MongoDB trigger event : {}", e.getMessage(), e);
    } finally {
      MDC.remove(SERVICE_NAME);
    }
  }
}
