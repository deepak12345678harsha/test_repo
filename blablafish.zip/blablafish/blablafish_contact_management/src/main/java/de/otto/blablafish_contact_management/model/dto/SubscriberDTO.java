package de.otto.blablafish_contact_management.model.dto;

import de.otto.blablafish_contact_management.model.entity.Subscriber;
import lombok.*;

@Getter
@Builder(access = AccessLevel.PUBLIC)
@AllArgsConstructor
@NoArgsConstructor
public class SubscriberDTO {
  @NonNull private String id;
  @NonNull private String firstName;
  @NonNull private String lastName;
  @NonNull private String email;

  public static SubscriberDTO from(Subscriber subscriber) {
    return SubscriberDTO.builder()
        .id(subscriber.getUserId().toString())
        .firstName(subscriber.getFirstName().getValue())
        .lastName(subscriber.getLastName().getValue())
        .email(subscriber.getEmail().getValue())
        .build();
  }
}
