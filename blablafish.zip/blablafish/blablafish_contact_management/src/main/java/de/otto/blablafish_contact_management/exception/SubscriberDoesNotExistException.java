package de.otto.blablafish_contact_management.exception;

public class SubscriberDoesNotExistException extends Exception {

  public SubscriberDoesNotExistException(String message) {
    super(message);
  }
}
