package de.otto.blablafish_email.model.entity;

import de.otto.blablafish_contact_management.model.encryption.EncryptedField;
import de.otto.blablafish_contact_management.model.encryption.EncryptedString;
import java.time.Instant;
import java.util.List;
import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.lang.NonNull;
import org.springframework.lang.Nullable;

@AllArgsConstructor
@Getter
@Document(collection = "mails")
@Builder
@CompoundIndex(
    name = "awsMessageId_1_statusTimestamp_-1",
    def = "{'awsMessageId' : 1, 'statusTimestamp' : -1 }")
public class Email {
  public static final String FIELD_ID = "id";

  @Id private String id;

  @Nullable private String awsMessageId;

  private EncryptedField<String> htmlBody;

  private EncryptedField<String> textBody;

  @NonNull private EncryptedField<String> subject;

  @NonNull private EncryptedField<String> toAddress;

  @NonNull private EncryptedField<String> fromAddress;

  // TODO: sendDate is non-null in email-service, but not returned in API response. Mark these
  // non-null once fixed by team neptune
  private Instant sendDate;

  // TODO: createdAt is non-null in email-service, but not returned in API response. Mark these
  // non-null once fixed by team neptune
  private Instant createdAt;

  @NonNull private ObjectId mailRequestId;

  @NonNull private EmailStatus status;

  @NonNull private Instant statusTimestamp;

  private List<EmailStatusHistoryEntry> statusHistory;

  private Set<String> attachmentIds;

  public static Email of(
      ObjectId requestId,
      EmailRecipient recipient,
      String subject,
      String htmlBody,
      String textBody,
      String fromAddress,
      Set<String> attachmentIds) {
    final Instant now = Instant.now();
    return Email.builder()
        .id(recipient.getEmailId())
        .mailRequestId(requestId)
        .htmlBody(encryptedHtmlBody(htmlBody))
        .textBody(encryptedTextBody(textBody))
        .subject(encryptedSubject(subject))
        .toAddress(encryptedToAddress(recipient.getEmailAddress().getValue()))
        .fromAddress(Email.encryptedFromAddress(fromAddress))
        .createdAt(now)
        .sendDate(now)
        .status(EmailStatus.READY_TO_SEND)
        .statusTimestamp(now)
        .statusHistory(List.of(EmailStatusHistoryEntry.of(EmailStatus.READY_TO_SEND, now)))
        .attachmentIds(attachmentIds)
        .build();
  }

  public static EncryptedField<String> encryptedHtmlBody(String htmlBody) {
    return new EncryptedString(htmlBody, "mails.htmlBody", false);
  }

  public static EncryptedField<String> encryptedTextBody(String textBody) {
    return new EncryptedString(textBody, "mails.textBody", false);
  }

  public static EncryptedField<String> encryptedSubject(String subject) {
    return new EncryptedString(subject, "mails.subject", false);
  }

  public static EncryptedField<String> encryptedToAddress(String toAddress) {
    return new EncryptedString(toAddress, "mails.toAddress", false);
  }

  public static EncryptedField<String> encryptedFromAddress(String fromAddress) {
    return new EncryptedString(fromAddress, "mails.fromAddress", false);
  }
}
