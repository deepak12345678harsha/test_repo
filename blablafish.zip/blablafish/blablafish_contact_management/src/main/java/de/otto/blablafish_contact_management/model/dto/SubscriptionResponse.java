package de.otto.blablafish_contact_management.model.dto;

public enum SubscriptionResponse {
  SUBSCRIPTION_SUCCESSFUL,
  SUBSCRIPTION_UNSUCCESSFUL
}
