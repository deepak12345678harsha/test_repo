package de.otto.blablafish_email.listeners;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import de.otto.blablafish_contact_management.model.dto.EventType;
import de.otto.blablafish_contact_management.model.entity.Requester;
import de.otto.blablafish_contact_management.service.SubscriberService;
import de.otto.blablafish_email.model.dto.MongoDbTriggerEvent;
import io.awspring.cloud.messaging.listener.SqsMessageDeletionPolicy;
import io.awspring.cloud.messaging.listener.annotation.SqsListener;
import lombok.extern.slf4j.Slf4j;
import org.bson.types.ObjectId;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class EmailBlacklistsMongoDBEventListener {
  private final ObjectMapper objectMapper;
  private final SubscriberService subscriberService;

  public EmailBlacklistsMongoDBEventListener(
      ObjectMapper objectMapper, SubscriberService subscriberService) {
    this.objectMapper = objectMapper;
    this.subscriberService = subscriberService;
  }

  @SqsListener(
      value = "${mongoDbTrigger.mailBlacklists.queueUrl}",
      deletionPolicy = SqsMessageDeletionPolicy.ON_SUCCESS)
  public void emailRequestsListener(String mongoTriggerMessage) {
    log.debug("MongoDB Trigger is initiated for mail blacklists collection");
    ObjectId blacklistId = null;
    try {
      final MongoDbTriggerEvent event =
          objectMapper.readValue(mongoTriggerMessage, MongoDbTriggerEvent.class);
      blacklistId = new ObjectId(event.getDetail().getDocumentKey().get_id());

      log.info("mongodb trigger received blacklist with id: {}", blacklistId);
      this.subscriberService.setIsUserBlacklistedToTrue(
          blacklistId, Requester.ofEventType(EventType.EMAIL_BLACKLISTED_MONGO_TRIGGER));

    } catch (JsonProcessingException | RuntimeException e) {
      log.error("Failed to parse message", e);
      throw new RuntimeException("Failed to parse message.", e);
    }
  }
}
