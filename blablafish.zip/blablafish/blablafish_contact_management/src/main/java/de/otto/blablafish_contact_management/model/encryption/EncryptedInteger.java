package de.otto.blablafish_contact_management.model.encryption;

import org.bson.BsonBinary;
import org.bson.BsonInt32;
import org.bson.BsonValue;

public class EncryptedInteger extends EncryptedField<Integer> {
  public EncryptedInteger(Integer value, String keyAltName, boolean isSearchable) {
    super(value, keyAltName, isSearchable);
  }

  public EncryptedInteger(Integer value, BsonBinary bsonBinary) {
    super(value, bsonBinary);
  }

  public BsonValue toBsonValue() {
    return getValue() == null ? null : new BsonInt32(getValue());
  }
}
