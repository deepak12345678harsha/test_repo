package de.otto.blablafish_email.model.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.bson.Document;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@JsonIgnoreProperties(ignoreUnknown = true)
public class UpdateDescription {
  private List<String> removedFields;
  private Document updatedFields;
  private List<TruncatedArray> truncatedArrays;
}
