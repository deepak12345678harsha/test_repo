package de.otto.blablafish_email.model.dto.mail;

import static javax.mail.Message.RecipientType.TO;

import com.amazonaws.services.simpleemailv2.model.EmailContent;
import com.amazonaws.services.simpleemailv2.model.RawMessage;
import de.otto.blablafish_email.model.entity.Email;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.List;
import java.util.Objects;
import java.util.Properties;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import lombok.Builder;
import lombok.Getter;
import org.springframework.util.CollectionUtils;

@Builder
public class EmailBody {

  private static final String HTML_MIME_TYPE = "text/html; charset=UTF-8";
  private static final String TEXT_PLAIN_MIME_TYPE = "text/plain; charset=UTF-8";
  private static final String MIXED_MULTIPART_SUBTYPE = "mixed";
  private static final String ALTERNATE_MULTIPART_SUBTYPE = "alternative";
  private static final String RETURN_PATH_HEADER = "Return-Path";

  private final String from;
  private final String to;
  private final String subject;
  private final String htmlContent;
  private final String textContent;
  private final List<EmailAttachmentDetail> attachments;
  private final String sesSenderDomain;

  @Getter private final MimeMessage mimeMessage;

  @Getter private final MimeMultipart msg;

  public static EmailBody of(
      Email email, List<EmailAttachmentDetail> attachments, String sesSenderDomain) {
    boolean isAttachmentsAvailable = !CollectionUtils.isEmpty(attachments);
    return EmailBody.builder()
        .from(email.getFromAddress().getValue())
        .to(email.getToAddress().getValue())
        .subject(email.getSubject().getValue())
        .htmlContent(Objects.isNull(email.getHtmlBody()) ? "" : email.getHtmlBody().getValue())
        .textContent(Objects.isNull(email.getTextBody()) ? "" : email.getTextBody().getValue())
        .mimeMessage(createMimeMessage())
        /**
         * multipart/alternative - Indicates that each part is an "alternative" version of the same
         * content, each in a different format denoted by its "Content-Type" header. multipart/mixed
         * - The primary subtype is intended for use when the body parts are independent and
         * intended to be displayed serially. Any multipart subtypes that an implementation does not
         * recognize should be treated as being of subtype "mixed".
         */
        .msg(
            isAttachmentsAvailable
                ? new MimeMultipart(MIXED_MULTIPART_SUBTYPE)
                : new MimeMultipart(ALTERNATE_MULTIPART_SUBTYPE))
        .attachments(attachments)
        .sesSenderDomain(sesSenderDomain)
        .build();
  }

  private static MimeMessage createMimeMessage() {
    Session session = Session.getDefaultInstance(new Properties());
    return new MimeMessage(session);
  }

  public EmailContent build() throws MessagingException, IOException {
    addMailParams();
    addMailContent();
    addAttachments();
    mimeMessage.setContent(msg);

    return new EmailContent().withRaw(getRawMessage());
  }

  private RawMessage getRawMessage() throws IOException, MessagingException {
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    mimeMessage.writeTo(byteArrayOutputStream);
    return new RawMessage().withData(ByteBuffer.wrap(byteArrayOutputStream.toByteArray()));
  }

  private void addAttachments() throws MessagingException {
    if (attachments != null && !attachments.isEmpty()) {
      for (EmailAttachmentDetail attachment : attachments) {
        MimeBodyPart mimeBodyPart = new MimeBodyPart();
        DataSource source = new FileDataSource(attachment.getAttachment());
        mimeBodyPart.setDataHandler(new DataHandler(source));
        mimeBodyPart.setFileName(attachment.getFileName());
        msg.addBodyPart(mimeBodyPart);
      }
    }
  }

  private void addMailContent() throws MessagingException {
    // The order of the parts is significant. Entities should place the body parts in increasing
    // order of preference, that is, with the preferred format last.
    // Systems can then choose the "best" representation they are capable of processing; in general,
    // this will be the last part that the system can understand, although other factors may affect
    // this.
    boolean isAttachmentsAvailable = !CollectionUtils.isEmpty(attachments);
    MimeBodyPart textPart = new MimeBodyPart();
    textPart.setContent(textContent, TEXT_PLAIN_MIME_TYPE);

    MimeBodyPart htmlPart = new MimeBodyPart();
    htmlPart.setContent(htmlContent, HTML_MIME_TYPE);

    if (!isAttachmentsAvailable) {
      msg.addBodyPart(textPart);
      msg.addBodyPart(htmlPart);
    } else {
      // multipart/alternative - Indicates that each part is an "alternative" version of the same
      // content, each in a different format denoted by its "Content-Type" header.
      MimeMultipart msgBody = new MimeMultipart(ALTERNATE_MULTIPART_SUBTYPE);

      MimeBodyPart wrap = new MimeBodyPart();
      msgBody.addBodyPart(textPart);
      msgBody.addBodyPart(htmlPart);
      wrap.setContent(msgBody);

      msg.addBodyPart(wrap);
    }
  }

  private void addMailParams() throws MessagingException {
    mimeMessage.setFrom(new InternetAddress(from));
    mimeMessage.setSubject(subject);
    mimeMessage.addRecipients(TO, InternetAddress.parse(to));
    mimeMessage.addHeader(RETURN_PATH_HEADER, String.format("<bounce@%s>", sesSenderDomain));
  }
}
