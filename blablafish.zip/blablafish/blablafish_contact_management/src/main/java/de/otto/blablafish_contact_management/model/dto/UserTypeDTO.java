package de.otto.blablafish_contact_management.model.dto;

public enum UserTypeDTO {
  COOPERATION,
  COMMISSION,
  API,
  SERVICE_PROVIDER
}
