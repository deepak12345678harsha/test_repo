package de.otto.blablafish_email.publishers;

import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.model.PublishRequest;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import de.otto.blablafish_contact_management.model.dto.DeepSeaEvent;
import de.otto.blablafish_contact_management.model.dto.EventType;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class SNSPublisher {

  private final AmazonSNS amazonSNS;
  private final String topicArn;
  private final ObjectMapper objectMapper;

  public SNSPublisher(
      AmazonSNS amazonSNS,
      @Value("${topic.email_events.arn}") String topicArn,
      ObjectMapper objectMapper) {
    this.amazonSNS = amazonSNS;
    this.topicArn = topicArn;
    this.objectMapper = objectMapper;
  }

  public <T> void publish(T t, EventType eventType) {
    final Map<String, Object> data = objectMapper.convertValue(t, new TypeReference<>() {});
    final DeepSeaEvent deepSeaEvent = DeepSeaEvent.of(eventType, data);

    final PublishRequest publishRequest = new PublishRequest().withTopicArn(topicArn);

    try {
      String message = this.objectMapper.writeValueAsString(deepSeaEvent);
      log.info("Publishing message: {} on topic: {}", message, topicArn);
      publishRequest.setMessage(message);
      amazonSNS.publish(publishRequest);
    } catch (JsonProcessingException e) {
      throw new RuntimeException("Failed to publish message", e);
    } catch (Exception e) {
      log.error("Exception {} in publishing message: {}", e.getClass(), e);
      throw e;
    }
  }
}
