package de.otto.blablafish_email.service;

import de.otto.blablafish_contact_management.exception.TopicNotFoundException;
import de.otto.blablafish_contact_management.model.entity.Topic;
import de.otto.blablafish_contact_management.respository.TopicRepository;
import de.otto.blablafish_email.exception.EmailRequestNotFoundException;
import de.otto.blablafish_email.model.entity.Email;
import de.otto.blablafish_email.model.entity.EmailRecipient;
import de.otto.blablafish_email.model.entity.EmailRequest;
import de.otto.blablafish_email.model.entity.EmailRequestStatus;
import de.otto.blablafish_email.respository.EmailRepository;
import de.otto.blablafish_email.respository.EmailRequestRepository;
import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.servlet.view.freemarker.FreeMarkerConfigurer;

@Slf4j
@Service
public class EmailTemplateService {

  private final EmailRequestRepository emailRequestRepository;
  private final EmailRepository emailRepository;
  private final TopicRepository topicRepository;
  private final Configuration freeMarkerConfiguration;
  private final String sesSenderDomain;

  public EmailTemplateService(
      EmailRequestRepository emailRequestRepository,
      EmailRepository emailRepository,
      TopicRepository topicRepository,
      FreeMarkerConfigurer freeMarkerConfigurer,
      @Value("${ses-sender-domain}") String sesSenderDomain) {
    this.emailRequestRepository = emailRequestRepository;
    this.emailRepository = emailRepository;
    this.topicRepository = topicRepository;
    this.sesSenderDomain = sesSenderDomain;
    this.freeMarkerConfiguration = freeMarkerConfigurer.getConfiguration();
  }

  public void handleRenderEmailTrigger(ObjectId emailRequestId)
      throws EmailRequestNotFoundException, TopicNotFoundException {
    log.info("Rendering Email for {}", emailRequestId);
    {
      final EmailRequest emailRequest =
          emailRequestRepository
              .findById(emailRequestId)
              .orElseThrow(
                  () ->
                      new EmailRequestNotFoundException(
                          String.format(
                              "EmailRequest with id %s does not exists", emailRequestId)));

      if (emailRequest.getStatus() != EmailRequestStatus.ACCEPTED) {
        log.info(
            "Skipped sending email as EmailRequest {} is already processed as {}",
            emailRequest.getRequestId().toHexString(),
            emailRequest.getStatus());
        return;
      }

      Topic topic =
          topicRepository
              .findById(emailRequest.getTopicId())
              .orElseThrow(
                  () ->
                      new TopicNotFoundException(
                          String.format("Topic with id %s not found", emailRequest.getTopicId())));

      final List<EmailRecipient> recipients = emailRequest.getRecipients();

      if (CollectionUtils.isEmpty(recipients)) {
        throw new RuntimeException("Missing recipients!");
      }

      for (EmailRecipient recipient : recipients) {
        final Email mail = generateEmailFromRecipient(emailRequest, recipient, topic);
        try {
          emailRepository.insert(mail);
        } catch (DuplicateKeyException e) {
          log.warn("Mail with Id: {} has been already sent.", mail.getId());
        }
      }
    }
  }

  private Email generateEmailFromRecipient(
      EmailRequest emailRequest, EmailRecipient recipient, Topic topic) {
    try {
      Map<String, Object> payload = emailRequest.getPayload().getValue();
      Map<String, Object> userVariables =
          Map.of(
              "firstName",
              recipient.getFirstName().getValue(),
              "lastName",
              recipient.getLastName().getValue(),
              "email",
              recipient.getEmailAddress().getValue(),
              "partnerId",
              Optional.ofNullable(recipient.getPartnerId()).orElse(""),
              "newsletterAccepted",
              Optional.ofNullable(recipient.getNewsletterAccepted()).orElse(Boolean.FALSE));

      payload.put("user", userVariables);

      final String textBody = resolveBody(payload, topic.getEmailPlainTextTemplate());
      final String htmlBody = resolveBody(payload, topic.getEmailHtmlTemplate());
      final String subject = resolveSubject(payload, topic.getEmailSubject());

      return Email.of(
          emailRequest.getRequestId(),
          recipient,
          subject,
          htmlBody,
          textBody,
          "no-reply@" + this.sesSenderDomain,
          emailRequest.getAttachmentIds());
    } catch (TemplateException | IOException e) {
      log.error(e.getMessage());
      throw new RuntimeException("could not resolve template", e);
    }
  }

  private String resolveSubject(Object object, String templateString)
      throws IOException, TemplateException {
    Template template =
        new Template("subjectTemplate", new StringReader(templateString), freeMarkerConfiguration);
    return resolveTemplate(object, template);
  }

  private String resolveBody(Object object, String templateName)
      throws IOException, TemplateException {
    final Template template = freeMarkerConfiguration.getTemplate(templateName);
    return resolveTemplate(object, template);
  }

  private String resolveTemplate(Object object, Template template)
      throws IOException, TemplateException {
    final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
    try (Writer out = new OutputStreamWriter(outputStream)) {
      template.process(object, out);
      return outputStream.toString(StandardCharsets.UTF_8);
    }
  }
}
