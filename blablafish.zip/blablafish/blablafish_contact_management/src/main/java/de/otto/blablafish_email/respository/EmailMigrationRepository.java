package de.otto.blablafish_email.respository;

import de.otto.blablafish_email.model.entity.EmailMigrationRequest;
import de.otto.blablafish_email.model.entity.EmailMigrationStatus;
import java.time.Instant;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

@Repository
@Slf4j
@RequiredArgsConstructor
public class EmailMigrationRepository {

  private final MongoTemplate mongoTemplate;

  public Optional<EmailMigrationRequest> findById(String emailRequestId) {
    return Optional.ofNullable(
        mongoTemplate.findById(new ObjectId(emailRequestId), EmailMigrationRequest.class));
  }

  public void save(EmailMigrationRequest request) {
    mongoTemplate.save(request);
  }

  public void saveEmailMigrationStatus(String mailRequestId, EmailMigrationStatus status) {
    mongoTemplate.save(
        new EmailMigrationRequest(new ObjectId(mailRequestId), status, Instant.now()));
  }

  public boolean exists(String emailRequestId) {
    return mongoTemplate.exists(
        Query.query(Criteria.where(EmailMigrationRequest.FIELD_MAIL_REQUEST_ID).is(emailRequestId)),
        EmailMigrationRequest.class);
  }
}
