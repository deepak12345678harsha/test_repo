package de.otto.blablafish_email.service;

import de.otto.blablafish_email.exception.EmailNotFoundException;
import de.otto.blablafish_email.model.dto.mail.EmailDTO;
import de.otto.blablafish_email.model.entity.Email;
import de.otto.blablafish_email.respository.EmailRepository;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class EmailService {

  private final EmailRepository emailRepository;

  public EmailService(EmailRepository emailRepository) {
    this.emailRepository = emailRepository;
  }

  public EmailDTO getEmailById(String id) throws EmailNotFoundException {
    Email email =
        emailRepository
            .findById(id)
            .orElseThrow(
                () -> new EmailNotFoundException(String.format("Email with id %s not found", id)));
    return EmailDTO.of(email);
  }

  public void saveAll(List<Email> emails) {
    emailRepository.deleteAll(emails);
    emailRepository.saveAll(emails);
  }
}
