package de.otto.newsletter.exception;

import de.otto.blablafish_contact_management.exception.BlaBlaFishError;
import de.otto.blablafish_contact_management.exception.BlaBlaFishException;

public class EmarsysConnectionFailedException extends BlaBlaFishException {

  public EmarsysConnectionFailedException(String message) {
    super(message, BlaBlaFishError.EMARSYS_CONNECTION_FAILED_ERROR);
  }
}
