package de.otto.blablafish_contact_management.filters;

import com.auth0.jwk.JwkException;
import com.auth0.jwk.JwkProvider;
import com.auth0.jwk.JwkProviderBuilder;
import de.otto.blablafish_contact_management.model.dto.UserPrincipal;
import io.jsonwebtoken.*;
import java.io.IOException;
import java.net.URL;
import java.security.Key;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

@Slf4j
public class JWTAuthenticationFilter extends BasicAuthenticationFilter {

  private final List<JwkProvider> providers;
  private final JwtParser jwtParser;

  public JWTAuthenticationFilter(AuthenticationManager authenticationManager, Set<URL> jwkUrls) {
    super(authenticationManager);

    providers =
        jwkUrls.stream()
            .map(u -> new JwkProviderBuilder(u).cached(10, 24, TimeUnit.HOURS).build())
            .collect(Collectors.toList());
    log.info("Providers in Filter: " + providers.isEmpty());
    log.info("Providers in Filter: " + providers.get(0));
    jwtParser = Jwts.parserBuilder().setSigningKeyResolver(new MyResolver()).build();
  }

  protected void doFilterInternal(
      HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
      throws IOException, ServletException {
    log.debug("received request: {}", request.getMethod());
    final String header = request.getHeader("Authorization");

    if (StringUtils.isEmpty(header) || !header.startsWith("Bearer ")) {
      // TODO: remove this filter-chain as its passing all APIs
      filterChain.doFilter(request, response);
      return;
    }
    final Authentication authentication = getAuthentication(header);
    SecurityContextHolder.getContext().setAuthentication(authentication);
    filterChain.doFilter(request, response);
  }

  private Authentication getAuthentication(String authorizationHeader) {

    try {
      final String token = authorizationHeader.replace("Bearer ", "");

      final Jws<Claims> claimsJws = jwtParser.parseClaimsJws(token);

      final Claims body = claimsJws.getBody();
      final String subject = body.getSubject();
      final String clientId = body.get("azp", String.class);
      final String partnerId = body.get("partner_id", String.class);
      final String username = body.get("preferred_username", String.class);
      final LinkedHashMap<String, List<String>> realm_access =
          claimsJws.getBody().get("realm_access", LinkedHashMap.class);
      final UserPrincipal userPrincipal =
          new UserPrincipal(subject, clientId, partnerId, extractRoles(realm_access), username);
      log.info(
          "userPrincipal-subject: {}, clientId: {}",
          userPrincipal.getSubject(),
          userPrincipal.getClientId());
      return new UsernamePasswordAuthenticationToken(
          userPrincipal, null, getGrantedAuthorities(realm_access));
    } catch (Exception e) {
      log.error("Failed to authenticate the user.", e);
      return new UsernamePasswordAuthenticationToken(null, null);
    }
  }

  private Set<String> extractRoles(LinkedHashMap<String, List<String>> realm_access) {
    if (CollectionUtils.isEmpty(realm_access) || !realm_access.containsKey("roles")) {
      return Set.of();
    }
    return new HashSet<>(realm_access.get("roles"));
  }

  private Set<GrantedAuthority> getGrantedAuthorities(
      LinkedHashMap<String, List<String>> realm_access) {
    if (CollectionUtils.isEmpty(realm_access) || !realm_access.containsKey("roles")) {
      return Set.of();
    }
    return realm_access.get("roles").stream()
        .map(role -> new SimpleGrantedAuthority(role))
        .collect(Collectors.toSet());
  }

  class MyResolver extends SigningKeyResolverAdapter {

    public Key resolveSigningKey(JwsHeader header, Claims claims) {
      log.info("In MyResolver!");
      for (JwkProvider provider : providers) {
        try {
          log.info("header.get key: " + header.getKeyId());
          log.info("provider.get key: " + provider.get(header.getKeyId()));
          log.info("provider.get public key: " + provider.get(header.getKeyId()).getPublicKey());
          return provider.get(header.getKeyId()).getPublicKey();
        } catch (JwkException e) {
          continue;
        }
      }
      throw new RuntimeException("Failed to get public key for the kid: " + header.getKeyId());
    }
  }
}
