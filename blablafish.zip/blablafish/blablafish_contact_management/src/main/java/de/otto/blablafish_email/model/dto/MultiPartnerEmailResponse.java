package de.otto.blablafish_email.model.dto;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public class MultiPartnerEmailResponse {

  private String attachmentId;

  private List<String> emailRequestIds;
}
