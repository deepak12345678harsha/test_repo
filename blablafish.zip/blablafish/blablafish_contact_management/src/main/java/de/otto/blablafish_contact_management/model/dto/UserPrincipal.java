package de.otto.blablafish_contact_management.model.dto;

import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public class UserPrincipal {

  private String subject;

  private String clientId;

  private String partnerId;

  private Set<String> realmRoles;

  private String userName;
}
