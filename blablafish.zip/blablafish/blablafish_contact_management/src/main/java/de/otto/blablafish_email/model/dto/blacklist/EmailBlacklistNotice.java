package de.otto.blablafish_email.model.dto.blacklist;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public class EmailBlacklistNotice {
  private String neptuneUserId;
}
