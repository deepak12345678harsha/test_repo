package de.otto.blablafish_email.model.dto;

import java.time.Instant;
import lombok.*;
import org.springframework.lang.NonNull;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Getter
@Builder(access = AccessLevel.PUBLIC)
public class EmailAttachmentDTO {

  @NonNull private String attachmentId;
  @NonNull private String s3BucketName;
  @NonNull private String s3UploadKey;
  @NonNull private String fileName;
  @NonNull private String contentType;
  @NonNull private Long fileSizeInBytes;
  @NonNull private Instant createdAt;
  @NonNull private String clientId;
  @NonNull private String subject;
}
