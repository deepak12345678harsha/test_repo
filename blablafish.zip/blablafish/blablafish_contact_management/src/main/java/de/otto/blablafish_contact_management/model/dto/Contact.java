package de.otto.blablafish_contact_management.model.dto;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Builder(access = AccessLevel.PRIVATE)
public class Contact {

  @NonNull private String email;
  @NonNull private String firstName;
  @NonNull private String lastName;

  public static Contact of(String email, String firstName, String lastName) {
    return Contact.builder().email(email).firstName(firstName).lastName(lastName).build();
  }
}
