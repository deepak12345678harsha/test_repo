package de.otto.blablafish_email.config;

import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
@Getter
public class ApplicationProperties {
  private String internalApiDomain;

  public ApplicationProperties(@Value("${internal-api-domain}") String internalApiDomain) {
    this.internalApiDomain = internalApiDomain;
  }
}
