package de.otto.blablafish_email.service;

import de.otto.blablafish_email.model.dto.ses.SESEventDTO;
import de.otto.blablafish_email.model.entity.SESEvent;
import de.otto.blablafish_email.respository.SESEventRepository;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class SESEventService {

  private final SESEventRepository sesEventRepository;

  public List<SESEventDTO> getByAWSMessageId(String awsMessageId) {

    return sesEventRepository.findByAWSMessageId(awsMessageId).stream()
        .map(SESEventDTO::from)
        .toList();
  }

  public void saveAll(List<SESEvent> sesEvents) {
    sesEventRepository.deleteAll(sesEvents);
    sesEventRepository.saveAll(sesEvents);
  }
}
