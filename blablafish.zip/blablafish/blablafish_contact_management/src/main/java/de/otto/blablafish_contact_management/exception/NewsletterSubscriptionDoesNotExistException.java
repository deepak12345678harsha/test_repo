package de.otto.blablafish_contact_management.exception;

public class NewsletterSubscriptionDoesNotExistException extends Exception {

  public NewsletterSubscriptionDoesNotExistException(String message) {
    super(message);
  }
}
