package de.otto.blablafish_email.model.dto.mail;

import de.otto.blablafish_email.model.entity.Email;
import de.otto.blablafish_email.model.entity.EmailStatus;
import java.time.Instant;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;
import org.springframework.util.CollectionUtils;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter
public class EmailDTO {

  private String mailId;

  private String awsMessageId;

  private String htmlBody;

  private String textBody;

  private String subject;

  private String toAddress;

  private String fromAddress;

  private String emailRequestId;

  private EmailStatus status;

  private Instant statusTimestamp;

  private List<EmailStatusHistoryEntryDTO> statusHistory;

  private Instant sendDate;

  private Instant createdAt;

  private Set<String> attachmentIds;

  public static EmailDTO of(Email email) {
    List<EmailStatusHistoryEntryDTO> emailStatusHistoryEntryDTOS = null;
    if (!CollectionUtils.isEmpty(email.getStatusHistory())) {
      emailStatusHistoryEntryDTOS =
          email.getStatusHistory().stream().map(EmailStatusHistoryEntryDTO::of).toList();
    }
    var htmlBody = Objects.nonNull(email.getHtmlBody()) ? email.getHtmlBody().getValue() : null;
    var textBody = Objects.nonNull(email.getTextBody()) ? email.getTextBody().getValue() : null;

    return EmailDTO.builder()
        .mailId(email.getId())
        .awsMessageId(email.getAwsMessageId())
        .subject(email.getSubject().getValue())
        .toAddress(email.getToAddress().getValue())
        .fromAddress(email.getFromAddress().getValue())
        .htmlBody(htmlBody)
        .textBody(textBody)
        .sendDate(email.getSendDate())
        .createdAt(email.getCreatedAt())
        .emailRequestId(email.getMailRequestId().toHexString())
        .status(email.getStatus())
        .statusTimestamp(email.getStatusTimestamp())
        .statusHistory(emailStatusHistoryEntryDTOS)
        .attachmentIds(email.getAttachmentIds())
        .build();
  }

  public Email toEmail() {
    return Email.builder()
        .id(mailId)
        .awsMessageId(awsMessageId)
        .htmlBody(Email.encryptedHtmlBody(htmlBody))
        .mailRequestId(new ObjectId(emailRequestId))
        .textBody(Email.encryptedTextBody(textBody))
        .subject(Email.encryptedSubject(subject))
        .toAddress(Email.encryptedToAddress(toAddress))
        .fromAddress(Email.encryptedFromAddress(fromAddress))
        .sendDate(sendDate)
        .createdAt(createdAt)
        .status(status)
        .statusTimestamp(statusTimestamp)
        .statusHistory(
            statusHistory.stream()
                .map(EmailStatusHistoryEntryDTO::toEmailStatusHistoryEntry)
                .toList())
        .attachmentIds(attachmentIds)
        .build();
  }
}
