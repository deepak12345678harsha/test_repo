package de.otto.blablafish_email.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import de.otto.blablafish_contact_management.exception.BlaBlaFishException;
import de.otto.blablafish_contact_management.exception.TopicNotFoundException;
import de.otto.blablafish_contact_management.model.dto.UserPrincipal;
import de.otto.blablafish_contact_management.model.entity.Topic;
import de.otto.blablafish_contact_management.service.SubscriberService;
import de.otto.blablafish_contact_management.service.TopicService;
import de.otto.blablafish_email.exception.FileUploadException;
import de.otto.blablafish_email.exception.MultiPartnerEmailException;
import de.otto.blablafish_email.model.dto.MultiPartnerEmailResponse;
import de.otto.blablafish_email.model.dto.PostEmailToInternalRequest;
import de.otto.blablafish_email.model.dto.PostEmailToPartnerRequest;
import de.otto.blablafish_email.model.dto.PostEmailToUserRequest;
import de.otto.blablafish_email.model.dto.SplunkOperationCode;
import de.otto.blablafish_email.model.entity.EmailRecipient;
import de.otto.blablafish_email.model.entity.EmailRequest;
import de.otto.blablafish_email.model.entity.EmailRequestStatus;
import de.otto.blablafish_email.model.entity.EmailRequester;
import de.otto.blablafish_email.model.entity.EmailStatusHistoryEntry;
import de.otto.blablafish_email.respository.EmailRequestRepository;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.Set;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.jboss.logging.MDC;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import org.springframework.web.multipart.MultipartFile;

@Slf4j
@Service
@RequiredArgsConstructor
public class EmailRequestService {

  public static final int MULTI_PARTNER_EMAIL_TOPIC_ID = 9999;
  private final TopicService topicService;
  private final EmailRequestRepository emailRequestRepository;
  private final SubscriberService subscriberService;
  private final EmailPayloadValidationService payloadValidationService;
  private final EmailAttachmentService emailAttachmentService;
  private final ObjectMapper objectMapper;

  public String sendEmailToPartner(
      @NonNull PostEmailToPartnerRequest emailRequest, UserPrincipal userPrincipal)
      throws TopicNotFoundException, BlaBlaFishException {
    loggingForSendEmail(EmailLogType.PARTNER);
    final EmailRequest request =
        createEmailRequestForPartner(
            emailRequest, userPrincipal.getClientId(), userPrincipal.getSubject());
    emailRequestRepository.insert(request);
    return request.getRequestId().toHexString();
  }

  public MultiPartnerEmailResponse sendEmailToPartners(
      List<String> partnerIds,
      String emailBodyText,
      MultipartFile file,
      UserPrincipal userPrincipal)
      throws FileUploadException, MultiPartnerEmailException {

    var subscriber = subscriberService.getUserByEmail(userPrincipal.getUserName()).orElseThrow();

    String attachmentId = null;
    if (Objects.nonNull(file)) {
      attachmentId =
          emailAttachmentService.upload(
              file, subscriber.getSubscriberIdAsString(), userPrincipal.getSubject());
    }
    log.info("creating emailRequest for partners: {}", partnerIds);
    var partnerRequests = buildPartnerMailRequests(partnerIds, emailBodyText, attachmentId);
    var emailRequestsErrorMessagesPair =
        processEmailRequestForPartners(
            partnerRequests, subscriber.getSubscriberIdAsString(), userPrincipal.getSubject());

    if (!emailRequestsErrorMessagesPair.getRight().isEmpty()) {
      throw new MultiPartnerEmailException(
          "Could not process multi partner email request.",
          emailRequestsErrorMessagesPair.getRight());
    }

    var emailRequestIds =
        emailRequestRepository.insertAll(emailRequestsErrorMessagesPair.getLeft());
    return new MultiPartnerEmailResponse(attachmentId, emailRequestIds);
  }

  private List<PostEmailToPartnerRequest> buildPartnerMailRequests(
      List<String> partnerIds, String emailBodyText, String attachmentId) {
    return partnerIds.stream()
        .map(
            partnerId ->
                PostEmailToPartnerRequest.builder()
                    .attachmentIds(
                        Objects.isNull(attachmentId)
                            ? Collections.emptySet()
                            : Set.of(attachmentId))
                    .partnerId(partnerId)
                    .payload(Map.of("emailBodyText", emailBodyText))
                    .topicId(MULTI_PARTNER_EMAIL_TOPIC_ID)
                    .build())
        .toList();
  }

  private ImmutablePair<ArrayList<EmailRequest>, ArrayList<String>> processEmailRequestForPartners(
      List<PostEmailToPartnerRequest> partnerRequests, String subscriberId, String subject) {
    var emailRequests = new ArrayList<EmailRequest>();
    var errorMessages = new ArrayList<String>();
    partnerRequests.forEach(
        partnerRequest -> {
          try {
            emailRequests.add(createEmailRequestForPartner(partnerRequest, subscriberId, subject));
          } catch (TopicNotFoundException | BlaBlaFishException e) {
            errorMessages.add(partnerRequest.getPartnerId());
            log.error(
                String.format(
                    "An error occurred while processing email request for partner : %s ",
                    partnerRequest.getPartnerId()),
                e);
          }
        });
    return new ImmutablePair<>(emailRequests, errorMessages);
  }

  private EmailRequest createEmailRequestForPartner(
      PostEmailToPartnerRequest emailRequest, String clientId, String subject)
      throws TopicNotFoundException, BlaBlaFishException {

    final var topic =
        getValidTopicForPayload(
            emailRequest.getPayload(),
            emailRequest.getInternalPayload(),
            emailRequest.getTopicId());
    final var subscribers =
        subscriberService.getSubscribersByValidatingRolesAndPreferences(
            emailRequest.getPartnerId(), topic);
    emailAttachmentService.validateAttachments(emailRequest.getAttachmentIds(), clientId);

    final var recipients = subscribers.stream().map(EmailRecipient::of).toList();
    return EmailRequest.of(
        payloadAsDocument(emailRequest.getPayload()),
        payloadAsDocument(emailRequest.getInternalPayload()),
        emailRequest.getTopicId(),
        recipients,
        EmailRequester.of(clientId, subject),
        emailRequest.getAttachmentIds());
  }

  public String sendEmailToUser(
      @NonNull PostEmailToUserRequest userEmailRequest, UserPrincipal userPrincipal)
      throws TopicNotFoundException, BlaBlaFishException {
    loggingForSendEmail(EmailLogType.USER);
    payloadValidationService.validate(
        userEmailRequest.getPayload(), topicService.findByTopicId(userEmailRequest.getTopicId()));
    emailAttachmentService.validateAttachments(
        userEmailRequest.getAttachmentIds(), userPrincipal.getClientId());
    var recipient =
        EmailRecipient.of(
            userEmailRequest.getFirstName(),
            userEmailRequest.getLastName(),
            userEmailRequest.getToAddress(),
            userEmailRequest.getPartnerId());
    final var request =
        EmailRequest.of(
            payloadAsDocument(userEmailRequest.getPayload()),
            userEmailRequest.getTopicId(),
            List.of(recipient),
            EmailRequester.of(userPrincipal.getClientId(), userPrincipal.getSubject()),
            userEmailRequest.getAttachmentIds());
    emailRequestRepository.insert(request);

    return request.getRequestId().toHexString();
  }

  public String sendInternalEmail(
      @NonNull PostEmailToInternalRequest internalEmailRequest, UserPrincipal userPrincipal)
      throws BlaBlaFishException, TopicNotFoundException {
    loggingForSendEmail(EmailLogType.INTERNAL);
    var topicId = internalEmailRequest.getTopicId();
    var attachmentIds = internalEmailRequest.getAttachmentIds();
    var payload = internalEmailRequest.getPayload();
    var clientId = userPrincipal.getClientId();

    topicService.validateTopicExists(internalEmailRequest.getTopicId());
    emailAttachmentService.validateAttachments(attachmentIds, clientId);

    var recipient =
        EmailRecipient.of(
            internalEmailRequest.getFirstName(),
            internalEmailRequest.getLastName(),
            internalEmailRequest.getToAddress());
    var emailRequester = EmailRequester.of(clientId, userPrincipal.getSubject());
    final var request =
        EmailRequest.of(
            payloadAsDocument(payload), topicId, List.of(recipient), emailRequester, attachmentIds);
    emailRequestRepository.insert(request);

    return request.getRequestId().toHexString();
  }

  private Document payloadAsDocument(Map<String, Object> payload) {
    return objectMapper.convertValue(payload, Document.class);
  }

  private Topic getValidTopicForPayload(
      Map<String, Object> payload, Map<String, Object> internalPayload, Integer topicId)
      throws TopicNotFoundException {
    final Topic topic = topicService.findByTopicId(topicId);
    payloadValidationService.validate(payload, internalPayload, topic);
    return topic;
  }

  public void insertEmailRequest(EmailRequest emailRequest) {
    emailRequestRepository.deleteIfPresent(emailRequest.getRequestId());
    emailRequestRepository.insert(emailRequest);
  }

  public EmailRequest getRequestById(String emailRequestId) {
    log.info("Processing email request for requestId: {}", emailRequestId);
    return emailRequestRepository.findById(new ObjectId(emailRequestId)).orElseThrow();
  }

  public EmailRequest setRecipientEmailStatus(
      ObjectId emailRequestId, String emailId, EmailStatusHistoryEntry emailStatusHistoryEntry) {
    Assert.notNull(emailRequestId, "Missing EmailRequestId");
    Assert.hasText(emailId, "Missing Email Id");
    Assert.notNull(emailRequestId, "Missing emailStatusHistoryEntry");

    var mailRequest =
        emailRequestRepository.findByEmailRequestIdAndEmailId(emailRequestId, emailId);
    if (mailRequest.isEmpty()) {
      log.error(
          "Could not find a mail request for mailRequestId {}. Failed to set recipient status.",
          emailRequestId.toHexString());
      throw new NoSuchElementException(
          "Missing emailRequest for mailRequestId '" + emailRequestId.toHexString() + "'");
    }

    log.info(
        "updating emailRequest {} with emailStatusHistoryEntry#status {} for emailId {}",
        emailRequestId,
        emailStatusHistoryEntry.getStatus(),
        emailId);

    var updatedMailRequest =
        emailRequestRepository.findByIdAndUpdateRecipientWithEmailStatusHistory(
            emailRequestId, emailId, emailStatusHistoryEntry);
    if (updatedMailRequest.isEmpty()) {
      log.info(
          "Failed to update recipient mail status to {} for emailRequest: {} and emailId: {}, it maybe due to that events maybe consumed in incorrect order",
          emailStatusHistoryEntry.getStatus(),
          emailRequestId,
          emailId);
      // Fetching it again as the mail request is being updated by other threads on receiving other
      // events
      var latestMailRequest =
          emailRequestRepository.findByEmailRequestIdAndEmailId(emailRequestId, emailId);
      return latestMailRequest.orElseGet(mailRequest::get);
    }

    var emailRecipients =
        updatedMailRequest.get().getRecipients().stream()
            .filter(emailRecipient -> emailRecipient.getEmailId().equals(emailId))
            .map(EmailRecipient::getEmailStatusHistoryEntry)
            .map(EmailStatusHistoryEntry::getStatus)
            .findFirst();

    log.info(
        "Updated emailRequest {} with emailStatusHistoryEntry#status {} for emailId {}",
        updatedMailRequest.get().getRequestId(),
        emailRecipients.isPresent() ? emailRecipients.get() : "NOT_FOUND",
        emailId);
    return updatedMailRequest.get();
  }

  public void setEmailRequestStatus(ObjectId emailRequestId, EmailRequestStatus mailRequestStatus) {
    Assert.notNull(emailRequestId, "Missing emailRequestId.");
    Assert.notNull(mailRequestStatus, "Missing emailRequestStatus.");
    emailRequestRepository.findByIdAndSetEmailStatusHistory(emailRequestId, mailRequestStatus);
  }

  private void loggingForSendEmail(EmailLogType logType) {
    Map<String, Object> detailsLogging = new HashMap<>();
    detailsLogging.put(
        "operationCode", List.of(SplunkOperationCode.API_WITH_OTTO_TEAMS_ACCESS.getCode()));
    try {
      MDC.put("details", new ObjectMapper().writeValueAsString(detailsLogging));
      log.info("Processing create email request for {}", logType);
    } catch (JsonProcessingException e) {
      log.error("Error in logging email requst for {}", logType);
    } finally {
      MDC.remove("details");
    }
  }

  private enum EmailLogType {
    PARTNER,
    USER,
    INTERNAL
  }
}
