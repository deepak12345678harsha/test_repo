package de.otto.blablafish_contact_management.model.entity;

import java.time.Instant;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NonNull;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.mapping.Document;

@AllArgsConstructor
@Builder(toBuilder = true)
@Document(collection = "mailPreferences")
@Getter
public class EmailPreference {

  public static final String FIELD_SUBSCRIBER_ID = "subscriberId";
  public static final String FIELD_TOPIC_ID = "topicId";
  public static final String FIELD_LAST_UPDATED_AT = "lastUpdatedAt";
  public static final String FIELD_OPT_IN = "optIn";

  @NonNull private int topicId;

  @NonNull private ObjectId subscriberId;

  @NonNull private Instant lastUpdatedAt;

  private boolean optIn;
}
