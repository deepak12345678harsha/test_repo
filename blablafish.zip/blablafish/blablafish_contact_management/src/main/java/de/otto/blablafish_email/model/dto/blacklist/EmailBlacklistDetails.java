package de.otto.blablafish_email.model.dto.blacklist;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public class EmailBlacklistDetails {
  private final String id;
  private final String emailAddress;
  private final List<EmailBlackListReasonDTO> reasons;
}
