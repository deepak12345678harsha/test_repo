package de.otto.blablafish_email.model.dto.blacklist;

import de.otto.blablafish_email.model.entity.EmailBlackListReason;
import de.otto.blablafish_email.model.entity.EmailBlacklist;
import java.util.List;
import lombok.*;
import org.springframework.lang.NonNull;

@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder(access = AccessLevel.PUBLIC)
public class EmailBlacklistDTO {

  @NonNull private String id;

  @NonNull private String emailAddress;

  @NonNull private List<EmailBlackListReason> reasons;

  public static EmailBlacklistDTO from(EmailBlacklist blacklist) {
    return new EmailBlacklistDTO(
        blacklist.getId().toString(),
        blacklist.getEmailAddress().getValue(),
        blacklist.getReasons());
  }
}
