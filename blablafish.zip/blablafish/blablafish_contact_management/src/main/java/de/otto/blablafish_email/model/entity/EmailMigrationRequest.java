package de.otto.blablafish_email.model.entity;

import java.time.Instant;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NonNull;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@AllArgsConstructor
@Getter
@Document(collection = "mailMigrationRequests")
@Builder
public class EmailMigrationRequest {

  public static final String FIELD_MAIL_REQUEST_ID = "mailRequestId";

  @Id private ObjectId mailRequestId;

  @NonNull private EmailMigrationStatus status;

  private Instant updatedAt;
}
