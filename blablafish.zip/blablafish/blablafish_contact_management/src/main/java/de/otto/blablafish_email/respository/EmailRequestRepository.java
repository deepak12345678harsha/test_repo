package de.otto.blablafish_email.respository;

import static de.otto.blablafish_email.model.entity.EmailRecipient.FIELD_EMAIL_ID;
import static de.otto.blablafish_email.model.entity.EmailRequest.FIELD_REQUEST_ID;

import de.otto.blablafish_email.model.entity.EmailRequest;
import de.otto.blablafish_email.model.entity.EmailRequestStatus;
import de.otto.blablafish_email.model.entity.EmailStatusHistoryEntry;
import java.util.List;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

@Slf4j
@Repository
public class EmailRequestRepository {
  private final MongoTemplate mongoTemplate;

  public EmailRequestRepository(MongoTemplate mongoTemplate) {
    this.mongoTemplate = mongoTemplate;
  }

  public void insert(EmailRequest mailRequest) {
    log.info("Inserting record for email request.");
    mongoTemplate.insert(mailRequest);
  }

  public List<String> insertAll(List<EmailRequest> mailRequests) {
    log.info("Inserting multiple email request.");
    return mongoTemplate.insertAll(mailRequests).stream()
        .map(emailRequest -> emailRequest.getRequestId().toString())
        .toList();
  }

  public Optional<EmailRequest> findById(ObjectId requestId) {
    log.info("Fetching record for email request: {}", requestId);
    return Optional.ofNullable(mongoTemplate.findById(requestId, EmailRequest.class));
  }

  public Optional<EmailRequest> findByEmailRequestIdAndEmailId(
      ObjectId emailRequestId, String emailId) {
    Criteria recipientMatchCriteria =
        Criteria.where("recipients").elemMatch(Criteria.where(FIELD_EMAIL_ID).is(emailId));
    final Query query =
        Query.query(Criteria.where(FIELD_REQUEST_ID).is(emailRequestId))
            .addCriteria(recipientMatchCriteria);
    return Optional.ofNullable(mongoTemplate.findOne(query, EmailRequest.class));
  }

  public Optional<EmailRequest> findByIdAndUpdateRecipientWithEmailStatusHistory(
      ObjectId emailRequestId, String emailId, EmailStatusHistoryEntry emailStatusHistoryEntry) {
    Criteria recipientMatchCriteria =
        Criteria.where(FIELD_EMAIL_ID)
            .is(emailId)
            .and("emailStatusHistoryEntry.date")
            .lt(emailStatusHistoryEntry.getDate());
    final Query query =
        Query.query(Criteria.where(FIELD_REQUEST_ID).is(emailRequestId))
            .addCriteria(Criteria.where("recipients").elemMatch(recipientMatchCriteria));

    final Update updateDefinition =
        new Update().set("recipients.$.emailStatusHistoryEntry", emailStatusHistoryEntry);
    return Optional.ofNullable(
        mongoTemplate.findAndModify(
            query,
            updateDefinition,
            new FindAndModifyOptions().returnNew(true),
            EmailRequest.class));
  }

  public void findByIdAndSetEmailStatusHistory(
      ObjectId emailRequestId, EmailRequestStatus emailRequestStatus) {
    log.info(
        "findByIdAndSetEmailStatusHistory emailRequestId : {} , emailRequestStatus : {} ",
        emailRequestId,
        emailRequestStatus);
    final Query query = Query.query(Criteria.where(FIELD_REQUEST_ID).is(emailRequestId));
    final Update updateDefinition = new Update().set("status", emailRequestStatus);

    mongoTemplate.updateFirst(query, updateDefinition, EmailRequest.class);
  }

  public void deleteIfPresent(ObjectId emailRequestId) {
    mongoTemplate.remove(
        Query.query(Criteria.where(FIELD_REQUEST_ID).is(emailRequestId)), EmailRequest.class);
  }
}
