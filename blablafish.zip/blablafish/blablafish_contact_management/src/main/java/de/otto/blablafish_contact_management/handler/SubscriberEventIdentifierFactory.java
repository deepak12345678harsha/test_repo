package de.otto.blablafish_contact_management.handler;

import de.otto.blablafish_email.model.dto.MongoDbTriggerEvent;
import java.util.Optional;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
@Slf4j
public class SubscriberEventIdentifierFactory {

  private final NewsLetterSubscriptionChangedEventIdentifier
      newsLetterSubscriptionChangedEventIdentifier;

  private final CommunicationSubscriptionChangedEventIdentifier
      communicationSubscriptionChangedEventIdentifier;

  public Optional<SubscriberEventIdentifier> identifiedEvent(MongoDbTriggerEvent event) {
    if (newsLetterSubscriptionChangedEventIdentifier.canIdentifyEvent(event)) {
      return Optional.of(newsLetterSubscriptionChangedEventIdentifier);
    }

    if (communicationSubscriptionChangedEventIdentifier.canIdentifyEvent(event)) {
      return Optional.of(communicationSubscriptionChangedEventIdentifier);
    }

    return Optional.empty();
  }
}
