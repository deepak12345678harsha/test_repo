package de.otto.blablafish_contact_management.encryption;

import com.mongodb.client.model.vault.DataKeyOptions;
import com.mongodb.client.model.vault.EncryptOptions;
import com.mongodb.client.vault.ClientEncryption;
import de.otto.blablafish_contact_management.model.encryption.EncryptedField;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.bson.*;
import org.springframework.util.Assert;

@Slf4j
public class EncryptionHelper {

  private static final String DETERMINISTIC_ALGORITHM =
      "AEAD_AES_256_CBC_HMAC_SHA_512-Deterministic";
  private static final String RANDOM_ALGORITHM = "AEAD_AES_256_CBC_HMAC_SHA_512-Random";

  private final ClientEncryption clientEncryption;
  private final String kmsProviderKey;

  private final String masterKeyRegion;
  private final String masterKeyArn;

  public EncryptionHelper(
      ClientEncryption clientEncryption,
      String kmsProviderKey,
      String masterKeyRegion,
      String masterKeyArn) {
    this.clientEncryption = clientEncryption;
    this.kmsProviderKey = kmsProviderKey;
    this.masterKeyRegion = masterKeyRegion;
    this.masterKeyArn = masterKeyArn;
  }

  private DataKeyOptions dataKeyOptions() {
    if ("aws".equalsIgnoreCase(this.kmsProviderKey)) {
      BsonString masterKeyRegionAsBson = new BsonString(masterKeyRegion);
      BsonString masterKeyArnAsBson = new BsonString(masterKeyArn);
      return new DataKeyOptions()
          .masterKey(
              new BsonDocument()
                  .append("region", masterKeyRegionAsBson)
                  .append("key", masterKeyArnAsBson));
    } else {
      return new DataKeyOptions();
    }
  }

  public BsonBinary encrypt(EncryptedField<?> var1) {
    if (var1.getBsonBinary().isPresent()) {
      return var1.getBsonBinary().get();
    }
    Assert.hasText(var1.keyAltName(), "Missing keyAltName.");
    if (var1.toBsonValue() == null) {
      return null;
    }
    final DataKeyOptions dataKeyOptions = dataKeyOptions();
    try {
      return this.clientEncryption.encrypt(
          var1.toBsonValue(),
          new EncryptOptions(var1.isSearchable() ? DETERMINISTIC_ALGORITHM : RANDOM_ALGORITHM)
              .keyAltName(var1.keyAltName()));
    } catch (RuntimeException ex) {
      // try one more time as for the first time data encryption key is missing.
      log.warn(
          "Failed to encrypt with dataencryption key. A new data encryption key will be created.",
          ex);
      final BsonBinary dataKey =
          this.clientEncryption.createDataKey(
              kmsProviderKey, dataKeyOptions.keyAltNames(List.of(var1.keyAltName())));
      return this.clientEncryption.encrypt(
          var1.toBsonValue(),
          new EncryptOptions(var1.isSearchable() ? DETERMINISTIC_ALGORITHM : RANDOM_ALGORITHM)
              .keyId(dataKey));
    }
  }

  public BsonValue decrypt(BsonBinary bsonBinary) {
    return this.clientEncryption.decrypt(bsonBinary);
  }

  public void decryptBsonBinariesAndReplace(Map document) {
    document.replaceAll(
        (s, o) -> {
          if (o instanceof Map) {
            final Map oAsMap = (Map) o;
            if (!oAsMap.containsKey("Subtype")) {
              decryptBsonBinariesAndReplace(oAsMap);
            } else {
              var subtype = (int) oAsMap.get("Subtype");
              if (subtype == 6) {
                var data = (String) oAsMap.get("Data");
                return decrypt(data);
              }
            }
          }
          return o;
        });
  }

  private Object decrypt(String data) {
    byte bsonSubType = 6;
    final BsonBinary bsonBinary = new BsonBinary(bsonSubType, Base64.getDecoder().decode(data));
    final BsonValue decrypt = clientEncryption.decrypt(bsonBinary);
    if (decrypt.isString()) {
      return decrypt.asString().getValue();
    } else if (decrypt.isNull()) {
      return null;
    } else if (decrypt.isBinary()) {
      return decrypt.asBinary().getData();
    } else if (decrypt.isArray()) {
      return decrypt.asArray().toArray();
    } else if (decrypt.isInt32()) {
      return decrypt.asInt32().getValue();
    } else if (decrypt.isInt64()) {
      return decrypt.asInt64().getValue();
    } else if (decrypt.isDocument()) {
      return Document.parse(decrypt.asDocument().toJson());
    }
    throw new IllegalArgumentException("decrypt " + decrypt.getBsonType() + " not supported.");
  }
}
