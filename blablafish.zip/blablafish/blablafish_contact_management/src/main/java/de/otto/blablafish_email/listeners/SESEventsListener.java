package de.otto.blablafish_email.listeners;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import de.otto.blablafish_contact_management.model.dto.EventType;
import de.otto.blablafish_contact_management.service.SubscriberService;
import de.otto.blablafish_email.model.dto.JsonLogger;
import de.otto.blablafish_email.model.dto.blacklist.EmailBlacklistNotice;
import de.otto.blablafish_email.model.dto.ses.EmailRequestNotice;
import de.otto.blablafish_email.model.dto.ses.SESEventMessageDTO;
import de.otto.blablafish_email.model.dto.ses.SESEventType;
import de.otto.blablafish_email.model.entity.Email;
import de.otto.blablafish_email.model.entity.EmailBlackListReason;
import de.otto.blablafish_email.model.entity.EmailRecipient;
import de.otto.blablafish_email.model.entity.EmailRequest;
import de.otto.blablafish_email.model.entity.EmailRequestStatus;
import de.otto.blablafish_email.model.entity.EmailStatus;
import de.otto.blablafish_email.model.entity.EmailStatusHistoryEntry;
import de.otto.blablafish_email.model.entity.SESEvent;
import de.otto.blablafish_email.publishers.SNSPublisher;
import de.otto.blablafish_email.respository.EmailBlacklistRepository;
import de.otto.blablafish_email.respository.EmailRepository;
import de.otto.blablafish_email.respository.SESEventRepository;
import de.otto.blablafish_email.service.EmailBlacklistStrategy;
import de.otto.blablafish_email.service.EmailRequestService;
import io.awspring.cloud.messaging.config.annotation.NotificationMessage;
import io.awspring.cloud.messaging.listener.SqsMessageDeletionPolicy;
import io.awspring.cloud.messaging.listener.annotation.SqsListener;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class SESEventsListener {

  private static final Set<EmailStatus> FAILED_EMAIL_STATES =
      Set.of(EmailStatus.AWS_COMPLAINT, EmailStatus.AWS_REJECT, EmailStatus.AWS_BOUNCE);
  private static final Set<EmailStatus> SUCCESSFUL_EMAIL_STATES =
      Set.of(EmailStatus.AWS_CLICK, EmailStatus.AWS_DELIVERY, EmailStatus.AWS_OPEN);
  private static final Set<SESEventType> UPDATE_STATUS_ON_EVENT_TYPES =
      Set.of(SESEventType.DELIVERY, SESEventType.REJECT, SESEventType.BOUNCE);

  private final ObjectMapper objectMapper;
  private final EmailRepository emailRepository;
  private final EmailRequestService emailRequestService;
  private final SubscriberService subscriberService;
  private final SESEventRepository sesEventRepository;
  private final EmailBlacklistRepository blacklistRepository;
  private final SNSPublisher snsPublisher;
  private final EmailBlacklistStrategy blacklistStrategy;

  public SESEventsListener(
      ObjectMapper objectMapper,
      EmailRepository emailRepository,
      EmailRequestService emailRequestService,
      SubscriberService subscriberService,
      SESEventRepository sesEventRepository,
      EmailBlacklistRepository blacklistRepository,
      SNSPublisher snsPublisher,
      EmailBlacklistStrategy blacklistStrategy) {
    this.objectMapper = objectMapper;
    this.emailRepository = emailRepository;
    this.emailRequestService = emailRequestService;
    this.subscriberService = subscriberService;
    this.sesEventRepository = sesEventRepository;
    this.blacklistRepository = blacklistRepository;
    this.snsPublisher = snsPublisher;
    this.blacklistStrategy = blacklistStrategy;
  }

  @SqsListener(
      value = "${sesEvents.queueUrl}",
      deletionPolicy = SqsMessageDeletionPolicy.ON_SUCCESS)
  public void onSESEvent(@NotificationMessage String message) throws JsonProcessingException {
    final SESEventMessageDTO sesEventDTO =
        objectMapper.readValue(message, SESEventMessageDTO.class);
    final SESEventType sesEventType = sesEventDTO.getEventType();
    final String awsMessageId = sesEventDTO.getMail().getMessageId();
    log.info("Received SES event. type: {}, messageId: {}", sesEventType, awsMessageId);
    final EmailStatusHistoryEntry emailStatusHistoryEntry = EmailStatusHistoryEntry.of(sesEventDTO);
    final Email updatedEmail = updateEmailStatus(awsMessageId, emailStatusHistoryEntry);

    updateEmailRequestStatus(sesEventDTO, updatedEmail);
    updateBlacklistEmails(sesEventDTO, emailStatusHistoryEntry.getStatus());
    saveSESEvent(
        sesEventDTO.getEventType(), awsMessageId, updatedEmail.getMailRequestId(), message);
  }

  private Email updateEmailStatus(
      String awsMessageId, EmailStatusHistoryEntry emailStatusHistoryEntry) {
    log.info(
        "updating email status for awsMessageId: {} emailStatusHistoryEntry timestamp: {}",
        awsMessageId,
        emailStatusHistoryEntry.getDate());
    final Optional<Email> byAWSMessageIdAndSetStatus =
        emailRepository.findByAWSMessageIdAndSetStatus(awsMessageId, emailStatusHistoryEntry);

    if (byAWSMessageIdAndSetStatus.isEmpty()) {
      log.warn(
          "Failed to update email using awsMessageId: {} and timestamp: {}. It could be that events are consumed not in incoming order.",
          awsMessageId,
          emailStatusHistoryEntry.getDate());
      final Optional<Email> byAWSMessageIdAndAddStatusEntry =
          emailRepository.findByAWSMessageIdAndAddStatusEntry(
              awsMessageId, emailStatusHistoryEntry);
      if (byAWSMessageIdAndAddStatusEntry.isEmpty()) {
        log.error(
            "Something went wrong. Expected an email with awsMessageId: {} but found nothing.",
            awsMessageId);
        throw new RuntimeException(
            String.format(
                "Something went wrong. Expected an email with given awsMessageId: %s but found nothing.",
                awsMessageId));
      }
      return byAWSMessageIdAndAddStatusEntry.get();
    }
    return byAWSMessageIdAndSetStatus.get();
  }

  private void updateEmailRequestStatus(SESEventMessageDTO sesEventDTO, Email updatedEmail)
      throws JsonProcessingException {
    ObjectId mailRequestId = updatedEmail.getMailRequestId();
    if (sesEventDTO.isTypeAutoReply()) {
      log.info(
          "Received auto reply event, skipping mail request status update for - {}", mailRequestId);
    } else {
      final EmailRequest emailRequest = setEmailStatusForRecipients(mailRequestId, updatedEmail);
      final EmailRequestStatus mailRequestStatus = resolveEmailStatus(emailRequest.getRecipients());
      logMailInfoJSON(updatedEmail, emailRequest);
      updateEmailRequestStatusIfRequired(
          mailRequestId, mailRequestStatus, sesEventDTO.getEventType());
    }
  }

  private EmailRequest setEmailStatusForRecipients(ObjectId mailRequestId, Email updatedMail) {
    final EmailStatusHistoryEntry emailStatusHistoryEntry =
        EmailStatusHistoryEntry.of(updatedMail.getStatus(), updatedMail.getStatusTimestamp());
    return emailRequestService.setRecipientEmailStatus(
        mailRequestId, updatedMail.getId(), emailStatusHistoryEntry);
  }

  private EmailRequestStatus resolveEmailStatus(List<EmailRecipient> recipientList) {
    final boolean emailRequestFailed =
        recipientList.stream()
            .map(EmailRecipient::getEmailStatusHistoryEntry)
            .map(EmailStatusHistoryEntry::getStatus)
            .allMatch(FAILED_EMAIL_STATES::contains);
    if (emailRequestFailed) {
      return EmailRequestStatus.MAIL_DELIVERY_FAILED_FOR_ALL_RECIPIENTS;
    }

    final boolean emailRequestSuccessful =
        recipientList.stream()
            .map(EmailRecipient::getEmailStatusHistoryEntry)
            .map(EmailStatusHistoryEntry::getStatus)
            .anyMatch(SUCCESSFUL_EMAIL_STATES::contains);
    if (emailRequestSuccessful) {
      return EmailRequestStatus.MINIMUM_ONE_MAIL_DELIVERED;
    }

    return EmailRequestStatus.ACCEPTED;
  }

  private void logMailInfoJSON(Email updatedMail, EmailRequest request)
      throws JsonProcessingException {
    final String EmailStatus = updatedMail.getStatus().toString();
    final String statusTimestamp = updatedMail.getStatusTimestamp().toString();

    final String requestId = request.getRequestId().toHexString();
    final String requestStatus = request.getStatus().toString();
    final String topicId = request.getTopicId().toString();

    final JsonLogger jsonLogger =
        new JsonLogger(EmailStatus, statusTimestamp, requestId, topicId, requestStatus);
    log.info(objectMapper.writeValueAsString(jsonLogger));
  }

  private void updateEmailRequestStatusIfRequired(
      ObjectId emailRequestId, EmailRequestStatus mailRequestStatus, SESEventType sesEventType) {
    log.info(
        "Updating emailRequestStatus to {} for emailRequestId {} and sesEventType {}",
        mailRequestStatus,
        emailRequestId,
        sesEventType);
    if (isStatusUpdateRequired(sesEventType, mailRequestStatus)) {
      emailRequestService.setEmailRequestStatus(emailRequestId, mailRequestStatus);
      if (mailRequestStatus == EmailRequestStatus.MAIL_DELIVERY_FAILED_FOR_ALL_RECIPIENTS) {
        // this will also publish SNS message for teams
        snsPublisher.publish(
            new EmailRequestNotice(emailRequestId.toHexString()), EventType.EMAIL_REQUEST_FAILED);
      } else if (mailRequestStatus == EmailRequestStatus.MINIMUM_ONE_MAIL_DELIVERED) {
        snsPublisher.publish(
            new EmailRequestNotice(emailRequestId.toHexString()), EventType.EMAIL_REQUEST_SUCCESS);
      }
    }
  }

  private boolean isStatusUpdateRequired(
      SESEventType sesEventType, EmailRequestStatus mailRequestStatus) {
    return UPDATE_STATUS_ON_EVENT_TYPES.contains(sesEventType)
        && mailRequestStatus != EmailRequestStatus.ACCEPTED;
  }

  private void saveSESEvent(
      SESEventType eventType, String awsMessageId, ObjectId mailRequestId, String message)
      throws JsonProcessingException {
    final Document messageAsDocument = objectMapper.readValue(message, Document.class);
    sesEventRepository.insert(
        SESEvent.of(eventType, awsMessageId, mailRequestId, messageAsDocument));
  }

  private void updateBlacklistEmails(SESEventMessageDTO sesEventDTO, EmailStatus status) {
    if (blacklistStrategy.shouldBlacklistEmail(sesEventDTO, status)) {
      final EmailBlackListReason blackListReason =
          EmailBlackListReason.ofSESEvent(
              sesEventDTO.getMail().getMessageId(),
              "received event type of " + sesEventDTO.getEventType());
      String blacklistEmailAddress = sesEventDTO.getMail().getDestination().get(0);
      blacklistRepository.upsert(blacklistEmailAddress, blackListReason);
      publishEmailBlacklistedEvent(blacklistEmailAddress);
    }
  }

  private void publishEmailBlacklistedEvent(String blackListEmailAddress) {
    var subscriber = subscriberService.getUserByEmail(blackListEmailAddress);
    if (subscriber.isPresent()) {
      snsPublisher.publish(
          new EmailBlacklistNotice(subscriber.get().getUserId().toHexString()),
          EventType.EMAIL_BLACKLISTED);
      log.info(
          "Published Email Blacklisted event to SNS for subscriber {}",
          subscriber.get().getUserId());
    } else {
      log.warn("Email address not found, Cannot publish blacklisted event");
    }
  }
}
