package de.otto.blablafish_email.service;

import de.otto.blablafish_contact_management.model.entity.Requester;
import de.otto.blablafish_contact_management.model.entity.Subscriber;
import de.otto.blablafish_contact_management.service.SubscriberService;
import de.otto.blablafish_email.exception.EmailBlacklistNotFoundException;
import de.otto.blablafish_email.model.dto.blacklist.EmailBlacklistDTO;
import de.otto.blablafish_email.model.dto.blacklist.EmailBlacklistResponse;
import de.otto.blablafish_email.model.entity.EmailBlacklist;
import de.otto.blablafish_email.publishers.SNSPublisher;
import de.otto.blablafish_email.respository.EmailBlacklistRepository;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.bson.types.ObjectId;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Slf4j
@RequiredArgsConstructor
@Service
public class EmailBlacklistService {

  private final EmailBlacklistRepository blacklistRepository;
  private final SubscriberService subscriberService;
  private final SNSPublisher snsPublisher;

  public List<EmailBlacklistDTO> getByEmailAddress(String emailAddress)
      throws EmailBlacklistNotFoundException {
    var blacklists =
        blacklistRepository
            .findByEmail(emailAddress)
            .orElseThrow(
                () ->
                    new EmailBlacklistNotFoundException(
                        String.format(
                            "Email blacklist with email address: %s does not exists",
                            emailAddress)));
    return blacklists.stream().map(EmailBlacklistDTO::from).toList();
  }

  public EmailBlacklist getById(String mailBlacklistsId) throws EmailBlacklistNotFoundException {
    return blacklistRepository
        .findById(new ObjectId(mailBlacklistsId))
        .orElseThrow(
            () ->
                new EmailBlacklistNotFoundException(
                    String.format(
                        "Email blacklist with  mailBlacklistsId : %s does not exists",
                        mailBlacklistsId)));
  }

  public Page<EmailBlacklistResponse> getBlacklistedEmails(String searchString, Pageable pageable) {
    var blacklistedMails = blacklistRepository.findAll(searchString, pageable);
    var subscribers = getBlacklistedUsers(blacklistedMails);

    var blacklistedEmailResponses =
        blacklistedMails.stream()
            .map(blacklist -> getBlacklistedEmailResponse(blacklist, subscribers))
            .toList();

    return new PageImpl<>(blacklistedEmailResponses, pageable, blacklistedMails.getTotalElements());
  }

  private Map<String, Subscriber> getBlacklistedUsers(Page<EmailBlacklist> blacklists) {
    var blacklistedEmails =
        blacklists.stream()
            .map(blacklist -> blacklist.getEmailAddress().getValue())
            .collect(Collectors.toSet());

    return subscriberService.findAllByEmails(blacklistedEmails).stream()
        .collect(Collectors.toMap(user -> user.getEmail().getValue(), user -> user));
  }

  private EmailBlacklistResponse getBlacklistedEmailResponse(
      EmailBlacklist blacklist, Map<String, Subscriber> subscriberMap) {
    var emailAddress = blacklist.getEmailAddress().getValue();
    if (subscriberMap.containsKey(emailAddress)) {
      var subscriber = subscriberMap.get(emailAddress);
      return new EmailBlacklistResponse(
          blacklist.getId().toHexString(),
          subscriber.getFirstName().getValue(),
          subscriber.getLastName().getValue(),
          emailAddress);
    }
    return new EmailBlacklistResponse(blacklist.getId().toHexString(), emailAddress);
  }

  public void removeBlacklistedEmails(Set<String> emailIds, Requester requester) {
    if (CollectionUtils.isEmpty(emailIds)) {
      return;
    }
    blacklistRepository.removeBlacklistedEmails(emailIds);
    subscriberService.unBlacklistSubscribers(emailIds, requester);
  }
}
