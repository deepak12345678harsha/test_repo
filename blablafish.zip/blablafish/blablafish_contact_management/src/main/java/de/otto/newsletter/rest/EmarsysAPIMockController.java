package de.otto.newsletter.rest;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import de.otto.newsletter.model.dto.*;
import java.util.Collections;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("v1/emarsys")
@ConditionalOnProperty(value = "environment", havingValue = "develop")
@RequiredArgsConstructor
public class EmarsysAPIMockController {

  @Autowired private ObjectMapper objectMapper;

  @ResponseStatus(HttpStatus.OK)
  @PutMapping(path = "/v2/contact", produces = MediaType.TEXT_HTML_VALUE)
  public String handleEmarsysUserCreateRequest(@RequestBody EmarsysContactDTO emarsysContactDTO) {
    String message =
        String.format(
            "update Emarsys contact request received for userId : %s",
            emarsysContactDTO.getUserId());
    log.info(message);
    return message;
  }

  @ResponseStatus(HttpStatus.OK)
  @PostMapping(path = "/v2/contact/delete", produces = MediaType.TEXT_HTML_VALUE)
  public String handleEmarsysUserDeleteRequest(
      @RequestBody DeleteEmarsysContactDTO emarsysContactDTO) {
    String message =
        String.format(
            "Delete Emarsys contact request received for userId : %s",
            emarsysContactDTO.getUserId());
    log.info(message);
    return message;
  }

  @ResponseStatus(HttpStatus.OK)
  @PostMapping(path = "/v2/contact/getdata", produces = MediaType.TEXT_HTML_VALUE)
  public String handleEmarsysUserGetRequest(@RequestBody GetEmarsysContactDTO emarsysContactDTO)
      throws JsonProcessingException {
    String message =
        String.format(
            "Get Emarsys contact request received for userId : %s",
            emarsysContactDTO.getKeyValues());
    log.info(message);
    EmarsysContactResponse response =
        new EmarsysContactResponse(0, new EmarsysData(Collections.emptySet()));
    return objectMapper.writeValueAsString(response);
  }
}
