package de.otto.newsletter.model.dto;

import static de.otto.newsletter.model.dto.EmarsysContactFields.*;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@AllArgsConstructor
@NoArgsConstructor
public class GetEmarsysContactDTO {
  private String keyId;

  @JsonProperty(KEY_VALUES)
  private Set<String> keyValues;

  @JsonProperty(value = FIELDS)
  private Set<String> fields;

  public static GetEmarsysContactDTO of(String subscriberId) {
    return new GetEmarsysContactDTO(
        EmarsysContactFields.USER_ID, Set.of(subscriberId), Set.of(USER_ID));
  }
}
