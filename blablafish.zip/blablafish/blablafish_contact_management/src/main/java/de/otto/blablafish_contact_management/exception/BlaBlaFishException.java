package de.otto.blablafish_contact_management.exception;

public class BlaBlaFishException extends Exception {
  BlaBlaFishError blaBlaFishError;

  public BlaBlaFishException(String message, BlaBlaFishError errorCode) {
    super(message);
    this.blaBlaFishError = errorCode;
  }

  public BlaBlaFishError getBlaBlaFishError() {
    return blaBlaFishError;
  }
}
