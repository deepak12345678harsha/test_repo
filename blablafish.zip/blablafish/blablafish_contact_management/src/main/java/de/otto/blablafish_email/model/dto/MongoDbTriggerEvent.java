package de.otto.blablafish_email.model.dto;

import static java.util.Objects.nonNull;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.bson.Document;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@JsonIgnoreProperties(ignoreUnknown = true)
public class MongoDbTriggerEvent {

  private String id;

  @JsonProperty(value = "detail-type")
  private String detailType;

  private String source;

  private String account;

  private Instant time;

  private List<String> resources;

  private MongoDbTriggerEventDetail detail;

  @JsonIgnore
  public String getOperationType() {
    return detail.getOperationType();
  }

  @JsonIgnore
  public Document getUpdatedFields() {
    return getDetail().getUpdateDescription().getUpdatedFields();
  }

  @JsonIgnore
  public boolean isUpdateEvent() {
    return "UPDATE".equalsIgnoreCase(this.getDetail().getOperationType());
  }

  @JsonIgnore
  public boolean hasUpdatedField(String fieldName) {
    UpdateDescription updateDescription = this.getDetail().getUpdateDescription();
    return nonNull(updateDescription)
        && nonNull(updateDescription.getUpdatedFields())
        && updateDescription.getUpdatedFields().containsKey(fieldName);
  }

  @JsonIgnore
  public Map<String, Object> getUpdatedFieldValues(String fieldName) {
    UpdateDescription updateDescription = this.getDetail().getUpdateDescription();
    return (Map<String, Object>) updateDescription.getUpdatedFields().get(fieldName);
  }
}
