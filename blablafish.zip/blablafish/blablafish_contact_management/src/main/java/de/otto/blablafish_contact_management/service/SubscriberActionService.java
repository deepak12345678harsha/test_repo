package de.otto.blablafish_contact_management.service;

import de.otto.blablafish_contact_management.handler.ActionHandlerFactory;
import de.otto.blablafish_contact_management.model.Actions;
import de.otto.blablafish_contact_management.model.entity.ActionError;
import de.otto.blablafish_contact_management.model.entity.Subscriber;
import de.otto.blablafish_contact_management.respository.SubscriberRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

@Slf4j
@RequiredArgsConstructor
@Component
public class SubscriberActionService {

  private final SubscriberRepository subscriberRepository;

  private final ActionHandlerFactory actionHandlerFactory;

  public void executeAction(String subscriberId) {
    log.info("Execute action for subscriber : {}", subscriberId);
    var subscriberOptional = subscriberRepository.acquireLockAndReturnSubscriberById(subscriberId);
    if (subscriberOptional.isEmpty()) {
      log.info("Failed to acquire lock. Message will be ignored.");
      /*
      this sqs event will be treated as success.
      however there is another process (for another replica of CM Service)
      that is processing an event. Once that event gets processed,
      the corresponding action will be deleted.
      Such delete will trigger another SQS event as part of which the next action will be processed, and so on...
      */
      return;
    }

    Subscriber subscriber = subscriberOptional.get();
    if (CollectionUtils.isEmpty(subscriber.getActions())) {
      // ignore this sqs event if there are no actions to process
      log.error("No action present for the subscriber with id : {} ", subscriberId);
      subscriberRepository.releaseLockBySubscriberId(subscriberId, subscriber.getLock());
      return;
    }

    // always process the first action. this ensures that actions are always processed in order.
    // hence, linked list to optimise memory allocation & shifting
    Actions action = subscriber.getActions().getFirst();
    boolean isLockReleased = false;
    try {
      var usersAttributesToUpdate = actionHandlerFactory.handlerFor(action).handle(subscriber);
      isLockReleased =
          subscriberRepository.releaseLockPopActionUpdateSubscriberAttributes(
              subscriberId, subscriber.getLock(), usersAttributesToUpdate);

    } catch (Exception e) {
      log.error(
          "Failed to handle action {} for the subscriber with id: {} : exception: {}",
          action.name(),
          subscriber.getUserId().toHexString(),
          e);

      subscriberRepository.updateSubscriberActionError(subscriberId, ActionError.of(e));
      throw e;
    } finally {
      if (!isLockReleased) {
        subscriberRepository.releaseLockBySubscriberId(subscriberId, subscriber.getLock());
      }
    }
  }
}
