package de.otto.blablafish_contact_management.model.encryption;

import java.util.Optional;
import org.bson.BsonBinary;
import org.bson.BsonValue;

public abstract class EncryptedField<T> {

  protected final T value;
  protected final String keyAltName;
  protected final Boolean isSearchable;
  protected final BsonBinary bsonBinary;

  public EncryptedField(T value, String keyAltName, boolean isSearchable) {
    this.value = value;
    this.keyAltName = keyAltName;
    this.isSearchable = isSearchable;
    this.bsonBinary = null;
  }

  public EncryptedField(T value, BsonBinary bsonBinary) {
    this.value = value;
    this.keyAltName = null;
    this.isSearchable = null;
    this.bsonBinary = bsonBinary;
  }

  public T getValue() {
    return value;
  }

  public abstract BsonValue toBsonValue();

  public String keyAltName() {
    return keyAltName;
  }

  public boolean isSearchable() {
    return this.isSearchable;
  }

  public Optional<BsonBinary> getBsonBinary() {
    return Optional.ofNullable(this.bsonBinary);
  }
}
