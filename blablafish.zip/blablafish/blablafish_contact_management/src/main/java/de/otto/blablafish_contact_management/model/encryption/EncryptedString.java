package de.otto.blablafish_contact_management.model.encryption;

import org.bson.BsonBinary;
import org.bson.BsonString;
import org.bson.BsonValue;

public class EncryptedString extends EncryptedField<String> {
  public EncryptedString(String value, String keyAltName, boolean isSearchable) {
    super(value, keyAltName, isSearchable);
  }

  public EncryptedString(String value, BsonBinary bsonBinary) {
    super(value, bsonBinary);
  }

  @Override
  public BsonValue toBsonValue() {
    return getValue() == null ? null : new BsonString(getValue());
  }
}
