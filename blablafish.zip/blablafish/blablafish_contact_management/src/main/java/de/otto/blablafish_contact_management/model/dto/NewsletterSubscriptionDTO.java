package de.otto.blablafish_contact_management.model.dto;

import static de.otto.blablafish_contact_management.model.entity.NewsletterSubscriptionStatus.statusOf;

import de.otto.blablafish_contact_management.model.entity.NewsletterSubscription;
import java.time.Instant;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Getter
public class NewsletterSubscriptionDTO {
  @NotNull private Boolean isSubscribed;

  private String text;

  private Instant time;

  public static NewsletterSubscriptionDTO of(NewsletterSubscription newsletterSubscription) {
    return new NewsletterSubscriptionDTO(
        statusOf(newsletterSubscription.getStatus()),
        newsletterSubscription.getText(),
        newsletterSubscription.getTime());
  }
}
