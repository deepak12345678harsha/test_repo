package de.otto.blablafish_contact_management.listeners;

import static de.otto.blablafish_email.utils.Constants.EVENT_ID;
import static de.otto.blablafish_email.utils.Constants.EVENT_LABEL;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import de.otto.blablafish_contact_management.service.SubscriberActionService;
import de.otto.blablafish_email.model.dto.MongoDbTriggerEvent;
import io.awspring.cloud.messaging.listener.SqsMessageDeletionPolicy;
import io.awspring.cloud.messaging.listener.annotation.SqsListener;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.jboss.logging.MDC;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class SubscriberActionsMongoDBTriggerListener {
  private final SubscriberActionService subscriberActionService;
  private final ObjectMapper objectMapper;

  @SqsListener(
      value = "${mongoDbTrigger.subscribers.actions.queueUrl}",
      deletionPolicy = SqsMessageDeletionPolicy.ON_SUCCESS)
  public void listenToSubscribersMongoDbTriggersForActions(String mongoTriggerJsonAsString) {
    try {
      var event = objectMapper.readValue(mongoTriggerJsonAsString, MongoDbTriggerEvent.class);
      var subscriberId = event.getDetail().getDocumentKey().get_id();

      MDC.put(EVENT_LABEL, "HANDLE_SUBSCRIBER_ACTION_TRIGGER");
      MDC.put(EVENT_ID, event.getId());
      MDC.put("subscriberId", subscriberId);

      log.info("MongoDB Action trigger event received for Subscriber : {}", subscriberId);
      subscriberActionService.executeAction(subscriberId);
    } catch (JsonProcessingException | RuntimeException e) {
      // TODO: handle subscriber does not exists exception if needed
      log.error(
          "Failed to process MongoDB trigger event - HANDLE_SUBSCRIBER_ACTION_TRIGGER : {}",
          e.getMessage(),
          e);
      throw new RuntimeException(
          String.format(
              "An error occurred for HANDLE_SUBSCRIBER_ACTION_TRIGGER : %s", e.getMessage()));
    } finally {
      MDC.remove(EVENT_LABEL);
      MDC.remove(EVENT_ID);
      MDC.remove("subscriberId");
    }
  }
}
