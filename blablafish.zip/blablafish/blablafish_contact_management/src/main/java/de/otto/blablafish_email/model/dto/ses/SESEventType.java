package de.otto.blablafish_email.model.dto.ses;

import com.fasterxml.jackson.annotation.JsonProperty;

public enum SESEventType {
  @JsonProperty(value = "Delivery")
  DELIVERY,
  @JsonProperty(value = "Send")
  SEND,
  @JsonProperty(value = "Reject")
  REJECT,
  @JsonProperty(value = "Open")
  OPEN,
  @JsonProperty(value = "Click")
  CLICK,
  @JsonProperty(value = "Bounce")
  BOUNCE,
  @JsonProperty(value = "Complaint")
  COMPLAINT,
  @JsonProperty(value = "DeliveryDelay")
  DELIVERY_DELAY
}
