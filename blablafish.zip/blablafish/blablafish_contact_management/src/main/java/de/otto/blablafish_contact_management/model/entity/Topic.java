package de.otto.blablafish_contact_management.model.entity;

import java.util.List;
import java.util.Objects;
import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "topics")
@AllArgsConstructor
@Builder
@Getter
@NoArgsConstructor
public class Topic {
  @Id private int id;

  private String name;

  private String description;

  private List<String> mandatorySubscriberRoles;

  @NonNull private String emailSubject;

  @NonNull private String emailHtmlTemplate;

  @NonNull private String emailPlainTextTemplate;

  @NonNull private org.bson.Document emailSchema;

  private String internalSubject;

  private String internalDescription;

  private org.bson.Document internalEmailSchema;

  private TopicOptions options;

  public boolean shouldDisplayOnContactManagementUI() {
    return Objects.nonNull(options) && options.getDisplayOnContactManagementUI();
  }

  public boolean shouldDisplayOnEmailConfigUI() {
    return Objects.nonNull(options) && options.getDisplayOnEmailConfigUI();
  }
}
