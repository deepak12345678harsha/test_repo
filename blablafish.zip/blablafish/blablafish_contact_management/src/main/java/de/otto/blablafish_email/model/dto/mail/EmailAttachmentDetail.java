package de.otto.blablafish_email.model.dto.mail;

import java.io.File;
import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public class EmailAttachmentDetail {

  private String fileName;

  private File attachment;
}
