package de.otto.blablafish_email.model.dto.ses;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public class EmailRequestNotice {

  private String emailRequestId;
}
