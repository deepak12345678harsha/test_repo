package de.otto.blablafish_contact_management.service;

import static de.otto.blablafish_contact_management.model.dto.SubscriptionResponse.SUBSCRIPTION_SUCCESSFUL;
import static de.otto.blablafish_contact_management.model.dto.SubscriptionResponse.SUBSCRIPTION_UNSUCCESSFUL;

import de.otto.blablafish_contact_management.exception.TopicNotFoundException;
import de.otto.blablafish_contact_management.model.dto.*;
import de.otto.blablafish_contact_management.model.entity.Requester;
import de.otto.blablafish_contact_management.model.entity.Subscriber;
import de.otto.blablafish_contact_management.model.entity.Topic;
import de.otto.blablafish_contact_management.respository.SubscriberRepository;
import de.otto.blablafish_contact_management.respository.TopicRepository;
import java.util.*;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.bson.types.ObjectId;
import org.jboss.logging.MDC;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@AllArgsConstructor
public class TopicService {
  private final TopicRepository topicRepository;
  private final SubscriberRepository subscriberRepository;

  public List<TopicDTO> getTopicSubscribers(String partnerId) {
    List<Topic> topics = topicRepository.findAll();
    return topicsWithSubscribers(partnerId, topics);
  }

  private List<TopicDTO> topicsWithSubscribers(String partnerId, List<Topic> topics) {
    List<Subscriber> subscribers = subscriberRepository.findAllByPartner(partnerId);

    return topics.stream()
        .filter(Topic::shouldDisplayOnContactManagementUI)
        .map(
            topic -> {
              var subscriberDTOS =
                  subscribers.stream()
                      .filter(subscriber -> subscriber.getTopicIds().contains(topic.getId()))
                      .map(SubscriberDTO::from)
                      .toList();
              return TopicDTO.from(topic, subscriberDTOS);
            })
        .toList();
  }

  public AddSubscribersResponse addTopicSubscribers(
      int topicId, List<String> userIds, Requester requester) throws TopicNotFoundException {
    validateTopicExists(topicId);

    List<ObjectId> savedUserIds = userIds.stream().map(ObjectId::new).toList();
    Map<SubscriptionResponse, Set<String>> subscriptions =
        subscribeTopic(savedUserIds, topicId, requester);

    List<AddSubscriberResponse> responses = new ArrayList<>();
    responses.add(
        new AddSubscriberResponse(
            SUBSCRIPTION_SUCCESSFUL, subscriptions.get(SUBSCRIPTION_SUCCESSFUL)));
    responses.add(
        new AddSubscriberResponse(
            SUBSCRIPTION_UNSUCCESSFUL, subscriptions.get(SUBSCRIPTION_UNSUCCESSFUL)));
    MDC.put("topicId", topicId);
    log.info("Added subscribers to topic");
    MDC.remove("topicId");
    return new AddSubscribersResponse(responses);
  }

  public void validateTopicExists(Integer topicId) throws TopicNotFoundException {
    findByTopicId(topicId);
  }

  public Topic findByTopicId(Integer topicId) throws TopicNotFoundException {
    Optional<Topic> topic = topicRepository.findById(topicId);
    if (topic.isEmpty()) {
      throw new TopicNotFoundException(String.format("Topic with id %s does not exists", topicId));
    }
    return topic.get();
  }

  public List<Topic> findAllByMandatorySubscriberRole(String role) {
    return topicRepository.findAllByMandatorySubscriberRole(role);
  }

  private Map<SubscriptionResponse, Set<String>> subscribeTopic(
      List<ObjectId> savedUserIds, int topicId, Requester requester) {
    Map<SubscriptionResponse, Set<String>> subscriptions =
        new HashMap<>() {
          {
            put(SUBSCRIPTION_SUCCESSFUL, new HashSet<>());
            put(SUBSCRIPTION_UNSUCCESSFUL, new HashSet<>());
          }
        };

    Long modifiedSubscribersCount =
        subscriberRepository.subscribeTopicForUsers(savedUserIds, topicId, requester);
    if (modifiedSubscribersCount == savedUserIds.size()) {
      savedUserIds.forEach(
          userId -> subscriptions.get(SUBSCRIPTION_SUCCESSFUL).add(userId.toString()));
    } else {
      List<Subscriber> successfulUsers =
          subscriberRepository.filterSubscribedUsersForTopic(
              savedUserIds, topicId, requester.getPartnerId());
      List<ObjectId> successfulUserIds =
          successfulUsers.stream().map(Subscriber::getUserId).toList();
      savedUserIds.forEach(
          userId -> {
            if (successfulUserIds.contains(userId))
              subscriptions.get(SUBSCRIPTION_SUCCESSFUL).add(userId.toString());
            else subscriptions.get(SUBSCRIPTION_UNSUCCESSFUL).add(userId.toString());
          });
    }
    return subscriptions;
  }

  public Set<Topic> getTopics(List<Integer> topicIds) {
    Set<Topic> topics = new HashSet<>();
    topicRepository.findAllById(topicIds).forEach(topics::add);
    return topics;
  }
}
