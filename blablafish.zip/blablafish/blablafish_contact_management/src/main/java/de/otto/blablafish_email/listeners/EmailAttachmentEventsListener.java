package de.otto.blablafish_email.listeners;

import static de.otto.blablafish_contact_management.utils.Constants.CONTACT_MANAGEMENT;
import static de.otto.blablafish_contact_management.utils.Constants.SERVICE_NAME;
import static de.otto.blablafish_email.utils.Constants.*;

import com.fasterxml.jackson.databind.ObjectMapper;
import de.otto.blablafish_contact_management.cdc.EventMessageValidator;
import de.otto.blablafish_contact_management.model.dto.DeepSeaEvent;
import de.otto.blablafish_email.model.dto.EmailAttachmentDTO;
import de.otto.blablafish_email.service.EmailAttachmentService;
import io.awspring.cloud.messaging.config.annotation.NotificationMessage;
import io.awspring.cloud.messaging.listener.SqsMessageDeletionPolicy;
import io.awspring.cloud.messaging.listener.annotation.SqsListener;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.jboss.logging.MDC;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class EmailAttachmentEventsListener {

  private final EmailAttachmentService emailAttachmentService;
  private final ObjectMapper objectMapper;

  @SqsListener(
      value = "${emailAttachmentEvents.queueUrl}",
      deletionPolicy = SqsMessageDeletionPolicy.ON_SUCCESS)
  void listen(@NotificationMessage String message) {
    try {
      EventMessageValidator.validateMessage(message);

      final DeepSeaEvent deepSeaEvent = objectMapper.readValue(message, DeepSeaEvent.class);
      MDC.put(SERVICE_NAME, CONTACT_MANAGEMENT);
      MDC.put(EVENT_LABEL, deepSeaEvent.getType());
      MDC.put(EVENT_ID, deepSeaEvent.getEventId());
      log.info("DeepSeaEvent Message received. EventType: {} ", deepSeaEvent.getType());

      var emailAttachmentDTO =
          objectMapper.convertValue(deepSeaEvent.getData(), EmailAttachmentDTO.class);
      emailAttachmentService.syncAttachment(emailAttachmentDTO);
    } catch (Exception e) {
      log.error("Unable to process attachment, error message: {}", e.getMessage());
      throw new RuntimeException(e);
    } finally {
      MDC.remove(SERVICE_NAME);
      MDC.remove(EVENT_LABEL);
      MDC.remove(EVENT_ID);
    }
  }
}
