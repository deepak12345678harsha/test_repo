package de.otto.blablafish_contact_management.utils;

import de.otto.blablafish_contact_management.model.dto.UserPrincipal;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.security.Principal;
import lombok.NonNull;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;

public class Helper {

  public static UserPrincipal toUserPrincipal(Principal principal) {
    UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken =
        (UsernamePasswordAuthenticationToken) principal;
    return (UserPrincipal) usernamePasswordAuthenticationToken.getPrincipal();
  }

  public static String stringifyStackTrace(@NonNull Throwable t) {
    final StringWriter sw = new StringWriter();
    t.printStackTrace(new PrintWriter(sw));
    return sw.toString().replaceAll("\\n\\t", " ");
  }
}
