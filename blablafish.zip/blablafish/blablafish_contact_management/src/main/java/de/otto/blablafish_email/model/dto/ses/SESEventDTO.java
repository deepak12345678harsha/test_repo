package de.otto.blablafish_email.model.dto.ses;

import de.otto.blablafish_email.model.entity.SESEvent;
import java.time.Instant;
import java.util.Objects;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.springframework.lang.NonNull;

@Getter
@AllArgsConstructor
@NoArgsConstructor
public class SESEventDTO {

  @NonNull private String id;

  @NonNull private String eventType;

  @NonNull private String awsMessageId;

  @NonNull private Document body;

  @NonNull private Instant createdAt;

  // TODO: mark mailRequestId as @NonNull after live email -migration
  private String mailRequestId;

  public static SESEventDTO from(SESEvent event) {
    return new SESEventDTO(
        event.getId().toString(),
        event.getEventType(),
        event.getAwsMessageId(),
        event.getBody().getValue(),
        event.getCreatedAt(),
        event.getMailRequestId().toString());
  }

  public SESEvent toSESEvent(String emailRequestId) {
    var validMailRequestId = Objects.isNull(mailRequestId) ? emailRequestId : mailRequestId;

    return SESEvent.builder()
        .id(new ObjectId(id))
        .eventType(eventType)
        .awsMessageId(awsMessageId)
        .body(SESEvent.encryptedBody(body))
        .createdAt(createdAt)
        .mailRequestId(new ObjectId(validMailRequestId))
        .build();
  }
}
