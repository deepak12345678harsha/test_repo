package de.otto.blablafish_contact_management.model.entity;

import java.time.Instant;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class CommunicationSubscription {

  @NotNull private CommunicationSubscriptionStatus status;

  @NotNull private Instant time;

  public boolean isSubscribed() {
    return CommunicationSubscriptionStatus.SUBSCRIBED.equals(status);
  }
}
