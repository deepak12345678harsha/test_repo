package de.otto.newsletter.service;

import de.otto.newsletter.exception.JWTActionNotFoundException;
import de.otto.newsletter.exception.RSAKeyPairDoesNotExistException;
import de.otto.newsletter.model.JWTActions;
import de.otto.newsletter.model.JWTClaims;
import de.otto.newsletter.model.entity.RSAKeyPair;
import de.otto.newsletter.repository.RSAKeyPairRepository;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.JwsHeader;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.SigningKeyResolverAdapter;
import io.jsonwebtoken.lang.Assert;
import java.security.Key;
import java.security.KeyPair;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Base64;
import java.util.Date;
import java.util.Map;
import java.util.Optional;
import javax.crypto.spec.SecretKeySpec;
import lombok.extern.slf4j.Slf4j;
import org.bson.types.ObjectId;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class JWTService {

  private static final int EXPIRATION_TIME_IN_DAYS = 10 * 365;
  private final RSAKeyPairRepository rsaKeyPairRepository;

  public JWTService(RSAKeyPairRepository rsaKeyPairRepository) {
    this.rsaKeyPairRepository = rsaKeyPairRepository;
  }

  public String getJWT(ObjectId subscriberId, JWTActions action) {
    Assert.notNull(subscriberId, "subscriberId is missing");
    final Map<String, Object> claims = Map.of(JWTClaims.ACTION.getClaimName(), action.toString());
    final RSAKeyPair rsaEncodedSigningKey = getRSAEncodedSigningKey();
    return Jwts.builder()
        .setSubject(subscriberId.toHexString())
        .addClaims(claims)
        .setExpiration(Date.from(Instant.now().plus(EXPIRATION_TIME_IN_DAYS, ChronoUnit.DAYS)))
        .setHeaderParam("kid", rsaEncodedSigningKey.getKid())
        .signWith(toPrivateKey(rsaEncodedSigningKey), SignatureAlgorithm.HS256)
        .compact();
  }

  private RSAKeyPair getRSAEncodedSigningKey() {
    return getKeyPairWithSigningKeyOrCreateIfMissing();
  }

  private RSAKeyPair getKeyPairWithSigningKeyOrCreateIfMissing() {
    final Optional<RSAKeyPair> existingRSAKeyPair = rsaKeyPairRepository.findByActiveSigningKey();
    if (existingRSAKeyPair.isEmpty()) {
      final KeyPair keyPair = io.jsonwebtoken.security.Keys.keyPairFor(SignatureAlgorithm.RS256);
      final RSAKeyPair rsaKeyPair =
          RSAKeyPair.asSigningKey(
              Base64.getEncoder().encodeToString(keyPair.getPublic().getEncoded()),
              Base64.getEncoder().encodeToString(keyPair.getPrivate().getEncoded()));
      try {
        rsaKeyPairRepository.insert(rsaKeyPair);
        return rsaKeyPair;
      } catch (DuplicateKeyException e) {
        return rsaKeyPairRepository.findByActiveSigningKey().get();
      }
    }
    return existingRSAKeyPair.get();
  }

  private Key toPrivateKey(RSAKeyPair rsaKeyPair) {
    String secret = rsaKeyPair.getPrivateKey().getValue();
    return new SecretKeySpec(
        Base64.getDecoder().decode(secret), SignatureAlgorithm.HS256.getJcaName());
  }

  public Claims getClaims(String jwt) {
    final Jws<Claims> claimsJws =
        Jwts.parserBuilder()
            .setSigningKeyResolver(new CustomSigningKeyResolverAdapter())
            .build()
            .parseClaimsJws(jwt);

    return claimsJws.getBody();
  }

  public void verifyClaimAction(Claims claims, JWTActions jwtAction) {
    Object action = claims.get("action");
    if (!jwtAction.toString().equals(action)) {
      throw new JWTActionNotFoundException("Unknown JWT Action: " + jwtAction.toString());
    }
  }

  private class CustomSigningKeyResolverAdapter extends SigningKeyResolverAdapter {
    @Override
    public Key resolveSigningKey(JwsHeader jwsHeader, Claims claims) {
      String keyId = jwsHeader.getKeyId();
      RSAKeyPair rsaKeyPair =
          rsaKeyPairRepository
              .findActiveSigningKeyByKeyId(keyId)
              .orElseThrow(() -> new RSAKeyPairDoesNotExistException(keyId));

      return toPrivateKey(rsaKeyPair);
    }
  }
}
