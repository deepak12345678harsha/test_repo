package de.otto.blablafish_email.gateway;

import static org.springframework.http.MediaType.APPLICATION_FORM_URLENCODED_VALUE;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import de.otto.blablafish_email.model.dto.mail.InternalApiTokenResponseDTO;
import java.util.Map;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(value = "internalApiGatewayClient", url = "${internal.api.baseUrl}")
public interface InternalApiGatewayClient {
  String INTERNAL_API_ACCESS_TOKEN_CACHE_NAME = "internalApiAccessTokenCache";

  @Cacheable(INTERNAL_API_ACCESS_TOKEN_CACHE_NAME)
  @PostMapping(
      path = "/v1/token",
      produces = APPLICATION_JSON_VALUE,
      consumes = APPLICATION_FORM_URLENCODED_VALUE)
  ResponseEntity<InternalApiTokenResponseDTO> getInternalApiAccessToken(
      @RequestBody Map<String, ?> requestParameters);
}
