package de.otto.blablafish_contact_management.handler;

import de.otto.blablafish_contact_management.respository.SubscriberRepository;
import de.otto.blablafish_email.model.dto.MongoDbTriggerEvent;
import java.time.Instant;

public abstract class SubscriberChangedEventIdentifier implements SubscriberEventIdentifier {

  protected final SubscriberRepository subscriberRepository;

  protected SubscriberChangedEventIdentifier(SubscriberRepository subscriberRepository) {
    this.subscriberRepository = subscriberRepository;
  }

  @Override
  public boolean canIdentifyEvent(MongoDbTriggerEvent event) {
    return event.isUpdateEvent();
  }

  @Override
  public Instant getEventTime(MongoDbTriggerEvent event) {

    // TODO: cross-check: neptune uses getLastUpdatedTime() as follows from change-event-json (we
    // have subscriber-mongo-trigger-json)
    //    return event.getLastUpdatedTime();
    return event.getTime();
  }
}
