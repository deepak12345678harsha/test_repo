package de.otto.blablafish_contact_management.model.dto;

public enum UserStateDTO {
  ENABLED,
  DISABLED,
  INVITATION_SENT,
  REJECTED
}
