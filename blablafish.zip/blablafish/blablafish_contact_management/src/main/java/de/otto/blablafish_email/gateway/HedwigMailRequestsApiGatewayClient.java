package de.otto.blablafish_email.gateway;

import de.otto.blablafish_email.model.dto.mail.EmailDTO;
import de.otto.blablafish_email.model.dto.mail.HedwigEmailRequestDTO;
import de.otto.blablafish_email.model.dto.ses.SESEventDTO;
import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(
    value = "hedwigMailRequestsApiGatewayClient",
    url = "${internal.api.baseUrl}",
    configuration = {HedwigApiFeignClientConfig.class})
public interface HedwigMailRequestsApiGatewayClient {
  @GetMapping(path = "/mails-requests/{mailRequestId}")
  HedwigEmailRequestDTO getMailRequest(@PathVariable("mailRequestId") String mailRequestId);

  @GetMapping(path = "/mails/{mailId}")
  EmailDTO getMail(@PathVariable("mailId") String mailId);

  @GetMapping(path = "/mails-events")
  List<SESEventDTO> getSESEvents(@RequestParam("aws_message_id") String awsMessageId);
}
