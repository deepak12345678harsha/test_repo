package de.otto.blablafish_contact_management.rest;

import static de.otto.blablafish_contact_management.utils.Constants.SERVICE_NAME;
import static de.otto.blablafish_email.utils.Constants.COOPERATION_BASIC;
import static de.otto.blablafish_email.utils.Constants.NEWSLETTER_SERVICE;

import de.otto.blablafish_contact_management.exception.SubscriberDoesNotExistException;
import de.otto.blablafish_contact_management.model.dto.NewsletterSubscriptionDTO;
import de.otto.blablafish_contact_management.model.dto.UserPrincipal;
import de.otto.blablafish_contact_management.model.entity.NewsletterSubscription;
import de.otto.blablafish_contact_management.service.SubscriberService;
import de.otto.blablafish_contact_management.utils.Helper;
import java.security.Principal;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.jboss.logging.MDC;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping("/v1")
public class NewsletterSubscriptionController {

  private final String NEWSLETTER_SUBSCRIPTION_URI = "/subscribers/newsletter-subscription-status";
  private final SubscriberService subscriberService;

  public NewsletterSubscriptionController(SubscriberService subscriberService) {
    this.subscriberService = subscriberService;
  }

  @GetMapping(value = NEWSLETTER_SUBSCRIPTION_URI, produces = MediaType.APPLICATION_JSON_VALUE)
  @PreAuthorize("hasAuthority('" + COOPERATION_BASIC + "')")
  @ResponseStatus(HttpStatus.OK)
  public NewsletterSubscriptionDTO getNewsletterSubscriptionBySubscriberId(Principal principal)
      throws SubscriberDoesNotExistException {
    MDC.put(SERVICE_NAME, NEWSLETTER_SERVICE);
    UserPrincipal userPrincipal = Helper.toUserPrincipal(principal);
    log.info(
        "Received get newsletter subscription request for subscriber subject : {}",
        userPrincipal.getSubject());
    var subscription =
        subscriberService.getNewsletterSubscriptionByEmailAddress(userPrincipal.getUserName());
    MDC.remove(SERVICE_NAME);
    return NewsletterSubscriptionDTO.of(subscription);
  }

  @PutMapping(value = NEWSLETTER_SUBSCRIPTION_URI, consumes = MediaType.APPLICATION_JSON_VALUE)
  @PreAuthorize("hasAuthority('" + COOPERATION_BASIC + "')")
  @ResponseStatus(HttpStatus.OK)
  public NewsletterSubscriptionDTO updateNewsletterSubscriptionStatus(
      @Valid @NotNull @RequestBody NewsletterSubscriptionDTO newsLetterDto,
      @RequestHeader("User-Agent") String userAgent,
      Principal principal)
      throws SubscriberDoesNotExistException {
    MDC.put(SERVICE_NAME, NEWSLETTER_SERVICE);
    UserPrincipal userPrincipal = Helper.toUserPrincipal(principal);
    var requester = subscriberService.requesterOf(userPrincipal, userAgent);
    log.info(
        "Received update newsletter subscription for subscriber subject: {} to {}",
        userPrincipal.getSubject(),
        newsLetterDto.getIsSubscribed());
    NewsletterSubscription updatedSubscription =
        subscriberService.handleNewsletterSubscription(
            userPrincipal.getUserName(),
            newsLetterDto.getIsSubscribed(),
            newsLetterDto.getText(),
            requester);
    log.info(
        "Newsletter status updated for subscriber subject {} to  {}",
        userPrincipal.getSubject(),
        updatedSubscription.getStatus());
    return NewsletterSubscriptionDTO.of(updatedSubscription);
  }
}
