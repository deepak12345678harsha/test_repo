package de.otto.newsletter.model.dto;

import java.time.Instant;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;

@Getter
@AllArgsConstructor
@NoArgsConstructor
public class NewsletterStatusDTO {

  @NonNull private String neptuneUserId;

  @NonNull private String status;

  private String newsletterAcceptedText;

  @NonNull private Instant timestamp;
}
