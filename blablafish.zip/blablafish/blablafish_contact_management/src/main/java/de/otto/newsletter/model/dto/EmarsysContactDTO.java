package de.otto.newsletter.model.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import de.otto.blablafish_contact_management.model.entity.CommunicationSubscription;
import de.otto.blablafish_contact_management.model.entity.NewsletterSubscription;
import de.otto.blablafish_contact_management.model.entity.Subscriber;
import java.util.Collections;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EmarsysContactDTO {

  @JsonProperty(EmarsysContactFields.KEY_ID)
  private String keyId;

  @JsonProperty(EmarsysContactFields.USER_ID)
  private String userId;

  @JsonProperty(EmarsysContactFields.FIRSTNAME)
  private String firstName;

  @JsonProperty(EmarsysContactFields.LASTNAME)
  private String lastName;

  @JsonProperty(EmarsysContactFields.EMAIL)
  private String email;

  @JsonProperty(EmarsysContactFields.PARTNER_ID)
  private String partnerId;

  @JsonProperty(EmarsysContactFields.NEWSLETTER_UNSUBSCRIBE_KEY)
  private String newsletterUnsubscribeKey;

  @JsonProperty(EmarsysContactFields.COMMUNICATIONS_UNSUBSCRIBE_KEY)
  private String communicationsUnsubscribeKey;

  @JsonProperty(EmarsysContactFields.NEWSLETTER_OPT_IN)
  private Integer newsletterOptIn;

  @JsonProperty(EmarsysContactFields.COMMUNICATIONS_OPT_IN)
  private Integer communicationsOptIn;

  @JsonProperty(EmarsysContactFields.ROLES)
  private Set<String> groups;

  @JsonProperty(EmarsysContactFields.ACCOUNT_STATUS)
  private String accountStatus;

  public static EmarsysContactDTO withPermissions(
      Subscriber subscriber, String newsletterUnsubscribeKey, String communicationsUnsubscribeKey) {
    return new EmarsysContactDTO(
        EmarsysContactFields.USER_ID,
        subscriber.getUserId().toHexString(),
        subscriber.getFirstName().getValue(),
        subscriber.getLastName().getValue(),
        subscriber.getEmail().getValue(),
        subscriber.getPartnerId(),
        newsletterUnsubscribeKey,
        communicationsUnsubscribeKey,
        getNewsletterOptInCode(subscriber.getNewsletterSubscription()),
        getCommunicationsOptInCode(subscriber.getCommunicationSubscription()),
        mapGroupsToRoles(subscriber.getGroups()),
        "ACTIVE");
  }

  private static Integer getCommunicationsOptInCode(
      CommunicationSubscription communicationSubscription) {

    if (Objects.isNull(communicationSubscription)) {
      return 1;
    }

    switch (communicationSubscription.getStatus()) {
      case SUBSCRIBED -> {
        return 1;
      }
      case UNSUBSCRIBED -> {
        return 2;
      }
      default -> {
        return null;
      }
    }
  }

  private static Integer getNewsletterOptInCode(NewsletterSubscription subscription) {
    if (Objects.isNull(subscription)) {
      return null;
    }

    switch (subscription.getStatus()) {
      case SUBSCRIBED -> {
        return 1;
      }
      case UNSUBSCRIBED -> {
        return 2;
      }
      default -> {
        return null;
      }
    }
  }

  private static Set<String> mapGroupsToRoles(Set<String> groups) {
    if (groups == null) {
      return Collections.emptySet();
    }

    Set<String> mappedGroups = new HashSet<>();
    for (String group : groups) {
      String groupId = getGroupCode(group);
      if (groupId != null) {
        mappedGroups.add(groupId);
      }
    }
    return mappedGroups;
  }

  private static String getGroupCode(String group) {
    switch (group) {
      case "administration" -> {
        return "1";
      }
      case "products" -> {
        return "2";
      }
      case "orders" -> {
        return "3";
      }
      case "analytics" -> {
        return "4";
      }
      case "finance" -> {
        return "5";
      }
      case "customerInquiries" -> {
        return "6";
      }
      case "services" -> {
        return "7";
      }
      default -> {
        return null;
      }
    }
  }
}
