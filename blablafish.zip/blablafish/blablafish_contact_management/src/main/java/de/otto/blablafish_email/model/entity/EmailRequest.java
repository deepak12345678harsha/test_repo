package de.otto.blablafish_email.model.entity;

import de.otto.blablafish_contact_management.model.encryption.EncryptedDocument;
import de.otto.blablafish_contact_management.model.encryption.EncryptedField;
import java.time.Instant;
import java.util.List;
import java.util.Set;
import javax.validation.constraints.Min;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.ToString;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.lang.NonNull;
import org.springframework.util.Assert;

@AllArgsConstructor
@ToString
@Getter
@org.springframework.data.mongodb.core.mapping.Document(collection = "mailRequests")
@Builder(access = AccessLevel.PUBLIC)
public class EmailRequest {

  public static final String FIELD_REQUEST_ID = "requestId";

  @Id private ObjectId requestId;

  @Min(1)
  private Integer topicId;

  @NonNull private List<EmailRecipient> recipients;

  @NonNull private EncryptedField<Document> payload;

  private EncryptedField<Document> internalPayload;

  @NonNull private Instant createdAt;

  private EmailRequester requester;

  @NonNull private EmailRequestStatus status;

  private Set<String> attachmentIds;

  public static EmailRequest of(
      Document payload,
      Document internalPayload,
      Integer topicId,
      List<EmailRecipient> recipients,
      EmailRequester requester,
      Set<String> attachmentIds) {
    Assert.notNull(payload, "Missing payload.");
    Assert.notNull(requester, "Missing requester.");
    return EmailRequest.builder()
        .requestId(new ObjectId())
        .topicId(topicId)
        .createdAt(Instant.now())
        .recipients(recipients)
        .payload(encryptPayload(payload))
        .internalPayload(encryptInternalPayload(internalPayload))
        .requester(requester)
        .status(EmailRequestStatus.ACCEPTED)
        .attachmentIds(attachmentIds)
        .build();
  }

  public static EmailRequest of(
      Document payload,
      Integer topicId,
      List<EmailRecipient> recipients,
      EmailRequester requester,
      Set<String> attachmentIds) {
    return of(payload, null, topicId, recipients, requester, attachmentIds);
  }

  public static EncryptedField<Document> encryptPayload(Document payload) {
    return new EncryptedDocument(payload, "emailRequests.payload");
  }

  public static EncryptedField<Document> encryptInternalPayload(Document internalPayload) {
    return new EncryptedDocument(internalPayload, "emailRequests.internalPayload");
  }
}
