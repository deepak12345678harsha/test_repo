package de.otto.blablafish_email.rest;

import static de.otto.blablafish_contact_management.utils.Constants.SERVICE_NAME;
import static de.otto.blablafish_email.utils.Constants.*;

import de.otto.blablafish_email.exception.SESEventNotFoundException;
import de.otto.blablafish_email.model.dto.ses.SESEventDTO;
import de.otto.blablafish_email.service.SESEventService;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.jboss.logging.MDC;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("/v1")
public class SESController {
  private final SESEventService sesEventService;

  public SESController(SESEventService sesEventService) {
    this.sesEventService = sesEventService;
  }

  @GetMapping(value = "/mails-events", produces = MediaType.APPLICATION_JSON_VALUE)
  @PreAuthorize("hasAuthority('" + CONTACT_MANAGEMENT_EMAIL_READ_ROLE + "')")
  @ResponseStatus(HttpStatus.OK)
  public List<SESEventDTO> getSESEventByAWSMessageId(
      @RequestParam("aws_message_id") String awsMessageId) throws SESEventNotFoundException {
    MDC.put(SERVICE_NAME, EMAIL_SERVICE);
    log.info("Received get ses event for aws message Id: {}", awsMessageId);
    var sesEvents = sesEventService.getByAWSMessageId(awsMessageId);
    MDC.remove(SERVICE_NAME);
    return sesEvents;
  }
}
