package de.otto.blablafish_contact_management.model.dto;

import static com.fasterxml.jackson.annotation.JsonFormat.Shape.STRING;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.time.Instant;
import java.util.Map;
import java.util.UUID;
import lombok.*;

@AllArgsConstructor
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder(access = AccessLevel.PRIVATE)
@NoArgsConstructor
public class DeepSeaEvent {

  private static final String CONTACT_MANAGEMENT = "contact-management";
  private static final String TIMESTAMP_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSSX";
  private static final String TIMEZONE = "UTC";

  @NonNull private String eventId;
  @NonNull private String traceId;
  @NonNull private EventType type;
  @NonNull private String context;

  @NonNull
  @JsonFormat(shape = STRING, pattern = TIMESTAMP_FORMAT, timezone = TIMEZONE)
  private Instant eventTime;

  @NonNull private Map<String, Object> data;

  public static DeepSeaEvent of(EventType eventType, Map<String, Object> data) {
    return DeepSeaEvent.builder()
        .context(CONTACT_MANAGEMENT)
        .type(eventType)
        .data(data)
        .eventTime(Instant.now())
        .traceId(UUID.randomUUID().toString())
        .eventId(UUID.randomUUID().toString())
        .build();
  }
}
