package de.otto.blablafish_email.model.dto.mail;

import static com.fasterxml.jackson.annotation.JsonFormat.Shape.STRING;

import com.fasterxml.jackson.annotation.JsonFormat;
import de.otto.blablafish_email.model.entity.EmailStatus;
import de.otto.blablafish_email.model.entity.EmailStatusHistoryEntry;
import java.time.Instant;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Getter
public class EmailStatusHistoryEntryDTO {

  private EmailStatus status;

  @JsonFormat(shape = STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSX", timezone = "UTC")
  private Instant date;

  public static EmailStatusHistoryEntryDTO of(EmailStatusHistoryEntry emailStatusHistoryEntry) {
    return new EmailStatusHistoryEntryDTO(
        emailStatusHistoryEntry.getStatus(), emailStatusHistoryEntry.getDate());
  }

  public EmailStatusHistoryEntry toEmailStatusHistoryEntry() {
    return EmailStatusHistoryEntry.of(status, date);
  }
}
