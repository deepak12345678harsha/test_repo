package de.otto.blablafish_contact_management.model.entity;

import de.otto.blablafish_contact_management.model.Actions;
import de.otto.blablafish_contact_management.model.dto.EventType;
import de.otto.blablafish_contact_management.model.dto.UserPrincipal;
import de.otto.blablafish_contact_management.model.encryption.EncryptedField;
import de.otto.blablafish_contact_management.model.encryption.EncryptedString;
import java.time.Instant;
import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import org.bson.types.ObjectId;
import org.springframework.lang.NonNull;
import org.springframework.util.Assert;

@Getter
@Builder(access = AccessLevel.PRIVATE)
public class Requester {

  private ObjectId subscriberId;
  private String clientId;
  private String partnerId;
  private String userAgent;
  @NonNull private Instant date;
  private EncryptedField<String> username;

  private EventType eventType;
  private Actions action;

  public static Requester of(ObjectId subscriberId, String partnerId, String userAgent) {
    Assert.hasText(userAgent, "Missing user agent.");
    Assert.notNull(subscriberId, "Missing subscriberId.");
    return Requester.builder()
        .subscriberId(subscriberId)
        .userAgent(userAgent)
        .partnerId(partnerId)
        .date(Instant.now())
        .build();
  }

  public static Requester ofEventType(EventType eventType) {
    return Requester.builder().date(Instant.now()).eventType(eventType).build();
  }

  public static EncryptedField<String> encryptedUsername(String username) {
    return new EncryptedString(username.toLowerCase(), "requester.username", true);
  }

  public static Requester ofPrincipal(UserPrincipal principal, String userAgent) {
    Assert.notNull(principal, "Missing principal");

    EncryptedField<String> encryptedUserName = Requester.encryptedUsername(principal.getUserName());
    return Requester.builder()
        .clientId(principal.getClientId())
        .partnerId(principal.getPartnerId())
        .userAgent(userAgent)
        .date(Instant.now())
        .username(encryptedUserName)
        .build();
  }
}
