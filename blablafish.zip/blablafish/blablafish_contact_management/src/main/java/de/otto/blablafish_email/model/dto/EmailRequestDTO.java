package de.otto.blablafish_email.model.dto;

import static com.fasterxml.jackson.annotation.JsonFormat.Shape.STRING;

import com.fasterxml.jackson.annotation.JsonFormat;
import de.otto.blablafish_email.model.entity.EmailRequest;
import de.otto.blablafish_email.model.entity.EmailRequestStatus;
import java.time.Instant;
import java.util.List;
import java.util.Set;
import javax.validation.constraints.NotNull;
import lombok.*;
import org.bson.Document;

@AllArgsConstructor
@Getter
@Builder(access = AccessLevel.PRIVATE)
@NoArgsConstructor
public class EmailRequestDTO {

  @NotNull private Integer topicId;

  @NotNull private List<EmailRecipientDTO> recipients;

  @NotNull private Document payload;

  @NotNull
  @JsonFormat(shape = STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSX", timezone = "UTC")
  private Instant createdAt;

  @NotNull private EmailRequestStatus status;

  private Set<String> attachmentIds;

  public static EmailRequestDTO of(EmailRequest mailRequest) {
    final List<EmailRecipientDTO> recipientDTOS =
        mailRequest.getRecipients().stream().map(EmailRecipientDTO::of).toList();
    return EmailRequestDTO.builder()
        .createdAt(mailRequest.getCreatedAt())
        .recipients(recipientDTOS)
        .payload(mailRequest.getPayload().getValue())
        .topicId(mailRequest.getTopicId())
        .status(mailRequest.getStatus())
        .attachmentIds(mailRequest.getAttachmentIds())
        .build();
  }
}
