package de.otto.blablafish_contact_management.service;

import de.otto.blablafish_contact_management.exception.SubscriberDoesNotExistException;
import de.otto.blablafish_contact_management.model.dto.EmailPreferenceDTO;
import de.otto.blablafish_contact_management.model.dto.UpdateEmailPreferenceRequestDTO;
import de.otto.blablafish_contact_management.model.dto.UserPrincipal;
import de.otto.blablafish_contact_management.model.entity.EmailPreference;
import de.otto.blablafish_contact_management.model.entity.Subscriber;
import de.otto.blablafish_contact_management.model.entity.Topic;
import de.otto.blablafish_contact_management.respository.EmailPreferenceRepository;
import de.otto.blablafish_contact_management.respository.SubscriberRepository;
import de.otto.blablafish_contact_management.respository.TopicRepository;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.bson.types.ObjectId;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class EmailPreferenceService {

  private final SubscriberRepository subscriberRepository;
  private final EmailPreferenceRepository emailPreferenceRepository;
  private final TopicRepository topicRepository;

  private static Boolean hasOptedForTopic(
      Map<Integer, Boolean> subscriberEmailPreferences, Topic topic) {
    return subscriberEmailPreferences.containsKey(topic.getId())
        ? subscriberEmailPreferences.get(topic.getId())
        : topic.getOptions().getIsSubscribedByDefault();
    // TODO : getIsSubscribedByDefault can be null, use primitive datatype as return
  }

  public List<EmailPreferenceDTO> getAllEmailPreferencesForSubscriber(UserPrincipal userPrincipal)
      throws SubscriberDoesNotExistException {
    var subscriber = getSubscriber(userPrincipal.getUserName());
    var subscriberTopicsForEmailConfigUI =
        topicRepository.findAll(true, subscriber.getEffectiveRoleIds()).stream()
            .filter(Topic::shouldDisplayOnEmailConfigUI)
            .toList();
    var subscriberEmailPreferences =
        emailPreferenceRepository.findAll(subscriber.getUserId()).stream()
            .collect(Collectors.toMap(EmailPreference::getTopicId, EmailPreference::isOptIn));
    return subscriberTopicsForEmailConfigUI.stream()
        .map(
            topic ->
                EmailPreferenceDTO.of(topic, hasOptedForTopic(subscriberEmailPreferences, topic)))
        .toList();
  }

  private Subscriber getSubscriber(String emailAddress) throws SubscriberDoesNotExistException {
    return subscriberRepository
        .findByEmail(emailAddress)
        .orElseThrow(() -> new SubscriberDoesNotExistException("Subscriber does not exist"));
  }

  public void updateEmailPreferences(
      String email, List<UpdateEmailPreferenceRequestDTO> updateEmailPreferences)
      throws SubscriberDoesNotExistException {
    log.info("updating Email preferences..");
    Subscriber subscriber = getSubscriber(email);
    var topicsIdsApplicableToSubscriber =
        topicRepository.findAll(true, true, subscriber.getEffectiveRoleIds()).stream()
            .map(Topic::getId)
            .toList();

    var emailPreferences =
        updateEmailPreferences.stream()
            .filter(request -> topicsIdsApplicableToSubscriber.contains(request.getTopicId()))
            .map(request -> request.toEmailPreference(subscriber.getUserId()))
            .toList();
    emailPreferenceRepository.upsertAll(emailPreferences);
  }

  public List<EmailPreference> getPreferencesForSubscribers(
      int topicId, Set<ObjectId> subscriberIds) {
    return emailPreferenceRepository.findPreferences(topicId, subscriberIds);
  }
}
