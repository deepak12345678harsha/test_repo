package de.otto.blablafish_contact_management.model.dto;

import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;

@Getter
@AllArgsConstructor
@NoArgsConstructor
public class UserSetDTO {

  @NonNull private String partnerId;

  @NonNull private String neptuneUserId;

  @NonNull private UserTypeDTO userType;

  @NonNull private Contact contact;

  // TODO: should effectiveRoleIds field be non-null?
  private Set<String> effectiveRoleIds; // as defined in keycloak

  @NonNull private UserStateDTO state;

  @NonNull private Set<String> groups;
}
