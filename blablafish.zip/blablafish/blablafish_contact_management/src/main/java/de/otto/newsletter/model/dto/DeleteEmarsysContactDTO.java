package de.otto.newsletter.model.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@AllArgsConstructor
@NoArgsConstructor
public class DeleteEmarsysContactDTO {
  @JsonProperty(EmarsysContactFields.KEY_ID)
  private String keyId;

  @JsonProperty(EmarsysContactFields.USER_ID)
  private String userId;

  public static DeleteEmarsysContactDTO of(String subscriberId) {
    return new DeleteEmarsysContactDTO(EmarsysContactFields.USER_ID, subscriberId);
  }
}
