package de.otto.blablafish_contact_management.model.entity;

import de.otto.blablafish_contact_management.model.dto.UserStateDTO;

public enum Status {
  ENABLED,
  DISABLED,
  INVITATION_SENT,
  REJECTED;

  public static Status of(UserStateDTO arg) {
    return switch (arg) {
      case DISABLED -> Status.DISABLED;
      case ENABLED -> Status.ENABLED;
      case INVITATION_SENT -> Status.INVITATION_SENT;
      case REJECTED -> Status.REJECTED;
      default -> throw new IllegalArgumentException("Unsupported user state." + arg);
    };
  }
}
