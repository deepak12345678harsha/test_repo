package de.otto.blablafish_contact_management.cdc;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.stream.Stream;

public class CdcTestExecutor {

  private static final String MESSAGE_DIR_PATH = System.getenv("MESSAGES_PATH");

  public static void main(String[] args) throws Exception {
    File cdcMessageDir = getMessageDir();
    if (cdcMessageDir.listFiles().length < 1) {
      throw new Exception("No events found");
    }
    for (File file : cdcMessageDir.listFiles()) {
      System.out.println("Actual event: " + file.getPath());
      EventMessageValidator.validateMessage(getMessage(file));
      System.out.println("Successful");
    }
  }

  private static File getMessageDir() throws Exception {
    final File cdcMessageDir = new File(MESSAGE_DIR_PATH);
    if (!cdcMessageDir.exists()) {
      throw new Exception("Dir not found");
    }
    return cdcMessageDir;
  }

  private static String getMessage(File file) throws IOException {
    final Stream<String> allLines = Files.lines(file.toPath(), StandardCharsets.UTF_8);
    final StringBuilder msgBuilder = new StringBuilder();
    allLines.forEach(msgBuilder::append);
    return msgBuilder.toString();
  }
}
