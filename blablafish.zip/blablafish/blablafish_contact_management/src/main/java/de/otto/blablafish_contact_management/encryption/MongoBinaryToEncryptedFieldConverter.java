package de.otto.blablafish_contact_management.encryption;

import de.otto.blablafish_contact_management.model.encryption.*;
import org.bson.BsonBinary;
import org.bson.BsonValue;
import org.bson.Document;
import org.bson.types.Binary;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.ReadingConverter;

@ReadingConverter
public class MongoBinaryToEncryptedFieldConverter implements Converter<Binary, EncryptedField<?>> {
  private final EncryptionHelper clientEncryption;

  public MongoBinaryToEncryptedFieldConverter(EncryptionHelper clientEncryption) {
    this.clientEncryption = clientEncryption;
  }

  @Override
  public EncryptedField<?> convert(Binary binary) {
    final BsonBinary bsonBinary = new BsonBinary(binary.getType(), binary.getData());
    final BsonValue decrypt = clientEncryption.decrypt(bsonBinary);

    switch (decrypt.getBsonType()) {
      case STRING:
        return new EncryptedString(decrypt.asString().getValue(), bsonBinary);
      case INT32:
        return new EncryptedInteger(decrypt.asInt32().getValue(), bsonBinary);
      case BINARY:
        new EncryptedByteArray(decrypt.asBinary().getData(), bsonBinary);
      case DOCUMENT:
        return new EncryptedDocument(Document.parse(decrypt.asDocument().toJson()), bsonBinary);
      default:
        throw new RuntimeException(
            "BSON Type is NOT supported. BsonType: " + decrypt.getBsonType());
    }
  }
}
