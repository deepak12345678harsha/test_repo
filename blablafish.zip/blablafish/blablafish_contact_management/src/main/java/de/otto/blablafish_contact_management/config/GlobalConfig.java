package de.otto.blablafish_contact_management.config;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.web.client.RestTemplate;

@Configuration
public class GlobalConfig {

  @Bean
  @Primary
  public ObjectMapper objectMapper() {
    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm a z");
    return new ObjectMapper()
        .setDateFormat(dateFormat)
        .registerModule(new JavaTimeModule())
        .enable(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_USING_DEFAULT_VALUE)
        .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
  }

  @Bean
  public RestTemplate restTemplate() {
    return new RestTemplate();
  }
}
