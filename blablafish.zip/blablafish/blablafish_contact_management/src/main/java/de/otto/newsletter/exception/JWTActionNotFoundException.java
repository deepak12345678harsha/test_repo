package de.otto.newsletter.exception;

public class JWTActionNotFoundException extends RuntimeException {

  public JWTActionNotFoundException(String message) {
    super(message);
  }
}
