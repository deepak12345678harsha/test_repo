package de.otto.blablafish_email.gateway;

import feign.RequestInterceptor;
import feign.Retryer;
import feign.codec.ErrorDecoder;
import java.util.concurrent.TimeUnit;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.CacheManager;
import org.springframework.context.annotation.Bean;

public class HedwigApiFeignClientConfig {

  private final CacheManager cacheManager;
  private final InternalApiGatewayClient internalApiGatewayClient;
  private final String clientId;
  private final String clientSecret;

  public HedwigApiFeignClientConfig(
      CacheManager cacheManager,
      InternalApiGatewayClient internalApiGatewayClient,
      @Value("${internal.api.client.id}") String clientId,
      @Value("${internal.api.client.secret}") String clientSecret) {
    this.cacheManager = cacheManager;
    this.internalApiGatewayClient = internalApiGatewayClient;
    this.clientId = clientId;
    this.clientSecret = clientSecret;
  }

  @Bean
  public RequestInterceptor requestInterceptor() {
    return new HedwigClientRequestInterceptor(internalApiGatewayClient, clientId, clientSecret);
  }

  @Bean
  public Retryer retryer() {
    return new Retryer.Default(100, TimeUnit.SECONDS.toMillis(30), 3);
  }

  @Bean
  public ErrorDecoder decoder() {
    return new HedwigApiFeignErrorDecoder(cacheManager);
  }
}
