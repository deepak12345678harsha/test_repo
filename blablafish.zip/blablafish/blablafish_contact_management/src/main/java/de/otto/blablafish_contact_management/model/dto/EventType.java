package de.otto.blablafish_contact_management.model.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public enum EventType {
  @JsonProperty("neptune-usermanagement.USER_SET")
  NEPTUNE_USER_SET,

  @JsonProperty("neptune-usermanagement.USER_DELETED")
  NEPTUNE_USER_DELETED,

  @JsonProperty("contact-management.EMAIL_PRECONDITION_FAILED")
  EMAIL_PRECONDITION_FAILED,

  @JsonProperty("contact-management.EMAIL_REQUEST_FAILED")
  EMAIL_REQUEST_FAILED,

  @JsonProperty("contact-management.EMAIL_REQUEST_SUCCESS")
  EMAIL_REQUEST_SUCCESS,

  @JsonProperty("contact-management.EMAIL_BLACKLISTED")
  EMAIL_BLACKLISTED,

  @JsonProperty("contact-management.EMAIL_UNBLACKLISTED")
  EMAIL_UNBLACKLISTED,

  @JsonProperty("neptune-usermanagement.NEWSLETTER_STATUS_CHANGED")
  NEWSLETTER_STATUS_CHANGED,

  @JsonProperty("neptune-email_service.EMAIL_ATTACHMENT_CREATED")
  EMAIL_ATTACHMENT_CREATED,

  EMAIL_BLACKLISTED_MONGO_TRIGGER,

  UNKNOWN
}
