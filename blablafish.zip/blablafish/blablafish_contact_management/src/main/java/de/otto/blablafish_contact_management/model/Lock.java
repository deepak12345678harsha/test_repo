package de.otto.blablafish_contact_management.model;

import java.time.Instant;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NonNull;

@Getter
@AllArgsConstructor
public class Lock {
  @NonNull private UUID acquiredBy;
  @NonNull private Instant acquiredAt;
  @NonNull private Instant expiresAt;
}
