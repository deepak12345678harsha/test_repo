package de.otto.blablafish_email.model.dto.mail;

import de.otto.blablafish_email.model.entity.EmailRecipient;
import de.otto.blablafish_email.model.entity.EmailStatusHistoryEntry;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.springframework.lang.NonNull;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Getter
@Builder(access = AccessLevel.PUBLIC)
public class HedwigEmailRecipientDTO {

  @NonNull private String emailId;
  @NonNull private String firstName;
  @NonNull private String lastName;
  @NonNull private String email;
  @NonNull private EmailStatusHistoryEntry emailStatus;

  @NonNull private String partnerId;

  public static EmailRecipient toEmailRecipient(HedwigEmailRecipientDTO hedwigEmailRecipientDTO) {

    return EmailRecipient.builder()
        .emailId(hedwigEmailRecipientDTO.getEmailId())
        .firstName(EmailRecipient.encryptFirstName(hedwigEmailRecipientDTO.getFirstName()))
        .lastName(EmailRecipient.encryptLastName(hedwigEmailRecipientDTO.getLastName()))
        .emailAddress(EmailRecipient.encryptEmail(hedwigEmailRecipientDTO.getEmail()))
        .emailStatusHistoryEntry(hedwigEmailRecipientDTO.getEmailStatus())
        .partnerId(hedwigEmailRecipientDTO.getPartnerId())
        .build();
  }
}
