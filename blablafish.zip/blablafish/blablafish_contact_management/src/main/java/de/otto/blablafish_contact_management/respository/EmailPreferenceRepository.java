package de.otto.blablafish_contact_management.respository;

import static de.otto.blablafish_contact_management.model.entity.EmailPreference.*;

import de.otto.blablafish_contact_management.model.entity.EmailPreference;
import java.util.List;
import java.util.Set;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.BulkOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.*;
import org.springframework.data.util.Pair;
import org.springframework.stereotype.Repository;

@Repository
@Slf4j
@RequiredArgsConstructor
public class EmailPreferenceRepository {

  private final MongoTemplate mongoTemplate;

  public void upsertAll(List<EmailPreference> emailPreferences) {
    if (emailPreferences.isEmpty()) {
      return;
    }

    var upsertPairs =
        emailPreferences.stream()
            .map(
                emailPreference -> {
                  var query =
                      Query.query(
                          Criteria.where(FIELD_SUBSCRIBER_ID)
                              .is(emailPreference.getSubscriberId())
                              .and(FIELD_TOPIC_ID)
                              .is(emailPreference.getTopicId()));
                  var update =
                      new Update()
                          .set(FIELD_OPT_IN, emailPreference.isOptIn())
                          .set(FIELD_LAST_UPDATED_AT, emailPreference.getLastUpdatedAt());
                  return Pair.of(query, update);
                })
            .toList();

    var bulkWriteResult =
        mongoTemplate
            .bulkOps(BulkOperations.BulkMode.UNORDERED, EmailPreference.class)
            .upsert(upsertPairs)
            .execute();

    if (bulkWriteResult.getUpserts().size() + bulkWriteResult.getModifiedCount()
        != emailPreferences.size()) {
      var message = "Error while updating preference for the subscriber";
      log.error(message);
      throw new RuntimeException(message);
    }
  }

  public List<EmailPreference> findAll(ObjectId subscriberId) {
    return mongoTemplate.find(
        Query.query(Criteria.where(FIELD_SUBSCRIBER_ID).is(subscriberId)), EmailPreference.class);
  }

  public List<EmailPreference> findPreferences(int topicId, Set<ObjectId> subscriberIds) {
    var query =
        Query.query(
            Criteria.where(FIELD_TOPIC_ID).is(topicId).and(FIELD_SUBSCRIBER_ID).in(subscriberIds));
    return mongoTemplate.find(query, EmailPreference.class);
  }
}
