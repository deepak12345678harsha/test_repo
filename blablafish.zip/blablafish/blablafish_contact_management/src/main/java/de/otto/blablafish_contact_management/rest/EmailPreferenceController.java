package de.otto.blablafish_contact_management.rest;

import static de.otto.blablafish_contact_management.utils.Constants.CONTACT_MANAGEMENT;
import static de.otto.blablafish_contact_management.utils.Constants.SERVICE_NAME;
import static de.otto.blablafish_email.utils.Constants.COOPERATION_BASIC;

import de.otto.blablafish_contact_management.exception.SubscriberDoesNotExistException;
import de.otto.blablafish_contact_management.model.dto.EmailPreferenceDTO;
import de.otto.blablafish_contact_management.model.dto.UpdateEmailPreferenceRequestDTO;
import de.otto.blablafish_contact_management.model.dto.UserPrincipal;
import de.otto.blablafish_contact_management.service.EmailPreferenceService;
import de.otto.blablafish_contact_management.utils.Helper;
import java.security.Principal;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.jboss.logging.MDC;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("/v1")
public class EmailPreferenceController {

  private static final String EMAIL_PREFERENCE_URI = "/subscribers/notification-preferences";

  private final EmailPreferenceService emailPreferenceService;

  public EmailPreferenceController(EmailPreferenceService emailPreferenceService) {
    this.emailPreferenceService = emailPreferenceService;
  }

  @GetMapping(value = EMAIL_PREFERENCE_URI, produces = MediaType.APPLICATION_JSON_VALUE)
  @PreAuthorize("hasAuthority('" + COOPERATION_BASIC + "')")
  public ResponseEntity<ResponseCollection<EmailPreferenceDTO>> getAllEmailPreferencesForSubscriber(
      Principal principal) throws SubscriberDoesNotExistException {
    MDC.put(SERVICE_NAME, CONTACT_MANAGEMENT);
    UserPrincipal userPrincipal = Helper.toUserPrincipal(principal);
    log.info("Get email preferences for a subscriber - Controller Layer");
    var preferences = emailPreferenceService.getAllEmailPreferencesForSubscriber(userPrincipal);
    MDC.remove(SERVICE_NAME);
    return new ResponseEntity<>(new ResponseCollection(preferences), HttpStatus.OK);
  }

  @PostMapping(value = EMAIL_PREFERENCE_URI, consumes = MediaType.APPLICATION_JSON_VALUE)
  @PreAuthorize("hasAuthority('" + COOPERATION_BASIC + "')")
  public void updateSubscriberEmailPreferences(
      @RequestBody List<UpdateEmailPreferenceRequestDTO> updateEmailPreferences,
      Principal principal)
      throws SubscriberDoesNotExistException {
    UserPrincipal userPrincipal = Helper.toUserPrincipal(principal);
    emailPreferenceService.updateEmailPreferences(
        userPrincipal.getUserName(), updateEmailPreferences);
  }
}
