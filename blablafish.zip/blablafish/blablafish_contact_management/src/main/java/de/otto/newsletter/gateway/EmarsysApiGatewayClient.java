package de.otto.newsletter.gateway;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import static org.springframework.http.MediaType.TEXT_HTML_VALUE;

import de.otto.newsletter.emarsys.EmarsysFeignClientConfig;
import de.otto.newsletter.model.dto.DeleteEmarsysContactDTO;
import de.otto.newsletter.model.dto.EmarsysContactDTO;
import de.otto.newsletter.model.dto.GetEmarsysContactDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(
    value = "emarsysApiGatewayClient",
    url = "${emarsys.api.baseUrl}",
    configuration = {EmarsysFeignClientConfig.class})
public interface EmarsysApiGatewayClient {

  @PutMapping(path = "/v2/contact/", produces = TEXT_HTML_VALUE, consumes = APPLICATION_JSON_VALUE)
  ResponseEntity<String> updateContact(
      @RequestParam(name = "create_if_not_exists") int createIfNotExists,
      @RequestBody EmarsysContactDTO emarsysContact);

  @PostMapping(
      path = "/v2/contact/delete",
      produces = TEXT_HTML_VALUE,
      consumes = APPLICATION_JSON_VALUE)
  ResponseEntity<String> deleteContact(
      @RequestBody DeleteEmarsysContactDTO deleteEmarsysContactDTO);

  @PostMapping(
      path = "/v2/contact/getdata",
      produces = TEXT_HTML_VALUE,
      consumes = APPLICATION_JSON_VALUE)
  ResponseEntity<String> getContact(@RequestBody GetEmarsysContactDTO emarsysContactDTO);
}
