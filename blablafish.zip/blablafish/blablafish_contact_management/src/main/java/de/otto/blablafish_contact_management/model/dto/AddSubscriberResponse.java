package de.otto.blablafish_contact_management.model.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;

@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
public class AddSubscriberResponse {
  @NonNull private SubscriptionResponse status;
  @NonNull private Set<String> subscribersId;
}
