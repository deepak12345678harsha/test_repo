package de.otto.blablafish_contact_management.model.dto;

import de.otto.blablafish_contact_management.model.entity.EmailPreference;
import java.time.Instant;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;

@NoArgsConstructor
@AllArgsConstructor
@Getter
public class UpdateEmailPreferenceRequestDTO {

  private int topicId;

  private boolean optIn;

  public EmailPreference toEmailPreference(ObjectId subscriberId) {
    return EmailPreference.builder()
        .topicId(this.getTopicId())
        .subscriberId(subscriberId)
        .lastUpdatedAt(Instant.now())
        .optIn(this.isOptIn())
        .build();
  }
}
