package de.otto.blablafish_contact_management.model.encryption;

import org.bson.BsonBinary;
import org.bson.BsonDocument;
import org.bson.BsonValue;
import org.bson.Document;

public class EncryptedDocument extends EncryptedField<Document> {
  public EncryptedDocument(Document value, String keyAltName) {
    super(value, keyAltName, false);
  }

  public EncryptedDocument(Document value, BsonBinary bsonBinary) {
    super(value, bsonBinary);
  }

  @Override
  public BsonValue toBsonValue() {
    return getValue() == null ? null : BsonDocument.parse(getValue().toJson());
  }
}
