package de.otto.blablafish_contact_management.model.entity;

import de.otto.blablafish_contact_management.model.encryption.EncryptedDocument;
import de.otto.blablafish_contact_management.model.encryption.EncryptedField;
import java.time.Instant;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.lang.NonNull;

@Document(collection = "changeEvents")
@Builder(access = AccessLevel.PUBLIC)
@AllArgsConstructor
@Getter
public class ChangeEvent {

  @Id @NonNull private String id;

  private String eventDescription;

  private String source;

  @NonNull private String db;

  @NonNull private String collection;

  @NonNull private String operationType;

  @NonNull private org.bson.Document documentKey;

  @Indexed(expireAfterSeconds = 0)
  @NonNull
  private Instant expiresAt;

  @NonNull private Instant time;

  @NonNull private ClusterTime clusterTime;

  @NonNull private EncryptedField<org.bson.Document> event;

  public static EncryptedDocument encryptDocument(org.bson.Document document) {
    return new EncryptedDocument(document, "changeEvents.event");
  }
}
