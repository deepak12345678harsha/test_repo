package de.otto.blablafish_contact_management.rest;

import static de.otto.blablafish_contact_management.utils.Constants.*;

import de.otto.blablafish_contact_management.model.dto.TopicDTO;
import de.otto.blablafish_contact_management.service.TopicService;
import de.otto.blablafish_contact_management.utils.Helper;
import java.security.Principal;
import lombok.extern.slf4j.Slf4j;
import org.jboss.logging.MDC;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping("/v1")
public class TopicController {

  public static final String TOPICS_URI = "/topics";
  private final TopicService topicService;

  public TopicController(TopicService topicService) {
    this.topicService = topicService;
  }

  @GetMapping(value = TOPICS_URI, produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseStatus(HttpStatus.OK)
  @PreAuthorize("hasAuthority('" + CONTACT_MANAGEMENT_TOPIC_READ_ROLE + "')")
  public ResponseCollection<TopicDTO> getTopicSubscribers(Principal principal) {
    MDC.put(SERVICE_NAME, CONTACT_MANAGEMENT);
    var userPrincipal = Helper.toUserPrincipal(principal);
    log.info("Get topics Subscribers");
    var topicSubscribers = topicService.getTopicSubscribers(userPrincipal.getPartnerId());
    MDC.remove(SERVICE_NAME);
    return new ResponseCollection<>(topicSubscribers);
  }
}
