package de.otto.blablafish_contact_management.handler;

import de.otto.blablafish_contact_management.model.entity.NewsletterSubscription;
import de.otto.blablafish_contact_management.model.entity.NewsletterSubscriptionStatus;
import de.otto.blablafish_contact_management.respository.SubscriberRepository;
import de.otto.blablafish_email.model.dto.MongoDbTriggerEvent;
import de.otto.newsletter.model.entity.SubscriberChangeEventType;
import java.time.Instant;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class NewsLetterSubscriptionChangedEventIdentifier extends SubscriberChangedEventIdentifier {

  public NewsLetterSubscriptionChangedEventIdentifier(SubscriberRepository subscriberRepository) {
    super(subscriberRepository);
  }

  @Override
  public SubscriberChangeEventType getEventType(MongoDbTriggerEvent event) {
    return SubscriberChangeEventType.from(
        mapToNewsletter(event.getUpdatedFieldValues("newsletterSubscription")).getStatus());
  }

  @Override
  public Instant getSubscriberUpdatedTime(MongoDbTriggerEvent event) {
    return mapToNewsletter(event.getUpdatedFieldValues("newsletterSubscription")).getTime();
  }

  @Override
  public boolean canIdentifyEvent(MongoDbTriggerEvent event) {
    return event.isUpdateEvent() && event.hasUpdatedField("newsletterSubscription");
  }

  private NewsletterSubscription mapToNewsletter(Map<String, Object> map) {
    return new NewsletterSubscription(
        NewsletterSubscriptionStatus.valueOf(map.get("status").toString()),
        map.containsKey("text") ? map.get("text").toString() : null,
        Instant.parse(map.get("time").toString()));
  }
}
