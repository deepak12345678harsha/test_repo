package de.otto.blablafish_email.service;

import static de.otto.blablafish_email.model.dto.ValidationReason.INTERNAL_PAYLOAD_DOES_NOT_MATCH_TOPIC_INTERNAL_SCHEMA;
import static de.otto.blablafish_email.model.dto.ValidationReason.PAYLOAD_DOES_NOT_MATCH_TOPIC_SCHEMA;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.networknt.schema.JsonSchema;
import com.networknt.schema.JsonSchemaFactory;
import com.networknt.schema.SpecVersion;
import com.networknt.schema.ValidationMessage;
import de.otto.blablafish_contact_management.model.entity.Topic;
import de.otto.blablafish_email.exception.ValidationException;
import de.otto.blablafish_email.model.dto.ValidationReason;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.bson.Document;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

@Slf4j
@Component
public class EmailPayloadValidationService {
  private final ObjectMapper objectMapper;

  public EmailPayloadValidationService(ObjectMapper objectMapper) {
    this.objectMapper = objectMapper;
  }

  public void validate(Map<String, Object> payload, Topic topic) {
    validate(payload, Map.of(), topic);
  }

  public void validate(
      Map<String, Object> payload, Map<String, Object> internalPayload, Topic topic) {
    log.info("Validating email request for topic: " + topic.getId());

    validateSchema(payload, topic.getEmailSchema(), PAYLOAD_DOES_NOT_MATCH_TOPIC_SCHEMA);
    validateSchema(
        internalPayload,
        topic.getInternalEmailSchema(),
        INTERNAL_PAYLOAD_DOES_NOT_MATCH_TOPIC_INTERNAL_SCHEMA);
  }

  private void validateSchema(
      Map<String, Object> payload, Document schema, ValidationReason reason) {
    if (Objects.isNull(schema)) {
      return;
    }
    final JsonNode schemaAsJsonNode = this.objectMapper.convertValue(schema, JsonNode.class);
    final JsonNode payloadAsJsonNode = this.objectMapper.convertValue(payload, JsonNode.class);

    final JsonSchemaFactory factory = JsonSchemaFactory.getInstance(SpecVersion.VersionFlag.V7);
    final JsonSchema jsonSchema = factory.getSchema(schemaAsJsonNode);
    final Set<ValidationMessage> validate = jsonSchema.validate(payloadAsJsonNode);
    if (!CollectionUtils.isEmpty(validate)) {
      final String errorDescription =
          validate.stream().map(this::formatValidationMessage).collect(Collectors.joining());
      throw new ValidationException(reason, errorDescription);
    }
  }

  private String formatValidationMessage(ValidationMessage validationMessage) {
    return "type: "
        + validationMessage.getType()
        + ", code: "
        + validationMessage.getCode()
        + ", path: "
        + validationMessage.getPath()
        + ", message: "
        + validationMessage.getMessage()
        + ", details: "
        + validationMessage.getDetails();
  }
}
