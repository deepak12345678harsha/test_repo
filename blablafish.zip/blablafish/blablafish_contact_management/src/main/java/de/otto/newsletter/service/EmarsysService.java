package de.otto.newsletter.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import de.otto.blablafish_contact_management.exception.SubscriberDoesNotExistException;
import de.otto.blablafish_contact_management.model.entity.Subscriber;
import de.otto.blablafish_contact_management.service.SubscriberService;
import de.otto.newsletter.exception.EmarsysConnectionFailedException;
import de.otto.newsletter.gateway.EmarsysApiGatewayClient;
import de.otto.newsletter.model.JWTActions;
import de.otto.newsletter.model.dto.DeleteEmarsysContactDTO;
import de.otto.newsletter.model.dto.EmarsysContactDTO;
import de.otto.newsletter.model.dto.EmarsysContactResponse;
import de.otto.newsletter.model.dto.GetEmarsysContactDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class EmarsysService {

  private final SubscriberService subscriberService;
  private final JWTService jwtService;
  private final EmarsysApiGatewayClient emarsysApiGatewayClient;
  private final ObjectMapper objectMapper;

  public EmarsysService(
      SubscriberService subscriberService,
      JWTService jwtService,
      EmarsysApiGatewayClient emarsysApiGatewayClient,
      ObjectMapper objectMapper) {
    this.subscriberService = subscriberService;
    this.jwtService = jwtService;
    this.emarsysApiGatewayClient = emarsysApiGatewayClient;
    this.objectMapper = objectMapper;
  }

  public void updateOrCreateContact(String subscriberId)
      throws SubscriberDoesNotExistException, EmarsysConnectionFailedException {
    log.info("Creating/Updating Emarsys contact for subscriber id : {}", subscriberId);
    Subscriber subscriber = subscriberService.getSubscriberById(subscriberId);
    if (subscriber.isCooperationSubscriber() && subscriber.isActive()) {
      try {
        var responseEntity = emarsysApiGatewayClient.updateContact(1, emarsysContactOf(subscriber));
        log.info(
            "Emarsys Contact updated {} , status code: {} ",
            subscriberId,
            responseEntity.getStatusCode().value());
      } catch (Exception e) {
        log.error(
            "error occurred while updating Emarsys Contact for subscriber id : {} | Reason "
                + ": {}",
            subscriberId,
            e.getMessage());
        throw new EmarsysConnectionFailedException(
            String.format(
                "Unable to connect with Emarsys API %s | Unable to updateOrCreate Contact",
                e.getMessage()));
      }
    } else {
      log.info(
          "Ignoring create/update sync with Emarsys as subscriber with id: {} isn't Cooperation subscriber or is not active",
          subscriberId);
    }
  }

  private EmarsysContactDTO emarsysContactOf(Subscriber subscriber) {
    return EmarsysContactDTO.withPermissions(
        subscriber,
        getNewsletterUnsubscribeKey(subscriber),
        getCommunicationsUnsubscribeKey(subscriber));
  }

  private String getCommunicationsUnsubscribeKey(Subscriber subscriber) {
    if (subscriber.isSubscribedToCommunications()) {
      return jwtService.getJWT(subscriber.getUserId(), JWTActions.UNSUBSCRIBE_COMMUNICATIONS);
    }
    return "";
  }

  private String getNewsletterUnsubscribeKey(Subscriber subscriber) {
    if (subscriber.isSubscribedToNewsletter()) {
      return jwtService.getJWT(subscriber.getUserId(), JWTActions.UNSUBSCRIBE_NEWSLETTER);
    }
    return "";
  }

  public void deleteContact(String subscriberId) throws EmarsysConnectionFailedException {
    log.info("Deleting Emarsys contact for subscriber id : {}", subscriberId);
    if (!userExistsInEmarsys(subscriberId)) {
      log.info("Ignoring delete as user doesn't exist in Emarsys");
      return;
    }
    try {
      var responseEntity =
          emarsysApiGatewayClient.deleteContact(DeleteEmarsysContactDTO.of(subscriberId));
      log.info(
          "Emarsys Contact deleted {} , status code: {} ",
          subscriberId,
          responseEntity.getStatusCode().value());
    } catch (Exception e) {
      log.error("Error occurred while updating Emarsys Contact : {}", e.getMessage());
      throw new EmarsysConnectionFailedException(
          String.format(
              "Unable to connect with Emarsys API %s | Unable to delete contact", e.getMessage()));
    }
  }

  private boolean userExistsInEmarsys(String subscriberId) throws EmarsysConnectionFailedException {
    try {
      var responseEntity =
          emarsysApiGatewayClient.getContact(GetEmarsysContactDTO.of(subscriberId));
      log.info(
          "Emarsys Contact fetched for subscriber id: {} , status code: {} ",
          subscriberId,
          responseEntity.getStatusCode().value());
      EmarsysContactResponse emarsysContactResponse =
          objectMapper.readValue(responseEntity.getBody(), EmarsysContactResponse.class);

      return ((emarsysContactResponse.getReplyCode() == 0)
          && emarsysContactResponse.getData().getErrors().isEmpty());

    } catch (Exception e) {
      log.error("Error occurred while fetching Emarsys Contact : {}", e.getMessage());
      throw new EmarsysConnectionFailedException(
          String.format(
              "Unable to connect with Emarsys API %s | Unable to fetch contact", e.getMessage()));
    }
  }
}
