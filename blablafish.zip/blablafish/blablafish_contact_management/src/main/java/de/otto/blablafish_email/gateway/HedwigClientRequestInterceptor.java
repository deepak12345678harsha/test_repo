package de.otto.blablafish_email.gateway;

import feign.RequestInterceptor;
import feign.RequestTemplate;
import java.util.Map;

public class HedwigClientRequestInterceptor implements RequestInterceptor {

  private final InternalApiGatewayClient internalApiGatewayClient;
  private final String clientId;
  private final String clientSecret;

  public HedwigClientRequestInterceptor(
      InternalApiGatewayClient internalApiGatewayClient, String clientId, String clientSecret) {

    this.internalApiGatewayClient = internalApiGatewayClient;
    this.clientId = clientId;
    this.clientSecret = clientSecret;
  }

  @Override
  public void apply(RequestTemplate requestTemplate) {
    requestTemplate.removeHeader("Authorization");
    var form =
        Map.of(
            "client_id",
            clientId,
            "client_secret",
            clientSecret,
            "grant_type",
            "client_credentials");

    var internalApiAccessToken = internalApiGatewayClient.getInternalApiAccessToken(form);
    requestTemplate.header(
        "Authorization",
        String.format("Bearer %s", internalApiAccessToken.getBody().getAccessToken()));
  }
}
