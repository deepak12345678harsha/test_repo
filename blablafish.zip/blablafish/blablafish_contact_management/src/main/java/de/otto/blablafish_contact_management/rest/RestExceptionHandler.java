package de.otto.blablafish_contact_management.rest;

import static org.springframework.http.HttpStatus.*;

import de.otto.blablafish_contact_management.exception.BlaBlaFishException;
import de.otto.blablafish_contact_management.exception.NewsletterSubscriptionDoesNotExistException;
import de.otto.blablafish_contact_management.exception.SubscriberDoesNotExistException;
import de.otto.blablafish_contact_management.exception.TopicNotFoundException;
import de.otto.blablafish_contact_management.model.dto.ErrorResponse;
import de.otto.blablafish_email.exception.*;
import javax.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.multipart.MaxUploadSizeExceededException;

@Slf4j
@ControllerAdvice
public class RestExceptionHandler {

  @ExceptionHandler(
      value = {
        TopicNotFoundException.class,
        SubscriberDoesNotExistException.class,
        EmailNotFoundException.class,
        EmailBlacklistNotFoundException.class,
        NewsletterSubscriptionDoesNotExistException.class
      })
  private ResponseEntity<ErrorResponse> handleNotFoundException(HttpServletRequest r, Exception e) {
    log.error(String.format("An error occurred %s", e.getMessage()), e);
    return buildErrorResponseEntity(e, NOT_FOUND);
  }

  @ExceptionHandler(
      value = {
        BlaBlaFishException.class,
        FileUploadException.class,
        ValidationException.class,
        MissingServletRequestParameterException.class
      })
  private ResponseEntity<ErrorResponse> handleBlaBlaFishException(
      HttpServletRequest r, Exception e) {
    log.error(String.format("An error occurred %s", e.getMessage()), e);
    return buildErrorResponseEntity(e, BAD_REQUEST);
  }

  @ExceptionHandler(MethodArgumentNotValidException.class)
  private ResponseEntity<ErrorResponse> handleMethodArgumentNotValidException(
      MethodArgumentNotValidException e) {
    BindingResult result = e.getBindingResult();
    final var fieldErrors = result.getFieldErrors();

    ErrorResponse errorResponse =
        ErrorResponse.builder()
            .message("Validation Failed for request body.")
            .details(
                fieldErrors.stream()
                    .map(
                        fieldError -> fieldError.getField() + ": " + fieldError.getDefaultMessage())
                    .toList())
            .build();
    log.error("Exception occurred {}: {}", errorResponse.getDetails(), e.getCause());
    return ResponseEntity.status(BAD_REQUEST).body(errorResponse);
  }

  @ExceptionHandler(AccessDeniedException.class)
  private ResponseEntity<ErrorResponse> handleAccessDeniedException(
      HttpServletRequest r, Exception e) {
    log.error(String.format("An error occurred %s", e.getMessage()), e);
    return buildErrorResponseEntity(e, FORBIDDEN);
  }

  @ExceptionHandler(value = {Exception.class})
  private ResponseEntity<ErrorResponse> handleException(HttpServletRequest r, Exception e) {
    log.error(String.format("An error occurred %s", e.getMessage()), e);
    return buildErrorResponseEntity(e, INTERNAL_SERVER_ERROR);
  }

  @ExceptionHandler(value = {EmailNotProcessableException.class})
  private ResponseEntity<ErrorResponse> handleEmailNotProcessableException(
      HttpServletRequest r, Exception e) {
    log.error(String.format("An error occurred %s", e.getMessage()), e);
    return buildErrorResponseEntity(e, UNPROCESSABLE_ENTITY);
  }

  @ExceptionHandler(value = MaxUploadSizeExceededException.class)
  private ResponseEntity<ErrorResponse> handleMaxUploadSizeExceededException(
      HttpServletRequest r, Exception e) {
    ErrorResponse errorResponse = ErrorResponse.builder().message(e.getMessage()).build();
    log.error("Exception occurred {}: {}", e.getMessage(), e.getCause());
    return ResponseEntity.status(PAYLOAD_TOO_LARGE).body(errorResponse);
  }

  @ExceptionHandler(value = MultiPartnerEmailException.class)
  private ResponseEntity<ErrorResponse> handleMultiPartnerEmailException(
      HttpServletRequest r, MultiPartnerEmailException e) {
    var errorResponse =
        ErrorResponse.builder().message(e.getMessage()).details(e.getErrorMessages()).build();
    return ResponseEntity.status(UNPROCESSABLE_ENTITY).body(errorResponse);
  }

  private ResponseEntity<ErrorResponse> buildErrorResponseEntity(
      Exception e, HttpStatus httpStatus) {
    ErrorResponse.ErrorResponseBuilder errorResponseBuilder = ErrorResponse.builder();
    if (e instanceof BlaBlaFishException blaBlaFishException) {
      int code = blaBlaFishException.getBlaBlaFishError().getCode();
      errorResponseBuilder.errorCode(code);
    }
    ErrorResponse errorResponse = errorResponseBuilder.message(e.getMessage()).build();
    return ResponseEntity.status(httpStatus).body(errorResponse);
  }
}
