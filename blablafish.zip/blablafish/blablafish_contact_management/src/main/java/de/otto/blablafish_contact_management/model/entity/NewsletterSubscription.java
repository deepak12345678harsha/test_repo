package de.otto.blablafish_contact_management.model.entity;

import java.time.Instant;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class NewsletterSubscription {

  @NotNull private NewsletterSubscriptionStatus status;

  private String text;

  @NotNull private Instant time;
}
