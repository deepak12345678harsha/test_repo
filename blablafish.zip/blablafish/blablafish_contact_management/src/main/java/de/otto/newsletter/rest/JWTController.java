package de.otto.newsletter.rest;

import de.otto.blablafish_contact_management.exception.SubscriberDoesNotExistException;
import de.otto.blablafish_contact_management.service.SubscriberService;
import de.otto.blablafish_contact_management.utils.Helper;
import de.otto.newsletter.model.JWTActions;
import de.otto.newsletter.service.JWTService;
import java.security.Principal;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

// TODO: Remove this controller post testing is done
@RequestMapping("/v1")
@RestController
@ConditionalOnProperty(value = "environment", havingValue = "develop")
public class JWTController {

  private final SubscriberService subscriberService;

  private final JWTService jwtService;

  public JWTController(SubscriberService subscriberService, JWTService jwtService) {
    this.subscriberService = subscriberService;
    this.jwtService = jwtService;
  }

  @GetMapping(path = "/jwtToken", produces = MediaType.APPLICATION_JSON_VALUE)
  public Object jwtToken(Principal principal, @RequestParam(required = false) String type)
      throws SubscriberDoesNotExistException {
    var action = JWTActions.UNSUBSCRIBE_NEWSLETTER;
    if ("communication".equalsIgnoreCase(type)) {
      action = JWTActions.UNSUBSCRIBE_COMMUNICATIONS;
    }
    var userPrincipal = Helper.toUserPrincipal(principal);
    var emailAddress = userPrincipal.getUserName();
    var subscriberId =
        subscriberService
            .getUserByEmail(emailAddress)
            .orElseThrow(() -> new SubscriberDoesNotExistException("Subscriber does not exists"))
            .getUserId();
    return jwtService.getJWT(subscriberId, action);
  }
}
