package de.otto.blablafish_email.model.entity;

public enum EmailRequestStatus {
  ACCEPTED,
  MINIMUM_ONE_MAIL_DELIVERED,
  MAIL_DELIVERY_FAILED_FOR_ALL_RECIPIENTS
}
