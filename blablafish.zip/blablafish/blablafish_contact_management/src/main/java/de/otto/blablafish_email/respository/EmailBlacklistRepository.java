package de.otto.blablafish_email.respository;

import static de.otto.blablafish_email.model.entity.EmailBlacklist.FIELD_EMAIL_ADDRESS;

import de.otto.blablafish_email.model.entity.EmailBlackListReason;
import de.otto.blablafish_email.model.entity.EmailBlacklist;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.BasicQuery;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.data.support.PageableExecutionUtils;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

@Repository
@Slf4j
public class EmailBlacklistRepository {

  private final MongoTemplate mongoTemplate;

  public EmailBlacklistRepository(MongoTemplate mongoTemplate) {
    this.mongoTemplate = mongoTemplate;
  }

  public void upsert(String emailAddress, EmailBlackListReason blackListReason) {
    final Query query =
        new Query(
            Criteria.where(FIELD_EMAIL_ADDRESS).is(EmailBlacklist.encryptEmail(emailAddress)));
    final Update updateDefinition = new Update().push("reasons", blackListReason);
    mongoTemplate.upsert(query, updateDefinition, EmailBlacklist.class);
  }

  public Optional<EmailBlacklist> findById(ObjectId blacklistId) {
    log.info("Fetching blacklist details: {}", blacklistId);
    return Optional.ofNullable(mongoTemplate.findById(blacklistId, EmailBlacklist.class));
  }

  public Optional<List<EmailBlacklist>> findByEmail(String emailAddress) {
    final Query query =
        new Query(
            Criteria.where(FIELD_EMAIL_ADDRESS).is(EmailBlacklist.encryptEmail(emailAddress)));
    return Optional.of(mongoTemplate.find(query, EmailBlacklist.class));
  }

  public Page<EmailBlacklist> findAll(String searchString, Pageable pageable) {
    BasicQuery basicQuery = searchQuery(searchString);
    Query query = searchQuery(searchString).with(pageable);
    List<EmailBlacklist> blacklists = mongoTemplate.find(query, EmailBlacklist.class);
    return PageableExecutionUtils.getPage(
        blacklists, pageable, () -> mongoTemplate.count(basicQuery, EmailBlacklist.class));
  }

  private BasicQuery searchQuery(String searchString) {
    Document document = new Document();
    if (StringUtils.hasText(searchString)) {
      document.append(FIELD_EMAIL_ADDRESS, EmailBlacklist.encryptEmail(searchString));
    }
    return new BasicQuery(document);
  }

  public void removeBlacklistedEmails(Set<String> emailIds) {
    var encryptedEmailIds = emailIds.stream().map(EmailBlacklist::encryptEmail).toList();
    var query = Query.query(Criteria.where(FIELD_EMAIL_ADDRESS).in(encryptedEmailIds));
    mongoTemplate.remove(query, EmailBlacklist.class);
    log.info("Successfully removed {} from blacklist.", emailIds.size());
  }
}
