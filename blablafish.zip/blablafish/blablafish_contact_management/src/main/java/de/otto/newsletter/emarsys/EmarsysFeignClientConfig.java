package de.otto.newsletter.emarsys;

import feign.RequestInterceptor;
import feign.Retryer;
import feign.codec.ErrorDecoder;
import java.util.concurrent.TimeUnit;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;

public class EmarsysFeignClientConfig {

  @Value("${emarsys.api.username}")
  private String emarsysApiUsername;

  @Value("${emarsys.api.password}")
  private String emarsysApiPassword;

  @Bean
  public RequestInterceptor requestInterceptor() {
    return new EmarsysFeignClientRequestInterceptor(emarsysApiUsername, emarsysApiPassword);
  }

  @Bean
  public Retryer retryer() {
    return new Retryer.Default(TimeUnit.SECONDS.toMillis(2), TimeUnit.SECONDS.toMillis(30), 3);
  }

  @Bean
  public ErrorDecoder decoder() {
    return new EmarsysFeignErrorDecoder();
  }
}
