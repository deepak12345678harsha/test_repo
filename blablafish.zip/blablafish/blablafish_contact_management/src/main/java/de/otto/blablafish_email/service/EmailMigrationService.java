package de.otto.blablafish_email.service;

import de.otto.blablafish_contact_management.exception.BlaBlaFishError;
import de.otto.blablafish_contact_management.exception.BlaBlaFishException;
import de.otto.blablafish_email.model.entity.EmailMigrationRequest;
import de.otto.blablafish_email.model.entity.EmailMigrationStatus;
import de.otto.blablafish_email.respository.EmailMigrationRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class EmailMigrationService {

  private final EmailMigrationRepository emailMigrationRepository;

  public EmailMigrationRequest getEmailMigrationRequest(String emailRequestId)
      throws BlaBlaFishException {
    return emailMigrationRepository
        .findById(emailRequestId)
        .orElseThrow(
            () ->
                new BlaBlaFishException(
                    String.format("EmailRequestId %s does not exist for Migration", emailRequestId),
                    BlaBlaFishError.EMAIL_MIGRATION_ERROR));
  }

  public boolean migrationRequestExists(String emailRequestId) {
    return emailMigrationRepository.exists(emailRequestId);
  }

  public void updateMigrationStatus(String mailRequestId, EmailMigrationStatus status) {
    emailMigrationRepository.saveEmailMigrationStatus(mailRequestId, status);
  }
}
