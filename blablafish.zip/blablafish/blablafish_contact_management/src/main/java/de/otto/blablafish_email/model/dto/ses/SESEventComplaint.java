package de.otto.blablafish_email.model.dto.ses;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.springframework.lang.NonNull;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@JsonIgnoreProperties(ignoreUnknown = true)
public class SESEventComplaint {

  @JsonFormat(
      shape = JsonFormat.Shape.STRING,
      pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSX",
      timezone = "UTC")
  @NonNull
  private Instant timestamp;

  private String feedbackId;

  private String complaintSubType;

  private List<Map<String, String>> complainedRecipients;

  private String userAgent;

  private String complaintFeedbackType;

  @JsonFormat(
      shape = JsonFormat.Shape.STRING,
      pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSX",
      timezone = "UTC")
  private Instant arrivalDate;
}
