package de.otto.blablafish_contact_management.model.dto;

import de.otto.blablafish_contact_management.model.entity.Topic;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.springframework.lang.NonNull;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TopicDTO {

  @NonNull private String id;

  @NonNull private String name;

  @NonNull private String description;

  private List<SubscriberDTO> subscribers;

  public static TopicDTO from(Topic topic, List<SubscriberDTO> subscriberDTOS) {
    return TopicDTO.builder()
        .id(String.valueOf(topic.getId()))
        .name(topic.getName())
        .description(topic.getDescription())
        .subscribers(subscriberDTOS)
        .build();
  }
}
