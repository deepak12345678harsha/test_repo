package de.otto.newsletter.model;

public enum JWTClaims {
  ACTION("action");

  private String claimName;

  public String getClaimName() {
    return this.claimName;
  }

  JWTClaims(String claimName) {
    this.claimName = claimName;
  }
}
