package de.otto.newsletter.repository;

import static org.springframework.data.mongodb.core.query.Criteria.where;

import de.otto.newsletter.model.entity.RSAKeyPair;
import java.util.Optional;
import org.bson.Document;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.BasicQuery;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

@Repository
public class RSAKeyPairRepository {

  private final MongoTemplate mongoTemplate;

  public RSAKeyPairRepository(MongoTemplate mongoTemplate) {
    this.mongoTemplate = mongoTemplate;
  }

  public Optional<RSAKeyPair> findByActiveSigningKey() {
    final BasicQuery basicQuery = new BasicQuery(new Document("isSigningKey", true));
    mongoTemplate.findAll(RSAKeyPair.class);
    return Optional.ofNullable(mongoTemplate.findOne(basicQuery, RSAKeyPair.class));
  }

  public Optional<RSAKeyPair> findActiveSigningKeyByKeyId(String kid) {
    Criteria criteriaDefinition = where("_id").is(kid).and("isSigningKey").is(true);
    Query query = Query.query(criteriaDefinition);
    return Optional.ofNullable(this.mongoTemplate.findOne(query, RSAKeyPair.class));
  }

  public void insert(RSAKeyPair rsaKeyPair) {
    this.mongoTemplate.insert(rsaKeyPair);
  }
}
