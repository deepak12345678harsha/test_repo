package de.otto.blablafish_contact_management.model.entity;

public enum UpdatedBy {
  EVENT,
  BLABLAFISH_UI;
}
