package de.otto.blablafish_email.respository;

import static de.otto.blablafish_email.model.entity.SESEvent.FIELD_AWS_MESSAGE_ID;

import de.otto.blablafish_email.model.entity.SESEvent;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;
import org.springframework.util.Assert;

@Slf4j
@Repository
public class SESEventRepository {

  private final MongoTemplate mongoTemplate;

  public SESEventRepository(MongoTemplate mongoTemplate) {
    this.mongoTemplate = mongoTemplate;
  }

  public void insert(SESEvent sesEvent) {
    log.info("Saving SESEvent with awsMessageId {}", sesEvent.getAwsMessageId());
    mongoTemplate.save(sesEvent);
  }

  public List<SESEvent> findByAWSMessageId(String awsMessageId) {
    Assert.notNull(awsMessageId, "Missing awsMessageId");
    log.info("Fetching ses events for aws message id: {}", awsMessageId);
    final var query = new Query(Criteria.where(FIELD_AWS_MESSAGE_ID).is(awsMessageId));
    return mongoTemplate.find(query, SESEvent.class);
  }

  public void saveAll(List<SESEvent> sesEvents) {
    mongoTemplate.insertAll(sesEvents);
  }

  public void deleteAll(List<SESEvent> sesEvents) {
    var sesEventIds = sesEvents.stream().map(SESEvent::getId).toList();
    mongoTemplate.findAllAndRemove(
        Query.query(Criteria.where(SESEvent.FIELD_ID).in(sesEventIds)), SESEvent.class);
  }
}
