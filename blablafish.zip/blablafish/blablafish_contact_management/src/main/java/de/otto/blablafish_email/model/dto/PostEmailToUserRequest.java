package de.otto.blablafish_email.model.dto;

import java.util.Map;
import java.util.Set;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@Getter
@NoArgsConstructor
@Builder
public class PostEmailToUserRequest {

  @NotBlank private String partnerId;

  @NotNull
  @Min(1)
  private Integer topicId;

  @NotNull private Map<String, Object> payload;

  @NotBlank private String firstName;

  @NotBlank private String lastName;

  @NotBlank private String toAddress;

  private Set<String> attachmentIds;
}
