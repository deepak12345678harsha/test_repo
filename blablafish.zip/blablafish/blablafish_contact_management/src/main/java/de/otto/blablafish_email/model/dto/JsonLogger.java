package de.otto.blablafish_email.model.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import org.springframework.lang.NonNull;

@AllArgsConstructor
@Getter
public class JsonLogger {
  @NonNull private String mailStatus;
  @NonNull private String statusTimestamp;
  @NonNull private String requestId;
  @NonNull private String topicId;
  @NonNull private String requestStatus;
}
