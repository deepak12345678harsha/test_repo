package de.otto.blablafish_contact_management.model.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ClusterTime {
  private Long T;
  private Long I;

  public static ClusterTime fromDTO(de.otto.blablafish_email.model.dto.ClusterTime clusterTimeDto) {
    return new ClusterTime(clusterTimeDto.getT(), clusterTimeDto.getI());
  }
}
