package de.otto.newsletter.model.dto;

public class EmarsysContactFields {

  public static final String KEY_ID = "key_id";
  public static final String KEY_VALUES = "keyValues";
  public static final String FIELDS = "fields";
  public static final String FIRSTNAME = "1";
  public static final String LASTNAME = "2";
  public static final String EMAIL = "3";
  public static final String USER_ID = "1530";
  public static final String PARTNER_ID = "1528";
  public static final String NEWSLETTER_UNSUBSCRIBE_KEY = "1531";
  public static final String COMMUNICATIONS_UNSUBSCRIBE_KEY = "1560";
  public static final String COMMUNICATIONS_OPT_IN = "1561";
  public static final String NEWSLETTER_OPT_IN = "31";
  public static final String ACCOUNT_STATUS = "1534";
  public static final String ROLES = "1555";

  private EmarsysContactFields() {
    throw new IllegalStateException("Utility class");
  }
}
