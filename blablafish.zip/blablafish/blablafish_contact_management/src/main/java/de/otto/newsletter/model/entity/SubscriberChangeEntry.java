package de.otto.newsletter.model.entity;

import de.otto.blablafish_contact_management.model.encryption.EncryptedDocument;
import de.otto.blablafish_contact_management.model.encryption.EncryptedField;
import java.time.Instant;
import javax.validation.constraints.NotNull;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.lang.NonNull;

@Document(collection = "subscriberChangeEntries")
@Builder(access = AccessLevel.PRIVATE)
@AllArgsConstructor
@Getter
public class SubscriberChangeEntry {
  @Id private ObjectId id;

  @NotNull private String subscriberId;

  @NotNull private SubscriberChangeEventType subscriberChangeEventType;

  private Instant subscriberChangeTime;

  @NotNull private Instant eventTime;

  @Indexed(expireAfterSeconds = 0)
  private Instant expiresAt;

  @NonNull private EncryptedField<org.bson.Document> event;

  public static EncryptedDocument encryptDocument(org.bson.Document document) {
    return new EncryptedDocument(document, "subscriberChangeEntries.event");
  }

  public static SubscriberChangeEntry of(
      String subscriberId,
      SubscriberChangeEventType subscriberChangeEventType,
      Instant subscriberChangeTime,
      Instant eventTime,
      Instant expiresAt,
      org.bson.Document document) {
    return SubscriberChangeEntry.builder()
        .id(new ObjectId())
        .subscriberId(subscriberId)
        .subscriberChangeEventType(subscriberChangeEventType)
        .subscriberChangeTime(subscriberChangeTime)
        .eventTime(eventTime)
        .expiresAt(expiresAt)
        .event(encryptDocument(document))
        .build();
  }

  @Override
  public String toString() {
    return "SubscriberChangeEntry{"
        + "subscriberId='"
        + subscriberId
        + '\''
        + ", subscriberChangeEventType="
        + subscriberChangeEventType
        + ", eventTime="
        + eventTime
        + '}';
  }
}
