package de.otto.blablafish_contact_management.model.entity;

import lombok.*;

@Getter
@Builder
@NoArgsConstructor
public class TopicOptions {
  public TopicOptions(
      @NonNull Boolean archiving,
      @NonNull Boolean displayOnEmailConfigUI,
      @NonNull Boolean canUnsubscribe,
      @NonNull Boolean isSubscribedByDefault,
      @NonNull Boolean displayOnContactManagementUI) {

    if (displayOnContactManagementUI && displayOnEmailConfigUI) {
      throw new IllegalArgumentException(
          "Invalid TopicOptions Configuration!! Cannot create topic with options having same value "
              + ": displayOnContactManagementUI, displayOnContactManagementUI");
    }
    this.archiving = archiving;
    this.displayOnEmailConfigUI = displayOnEmailConfigUI;
    this.canUnsubscribe = canUnsubscribe;
    this.isSubscribedByDefault = isSubscribedByDefault;
    this.displayOnContactManagementUI = displayOnContactManagementUI;
  }

  @NonNull private Boolean archiving;

  @NonNull private Boolean displayOnEmailConfigUI;

  @NonNull private Boolean canUnsubscribe;

  // TODO: verify if flag isSubscribedByDefault is used while sending emails
  @NonNull private Boolean isSubscribedByDefault;

  @NonNull private Boolean displayOnContactManagementUI;
}
