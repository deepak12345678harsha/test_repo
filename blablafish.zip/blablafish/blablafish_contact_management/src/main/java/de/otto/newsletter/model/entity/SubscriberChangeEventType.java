package de.otto.newsletter.model.entity;

import de.otto.blablafish_contact_management.model.entity.CommunicationSubscriptionStatus;
import de.otto.blablafish_contact_management.model.entity.NewsletterSubscriptionStatus;

public enum SubscriberChangeEventType {
  SUBSCRIBER_SUBSCRIBED_TO_NEWSLETTER,

  SUBSCRIBER_UNSUBSCRIBED_TO_NEWSLETTER,

  SUBSCRIBER_SUBSCRIBED_TO_COMMUNICATION,

  SUBSCRIBER_UNSUBSCRIBED_TO_COMMUNICATION;

  public static SubscriberChangeEventType from(NewsletterSubscriptionStatus status) {
    return switch (status) {
      case SUBSCRIBED -> SUBSCRIBER_SUBSCRIBED_TO_NEWSLETTER;
      case UNSUBSCRIBED -> SUBSCRIBER_UNSUBSCRIBED_TO_NEWSLETTER;
      default -> throw new IllegalArgumentException(
          "Unsupported NewsletterSubscriptionStatus state." + status);
    };
  }

  public static SubscriberChangeEventType from(CommunicationSubscriptionStatus status) {
    return switch (status) {
      case SUBSCRIBED -> SUBSCRIBER_SUBSCRIBED_TO_COMMUNICATION;
      case UNSUBSCRIBED -> SUBSCRIBER_UNSUBSCRIBED_TO_COMMUNICATION;
    };
  }
}
