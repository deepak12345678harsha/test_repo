package de.otto.blablafish_email.exception;

import de.otto.blablafish_contact_management.exception.BlaBlaFishError;
import de.otto.blablafish_contact_management.exception.BlaBlaFishException;

public class EmailNotFoundException extends BlaBlaFishException {

  public EmailNotFoundException(String message) {
    super(message, BlaBlaFishError.EMAIL_NOT_FOUND_ERROR);
  }
}
