package de.otto.blablafish_contact_management.model.dto;

import de.otto.blablafish_contact_management.model.entity.Topic;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NonNull;

@Getter
@AllArgsConstructor
public class EmailPreferenceDTO {

  @NonNull private Integer topicId;

  @NonNull private String name;

  @NonNull private String description;

  @NonNull private Boolean canUnsubscribe;

  private boolean optIn;

  public static EmailPreferenceDTO of(Topic topic, boolean optIn) {
    return new EmailPreferenceDTO(
        topic.getId(),
        topic.getName(),
        topic.getDescription(),
        topic.getOptions().getCanUnsubscribe(),
        optIn);
  }
}
