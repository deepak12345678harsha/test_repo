package de.otto.blablafish_contact_management.model.entity;

public enum CommunicationSubscriptionStatus {
  SUBSCRIBED,
  UNSUBSCRIBED;
}
