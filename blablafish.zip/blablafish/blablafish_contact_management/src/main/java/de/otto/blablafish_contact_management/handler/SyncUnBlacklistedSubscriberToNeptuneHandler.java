package de.otto.blablafish_contact_management.handler;

import de.otto.blablafish_contact_management.model.dto.EventType;
import de.otto.blablafish_contact_management.model.entity.Subscriber;
import de.otto.blablafish_email.model.dto.blacklist.EmailBlacklistNotice;
import de.otto.blablafish_email.publishers.SNSPublisher;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@RequiredArgsConstructor
@Component
public class SyncUnBlacklistedSubscriberToNeptuneHandler implements SubscriberActionHandler {

  private final SNSPublisher snsPublisher;

  @Override
  public Map<String, Object> handle(Subscriber user) {
    log.info("Received Action to Publish UnBlacklisted User to Neptune");
    snsPublisher.publish(
        new EmailBlacklistNotice(user.getUserId().toHexString()), EventType.EMAIL_UNBLACKLISTED);
    log.info("Successfully Published UnBlacklisted User to Neptune");
    return Map.of();
  }
}
