package de.otto.blablafish_email.exception;

import de.otto.blablafish_contact_management.exception.BlaBlaFishError;
import de.otto.blablafish_contact_management.exception.BlaBlaFishException;

public class FileUploadException extends BlaBlaFishException {
  public FileUploadException(String message) {
    super(message, BlaBlaFishError.FILE_UPLOAD_FAILED_ERROR);
  }
}
