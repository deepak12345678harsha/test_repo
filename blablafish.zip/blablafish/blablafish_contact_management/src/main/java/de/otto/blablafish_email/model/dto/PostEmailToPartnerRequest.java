package de.otto.blablafish_email.model.dto;

import java.util.Map;
import java.util.Set;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@Getter
@NoArgsConstructor
@Builder
public class PostEmailToPartnerRequest {

  @NotBlank private String partnerId;

  @Min(1)
  @NotNull
  private Integer topicId;

  @NotNull private Map<String, Object> payload;

  private Map<String, Object> internalPayload;

  private Set<String> attachmentIds;
}
