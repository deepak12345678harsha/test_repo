package de.otto.blablafish_contact_management.model.entity;

import de.otto.blablafish_contact_management.utils.Helper;
import java.time.Instant;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

/**
 * Information about an exception (name, message, and count) which was thrown during the execution
 * of an action
 */
@Getter
@AllArgsConstructor
@Builder
public class ActionError {
  private String errorName;
  private String errorMessage;
  private Integer errorCount;
  private String stackTrace;
  private Instant attemptedAt;

  public static ActionError of(Exception e) {
    return ActionError.builder()
        .errorName(e.getClass().getSimpleName())
        .errorMessage(e.getMessage())
        .stackTrace(Helper.stringifyStackTrace(e))
        .attemptedAt(Instant.now())
        .build();
  }
}
