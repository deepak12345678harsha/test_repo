package de.otto.newsletter.model.entity;

import de.otto.blablafish_contact_management.model.encryption.EncryptedField;
import de.otto.blablafish_contact_management.model.encryption.EncryptedString;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "rsaKeyPairs")
@AllArgsConstructor
@Getter
public class RSAKeyPair {

  @Id private String kid;

  private String publicKey;

  private EncryptedField<String> privateKey;

  private boolean isSigningKey;

  public static RSAKeyPair asSigningKey(String based64EncodedPublicKey, String privateKey) {
    return new RSAKeyPair(
        UUID.randomUUID().toString(), based64EncodedPublicKey, encryptPrivateKey(privateKey), true);
  }

  public static EncryptedString encryptPrivateKey(String privateKey) {
    return new EncryptedString(privateKey, "rsaKeypairs.privateKey", false);
  }
}
