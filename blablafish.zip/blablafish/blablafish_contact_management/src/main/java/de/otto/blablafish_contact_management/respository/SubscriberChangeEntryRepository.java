package de.otto.blablafish_contact_management.respository;

import static org.springframework.data.mongodb.core.query.Criteria.where;

import de.otto.newsletter.model.entity.SubscriberChangeEntry;
import de.otto.newsletter.model.entity.SubscriberChangeEventType;
import java.time.Instant;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

@Slf4j
@Repository
public class SubscriberChangeEntryRepository {

  private final MongoTemplate mongoTemplate;

  public SubscriberChangeEntryRepository(MongoTemplate mongoTemplate) {
    this.mongoTemplate = mongoTemplate;
  }

  public void insert(SubscriberChangeEntry subscriberChangeEntry) {
    mongoTemplate.insert(subscriberChangeEntry);
    log.info("SUBSCRIBER_CHANGE_ENTRY: Added new entry {}", subscriberChangeEntry);
  }

  public boolean exists(
      String subscriberId,
      SubscriberChangeEventType subscriberChangeEventType,
      Instant subscriberChangeTime) {
    Criteria criteriaDefinition =
        where("subscriberId")
            .is(subscriberId)
            .and("subscriberChangeEventType")
            .is(subscriberChangeEventType)
            .and("subscriberChangeTime")
            .is(subscriberChangeTime);
    Query query = Query.query(criteriaDefinition);
    return !mongoTemplate.find(query, SubscriberChangeEntry.class).isEmpty();
  }
}
