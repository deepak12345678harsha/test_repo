package de.otto.blablafish_contact_management.handler;

import de.otto.blablafish_contact_management.exception.SubscriberDoesNotExistException;
import de.otto.blablafish_contact_management.model.entity.Subscriber;
import de.otto.newsletter.exception.EmarsysConnectionFailedException;
import de.otto.newsletter.service.EmarsysService;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@RequiredArgsConstructor
@Component
public class SyncSubscriberDataToEmarsysHandler implements SubscriberActionHandler {

  private final EmarsysService emarsysService;

  @Override
  public Map<String, Object> handle(Subscriber subscriber) {

    try {
      var markedForDeletion = subscriber.getMarkedForDeletion();
      var subscriberId = subscriber.getUserId().toString();
      if (subscriber.isAnActiveCooperationSubscriber()
          && (markedForDeletion == null || !markedForDeletion)) {
        emarsysService.updateOrCreateContact(subscriberId);
      } else {
        emarsysService.deleteContact(subscriberId);
      }
      return Map.of();
    } catch (EmarsysConnectionFailedException | SubscriberDoesNotExistException e) {
      throw new RuntimeException(e);
    }
  }
}
