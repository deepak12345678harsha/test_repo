package de.otto.blablafish_email.model.entity;

import io.jsonwebtoken.lang.Assert;
import java.time.Instant;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import org.springframework.lang.NonNull;

@AllArgsConstructor
@Getter
@Builder(access = AccessLevel.PRIVATE)
public class EmailBlackListReason {

  @NonNull private EmailBlackListReasonSourceType sourceType;

  private String awsMessageId;

  private String description;

  @NonNull private Instant timestamp;

  public static EmailBlackListReason ofSESEvent(String awsMessageId, String description) {
    Assert.hasText(awsMessageId, "Missing sesEventId.");
    Assert.hasText(description, "Missing description.");
    return EmailBlackListReason.builder()
        .sourceType(EmailBlackListReasonSourceType.SES_EVENT)
        .awsMessageId(awsMessageId)
        .description(description)
        .timestamp(Instant.now())
        .build();
  }
}
