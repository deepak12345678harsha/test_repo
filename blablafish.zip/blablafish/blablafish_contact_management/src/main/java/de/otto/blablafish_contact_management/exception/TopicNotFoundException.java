package de.otto.blablafish_contact_management.exception;

public class TopicNotFoundException extends Exception {
  public TopicNotFoundException(String message) {
    super(message);
  }
}
