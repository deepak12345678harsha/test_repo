package de.otto.blablafish_email.model.entity;

import de.otto.blablafish_contact_management.model.encryption.EncryptedField;
import de.otto.blablafish_contact_management.model.encryption.EncryptedString;
import de.otto.blablafish_email.model.dto.EmailAttachmentDTO;
import java.time.Instant;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.lang.NonNull;

@AllArgsConstructor
@Getter
@Builder
@Document(collection = "mailAttachments")
public class EmailAttachment {

  private static final String KEY_FILE_NAME = "mailAttachments.fileName";

  @Id private String id;

  @NonNull private String s3BucketName;

  private String oldS3BucketName;

  @NonNull private String s3UploadKey;

  private String oldS3UploadKey;

  @NonNull private EncryptedField<String> fileName;

  @NonNull private String contentType;

  @NonNull private Long fileSizeInBytes;

  @NonNull private String clientId;

  @NonNull private String subject;

  @NonNull private Instant createdAt;

  public static EmailAttachment of(
      String s3BucketName, String s3UploadKey, EmailAttachmentDTO emailAttachmentDTO) {
    return EmailAttachment.builder()
        .id(emailAttachmentDTO.getAttachmentId())
        .fileName(encryptFileName(emailAttachmentDTO.getFileName()))
        .contentType(emailAttachmentDTO.getContentType())
        .fileSizeInBytes(emailAttachmentDTO.getFileSizeInBytes())
        .s3BucketName(s3BucketName)
        .oldS3BucketName(emailAttachmentDTO.getS3BucketName())
        .s3UploadKey(s3UploadKey)
        .oldS3UploadKey(emailAttachmentDTO.getS3UploadKey())
        .createdAt(emailAttachmentDTO.getCreatedAt())
        .clientId(emailAttachmentDTO.getClientId())
        .subject(emailAttachmentDTO.getSubject())
        .build();
  }

  public static EncryptedField<String> encryptFileName(String fileName) {
    return new EncryptedString(fileName, KEY_FILE_NAME, false);
  }
}
