package de.otto.blablafish_contact_management.handler;

import de.otto.blablafish_contact_management.model.Actions;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@RequiredArgsConstructor
@Component
public class ActionHandlerFactory {

  private final SyncSubscriberDataToEmarsysHandler syncSubscriberDataToEmarsysHandler;
  private final SyncUnBlacklistedSubscriberToNeptuneHandler
      syncUnBlacklistedSubscriberToNeptuneHandler;
  private final RemoveEmailFromSESSuppressionListHandler removeEmailFromSESSuppressionListHandler;

  public SubscriberActionHandler handlerFor(Actions action) {
    return switch (action) {
      case SYNC_USER_DATA_TO_EMARSYS -> syncSubscriberDataToEmarsysHandler;
      case SEND_UNBLACKLIST_EVENT_TO_NEPTUNE -> syncUnBlacklistedSubscriberToNeptuneHandler;
      case REMOVE_EMAIL_FROM_SES_SUPPRESSION_LIST -> removeEmailFromSESSuppressionListHandler;
      default -> throw new UnsupportedOperationException("No handler for action: " + action);
    };
  }
}
