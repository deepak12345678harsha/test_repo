package de.otto.blablafish_email.exception;

import de.otto.blablafish_contact_management.exception.BlaBlaFishError;
import de.otto.blablafish_contact_management.exception.BlaBlaFishException;
import java.util.List;
import lombok.Getter;

@Getter
public class MultiPartnerEmailException extends BlaBlaFishException {

  private final List<String> errorMessages;

  public MultiPartnerEmailException(String message, List<String> errorMessages) {
    super(message, BlaBlaFishError.MULTI_PARTNER_EMAIL_REQUEST_FAILED);
    this.errorMessages = errorMessages;
  }
}
