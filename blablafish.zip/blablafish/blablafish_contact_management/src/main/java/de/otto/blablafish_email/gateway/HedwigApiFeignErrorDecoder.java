package de.otto.blablafish_email.gateway;

import static de.otto.blablafish_email.gateway.InternalApiGatewayClient.INTERNAL_API_ACCESS_TOKEN_CACHE_NAME;

import feign.Response;
import feign.RetryableException;
import feign.codec.ErrorDecoder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.CacheManager;
import org.springframework.http.HttpStatus;

@Slf4j
public class HedwigApiFeignErrorDecoder implements ErrorDecoder {

  private final CacheManager cacheManager;
  private final ErrorDecoder defaultErrorDecoder;

  public HedwigApiFeignErrorDecoder(CacheManager cacheManager) {
    this.cacheManager = cacheManager;
    defaultErrorDecoder = new Default();
  }

  @Override
  public Exception decode(String methodKey, Response response) {
    var responseStatus = HttpStatus.valueOf(response.status());
    if (HttpStatus.UNAUTHORIZED.equals(responseStatus)) {
      log.info("Token Expired, Clearing cache: {}", INTERNAL_API_ACCESS_TOKEN_CACHE_NAME);
      cacheManager.getCache(INTERNAL_API_ACCESS_TOKEN_CACHE_NAME).clear();
    }
    if (responseStatus.is5xxServerError() || responseStatus.is4xxClientError()) {
      log.error(
          "An error occurred while invoking API : Status {} |  reason : {} | request detail:  {}",
          responseStatus,
          response.reason(),
          getRequestLogs(response));

      return new RetryableException(
          responseStatus.value(),
          response.reason(),
          response.request().httpMethod(),
          null,
          response.request());
    }
    return defaultErrorDecoder.decode(methodKey, response);
  }

  private String getRequestLogs(Response response) {
    return String.format("%s %s", response.request().httpMethod(), response.request().url());
  }
}
