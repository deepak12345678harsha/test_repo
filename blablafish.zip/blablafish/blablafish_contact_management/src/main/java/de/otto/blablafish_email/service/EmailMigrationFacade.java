package de.otto.blablafish_email.service;

import static java.util.Objects.isNull;

import de.otto.blablafish_contact_management.exception.BlaBlaFishException;
import de.otto.blablafish_email.gateway.HedwigMailRequestsApiGatewayClient;
import de.otto.blablafish_email.model.dto.mail.EmailDTO;
import de.otto.blablafish_email.model.dto.mail.HedwigEmailRequestDTO;
import de.otto.blablafish_email.model.entity.Email;
import de.otto.blablafish_email.model.entity.EmailMigrationStatus;
import de.otto.blablafish_email.model.entity.EmailRecipient;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class EmailMigrationFacade {

  private final HedwigMailRequestsApiGatewayClient hedwigApiGatewayClient;
  private final EmailMigrationService emailMigrationService;
  private final EmailRequestService emailRequestService;
  private final EmailService emailService;
  private final SESEventService sesEventService;

  public void processEmailMigrationRequest(String emailRequestId) throws BlaBlaFishException {
    var emailMigrationRequest = emailMigrationService.getEmailMigrationRequest(emailRequestId);
    if (EmailMigrationStatus.PROCESSED.equals(emailMigrationRequest.getStatus())) {
      log.info("Skipping Email migration request as it is already Processed.");
      return;
    }

    migrateEmailRequest(emailRequestId);
    var awsMessageIds = migrateEmail(emailRequestId);
    migrateSesEvents(awsMessageIds, emailRequestId);
    emailMigrationService.updateMigrationStatus(emailRequestId, EmailMigrationStatus.PROCESSED);
  }

  private void migrateEmailRequest(String emailRequestId) {
    log.info("----Migration of Email Request started for emailRequestId: {}", emailRequestId);
    var hedwigMailRequest = hedwigApiGatewayClient.getMailRequest(emailRequestId);
    var emailRequest = HedwigEmailRequestDTO.toEmailRequest(hedwigMailRequest, emailRequestId);
    emailRequestService.insertEmailRequest(emailRequest);
    log.info("----Migration of Email Request completed for emailRequestId: {}", emailRequestId);
  }

  private List<String> migrateEmail(String emailRequestId) {
    var emailRequest = emailRequestService.getRequestById(emailRequestId);
    var mailIds = emailRequest.getRecipients().stream().map(EmailRecipient::getEmailId).toList();
    log.info("Migration started for emailIds: {}", mailIds);
    var emailsToSave =
        mailIds.stream().map(hedwigApiGatewayClient::getMail).map(EmailDTO::toEmail).toList();
    emailService.saveAll(emailsToSave);
    log.info("Migration completed for emailIds: {}", mailIds);
    return emailsToSave.stream().map(Email::getAwsMessageId).filter(Objects::nonNull).toList();
  }

  private void migrateSesEvents(List<String> awsMessageIds, String emailRequestId) {
    log.info("Migration started for SESEvents with awsMessageIds: {}", awsMessageIds);
    var sesEvents =
        awsMessageIds.stream()
            .map(hedwigApiGatewayClient::getSESEvents)
            .flatMap(Collection::stream)
            .map(
                dto -> {
                  if (isNull(dto.getMailRequestId())) {
                    log.info(
                        "EmailRequestId is null for SESEventId: {} , it will be updated with EmailRequestId: {}",
                        dto.getId(),
                        emailRequestId);
                  }
                  return dto.toSESEvent(emailRequestId);
                })
            .toList();
    sesEventService.saveAll(sesEvents);
    log.info("Migration completed for SESEvents with awsMessageIds: {}", awsMessageIds);
  }
}
