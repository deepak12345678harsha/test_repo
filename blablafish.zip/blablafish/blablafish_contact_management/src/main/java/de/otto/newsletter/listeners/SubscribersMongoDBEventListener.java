package de.otto.newsletter.listeners;

import static de.otto.blablafish_email.utils.Constants.EVENT_ID;
import static de.otto.blablafish_email.utils.Constants.EVENT_LABEL;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import de.otto.blablafish_contact_management.handler.SubscriberChangedEventHandler;
import de.otto.blablafish_email.model.dto.MongoDbTriggerEvent;
import io.awspring.cloud.messaging.listener.SqsMessageDeletionPolicy;
import io.awspring.cloud.messaging.listener.annotation.SqsListener;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.jboss.logging.MDC;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class SubscribersMongoDBEventListener {
  private final ObjectMapper objectMapper;
  private final SubscriberChangedEventHandler subscriberChangedEventHandler;

  @SqsListener(
      value = "${mongoDbTrigger.subscribers.changeEvents.queueUrl}",
      deletionPolicy = SqsMessageDeletionPolicy.ON_SUCCESS)
  public void listenToSubscribersMongoDbTriggersForChangeHistory(String mongoTriggerJsonAsString) {
    try {
      final MongoDbTriggerEvent event =
          objectMapper.readValue(mongoTriggerJsonAsString, MongoDbTriggerEvent.class);
      var subscriberId = event.getDetail().getDocumentKey().get_id();
      MDC.put(EVENT_LABEL, "HANDLE_SUBSCRIBER_CHANGE_ENTRY");
      MDC.put(EVENT_ID, event.getId());
      MDC.put("subscriberId", subscriberId);
      log.info("MongoDB trigger event received for Subscriber : {}", subscriberId);
      subscriberChangedEventHandler.handleEvent(mongoTriggerJsonAsString, event, subscriberId);
    } catch (JsonProcessingException | RuntimeException e) {
      log.error(
          "Failed to process MongoDB trigger event - SUBSCRIBER_CHANGE_ENTRY : {}",
          e.getMessage(),
          e);
      throw new RuntimeException(
          String.format("An error occurred for SUBSCRIBER_CHANGE_ENTRY : %s", e.getMessage()));
    } finally {
      MDC.remove(EVENT_LABEL);
      MDC.remove(EVENT_ID);
      MDC.remove("subscriberId");
    }
  }
}
