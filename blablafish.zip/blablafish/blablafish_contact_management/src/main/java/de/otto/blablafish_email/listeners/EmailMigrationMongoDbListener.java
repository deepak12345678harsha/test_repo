package de.otto.blablafish_email.listeners;

import static de.otto.blablafish_email.utils.Constants.EVENT_ID;
import static de.otto.blablafish_email.utils.Constants.EVENT_LABEL;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import de.otto.blablafish_contact_management.exception.BlaBlaFishException;
import de.otto.blablafish_email.model.dto.MongoDbTriggerEvent;
import de.otto.blablafish_email.service.EmailMigrationFacade;
import io.awspring.cloud.messaging.listener.SqsMessageDeletionPolicy;
import io.awspring.cloud.messaging.listener.annotation.SqsListener;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.jboss.logging.MDC;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class EmailMigrationMongoDbListener {

  private static final String MAIL_REQUEST_ID = "mailRequestId";
  private static final String EVENT_LABEL_EMAIL_MIGRATION = "MAIL_MIGRATION";
  private final ObjectMapper objectMapper;

  private final EmailMigrationFacade emailMigrationFacade;

  @SqsListener(
      value = "${mongoDbTrigger.mails.migration.queueUrl}",
      deletionPolicy = SqsMessageDeletionPolicy.ON_SUCCESS)
  public void emailMigrationEventListener(String mongoTriggerMessage)
      throws BlaBlaFishException, JsonProcessingException {

    try {
      final MongoDbTriggerEvent event =
          objectMapper.readValue(mongoTriggerMessage, MongoDbTriggerEvent.class);
      var emailRequestId = event.getDetail().getDocumentKey().get_id();
      MDC.put(EVENT_LABEL, EVENT_LABEL_EMAIL_MIGRATION);
      MDC.put(EVENT_ID, event.getId());
      MDC.put(MAIL_REQUEST_ID, emailRequestId);
      log.info("Mail Migration event received for emailRequestId: {}", emailRequestId);
      emailMigrationFacade.processEmailMigrationRequest(emailRequestId);
      log.info("Mail Migration completed for emailRequestId: {}", emailRequestId);
    } catch (JsonProcessingException | BlaBlaFishException e) {
      log.error("An error occurred while email migration | message:  {}", e.getMessage());
      throw e;
    } finally {
      MDC.clear();
    }
  }
}
