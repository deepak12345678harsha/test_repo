package de.otto.blablafish_contact_management.config;

import org.togglz.core.Feature;
import org.togglz.core.annotation.Label;

public enum Features implements Feature {
  @Label("Exclude Contact Management from Response URI header")
  EXCLUDE_CONTACT_MANAGEMENT_IN_RESPONSE_URI_HEADER;

  public boolean isInActive() {
    return !isActive();
  }
}
