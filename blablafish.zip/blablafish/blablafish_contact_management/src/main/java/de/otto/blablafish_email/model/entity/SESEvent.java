package de.otto.blablafish_email.model.entity;

import de.otto.blablafish_contact_management.model.encryption.EncryptedDocument;
import de.otto.blablafish_contact_management.model.encryption.EncryptedField;
import de.otto.blablafish_email.model.dto.ses.SESEventType;
import java.time.Instant;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.lang.NonNull;

@AllArgsConstructor
@Getter
@Document(collection = "sesEvents")
@Builder
public class SESEvent {

  public static final String FIELD_ID = "id";

  public static final String FIELD_AWS_MESSAGE_ID = "awsMessageId";

  @Id private ObjectId id;

  @NonNull private String eventType;

  @Indexed @NonNull private String awsMessageId;

  @NonNull private EncryptedField<org.bson.Document> body;

  @NonNull private Instant createdAt;

  @NonNull private ObjectId mailRequestId;

  public static EncryptedField<org.bson.Document> encryptedBody(org.bson.Document body) {
    return new EncryptedDocument(body, "sesEvents.body");
  }

  public static SESEvent of(
      SESEventType eventType, String awsMessageId, ObjectId mailRequestId, org.bson.Document body) {
    return SESEvent.builder()
        .id(new ObjectId())
        .eventType(eventType.name())
        .awsMessageId(awsMessageId)
        .body(SESEvent.encryptedBody(body))
        .createdAt(Instant.now())
        .mailRequestId(mailRequestId)
        .build();
  }
}
