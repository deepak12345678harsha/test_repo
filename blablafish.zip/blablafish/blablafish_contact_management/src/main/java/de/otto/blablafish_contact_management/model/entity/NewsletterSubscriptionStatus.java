package de.otto.blablafish_contact_management.model.entity;

public enum NewsletterSubscriptionStatus {
  SUBSCRIBED,
  UNSUBSCRIBED,
  AWAITING_PERMISSION;

  public static boolean statusOf(NewsletterSubscriptionStatus status) {
    return SUBSCRIBED.equals(status);
  }

  public static NewsletterSubscriptionStatus statusFrom(boolean isSubscribed) {
    return isSubscribed ? SUBSCRIBED : UNSUBSCRIBED;
  }
}
