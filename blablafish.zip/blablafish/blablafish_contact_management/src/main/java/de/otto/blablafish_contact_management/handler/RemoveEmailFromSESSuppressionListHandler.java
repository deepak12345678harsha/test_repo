package de.otto.blablafish_contact_management.handler;

import com.amazonaws.services.simpleemailv2.AmazonSimpleEmailServiceV2;
import com.amazonaws.services.simpleemailv2.model.DeleteSuppressedDestinationRequest;
import com.amazonaws.services.simpleemailv2.model.NotFoundException;
import de.otto.blablafish_contact_management.model.entity.Subscriber;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

@Slf4j
@RequiredArgsConstructor
@Component
public class RemoveEmailFromSESSuppressionListHandler implements SubscriberActionHandler {

  private final AmazonSimpleEmailServiceV2 sesClient;

  @Override
  public Map<String, Object> handle(Subscriber user) {
    var userId = user.getUserId().toHexString();
    log.info("Received request to remove email suppression for user: {}", userId);

    var deleteSuppressionRequest =
        new DeleteSuppressedDestinationRequest().withEmailAddress(user.getEmail().getValue());

    try {
      var deleteSuppressionResult = sesClient.deleteSuppressedDestination(deleteSuppressionRequest);

      var statusCode = deleteSuppressionResult.getSdkHttpMetadata().getHttpStatusCode();
      var httpStatus = HttpStatus.valueOf(statusCode);
      if (httpStatus.is2xxSuccessful()) {
        log.info("Successfully removed user {} from suppression list.", userId);
        return Map.of();
      } else {
        throw new RuntimeException(
            String.format(
                "Error in removing user %s from suppression list. Request failed with HttpStatus: %s",
                userId, HttpStatus.resolve(httpStatus.value())));
      }
    } catch (NotFoundException e) {
      log.info("Email Address for user {} not found in suppression list.", userId);
      return Map.of();
    } catch (Exception e) {
      log.error(e.getMessage());
      throw e;
    }
  }
}
