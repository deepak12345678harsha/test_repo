package de.otto.blablafish_contact_management.listeners;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import de.otto.blablafish_contact_management.service.ChangeEventService;
import de.otto.blablafish_email.model.dto.MongoDbTriggerEvent;
import io.awspring.cloud.messaging.listener.SqsMessageDeletionPolicy;
import io.awspring.cloud.messaging.listener.annotation.SqsListener;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class MongoDBChangeEventsListener {
  private final ObjectMapper objectMapper;

  private final ChangeEventService changeEventService;

  public MongoDBChangeEventsListener(
      ObjectMapper objectMapper, ChangeEventService changeEventService) {
    this.objectMapper = objectMapper;
    this.changeEventService = changeEventService;
  }

  @SqsListener(
      value = "${mongoDbTrigger.changeEvents.queueUrl}",
      deletionPolicy = SqsMessageDeletionPolicy.ON_SUCCESS)
  public void listenToMongoDbChangeEvents(String mongoTriggerJsonAsString) {
    try {
      final MongoDbTriggerEvent event =
          objectMapper.readValue(mongoTriggerJsonAsString, MongoDbTriggerEvent.class);
      String documentId = event.getDetail().getDocumentKey().get_id();
      log.info(
          "MongoDB ChangeEvent received for collection : {} and documentId: {} ",
          event.getDetail().getNs().getColl(),
          documentId);
      changeEventService.handleEvent(event, mongoTriggerJsonAsString);
      log.info("Change Event saved for documentId : {}", documentId);

    } catch (JsonProcessingException | RuntimeException e) {
      log.error("Failed to process MongoDB trigger event : {}", e.getMessage(), e);
    }
  }
}
