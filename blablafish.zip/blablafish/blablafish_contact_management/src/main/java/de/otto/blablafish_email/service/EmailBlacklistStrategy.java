package de.otto.blablafish_email.service;

import static de.otto.blablafish_email.model.entity.EmailStatus.AWS_BOUNCE;
import static de.otto.blablafish_email.model.entity.EmailStatus.AWS_COMPLAINT;

import de.otto.blablafish_email.model.dto.ses.SESEventMessageDTO;
import de.otto.blablafish_email.model.entity.EmailStatus;
import org.springframework.stereotype.Service;

@Service
public class EmailBlacklistStrategy {
  public boolean shouldBlacklistEmail(SESEventMessageDTO sesEventDTO, EmailStatus status) {
    if (status == AWS_COMPLAINT) return true;
    if (status == AWS_BOUNCE) {
      return !sesEventDTO.isTypeSoftBounce();
    }
    return false;
  }
}
