package de.otto.blablafish_contact_management.config;

import de.otto.blablafish_contact_management.filters.JWTAuthenticationFilter;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
@EnableWebSecurity
@ConditionalOnProperty(name = "integrationtest.enabled", havingValue = "false")
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

  private final URL jwkUrl;
  private final URL jwkUrlInternal;
  private final String username;
  private final String password;

  @Autowired private PasswordEncoder passwordEncoder;

  public WebSecurityConfig(
      @Value("${jwk-url}") String jwkUrlAsString,
      @Value("${jwk-url-internal}") String jwkUrlInternalAsString,
      @Value("${togglz.console.username}") String username,
      @Value("${togglz.console.password}") String password) {
    try {
      this.jwkUrl = new URL(jwkUrlAsString);
      this.jwkUrlInternal = new URL(jwkUrlInternalAsString);
      this.username = username;
      this.password = password;
    } catch (MalformedURLException e) {
      throw new RuntimeException("Missing valid JWK URL.", e);
    }
  }

  @Autowired
  public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
    auth.inMemoryAuthentication()
        .withUser(username)
        .password(passwordEncoder.encode(password))
        .roles("USER");
  }

  @Override
  public void configure(HttpSecurity http) throws Exception {
    http.csrf()
        .disable()
        .authorizeRequests()
        .antMatchers("/health", "/info", "/v1/newsletter-unsubscription")
        .permitAll()
        .and()
        .authorizeRequests()
        .antMatchers("/toggles-console/**")
        .authenticated()
        .and()
        .httpBasic()
        .and()
        .addFilter(
            new JWTAuthenticationFilter(authenticationManager(), Set.of(jwkUrl, jwkUrlInternal)));
  }
}
