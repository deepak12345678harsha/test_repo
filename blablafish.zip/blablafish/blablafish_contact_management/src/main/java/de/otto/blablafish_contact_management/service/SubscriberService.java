package de.otto.blablafish_contact_management.service;

import static de.otto.blablafish_contact_management.model.Actions.SYNC_USER_DATA_TO_EMARSYS;
import static de.otto.blablafish_contact_management.model.entity.NewsletterSubscriptionStatus.statusFrom;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import de.otto.blablafish_contact_management.exception.BlaBlaFishError;
import de.otto.blablafish_contact_management.exception.BlaBlaFishException;
import de.otto.blablafish_contact_management.exception.SubscriberDoesNotExistException;
import de.otto.blablafish_contact_management.exception.TopicNotFoundException;
import de.otto.blablafish_contact_management.model.dto.SubscriberDTO;
import de.otto.blablafish_contact_management.model.dto.UserPrincipal;
import de.otto.blablafish_contact_management.model.entity.EmailPreference;
import de.otto.blablafish_contact_management.model.entity.NewsletterSubscription;
import de.otto.blablafish_contact_management.model.entity.NewsletterSubscriptionStatus;
import de.otto.blablafish_contact_management.model.entity.Requester;
import de.otto.blablafish_contact_management.model.entity.Subscriber;
import de.otto.blablafish_contact_management.model.entity.Topic;
import de.otto.blablafish_contact_management.respository.SubscriberChangeEntryRepository;
import de.otto.blablafish_contact_management.respository.SubscriberRepository;
import de.otto.blablafish_email.exception.EmailNotProcessableException;
import de.otto.blablafish_email.model.dto.ClusterTime;
import de.otto.blablafish_email.model.dto.DocumentKey;
import de.otto.blablafish_email.model.dto.MongoDbTriggerEvent;
import de.otto.blablafish_email.model.dto.MongoDbTriggerEventDetail;
import de.otto.blablafish_email.model.dto.MongoNamespace;
import de.otto.blablafish_email.model.dto.SplunkOperationCode;
import de.otto.blablafish_email.model.dto.UpdateDescription;
import de.otto.blablafish_email.model.entity.EmailBlacklist;
import de.otto.blablafish_email.respository.EmailBlacklistRepository;
import de.otto.newsletter.model.entity.SubscriberChangeEntry;
import de.otto.newsletter.model.entity.SubscriberChangeEventType;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.jboss.logging.MDC;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

@Service
@Slf4j
public class SubscriberService {

  private static final int EXPIRATION_TIME_IN_DAYS = 4 * 365;
  private final TopicService topicService;
  private final SubscriberRepository subscriberRepository;
  private final EmailBlacklistRepository blacklistRepository;
  private final Boolean setDefaultTopicsForAdminOnUserSet;
  private final String contactManagementWriteRole;
  private final SubscriberChangeEntryRepository subscriberChangeEntryRepository;
  private final EmailPreferenceService emailPreferenceService;
  private final ObjectMapper objectMapper;

  public SubscriberService(
      SubscriberRepository subscriberRepository,
      @Value("${contactManagementWriteRole}") String contactManagementWriteRole,
      @Value("${featureToggles.setDefaultTopicsForAdminOnUSER_SET}")
          Boolean setDefaultTopicsForAdminOnUserSet,
      TopicService topicService,
      EmailBlacklistRepository blacklistRepository,
      SubscriberChangeEntryRepository subscriberChangeEntryRepository,
      EmailPreferenceService emailPreferenceService,
      ObjectMapper objectMapper) {
    this.subscriberRepository = subscriberRepository;
    this.contactManagementWriteRole = contactManagementWriteRole;
    this.setDefaultTopicsForAdminOnUserSet = setDefaultTopicsForAdminOnUserSet;
    this.topicService = topicService;
    this.blacklistRepository = blacklistRepository;
    this.subscriberChangeEntryRepository = subscriberChangeEntryRepository;
    this.emailPreferenceService = emailPreferenceService;
    this.objectMapper = objectMapper;
  }

  public void handleUserSetEvent(Subscriber subscriber) throws SubscriberDoesNotExistException {
    log.info("Saving subscriber details: " + subscriber.getUserId());
    // TODO: fetch subscriber if exists and check eventTime is older than one to update
    subscriberRepository.upsert(subscriber);
    if (Boolean.TRUE.equals(setDefaultTopicsForAdminOnUserSet)
        && subscriber.isAdmin(contactManagementWriteRole)) {
      log.info("Setting default topics for admin");
      Subscriber savedSubscriber = getSubscriberById(subscriber.getUserId().toHexString());
      if (savedSubscriber.hasTopics()) {
        log.info("Already subscribed to some topics for admin: " + subscriber.getUserId());
        return;
      }
      log.info("Saving Default topics for admin: " + subscriber.getUserId());
      List<Topic> topics =
          topicService.findAllByMandatorySubscriberRole(contactManagementWriteRole);
      List<Integer> topicIds = topics.stream().map(Topic::getId).toList();

      subscriberRepository.subscribeUserToTopics(subscriber.getUserId(), topicIds);
    }
  }

  public void handleUserDeletedEvent(String subscriberId, Requester requester)
      throws SubscriberDoesNotExistException, JsonProcessingException {
    final Subscriber subscriber = getSubscriberById(subscriberId);
    log.info(
        "Fetched subscriber with id: "
            + subscriberId
            + " has-topics: "
            + subscriber.hasTopics()
            + "get-topics: "
            + subscriber.getTopicIds());
    final List<Integer> topicIds = getTopicIdsIfLastUser(subscriber);
    if (!topicIds.isEmpty()) {
      var topics = topicService.getTopics(topicIds);
      loggingForDeletingLastUserDeleteEvent(topics);
      subscriberRepository.subscribeAllAdmins(
          topicIds, contactManagementWriteRole, subscriber.getPartnerId(), requester);
    }
    subscriberRepository.markForDeletion(
        new ObjectId(subscriberId), List.of(SYNC_USER_DATA_TO_EMARSYS), requester);
  }

  private void loggingForDeletingLastUserDeleteEvent(Set<Topic> topics)
      throws JsonProcessingException {
    Map<String, Object> detailsLogging = new HashMap<>();
    detailsLogging.put(
        "operationCode",
        List.of(SplunkOperationCode.DELETE_EVENT_TO_REMOVE_TOPIC_LAST_SUBSCRIBER.getCode()));
    MDC.put("details", objectMapper.writeValueAsString(detailsLogging));
    for (Topic topic : topics) {
      MDC.put("topicName", topic.getName());
      log.info("Last user of topic is getting deleted by USER_DELETED Event for the topic");
      MDC.remove("topicName");
    }
    MDC.remove("details");
  }

  public List<SubscriberDTO> getAllUsersByEmailAndPartner(
      String partnerId, String emailSearchString) {
    log.info("Get the list of users for the partner {}", partnerId);
    List<Subscriber> subscribers;
    if (emailSearchString != null) {
      log.info("Get the list of users by search for the partner {}", partnerId);
      subscribers = subscriberRepository.findAllByEmailAndPartner(emailSearchString, partnerId);
    } else {
      subscribers = subscriberRepository.findAllByPartner(partnerId);
    }
    return subscribers.stream().map(SubscriberDTO::from).toList();
  }

  public Optional<Subscriber> getUserByEmail(String email) {
    log.info("Get user details by the email");
    Assert.hasText(email, "Missing email.");
    return subscriberRepository.findByEmail(email);
  }

  public Requester requesterOf(UserPrincipal userPrincipal, String userAgent)
      throws SubscriberDoesNotExistException {
    log.info("building Requester instance from email id");
    return Requester.of(
        getUserByEmail(userPrincipal.getUserName())
            .orElseThrow(() -> new SubscriberDoesNotExistException("Subscriber does not exists"))
            .getUserId(),
        userPrincipal.getPartnerId(),
        userAgent);
  }

  public List<Subscriber> findAllByEmails(Set<String> emailAddresses) {
    return subscriberRepository.findAllByEmail(
        emailAddresses.stream().map(Subscriber::encryptEmail).collect(Collectors.toSet()));
  }

  public void unSubscribe(String subscriberId, Integer topicId, Requester requester)
      throws TopicNotFoundException, SubscriberDoesNotExistException, BlaBlaFishException {
    Topic topic = topicService.findByTopicId(topicId);
    Subscriber subscriber = getSubscriberById(subscriberId);

    if (subscriber.hasTopic(topicId)) {
      validateIfLastUserIsBeingUnsubscribe(subscriber, topic);
      subscriberRepository.unsubscribeSubscriberFromTopic(
          subscriber.getUserId(), topicId, requester);
      MDC.put("topicId", topicId);
      log.info("User unsubscribed successfully");
      MDC.remove("topicId");
    }
  }

  public List<Subscriber> getSubscribersByValidatingRolesAndPreferences(
      String partnerId, Topic topic) throws EmailNotProcessableException {
    List<Subscriber> subscribers = getSubscribersWithValidRoles(partnerId, topic);
    return getSubscribersWithValidPreferences(topic.getId(), subscribers);
  }

  private List<Subscriber> getSubscribersWithValidRoles(String partnerId, Topic topic)
      throws EmailNotProcessableException {
    List<Subscriber> subscribers;
    if (topic.shouldDisplayOnContactManagementUI()) {
      subscribers = getSubscribersByPartnerAndTopic(partnerId, topic.getId());
    } else {
      subscribers =
          getSubscribersByPartnerAndMandatorySubscriberRoles(
              partnerId, topic.getMandatorySubscriberRoles());
    }

    if (subscribers.isEmpty()) {
      throw new EmailNotProcessableException(
          String.format(
              "No users found with the required permissions or all users are unsubscribed to the topic: %s",
              topic.getId()),
          BlaBlaFishError.FOUND_NO_USER_WITH_REQUIRED_PERMISSIONS);
    }
    return subscribers;
  }

  private List<Subscriber> getSubscribersByPartnerAndTopic(String partnerId, int topicId) {
    var subscribers =
        subscriberRepository.findAllByPartnerForStatusEnabledAndNotBlacklisted(partnerId, topicId);

    return CollectionUtils.isNotEmpty(subscribers)
        ? subscribers
        : subscriberRepository.findAdminsByPartnerForStatusEnabledAndNotBlacklisted(partnerId);
  }

  private List<Subscriber> getSubscribersByPartnerAndMandatorySubscriberRoles(
      String partnerId, List<String> mandatorySubscriberRoles) {
    return subscriberRepository.findAllUsersByPartnerWithStatusEnabledAndNotBlacklisted(
        partnerId, mandatorySubscriberRoles);
  }

  private List<Subscriber> getSubscribersWithValidPreferences(
      int topicId, List<Subscriber> subscribers) throws EmailNotProcessableException {

    var objectIdSubscriberMap =
        subscribers.stream().collect(Collectors.toMap(Subscriber::getUserId, x -> x));
    var subscriberIds = new HashSet<>(objectIdSubscriberMap.keySet());
    var preferenceForSubscribers =
        emailPreferenceService.getPreferencesForSubscribers(topicId, subscriberIds);

    if (preferenceForSubscribers.isEmpty()) {
      // subscribers don't have entry in preferences, implicitly send mails
      return subscribers;
    }
    var subscriberIdWithPreferences =
        preferenceForSubscribers.stream()
            .map(EmailPreference::getSubscriberId)
            .collect(Collectors.toSet());
    subscriberIds.removeAll(subscriberIdWithPreferences);
    var subscriberIdWithoutPreferences = subscriberIds;
    var subscriberIdWithPreferencesOptedIn =
        preferenceForSubscribers.stream()
            .filter(EmailPreference::isOptIn)
            .map(EmailPreference::getSubscriberId)
            .toList();

    var subscribersWithValidPreferences =
        Stream.concat(
                subscriberIdWithoutPreferences.stream(),
                subscriberIdWithPreferencesOptedIn.stream())
            .map(objectIdSubscriberMap::get)
            .toList();

    if (subscribersWithValidPreferences.isEmpty()) {
      throw new EmailNotProcessableException(
          String.format("User(s) have not opted in to receive email for topic id: %s", topicId),
          BlaBlaFishError.FOUND_NO_USER_SUBSCRIBED_TO_TOPIC);
    }
    return subscribersWithValidPreferences;
  }

  private void validateIfLastUserIsBeingUnsubscribe(Subscriber user, Topic topic)
      throws BlaBlaFishException {
    if (isLastUserInTopic(user, topic.getId())) {
      String message =
          String.format(
              "Cannot unsubscribe %s because it is last user in topic : %s",
              user.getUserId(), topic.getId());
      log.error(message);
      throw new BlaBlaFishException(message, BlaBlaFishError.LAST_USER_DELETION_IN_TOPIC_ERROR);
    }
  }

  private List<Integer> getTopicIdsIfLastUser(Subscriber subscriber) {
    return subscriber.getTopicIds().stream()
        .filter(topicId -> isLastUserInTopic(subscriber, topicId))
        .toList();
  }

  private boolean isLastUserInTopic(Subscriber subscriber, Integer topicId) {
    long userCount = subscriberRepository.getCountOfUsersWith(topicId, subscriber.getPartnerId());
    return userCount == 1;
  }

  public Subscriber getSubscriberById(String subscriberId) throws SubscriberDoesNotExistException {
    Assert.hasText(subscriberId, "Missing subscriberId.");
    return subscriberRepository
        .findById(new ObjectId(subscriberId))
        .orElseThrow(
            () ->
                new SubscriberDoesNotExistException(
                    String.format("Subscriber with id: %s does not exists", subscriberId)));
  }

  public void setIsUserBlacklistedToTrue(ObjectId blacklistId, Requester requester) {
    log.info("Setting as blacklisted for blacklist id: {}", blacklistId);
    Optional<EmailBlacklist> blacklistOptional = blacklistRepository.findById(blacklistId);
    blacklistOptional.ifPresent(
        blacklist ->
            subscriberRepository.blacklistSubscriber(
                blacklist.getEmailAddress().getValue(), requester));
  }

  public void unBlacklistSubscribers(Set<String> emailIds, Requester requester) {
    subscriberRepository.unBlacklistSubscribers(emailIds, requester);
  }

  public NewsletterSubscription getNewsletterSubscriptionByEmailAddress(String emailAddress)
      throws SubscriberDoesNotExistException {
    Assert.hasText(emailAddress, "Missing emailAddress.");
    NewsletterSubscription newsletterSubscription =
        getUserByEmail(emailAddress)
            .orElseThrow(() -> new SubscriberDoesNotExistException("Subscriber not exists"))
            .getNewsletterSubscription();

    if (Objects.isNull(newsletterSubscription)) {
      newsletterSubscription =
          new NewsletterSubscription(NewsletterSubscriptionStatus.UNSUBSCRIBED, "", Instant.now());
    }

    return newsletterSubscription;
  }

  public NewsletterSubscription handleNewsletterSubscription(
      String emailAddress, Boolean isSubscribed, String text, Requester requester)
      throws SubscriberDoesNotExistException {
    Assert.notNull(isSubscribed, "Missing isSubscribed.");
    Assert.notNull(emailAddress, "Missing emailAddress.");
    Assert.notNull(text, "Missing text");
    NewsletterSubscription newsletterSubscription =
        new NewsletterSubscription(statusFrom(isSubscribed), text, Instant.now());
    subscriberRepository.updateSubscription(
        emailAddress, newsletterSubscription, List.of(SYNC_USER_DATA_TO_EMARSYS), requester);
    return getNewsletterSubscriptionByEmailAddress(emailAddress);
  }

  public void unsubscribeNewsletter(String subscriberId) {
    Assert.hasText(subscriberId, "Missing subscriberId.");
    subscriberRepository.unsubscribeNewsletter(subscriberId, List.of(SYNC_USER_DATA_TO_EMARSYS));
  }

  public void unsubscribeCommunication(String subscriberId) {
    Assert.hasText(subscriberId, "Missing subscriberId.");
    subscriberRepository.unsubscribeCommunication(subscriberId, List.of(SYNC_USER_DATA_TO_EMARSYS));
  }

  @Retryable(value = OptimisticLockingFailureException.class, backoff = @Backoff(delay = 1500))
  public void updateNewsletterSubscriptionStatus(
      String subscriberId, NewsletterSubscription updatedSubscription, Instant eventTime)
      throws SubscriberDoesNotExistException, JsonProcessingException {
    Assert.notNull(updatedSubscription, "Missing newsletterSubscription.");
    log.info("Updating newsletter subscription for : {} to {}", subscriberId, updatedSubscription);
    Subscriber subscriber = getSubscriberById(subscriberId);
    NewsletterSubscription currentSubscription = subscriber.getNewsletterSubscription();
    if (Objects.isNull(currentSubscription)
        || updatedSubscription.getTime().isAfter(currentSubscription.getTime())) {
      subscriberRepository.updateSubscriptionBySubscriberId(
          subscriberId,
          updatedSubscription,
          subscriber.getVersion(),
          List.of(SYNC_USER_DATA_TO_EMARSYS));
    } else {
      // TODO: remove this else part as we are done with newsletter migration
      addSubscriberChangedEntry(
          subscriberId,
          updatedSubscription,
          eventTime,
          eventAsDoc(subscriberId, updatedSubscription, eventTime));
    }
  }

  // TODO: unused remove this method
  public void handleNewsletterSubscriptionChanged(
      String subscriberId,
      NewsletterSubscription updatedSubscription,
      Instant eventTime,
      String eventAsString)
      throws SubscriberDoesNotExistException {
    validateSubscriberExists(subscriberId);
    log.info(
        "Newsletter subscription changed. Adding new entry for subscriber {}, new status {}",
        subscriberId,
        updatedSubscription.getStatus());
    addSubscriberChangedEntry(
        subscriberId, updatedSubscription, eventTime, Document.parse(eventAsString));
  }

  private void addSubscriberChangedEntry(
      String subscriberId,
      NewsletterSubscription updatedSubscription,
      Instant eventTime,
      Document eventAsDocument) {
    Instant expiresAt = Instant.now().plus(EXPIRATION_TIME_IN_DAYS, ChronoUnit.DAYS);
    SubscriberChangeEventType eventType =
        SubscriberChangeEventType.from(updatedSubscription.getStatus());
    Instant subscriberChangeTime = updatedSubscription.getTime();
    SubscriberChangeEntry subscriberChangeEntry =
        SubscriberChangeEntry.of(
            subscriberId, eventType, subscriberChangeTime, eventTime, expiresAt, eventAsDocument);
    if (subscriberChangeEntryRepository.exists(subscriberId, eventType, subscriberChangeTime)) {
      log.info(
          "SubscriberChangeEntry entry with same values already exist. Skipping this duplicate entry {}",
          subscriberChangeEntry);
      return;
    }
    subscriberChangeEntryRepository.insert(subscriberChangeEntry);
  }

  private Document eventAsDoc(
      String subscriberId, NewsletterSubscription updatedSubscription, Instant eventTime)
      throws JsonProcessingException {
    Document updatedFields = new Document(Map.of("newsletterSubscription", updatedSubscription));
    UpdateDescription updateDescription = new UpdateDescription(null, updatedFields, null);
    ClusterTime defaultClusterTime = new ClusterTime(1234587L, 76554L);
    MongoDbTriggerEventDetail detail =
        new MongoDbTriggerEventDetail(
            "UPDATE",
            defaultClusterTime,
            new DocumentKey(subscriberId),
            updateDescription,
            new MongoNamespace("contact_management_db", "subscribers"));
    MongoDbTriggerEvent mongoDbTriggerEvent =
        new MongoDbTriggerEvent(
            UUID.randomUUID().toString(),
            "custom/trigger/newsletter",
            "neptune.events/sqs/NEWSLETTER_STATUS_CHANGED",
            "NA",
            eventTime,
            List.of("neptune.events/sqs/NEWSLETTER_STATUS_CHANGED"),
            detail);

    return Document.parse(objectMapper.writeValueAsString(mongoDbTriggerEvent));
  }

  private void validateSubscriberExists(String subscriberId)
      throws SubscriberDoesNotExistException {
    if (!subscriberRepository.exists(subscriberId)) {
      throw new SubscriberDoesNotExistException(
          String.format("Subscriber with id: %s does not exists", subscriberId));
    }
  }
}
