package de.otto.blablafish_email.model.dto;

public enum SplunkOperationCode {
  API_WITH_OTTO_TEAMS_ACCESS("API_WITH_OTTO_TEAMS_ACCESS"),
  DELETE_EVENT_TO_REMOVE_TOPIC_LAST_SUBSCRIBER("DELETE_EVENT_TO_REMOVE_TOPIC_LAST_SUBSCRIBER");

  final String operationCode;

  SplunkOperationCode(String operationCode) {
    this.operationCode = operationCode;
  }

  public String getCode() {
    return operationCode;
  }
}
