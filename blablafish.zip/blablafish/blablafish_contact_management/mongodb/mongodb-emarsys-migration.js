//sync for all subscribers
    db.subscribers.updateMany({}, {
      $push: {
        actions: {$each: ["SYNC_USER_DATA_TO_EMARSYS"]}
      }
    })


//Sync for one subscriber :
db.subscribers.updateOne(
        { _id : ObjectId("62b1af5ebbbb2c5701bf4c99") },
        {$push: {actions: {$each: ["SYNC_USER_DATA_TO_EMARSYS"]}}}
)