alias awslocal=aws
function createSqsAndSSM() {
    formattedName=$(echo "$1" | tr / _)
    awslocal sqs create-queue --queue-name "$formattedName"
    awslocal ssm put-parameter \
      --cli-input-json '{
            "Name": '\"/config/blablafish-contactmanagement/$1\"',
            "Value": '\"http://localhost:4566/000000000000/$formattedName\"',
            "Type": "String"
            }' \
      --overwrite
}
createSqsAndSSM "userManagementEvents/queueUrl"
createSqsAndSSM "mongoDbTrigger/mails/queueUrl"
createSqsAndSSM "sesEvents/queueUrl"

