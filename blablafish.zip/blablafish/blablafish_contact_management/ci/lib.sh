SCRIPT_DIR="$(cd "$(dirname "$0")" ; pwd -P)"
ROOT_DIR="${SCRIPT_DIR}/.."

. "${SCRIPT_DIR}/config.sh"

_login_ecr() {
    echo "** Logging to ECR **"
    aws ecr get-login-password   --region eu-central-1 | docker login --username AWS --password-stdin ${INFRA_ACCOUNT_ID}.dkr.ecr.eu-central-1.amazonaws.com
}
_update_application_properties() {
    echo "** Updating application.properties - WORK IN PROGRESS **"
}

_update_lambda_libraries() {
  pushd "${SCRIPT_DIR}/../lambda/security_group_updater" > /dev/null
    pip3 install -r requirements.txt -t .
  popd > /dev/null
}
_generate_keystore() {
    echo "** Generating keystore **"
    keytool -genkey -noprompt \
    -alias ${SERVICE_NAME}_https \
    -dname "CN=blablafish.platform.otto.de, OU=Deepsea, O=Otto, L=Hamburg, S=Germany, C=DE" \
    -keysize 4096 \
    -keystore "src/main/resources/keystore.p12" \
    -keyalg RSA \
    -storetype PKCS12 \
    -validity 3650 \
    -storepass "${1}" \
    -keypass "${1}" -v
}

_save_keystore_pswd() {
    local pswd=$(aws --region eu-central-1 secretsmanager get-secret-value --secret-id  "blablafish_contact_management/keystore_psw" | jq -r '.SecretString')
    _update_application_properties "$pswd"
    _generate_keystore "$pswd"
}

_build_jar() {
    echo "** Building Jar **"
    "${ROOT_DIR}/gradlew" clean build
}

_spotless_check() {
    echo "** Running spotlessCheck **"
    "${ROOT_DIR}/gradlew" spotlessCheck
}

_check(){
  "${ROOT_DIR}/gradlew" :dependencyCheckAnalyze
}

_build_image() {
    echo "** Building image **"
    docker build -f Dockerfile -t "${REGISTRY_NAME}:${REVISION}" .
}

_build_cdc_image(){
  echo "** Building cdc image"
  "${ROOT_DIR}/gradlew" clean build -x test -x compileTestJava -x spotbugsMain -x spotlessInternalRegisterDependencies -x spotlessJavaCheck -x spotlessCheck
  docker build -t "${ECR_CDC_REGISTRY}" . -f Dockerfile.cdc
}


_invoke_lambda(){
   echo $1 $2 $3 $4
  _assume_role $3 "${SERVICE_NAME}_pipeline_role" $4
  aws lambda invoke --function-name $2 out --log-type  Tail --output text
}

_push_image() {
  _assume_role "infra" "${SERVICE_NAME}_pipeline_role" ${INFRA_ACCOUNT_ID}
    _login_ecr
    local repo="$(aws ecr describe-repositories --output=text --region=${AWS_DEFAULT_REGION} --query="repositories[?repositoryName=='${REGISTRY_NAME}'].repositoryUri")"
    echo "** Tagging image **"
    docker tag "${REGISTRY_NAME}:${REVISION}" "${repo}:${REVISION}"

    echo "** Pushing image to ECR **"
    docker push "${repo}:${REVISION}"
}

_push_cdc_image(){
   _assume_role "infra" "${SERVICE_NAME}_pipeline_role" ${INFRA_ACCOUNT_ID}
    _login_ecr
    local ecrCdcRepo="$(aws ecr describe-repositories --output=text --region=${AWS_DEFAULT_REGION} --query="repositories[?repositoryName=='${ECR_CDC_REGISTRY}'].repositoryUri")"
    echo "** Tagging image **"
    docker tag "${ECR_CDC_REGISTRY}:latest" "${ecrCdcRepo}:latest"

    echo "** Pushing image to ECR **"
    docker push "${ecrCdcRepo}":latest
}

_assume_role(){
  local account=${1}
  local role_name=${2}
  local account_id=${3}
  local role_arn="arn:aws:iam::${account_id}:role/${role_name}"
  echo "Calling Assume role function"
  echo $role_arn
  local credentials
  local access_key_id
  local secret_access_key
  local session_token

    credentials=$( aws sts assume-role \
      --role-arn "${role_arn}" \
      --role-session-name "assumed_role_session_${role_name}" \
      --region ${AWS_DEFAULT_REGION})
  export AWS_ACCESS_KEY_ID=$(echo "${credentials}" | jq -r .Credentials.AccessKeyId)
  export AWS_SECRET_ACCESS_KEY=$(echo "${credentials}" | jq -r .Credentials.SecretAccessKey)
  export AWS_SESSION_TOKEN=$(echo "${credentials}" | jq -r .Credentials.SessionToken)
  echo "Assumed role"
}