#!/bin/bash
set -eu -o pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" ; pwd -P)"
. "${SCRIPT_DIR}/lib.sh"


_ensure_tfenv() {
  if ! type tfenv &> /dev/null ; then
    echo "Please install tfenv!" 1>&2
    exit 1
  fi
  if ! tfenv exec --version &> /dev/null; then
    echo "Please install required terraform version via tfenv!"
    exit 1
  fi
}

_deploy() {
  _ensure_tfenv

  export SCRIPT_DIR="$(cd "$(dirname "$0")" ; pwd -P)"

  local deployment="${2}"
  local environment="${3}"
  shift
  shift
  shift
  pushd "${SCRIPT_DIR}/../${deployment}/" > /dev/null
    tfenv list
    tfenv exec init
    tfenv exec workspace select "${environment}" || tfenv exec workspace new "${environment}"
    tfenv exec $@ -var-file="${environment}.tfvars" -input=false

  popd > /dev/null
}

_download_and_install_tfsec() {
  # check if tfsec version is already installed
  if [[  $(tfsec --version | grep "${TFSEC_VERSION}")  ]]; then
    printf "\ntfsec version ${TFSEC_VERSION} already installed" && return 0
  else
    TFSEC_URL="https://github.com/tfsec/tfsec/releases/download/v${TFSEC_VERSION}/tfsec-linux-amd64"
	  sudo wget -q -O tfsec "${TFSEC_URL}"
	  sudo chmod +x ./tfsec
	  sudo mv ./tfsec /usr/local/bin/tfsec
	  tfsec --version
  fi
}

_tfsec() {
  if ! tfsec --version &> /dev/null; then
    echo "Please install tfsec using \"brew install tfsec\""
    exit 1
  fi

  tfsec --config-file tfsec.yml
}
_test() {
  _ensure_tfenv
  tfenv exec fmt -check=true -recursive
}
_format() {
  _ensure_tfenv
  tfenv exec fmt -recursive
}

usage() {
  cat <<EOF
Usage: Before running the script, Assume the AWS-ADM role of corresponding account.
Export aws access key and secret eval $(saml2aws -a <saml_profile_name> script --shell=bash)
commands:
  deploy [folder] [env] [play|apply]              runs terraform
  tfsec                                           runs terraform static code analysis
  format                                          Formats tf code
  build_jar                                       Builds application jar and runs tests
  build_image                                     Create docker image
  push_image                                      Push docker image to ECR
  lambda_libraries                                Add dependent lambda libraries
  install_tfsec                                   download and install tfsec on linux
  invoke_lambda                                   invoke lambda
  check                                          Check for security vulnerabilities
EOF
  exit 1
}

CMD=${1:-}
case ${CMD} in
  deploy) _deploy "$@";;
  tfsec)  _tfsec ;;
  format) _format;;
  spotless_check) _spotless_check;;
  build_jar) _build_jar;;
  test) _test;;
  build_image) _build_image;;
  push_image) _push_image;;
  build_cdc_image) _build_cdc_image;;
  push_cdc_image)  _push_cdc_image;;
  lambda_libraries) _update_lambda_libraries;;
  install_tfsec) _download_and_install_tfsec;;
  assume_role) _assume_role "$@";;
  invoke_lambda) _invoke_lambda "$@";;
  check) _check;;
  *) usage ;;
esac