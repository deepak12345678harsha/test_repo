# blablafish_contactmanagement_service

To install  external libraries in 

````
cd lambda/security_group_updater
pip3 install -r requirements.txt -t . 
````

To run local
````
local/docker-compose up
./gradlew bootRun --args='--spring.profiles.active=local'
````

Terraform State Lock Error
````
Error: Error acquiring the state lock
Navigate to tf folder -> 40_deployment
terraform force-unlock <id>
````

# CDC Tests
## Pull Docker image

In order to log into our ECR we need to give your AWS account the necessary permission to pull Images from our ECR. Please contact us and provide your AWS Account ID.

After you have the necessary permission, you must first log in to your ECR:

```bash
aws ecr get-login-password  --region eu-central-1  | docker login  --username AWS --password-stdin 348078512286.dkr.ecr.eu-central-1.amazonaws.com
```

### Alternatively you can log in to our ECR as follows (This may be necessary if you want to start the docker image locally, e.g. in the powershell.):

1. you have to get the password with the AWS CLI:
```bash
aws ecr get-login-password  --region eu-central-1  | docker login  --username AWS --password-stdin 348078512286.dkr.ecr.eu-central-1.amazonaws.com
```

2. you execute a docker login:

```bash
docker login  348078512286.dkr.ecr.eu-central-1.amazonaws.com -u AWS -p <password_from_step_1>
```

After you are logged in, you have to pull the docker image:

```bash
docker pull 348078512286.dkr.ecr.eu-central-1.amazonaws.com/contact-management_cdc:latest:latest
````

## Execute Docker Image

With the following command you can start the CDC:

```bash
docker run \
  --rm \
  -v "<LOCAL_DIRECTORY>:/cdc-events" \
  -e MESSAGES_PATH="/cdc-events/" \
  348078512286.dkr.ecr.eu-central-1.amazonaws.com/contact-management_cdc:latest
```

# Point Local to develop Mongo Database

### Step 1 : Add your IP in IP Access List
1. Open MongoDB atlas in web browser
2. Navigate to Network Access --> `Click on ADD IP ADDRESS` and Use Your IP only.
3. Note: add expiry time as 6 hrs. Do not allow all IP's to have access

### Step 2
1. Open MongoDB atlas in web browser 
2. Navigate to  Database  --> Connect --> Standard Connection --> click "Choose a connection method" --> select method as "Connect your application" 
3. Copy connection string
4. Replace `spring.data.mongodb.uri` in `application-local.yml` with above string (you can get username and password from ssm parameter store)
5. Pick jwk-url and jwk-internal-url values from adfs paramstore for nonlive
6. Set aws.provider to aws in application-local.yml

### Step 3
1. Replace `aws.accessToken` and `aws.accessKey` from parameter store in application.yml
2. Replace `aws.kmsProvider` to aws in `application-local.yml`
3. Swap `local` profiles in clientEncryption in MongoConfiguration.java
