# blablafish_password_store
Shared Password Store for team BlaBlaFish

## Access
install KeepassXc: https://keepassxc.org/
Open the database .kdbx
Get the database password from another colleague
