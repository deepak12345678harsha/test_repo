#!/bin/bash
SCRIPT_DIR="$(cd "$(dirname "$0")" ; pwd -P)"
. "${SCRIPT_DIR}/register_service_json.sh"
if [ -z "$1" ]; then
  echo "please pass environment as argument : develop/live"
  exit 0
fi

aws secretsmanager get-secret-value --secret-id "arn:aws:secretsmanager:eu-west-1:787821785757:secret:/status-api/client_credential/blablafish" --region eu-west-1 --query SecretString --output text
rm -rf *.pem
CLIENT_ID=$(aws secretsmanager get-secret-value --secret-id "arn:aws:secretsmanager:eu-west-1:787821785757:secret:/status-api/client_credential/blablafish" --region eu-west-1 --query SecretString --output text |  jq .client_id | tr -d '"' )
echo $CLIENT_ID
CLIENT_SECRET=$(aws secretsmanager get-secret-value --secret-id "arn:aws:secretsmanager:eu-west-1:787821785757:secret:/status-api/client_credential/blablafish" --region eu-west-1 --query SecretString --output text |jq .client_secret| tr -d '"')
echo $CLIENT_SECRET
aws s3 cp "s3://de-otto-spoc-status-api-ca-eu-west-1-787821785757/status-api-client-2022.crt.pem" .
aws s3 cp "s3://de-otto-spoc-status-api-ca-eu-west-1-787821785757/status-api-client-2022.key.pem" .


TOKEN=$(curl --request POST \
  --http2-prior-knowledge \
  --tlsv1.2 --tls-max 1.2 \
  --url "https://status-api-live-787821785757.auth.eu-west-1.amazoncognito.com/token" \
  --header "Content-type: application/x-www-form-urlencoded" \
  --data grant_type=client_credentials \
  --data client_id=$CLIENT_ID \
  --data client_secret=$CLIENT_SECRET \
  --data audience=team-deepsea/blablafish | jq .access_token | tr -d '"')

  echo this is token $TOKEN


register_service()
{
  echo $1
curl --verbose \
  --http2-prior-knowledge \
  --tlsv1.2 --tls-max 1.2 \
  --key status-api-client-2022.key.pem \
  --cert status-api-client-2022.crt.pem \
  --url "https://status-api.live.spoc.cloud.otto.de/v1/metadata" \
  --header "Content-Type: application/json" \
  --header "Authorization: Bearer $TOKEN" \
  -d "{\"critical_damage_hours\": {\"image\":48, \"legal\":48, \"monetary\": 48},
   \"customer_impact\":\"Partners will not be able to manage user subscriptions\",
    \"environment\":\"$2\",
     \"heartbeat_minutes\":5,
     \"in_house_impact\":\"Partners will not be able to manage user subscriptions\",
      \"required_action\":\"Reach us via blablafish@otto.de or our MS Teams channel.\",
      \"service\":\"$1\",
      \"service_description\":\"User management with Subscriptions on opc portal\",
      \"team\":\"blablafish\",
      \"vertical\":\"blablafish\"}"
 }

register_service contact-management $1
register_service contact-management-ui  $1

register_email_service()
{
  echo $1
curl --verbose \
  --http2-prior-knowledge \
  --tlsv1.2 --tls-max 1.2 \
  --key status-api-client-2022.key.pem \
  --cert status-api-client-2022.crt.pem \
  --url "https://status-api.live.spoc.cloud.otto.de/v1/metadata" \
  --header "Content-Type: application/json" \
  --header "Authorization: Bearer $TOKEN" \
  -d "{
\"critical_damage_hours\":
{ \"image\":48, \"legal\":48, \"monetary\": 48},
 \"customer_impact\":\"Partners will not be able to send emails\",
 \"environment\":\"$2\",
  \"heartbeat_minutes\":5,
   \"in_house_impact\":\"Partners will not be able to send emails\",
    \"required_action\":\"Reach us via blablafish@otto.de or our MS Teams channel.\",
    \"service\":\"$1\",
    \"service_description\":\"This service sends emails in the context of OPC\",
    \"team\":\"blablafish\",
    \"vertical\":\"email\"
  }"
 }

register_email_service contact-management-email  $1
