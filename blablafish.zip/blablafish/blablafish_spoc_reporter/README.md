# blablafish_spoc_reporter
This will register all Blablfish  Services and send status of each service to SPoC.
spoc_reporter Lambda gets triggered for each 5 minutes in order to publish heartbeat of each registered service.
Services Registration will have to be manually done by Developers whenever there is a new service introduced.

## URL to Acccess
https://dashboard.live.spoc.cloud.otto.de/dashboard/develop
## Structure of Status and Metadata Message
Metadata Message:
```
{
  "type": "metadata",
  "environment": "<live/develop>",
  "team": "blablafish",
  "vertical": <vertical_name>,
  "service": <serviceName>,
  "service_description": "<Description of the service>",
  "heartbeat_minutes": 5,
  "critical_damage_hours": {
    "image": 72,
    "legal": 72,
    "monetary": 72
  },
  "customer_impact": "<write down the customer impact>",
  "in_house_impact": "<In-house imapct>",
  "required_action": "<Required action>"
}
```

Status Message:
```
{
"type": "status",
"environment": "<live/develop>",
"vertical": <vertical_name>,
"team": "blablafish",
"status": "<ok/error>",
"service": <serviceName>,
}
```

## Want to add to a new service?
Below is the process to register a new service and publish status for the same.

* Create a metadata json file under <Project Root>/spoc_metadata directory. Ex: contact-management_nonlive.json
* Run the following command to register the newly added service in Dev machine by assuming AWS-ADM role ./register_service_with_spoc.sh <environment>
* Add the service name to the terraform variable service_names under the directory <Project Root>/terraform/resources/lambda Ex: backend,contact-management

So once the changes are pushed, pipeline will take care of adding the new service to the lambda so that it will take care of publishing status messages of these services to SPoC.

Reference document: https://github.com/otto-ec/spoc_aws-status

## Format terraform file
./run.sh terraform_format

### Register Service

./register_service.sh <develop/live>

### Register new Service

Update register_service.sh  with new service name (last line of script)

