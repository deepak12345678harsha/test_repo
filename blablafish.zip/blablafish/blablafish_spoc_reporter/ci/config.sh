export SERVICE_NAME=spoc_reporter
export REGISTRY_NAME=spoc_reporter
export REVISION=$(git rev-parse HEAD)
export INFRA_ACCOUNT_ID=348078512286
export AWS_DEFAULT_REGION=eu-central-1
export TFSEC_VERSION="1.15.4"