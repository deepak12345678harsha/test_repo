SCRIPT_DIR="$(cd "$(dirname "$0")" ; pwd -P)"
ROOT_DIR="${SCRIPT_DIR}/.."

. "${SCRIPT_DIR}/config.sh"

_login_ecr() {
    echo "** Logging to ECR **"
    aws ecr get-login-password   --region eu-central-1 | docker login --username AWS --password-stdin ${INFRA_ACCOUNT_ID}.dkr.ecr.eu-central-1.amazonaws.com
}
_update_application_properties() {
    echo "** Updating application.properties - WORK IN PROGRESS **"
}
_install_dependency() {
  pushd "${SCRIPT_DIR}/../lambda" > /dev/null
    npm install --production
    mv ./node_modules ./src
  popd > /dev/null
}
_update_lambda_libraries() {
  pushd "${SCRIPT_DIR}/../lambda_python" > /dev/null
    pip3 install -r requirements.txt -t .
  popd > /dev/null
}
_generate_keystore() {
    echo "** Generating keystore **"
    keytool -genkey -noprompt \
    -alias ${SERVICE_NAME}_https \
    -dname "CN=blablafish.platform.otto.de, OU=Deepsea, O=Otto, L=Hamburg, S=Germany, C=DE" \
    -keysize 4096 \
    -keystore "src/main/resources/keystore.p12" \
    -keyalg RSA \
    -storetype PKCS12 \
    -validity 3650 \
    -storepass "${1}" \
    -keypass "${1}" -v
}

_save_keystore_pswd() {
    local pswd=$(aws --region eu-central-1 secretsmanager get-secret-value --secret-id  "blablafish_contact_management/keystore_psw" | jq -r '.SecretString')
    _update_application_properties "$pswd"
    _generate_keystore "$pswd"
}

_build_jar() {
   # _save_keystore_pswd
    echo "** Building Jar **"
    "${ROOT_DIR}/gradlew" clean build
}

_build_image() {
    echo "** Building image **"
    docker build -f Dockerfile -t "${REGISTRY_NAME}:${REVISION}" .
}

_invoke_lambda(){
   echo $1 $2 $3 $4
  _assume_role $3 "${SERVICE_NAME}_pipeline_role" $4
  aws lambda invoke --function-name $2 out --log-type  Tail --output text
}

_push_image() {
  _assume_role "infra" "${SERVICE_NAME}_pipeline_role" ${INFRA_ACCOUNT_ID}
    _login_ecr
    local repo="$(aws ecr describe-repositories --output=text --region=${AWS_DEFAULT_REGION} --query="repositories[?repositoryName=='${REGISTRY_NAME}'].repositoryUri")"
    echo "** Tagging image **"
    docker tag "${REGISTRY_NAME}:${REVISION}" "${repo}:${REVISION}"

    echo "** Pushing image to ECR **"
    docker push "${repo}:${REVISION}"
}

_assume_role(){
  local account=${1}
  local role_name=${2}
  local account_id=${3}
  local role_arn="arn:aws:iam::${account_id}:role/${role_name}"
  echo "Calling Assume role function"
  echo $role_arn
  local credentials
  local access_key_id
  local secret_access_key
  local session_token

    credentials=$( aws sts assume-role \
      --role-arn "${role_arn}" \
      --role-session-name "assumed_role_session_${role_name}" \
      --region ${AWS_DEFAULT_REGION})
  export AWS_ACCESS_KEY_ID=$(echo "${credentials}" | jq -r .Credentials.AccessKeyId)
  export AWS_SECRET_ACCESS_KEY=$(echo "${credentials}" | jq -r .Credentials.SecretAccessKey)
  export AWS_SESSION_TOKEN=$(echo "${credentials}" | jq -r .Credentials.SessionToken)
  echo "Assumed role"
}


_spoc_register()
{
 echo $2 $3
_assume_role $2 "${SERVICE_NAME}_pipeline_role" ${3}
if [ -z "$2" ]; then
  echo "please pass environment as argument : develop/live"
  exit 0
fi

aws secretsmanager get-secret-value --secret-id "arn:aws:secretsmanager:eu-west-1:787821785757:secret:/status-api/client_credential/blablafish" --region eu-west-1 --query SecretString --output text
rm -rf *.pem
CLIENT_ID=$(aws secretsmanager get-secret-value --secret-id "arn:aws:secretsmanager:eu-west-1:787821785757:secret:/status-api/client_credential/blablafish" --region eu-west-1 --query SecretString --output text |  jq .client_id | tr -d '"' )
echo $CLIENT_ID
CLIENT_SECRET=$(aws secretsmanager get-secret-value --secret-id "arn:aws:secretsmanager:eu-west-1:787821785757:secret:/status-api/client_credential/blablafish" --region eu-west-1 --query SecretString --output text |jq .client_secret| tr -d '"')
echo $CLIENT_SECRET
aws s3 cp "s3://de-otto-spoc-status-api-ca-eu-west-1-787821785757/status-api-client-2022.crt.pem" .
aws s3 cp "s3://de-otto-spoc-status-api-ca-eu-west-1-787821785757/status-api-client-2022.key.pem" .

TOKEN=$(curl --request POST \
  --http2-prior-knowledge \
  --tlsv1.2 --tls-max 1.2 \
  --url "https://status-api-live-787821785757.auth.eu-west-1.amazoncognito.com/token" \
  --header "Content-type: application/x-www-form-urlencoded" \
  --data grant_type=client_credentials \
  --data client_id=$CLIENT_ID \
  --data client_secret=$CLIENT_SECRET \
  --data audience=team-deepsea/blablafish | jq .access_token | tr -d '"')

  echo this is token $TOKEN
  reg_service contact-management $2
  reg_service contact-management-ui  $2

}

reg_service()
{
curl --verbose \
  --http2-prior-knowledge \
  --tlsv1.2 --tls-max 1.2 \
  --key status-api-client-2022.key.pem \
  --cert status-api-client-2022.crt.pem \
  --url "https://status-api.live.spoc.cloud.otto.de/v1/metadata" \
  --header "Content-Type: application/json" \
  --header "Authorization: Bearer $TOKEN" \
  -d "{\"critical_damage_hours\": {\"image\":48, \"legal\":48, \"monetary\": 48}, \"customer_impact\":\"Partners will not be able to manage user subscriptions\", \"environment\":\"$2\", \"heartbeat_minutes\":5, \"in_house_impact\":\"Partners will not be able to manage user subscriptions\", \"required_action\":\"Reach us via blablafish@otto.de or our MS Teams channel.\", \"service\":\"$1\", \"service_description\":\"User management with Subscriptions on opc portal\", \"team\":\"blablafish\", \"vertical\":\"blablafish\"}"
}