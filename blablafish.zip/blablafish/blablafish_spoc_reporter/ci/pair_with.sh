#!/bin/bash

set -eu -o pipefail

_find_pair() {
  local name="$1"

  if [ -n "${name}" ] ; then
    cat <<EOF |grep -i "${name}" | head -1
Bhawna Singla <bhawnas@thoughtworks.com>
Antje Radkiewicz <antje.radkiewicz@otto.de>
Nitika Thareja <nitika.thareja@thoughtworks.com>
Harsha Devulapalli <s.devulapalli@thoughtworks.com>
EOF
  else
    echo "tbd"
  fi
}

_format_issue() {
  local issue="$1"

  if [ -z "${issue}" ] ; then
    echo "[BLA-Scout]"
  elif [[ "${issue}" = *BLA* ]] ; then
    echo "[${issue}]"
  else
    echo "[BLA-${issue}]"
  fi
}

_create_git_message() {
  local pair="$1"
  local issue="$2"

  if [ -n "${issue}" ] ; then
    echo "${issue} subject"
  else
    echo "[BLA-Scout] subject"
  fi

  echo
  echo "some context/description"

  if [ -n "${pair}" ] ; then
    echo
    echo "Co-authored-by: ${pair}"
  fi
}

_main() {
  local name="$1"
  local issue="$2"
  name=$(_find_pair "${name}")
  issue=$(_format_issue "${issue}")

  if [ -z "${DRY_RUN}" ] ; then
    _create_git_message "${name}" "${issue}" > ./.git/.gitmessage.txt
    git config commit.template "$PWD/.git/.gitmessage.txt"
  else
    _create_git_message "${name}" "${issue}"
  fi
}

_usage() {
  cat <<EOF
Usage: $0 [-n] [-p <partial pair name>] [-i <issue-number>]

Options:
  -i <issue number>		The JIRA issue number
  -p <partial pair name>	Part of the pair name
  -n				dry run - only print template


This will create a file .git/.gitmessage.txt and set commit.template option to it.

EOF
  exit 1
}

PAIR=
ISSUE=
DRY_RUN=

while getopts "hi:np:" opt; do
  case "${opt}" in
    h) _usage ;;
    p) PAIR="${OPTARG}" ;;
    i) ISSUE="${OPTARG}" ;;
    n) DRY_RUN=1 ;;
    *) _usage ;;
  esac
done
shift $((OPTIND-1))

if [ ! -d ./.git ] ; then
  echo "This is not a git directory!" 1>&1
  _usage
fi

_main "${PAIR}" "${ISSUE}"