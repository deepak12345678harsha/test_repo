import os
import sys
import logging
import requests
import boto3
import json
import logging
from urllib.request import Request, urlopen
from datetime import date
from dataclasses import dataclass
LOGGER = logging.getLogger()
logging.basicConfig(level=logging.INFO)
logging.getLogger("botocore").setLevel(logging.WARN)
logging.getLogger("boto3").setLevel(logging.WARN)

print('Loading function')

s3 = boto3.client('s3')
KEY_TEAM = "team"
KEY_VERTICAL = "vertical"
KEY_ENV = "environment"
KEY_SERVICE = "service"
KEY_NAME = "name"
KEY_STATUS = "status"
STATUS_JSON = '{"environment":"{environment}","team":"blablafish","vertical":"blablafish","service":"{KEY_SERVICE}","status":"{KEY_SERVICE}"}'


def lambda_handler(event, context):
    #print("Received event: " + json.dumps(event, indent=2))
    spoc_aws_region = os.environ.get("SPOC_AWS_REGION")
    assert spoc_aws_region
    environment = os.environ.get("ENVIRONMENT")
    if environment == "live":
        spoc_account_id = "787821785757"
        account_id = "213876567008"
    elif environment == "develop":
        spoc_account_id = "787821785757"
        account_id = "353449567674"
    else:
        raise Exception(
            "environment has to match the spoc live or nonlive AWS accountIDs!")
    assert environment
    year_latest = str(date.today().year)
    print("Starting sending message finished ...")
    access_token = token_res(environment,spoc_aws_region,spoc_account_id,account_id)
    alarmtypes = ["CompositeAlarm","MetricAlarm"]
    for alarmtype in alarmtypes:
         alarms = fetch_all_alarms(environment,alarmtype)
         print('got %d alarms', len(alarms))
         print('alarms: %s', alarms)
         status_dlq = collect_functional_alarm_dlq_status(environment, alarms)
         print('dlq status:', status_dlq['OK'])
         for aStatus in status_dlq['ALARM_WARN']:
             print("inside dlq loop")
             json_dict = json.loads(STATUS_JSON);
             json_dict['service'] = aStatus[KEY_SERVICE]
             json_dict['environment'] = environment
             json_dict['vertical'] =  aStatus[KEY_VERTICAL]
             json_dict['status'] = "Alert: messages in dlq"
             json_object = json.dumps(json_dict)
             print(json_dict)
             url = "https://og2gether.webhook.office.com/webhookb2/149487d7-f1a4-4356-b848-debecfb1d22e@8794e153-c3bd-4479-8bea-61aeaf167d5a/IncomingWebhook/a51409eb99e9495a91da5e0131c275df/2fef8f1e-bcb6-471c-8f59-5fb672e3bf19"
             send_message_dlq(url, aStatus[KEY_NAME], environment)
         status = collect_functional_alarm_status(environment, alarms)
         print('status:', status['OK'])
         for aStatus in status['ALARM_WARN']:
             print("inside failed loop")
             json_dict = json.loads(STATUS_JSON);
             json_dict['service'] = aStatus[KEY_SERVICE]
             json_dict['environment'] = environment
             json_dict['vertical'] =  aStatus[KEY_VERTICAL]
             json_dict['status'] = "error"
             json_object = json.dumps(json_dict)
             print(json_dict)
             send_message("/v1/status", json_dict ,access_token,year_latest)
         for aStatus in status['OK']:
             print("inside ok loop")
             json_dict = json.loads(STATUS_JSON);
             json_dict['service'] = aStatus[KEY_SERVICE]
             json_dict['environment'] = environment
             json_dict['vertical'] =  aStatus[KEY_VERTICAL]
             json_dict['status'] = "ok"
             json_object = json.dumps(json_dict)
             print(json_dict)
             send_message("/v1/status", json_dict ,access_token,year_latest)
    cleanup_cert(year_latest)

def collect_functional_alarm_status(environment, alarms):
    status = {"OK": [], "ALARM_WARN": []}
    for alarm in alarms:
        alarm_info = parse_alarm_name_to_alarm_info(alarm['AlarmName'])
        #print('alarm name is: %s', KEY_ENV)
        print('alarm name is: %s', alarm['AlarmName'])
        if KEY_ENV not in alarm_info or alarm_info[KEY_ENV] != environment:
            continue
        if KEY_NAME in alarm_info and 'functional' in alarm_info[KEY_NAME]:
            print('functional alarm detected: %s', alarm_info)
            if alarm['StateValue'] == 'ALARM':
                alarm_info[KEY_STATUS] = 'error'
                status['ALARM_WARN'].append(alarm_info)
            else:
                alarm_info[KEY_STATUS] = 'ok'
                status['OK'].append(alarm_info)
    return status

def collect_functional_alarm_dlq_status(environment, alarms):
    status = {"OK": [], "ALARM_WARN": []}
    for alarm in alarms:
        alarm_info = parse_alarm_name_to_alarm_info(alarm['AlarmName'])
        #print('alarm name is: %s', KEY_ENV)
        print('alarm name is: %s', alarm['AlarmName'])
        if KEY_ENV not in alarm_info or alarm_info[KEY_ENV] != environment:
            continue
        if KEY_NAME in alarm_info and 'dlq' in alarm_info[KEY_NAME]:
            print('functional alarm detected: %s', alarm_info)
            if alarm['StateValue'] == 'ALARM':
                alarm_info[KEY_STATUS] = 'error'
                status['ALARM_WARN'].append(alarm_info)
            else:
                alarm_info[KEY_STATUS] = 'ok'
                status['OK'].append(alarm_info)
    return status

def parse_alarm_name_to_alarm_info(alarmName):
    keys = [KEY_ENV, KEY_VERTICAL, KEY_SERVICE, KEY_NAME]
    tokens = alarmName.split('/', len(keys) - 1)
    return {keys[i]: token for i, token in enumerate(tokens)}

def fetch_all_alarms(environment,alarmtype):
    cloudwatch = boto3.client('cloudwatch')
    paginator = cloudwatch.get_paginator('describe_alarms')
    pages = paginator.paginate(
        AlarmNamePrefix='%s/' % environment,
        AlarmTypes = [alarmtype]
    )
    print("alarm type is: "+str(alarmtype))
    if alarmtype == "CompositeAlarm" :
     alarms = [alarm for page in pages for alarm in page["CompositeAlarms"]]
    else:
     alarms = [alarm for page in pages for alarm in page["MetricAlarms"]]
    print('Got %d alarms', len(alarms))
    print(alarms)
    return alarms

def token_res(environment,spoc_aws_region,spoc_account_id,account_id):
    get_client_cert(environment, spoc_aws_region, spoc_account_id)
    secrets_values = get_client_credentials(environment, spoc_aws_region, account_id)
    client_id = secrets_values[0]
    client_secret = secrets_values[1]
    token_result = get_access_token(environment, spoc_aws_region, spoc_account_id, client_id, client_secret)
    return token_result

def get_client_cert(environment, spoc_aws_region, spoc_account_id):
    hostname = f"https://status-api.{environment}.spoc.cloud.otto.de"
    year = str(date.today().year)
    client_key_filename = f"status-api-client-{year}.key.pem"
    client_cert_filename = f"status-api-client-{year}.crt.pem"
    dest_dir = "/tmp"
    cert_bucket = f"de-otto-spoc-status-api-ca-{spoc_aws_region}-{spoc_account_id}"
    # getting the client certificates from the s3 bucket
    print("Getting client certs ...")
    # set bucket resource variables
    try:
        s3 = boto3.resource("s3")
        try:
            print(client_key_filename)
            print(client_cert_filename)
            s3.Bucket(cert_bucket).download_file(
                client_key_filename, f"{dest_dir}/{client_key_filename}")
            s3.Bucket(cert_bucket).download_file(
                client_cert_filename, f"{dest_dir}/{client_cert_filename}")
            dir_list = os.listdir(dest_dir)
            print(dir_list)
        except Exception as e:
            logging.error(e)
            logging.error(
                "Could not load current years certs. Trying to load last years certs!")
            last_year = str(date.today().year - 1)
            client_cert_filename = f"status-api-client-{last_year}.crt.pem"
            client_key_filename = f"status-api-client-{last_year}.key.pem"
            print(client_key_filename)
            print(client_cert_filename)
            s3.Bucket(cert_bucket).download_file(
                client_key_filename, f"{dest_dir}/{client_key_filename}")
            s3.Bucket(cert_bucket).download_file(
                client_cert_filename, f"{dest_dir}/{client_cert_filename}")
    except Exception as e:
        logging.error(f"Exception while getting client certs from bucket:")
        logging.error(e)
        sys.exit(1)

def cleanup_cert(year):
    client_key_filename = f"status-api-client-{year}.key.pem"
    client_cert_filename = f"status-api-client-{year}.crt.pem"
    dest_dir = "/tmp"

    if not os.path.isfile(f"{dest_dir}/{client_cert_filename}"):
        last_year = str(date.today().year - 1)
        client_key_filename = f"status-api-client-{last_year}.key.pem"
        client_cert_filename = f"status-api-client-{last_year}.crt.pem"
    # removing the client certificates again
    print("cleaning up certs ...")
    try:
        os.remove(f"{dest_dir}/{client_key_filename}")
        os.remove(f"{dest_dir}/{client_cert_filename}")
        dir_list = os.listdir(dest_dir)
        print(dir_list)
    except Exception as e:
        print(f"Exception while cleaning up cert files:")
        logging.error(e)
        sys.exit(1)

def get_client_credentials(environment, spoc_aws_region, account_id):
    # Get secrets (client_credentials) from spoc account in order to get Oauth tokens from spoc cognito instance
    print("Getting client credentials ...")
    #arn:aws:secretsmanager:eu-central-1:{account_id}:secret:blablafish/client_id_spoc-dwuilh
    secrets_arn = f"arn:aws:secretsmanager:eu-central-1:{account_id}:secret:blablafish/client_id_spoc-dwuilh"
    secrets_name = "blablafish/client_id_spoc"
    try:
        secretsmanager = boto3.client("secretsmanager")
        secrets = secretsmanager.get_secret_value(
            SecretId=secrets_name).get("SecretString")
        client_id = json.loads(secrets)["client_id"]
        client_secret = json.loads(secrets)["client_secret"]
        assert client_id, print(f"could not get client_id")
        assert client_secret, print(f"could not get client_secret")
        client_id = client_id
        client_secret = client_secret
        return client_id, client_secret
    except Exception as e:
        logging.error(
            f"Exception while getting client credentials from secretsmanager:")
        logging.error(e)
        sys.exit(1)

def get_access_token(environment, spoc_aws_region, spoc_account_id, client_id, client_secret):
    cognito_url = f"https://status-api-live-{spoc_account_id}.auth.{spoc_aws_region}.amazoncognito.com/token"
    # get an Oauth token for the API endpoints call
    print("Getting access token ...")
    try:
        url = cognito_url
        token_request = requests.post(
            url=url,
            data={
                "grant_type": "client_credentials",
                "client_id": {client_id},
                "client_secret": {client_secret},
                "audience": "team-ec/OTTO",
            }
        )
        if not (200 >= token_request.status_code < 300):
            print(
                f"can't get access token: {token_request.status_code}")
            print(token_request.text)
            return None
        token_result = token_request.json()["access_token"]
        access_token = token_result
        return token_result
    except Exception as e:
        print("error" +e)
        logging.error(f"Exception while getting access token from cognito:")
        logging.error(e)
        sys.exit(1)

def send_message_dlq(endpoint, queue, environment):
    # send a message to the teams channel though webhook
    print(f"Sending alarm to webhook  {queue} environment {environment}  ...")
    data = {
         "title": "Red Alert - There is an issue with %s" % queue,
         "text": "**%s** has mesages in  environment %s " % (queue, environment)
    }
    message = {
         "@context": "https://schema.org/extensions",
         "@type": "MessageCard",
         "title": data["title"],
         "text": data["text"]
    }
    req = Request(endpoint, json.dumps(message).encode('utf-8'))
    print(req)
    try:
        result = urlopen(req)
        response.read()
        print("Message posted")
    except Exception as e:
        print("Exception while sending the message to the teams:")
        print(e)
        #sys.exit(1)

def send_message(endpoint, json_dict,access_token,year):
    client_key_filename = f"status-api-client-{year}.key.pem"
    client_cert_filename = f"status-api-client-{year}.crt.pem"
    dest_dir = "/tmp"

    if not os.path.isfile(f"{dest_dir}/{client_cert_filename}"):
        last_year = str(date.today().year - 1)
        client_key_filename = f"status-api-client-{last_year}.key.pem"
        client_cert_filename = f"status-api-client-{last_year}.crt.pem"

    hostname = f"https://status-api.live.spoc.cloud.otto.de"
    # send a message to the spoc status API
    print(f"Sending message to API {endpoint} ...")

    if not access_token:
        raise Exception(f"Access token is empty!")
    cert_option = (f"{dest_dir}/{client_cert_filename}",
                   f"{dest_dir}/{client_key_filename}")

    try:
        result = requests.post(
            url=f"{hostname}{endpoint}",
            cert=cert_option,
            headers={"Authorization": f"Bearer {access_token}"},
            json=json_dict
        )
        print(f"API response: {str(result)}")
        if not (200 >= result.status_code < 300):
            print(
                f"can't post to {endpoint} to update: {result.status_code}")
            print(result.text)
        return result
    except Exception as e:
        print("Exception while sending the message to the API:")
        print(e)
        sys.exit(1)