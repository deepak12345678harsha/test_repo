#!/bin/bash
set -eu -o pipefail

if [[ $# -eq 0 ]] ; then
  echo "please pass environment  and account_id as argument : drdevelop/drlive <dr_account_id>"
  echo "./disaster-recovery.sh <drdevelop/drlive> <dr_account_id>"
  exit 0
fi

SCRIPT_DIR="$(cd "$(dirname "$0")" ; pwd -P)"

destination_environment=$1
dr_account_id=$2
echo $destination_environment
if [ $destination_environment == "drdevelop" ]
then
        source_environment="develop"
        account_id="353449567674"
else
        source_environment="live"
        account_id="213876567008"
fi

echo " Creating  $destination_environment tfvars in pipline-role "
cp $SCRIPT_DIR/terraform/10_pipeline_role/${source_environment}.tfvars $SCRIPT_DIR/terraform/10_pipeline_role/${destination_environment}.tfvars
sed -i '' "s/${account_id}/${dr_account_id}/g"   $SCRIPT_DIR/terraform/10_pipeline_role/${destination_environment}.tfvars
sed -i '' "s/${source_environment}/${destination_environment}/g"   $SCRIPT_DIR/terraform/10_pipeline_role/${destination_environment}.tfvars

echo " Creating $destination_environment tfvars in resources "
cp $SCRIPT_DIR/terraform/20_resources/${source_environment}.tfvars $SCRIPT_DIR/terraform/20_resources/${destination_environment}.tfvars
sed -i '' "s/${account_id}/${dr_account_id}/g"   $SCRIPT_DIR/terraform/20_resources/${destination_environment}.tfvars
sed -i '' "s/${source_environment}/${destination_environment}/g"   $SCRIPT_DIR/terraform/20_resources/${destination_environment}.tfvars

echo " Creating $destination_environment tfvars in terraform/30_logging_resource/ "
cp $SCRIPT_DIR/terraform/30_logging_resource/${source_environment}.tfvars $SCRIPT_DIR/terraform/30_logging_resource/${destination_environment}.tfvars
sed -i '' "s/${account_id}/${dr_account_id}/g"   $SCRIPT_DIR/terraform/30_logging_resource/${destination_environment}.tfvars
sed -i '' "s/${source_environment}/${destination_environment}/g"   $SCRIPT_DIR/terraform/30_logging_resource/${destination_environment}.tfvars

echo " Creating $destination_environment tfvars in terraform/31_logging_service/ "
cp $SCRIPT_DIR/terraform/31_logging_service/${source_environment}.tfvars $SCRIPT_DIR/terraform/31_logging_service/${destination_environment}.tfvars
sed -i '' "s/${account_id}/${dr_account_id}/g"   $SCRIPT_DIR/terraform/31_logging_service/${destination_environment}.tfvars
sed -i '' "s/${source_environment}/${destination_environment}/g"   $SCRIPT_DIR/terraform/31_logging_service/${destination_environment}.tfvars
