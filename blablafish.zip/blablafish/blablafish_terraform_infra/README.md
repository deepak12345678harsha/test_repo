# blablafish_terraform_infra
Provisioning the required infrastructure components for blablafish services

# To perform terraform deployment
````
* saml2aws login -a saml --region=eu-central-1
* eval $(saml2aws -a saml script --shell=bash)
* ./ci/init.sh deploy [folder] [env] [plan|apply|destroy] 
````
# blablafish_Infra_pipipeline
Deploy Infra pipeline role from local in develop/live environment.

Needs to run pipeline role creation from local only (not though pipeline)
````
./ci/init.sh deploy terraform/10_pipeline_role <develop/live> apply
````
## To run terraform on local:
````
./ci/init.sh deploy terraform/20_vpc develop apply
````
## Terraform static code analysis
````
./ci/init.sh tfsec
````
## Format terraform code
````
./ci/init.sh format
````