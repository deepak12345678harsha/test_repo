#!/bin/bash

bold=$(tput bold)
normal=$(tput sgr0)


OS=$(uname -s | tr '[:upper:]' '[:lower:]')
AWS_NUKE_VERSION=v2.16.0
echo "### Installing AWS Nuke ###"
curl -fL -o /tmp/aws-nuke.tar.gz "https://github.com/rebuy-de/aws-nuke/releases/download/${AWS_NUKE_VERSION}/aws-nuke-${AWS_NUKE_VERSION}-${OS}-amd64.tar.gz"
tar -xzf /tmp/aws-nuke.tar.gz -C /tmp
mv "/tmp/aws-nuke-${AWS_NUKE_VERSION}-${OS}-amd64" "/usr/local/bin/aws-nuke"

_cleanup() {


    echo "${bold}Nuking  Account${normal}"
    aws-nuke -c aws-nuke.yml --no-dry-run

}

_cleanup "$@"