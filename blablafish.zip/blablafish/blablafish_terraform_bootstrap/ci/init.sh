#!/bin/bash
set -eu -o pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" ; pwd -P)"

_ensure_tfenv() {
  if ! type tfenv &> /dev/null ; then
    echo "Please install tfenv!" 1>&2
    exit 1
  fi
  if ! tfenv exec --version &> /dev/null; then
    echo "Please install required terraform version via tfenv!"
    exit 1
  fi
}

_deploy() {
  _ensure_tfenv

  export SCRIPT_DIR="$(cd "$(dirname "$0")" ; pwd -P)"

  local deployment="${2}"
  local environment="${3}"
  shift
  shift
  shift
  pushd "${SCRIPT_DIR}/../${deployment}/" > /dev/null
    tfenv list
    tfenv exec init
    tfenv exec workspace select "${environment}" || tfenv exec workspace new "${environment}"
    tfenv exec $@ -var-file="${environment}.tfvars" -input=false

  popd > /dev/null
}
_tfsec() {
  if ! tfsec --version &> /dev/null; then
    echo "Please install tfsec using \"brew install tfsec\""
    exit 1
  fi

  tfsec .
}

_format() {
  _ensure_tfenv
  tfenv exec fmt -recursive
}

usage() {
  cat <<EOF
Usage: Before running the script, Assume the AWS-ADM role of corresponding account.
Export aws access key and secret eval $(saml2aws -a <saml_profile_name> script --shell=bash)
commands:
  deploy [folder] [env] [play|apply]              runs terraform
  tfsec                                           runs terraform static code analysis
  format                                          Formats tf code
EOF
  exit 1
}

CMD=${1:-}
case ${CMD} in
  deploy) _deploy "$@";;
  tfsec)  _tfsec ;;
  format) _format;;
  *) usage ;;
esac