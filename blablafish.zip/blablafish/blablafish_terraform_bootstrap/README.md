# blablafish_terraform_bootstrap
Provisioning the required initial AWS resources (terraform state bucket/dynamodb for state lock/etc.) in the infra account.
This won't run in pipeline because this is the first step towards infra creation.
This needs to run manually from the local machine.

## Prerequisites
- AWS-ADM role must be assigned to you in the respective account (Can be requested in IT Shop)
- Local machine setup with SAML for AWS authentication. Please refer to https://github.com/otto-ec/aquanar_starter/blob/main/saml-auth.md

## Running

- Base state bucket and dynamo db setup - Only for infra

```
./ci/init.sh deploy terraform/10_terraform_s3_backend_with_pipeline_role infra apply
```


- DNS setup - all environments

  infra, develop, live, drlive

```
./ci/init.sh deploy terraform/20_dns <develop/live> apply
```

## Initial run

If we are running this for the first time
then we will not have the terraform S3 backend setup by then.
Hence, We need to have the local state and then push the state to S3 backend.

- Comment out the `backend.tf` and run base_infra_setup/backend_setup
- Uncomment and run it again. Enter `yes` when it asks to push the state to S3 bucket
- Base_accounts_setup and base_infra_setup/pipeline_user can be run normally after this.


## Terraform static code analysis
````
./ci/init.sh tfsec
````

## Format terraform code
````
./ci/init.sh format
````

## Backup and restore state bucket
backup

- Tag your bucket with "backMyBitsUp", Value "on" to activate the replication.

- Tag your bucket with "backMyBitsUp", Value "off" to deactivate the replication.

https://confluence.otto.de/pages/viewpage.action?pageId=431464915


for restoring:

- Login to  infra  account you want to restore to, then use s3 sync or s3 cp with the replication target as source.

- click on the bucket, then managemenet, then replication, there is also the link to the destination bucket. you can access it from any of your acounts

Issue and fixes
git 
Example : Error: operation error STS: AssumeRole, https response error StatusCode: 403, RequestID: 2193886d-b385-4b6d-918e-502aaec6d9da, api error AccessDenied: User: arn:aws:sts::***:assumed-role/infra_oidc_pipeline_role/GitHubActions is not authorized to perform: sts:AssumeRole on resource: arn:aws:iam::353449567674:role/infra_pipeline_role
Ref: https://acloudguru.com/blog/engineering/fixing-5-common-aws-iam-errors
