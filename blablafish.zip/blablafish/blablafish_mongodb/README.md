# blablafish_mongodb
Obtain API key from Atlas: Project Access Manager -> Create API Key

set env variables: export MONGODB_ATLAS_PUBLIC_KEY=xxx export MONGODB_ATLAS_PRIVATE_KEY=xxx

for nonlive: saml2aws -a nonlive exec "./ci/init.sh resources nonlive"

for live: saml2aws -a live exec "./ci/init.sh resources live"

#Mongo Db Local SetUp

Install Robo 3T

Get The Connection String From MongoDb Atlas

-Select BlaBla Fish Dev Project.

-Go To Connect in Databases.

-Choose Connection Type as Standard Connection.

-Choose a Connection Method as MongoDb Compass for any of the mongodb client.

-Provide Temporary Public Ip Address access for testing purpose only by adding your public IP address in IP access list under Network option.

-In Robo 3T Choose Connect.

-Connect From URI and Provide the connection String.